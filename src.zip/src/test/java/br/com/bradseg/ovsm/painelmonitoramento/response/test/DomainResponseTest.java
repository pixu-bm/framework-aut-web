package br.com.bradseg.ovsm.painelmonitoramento.response.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.CentralAcessoUsuarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ListaConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ParametroEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.RelacionadoDetalheEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.GraficoDetalheEventoResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class DomainResponseTest {

    /**
     * Teste testeException
     *
     * @throws Exception
     */
    @Test
    void testeCentralAcessoUsuarioResponse() throws Exception {
        try {

            CentralAcessoUsuarioResponse response = new CentralAcessoUsuarioResponse();
            response.setDataSolicitacao("10/10/2021");
            response.setDepartamento("TI");
            response.setLogin("M232521");
            response.setNome("Pedro");
            response.setNomeEmpresa("BS");
            response.setPerfil("ADM");
            response.setStatus("APROV");

            Assert.notNull(response, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeException
     *
     * @throws Exception
     */
    @Test
    void testeEmpresaPainelMonitoramentoAtual() throws Exception {
        try {

            EmpresaPainelMonitoramentoAtual response = new EmpresaPainelMonitoramentoAtual();
            response.setCodigoEmpresa(new BigDecimal(1));
            BigDecimal bd = response.getCodigoEmpresa();
            response.setDescricaoEmpresa("BS");
            String descricao = response.getDescricaoEmpresa();

            response.setDataInclusaoRegistro(new Date());
            Date dateTeste = response.getDataInclusaoRegistro();

            response.setDataAlteracaoRegistro(new Date());
            dateTeste = response.getDataAlteracaoRegistro();
            
            List<ProdutoPainelMonitoramentoAtual> lista = response.getListaProduto();

            Assert.isTrue(response != null && bd != null && descricao != null && dateTeste != null && lista != null ,
                "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeException
     *
     * @throws Exception
     */
    @Test
    void testeEmpresaPainelMonitoramentoAtualDataNull() throws Exception {
        try {

            EmpresaPainelMonitoramentoAtual response = new EmpresaPainelMonitoramentoAtual();

            Date dateTeste = response.getDataInclusaoRegistro();
            dateTeste = response.getDataAlteracaoRegistro();

            Assert.isNull(dateTeste, "Deve ser Nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtual
     *
     * @throws Exception
     */
    @Test
    void testeCanalPainelMonitoramentoAtual() throws Exception {

        try {

            CanalPainelMonitoramentoAtual response = new CanalPainelMonitoramentoAtual();
            response.setCodigoCanal(new BigDecimal(1));
            BigDecimal bd = response.getCodigoCanal();
            response.setDescricaoCanal("MOBILE");
            String descricao = response.getDescricaoCanal();
            List<EventoPainelMonitoramentoAtual> listaTeste = new ArrayList<>();
            listaTeste.add(new EventoPainelMonitoramentoAtual());
            response.setListaEvento(listaTeste);

            response.setDataAlteracaoRegistro(new Date());
            Date dateTeste = response.getDataAlteracaoRegistro();

            response.setDataInicioRegitro(new Date());
            dateTeste = response.getDataInicioRegitro();

            List<EventoPainelMonitoramentoAtual> listaTesteResponse = response.getListaEvento();

            Assert.isTrue(
                response != null && bd != null && descricao != null && dateTeste != null && listaTesteResponse != null,
                "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtual
     *
     * @throws Exception
     */
    @Test
    void testeCanalPainelMonitoramentoAtualNull() throws Exception {

        try {

            CanalPainelMonitoramentoAtual response = new CanalPainelMonitoramentoAtual();

            Date dateTeste = response.getDataAlteracaoRegistro();
            dateTeste = response.getDataInicioRegitro();

            Assert.isNull(dateTeste, "Deve ser Nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtual
     *
     * @throws Exception
     */
    @Test
    void testeProdutoPainelMonitoramentoAtual() throws Exception {

        try {

            ProdutoPainelMonitoramentoAtual response = new ProdutoPainelMonitoramentoAtual();
            response.setCodigoProduto(new BigDecimal(1));
            BigDecimal bd = response.getCodigoProduto();
            response.setDescricaoProduto("MOBILE");
            String descricao = response.getDescricaoProduto();

            response.setDataAlteracaoRegistro(new Date());
            Date dateTeste = response.getDataAlteracaoRegistro();

            response.setDataInclusaoRegistro(new Date());
            dateTeste = response.getDataInclusaoRegistro();

            Assert.isTrue(response != null && bd != null && descricao != null && dateTeste != null,
                "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtualConstrutorNaoVazioVerdadeiro
     *
     * @throws Exception
     */
    @Test
    void testeCanalPainelMonitoramentoAtualConstrutorNaoVazioVerdadeiro() throws Exception {

        try {

            List<BigDecimal> fake = new ArrayList<BigDecimal>();
            fake.add(new BigDecimal(1));
            ProdutoPainelMonitoramentoAtual response = new ProdutoPainelMonitoramentoAtual(new BigDecimal(1), fake);

            Assert.notNull(response, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtualConstrutorNaoVazioFalso
     *
     * @throws Exception
     */
    @Test
    void testeCanalPainelMonitoramentoAtualConstrutorNaoVazioFalso() throws Exception {

        try {

            ProdutoPainelMonitoramentoAtual response = new ProdutoPainelMonitoramentoAtual(null, null);

            Assert.notNull(response, "Deve ser Nulo");
            ;

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtual
     *
     * @throws Exception
     */
    @Test
    void testeVisaoEvento() throws Exception {

        try {

            VisaoEvento response = new VisaoEvento();
            response.setQuantidadeEventosVolumetria(1);
            Integer quantidade = response.getQuantidadeEventosVolumetria();
            response.setPorcentagemEventosVolumetria(2);
            quantidade = response.getPorcentagemEventosVolumetria();

            response.setQuantidadeEventosDisponibilidade(2);
            ;
            quantidade = response.getQuantidadeEventosDisponibilidade();

            response.setQuantidadeEventosDisponibilidade(2);
            quantidade = response.getQuantidadeEventosDisponibilidade();

            response.setPorcentagemEventosDisponibilidade(2);
            quantidade = response.getPorcentagemEventosDisponibilidade();

            response.setQuantidadeEventosFuncionalidade(2);
            quantidade = response.getQuantidadeEventosDisponibilidade();

            response.setPorcentagemEventosFuncionalidade(2);
            quantidade = response.getPorcentagemEventosFuncionalidade();

            response.setQuantidadeTotalEventos(2);
            quantidade = response.getQuantidadeTotalEventos();

            Assert.notNull(quantidade, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeCanalPainelMonitoramentoAtual
     *
     * @throws Exception
     */
    @Test
    void EmpresaUsuario() throws Exception {

        try {

            EmpresaUsuario response = new EmpresaUsuario("BS", "BRADESCO");

            response.setCodigoEmpresa("BS");
            ;
            String codigo = response.getCodigoEmpresa();

            response.setDescricaoEmpresa("Bradesco");
            ;
            String descricao = response.getDescricaoEmpresa();

            Assert.notNull(codigo != null && descricao != null, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste VolumetriaTempoReal
     *
     * @throws Exception
     */
    @Test
    void VolumetriaTempoReal() throws Exception {

        try {
            VolumetriaTempoReal volume = new VolumetriaTempoReal();
            volume.setVolumetriaAtualTransacao(new BigDecimal(1));
            volume.setHoraOcorrencia("20:20");
            volume.setTransacaoEvento(new BigDecimal(2));
            volume.setTransacaoSemEvento(new BigDecimal(2));
            volume.setCodigoProduto(new BigDecimal(2));
            volume.setCodigoCanal(new BigDecimal(2));
            volume.setCodigoEmpresa(new BigDecimal(1));
            volume.setMediaHistoricaTransacao(new BigDecimal(2));

            Integer quantidade = volume.getVolumetriaAtualTransacao().intValue();
            quantidade = volume.getTransacaoEvento().intValue();
            quantidade = volume.getCodigoProduto().intValue();
            quantidade = volume.getCodigoCanal().intValue();
            quantidade = volume.getCodigoEmpresa().intValue();
            quantidade = volume.getTransacaoSemEvento().intValue();
            quantidade = volume.getMediaHistoricaTransacao().intValue();

            String hora = volume.getHoraOcorrencia();

            Assert.notNull(quantidade, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void SituacaoEvento() throws Exception {

        try {
            SituacaoEvento situacao = new SituacaoEvento();
            situacao.setCodigo(new BigDecimal(1));
            situacao.setDescricao("Teste");
            Integer quantidade = situacao.getCodigo().intValue();

            Assert.notNull(quantidade, "não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste VolumetriaTempoReal
     *
     * @throws Exception
     */
    @Test
    void RelacaoCanalProduto() throws Exception {

        try {
            RelacaoCanalProduto relacao = new RelacaoCanalProduto();
            relacao.setCodigoCanal(new BigDecimal(3));
            relacao.setDescricaoCanal("Teste");
            relacao.setEventoGrave(1);
            relacao.setEventoModerado(1);
            relacao.setTransacaoImpactada(3);

            Integer quantidade = relacao.getCodigoCanal().intValue();
            quantidade = relacao.getEventoGrave();
            quantidade = relacao.getEventoModerado();
            quantidade = relacao.getTransacaoImpactada();

            Assert.notNull(quantidade, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void RelacaoProdutoCanal() throws Exception {

        try {
            RelacaoProdutoCanal relacao = new RelacaoProdutoCanal();
            relacao.setCodigoProduto(new BigDecimal(3));
            relacao.setDescricaoProduto("Teste");
            relacao.setEventoGrave(1);
            relacao.setEventoModerado(1);
            relacao.setTransacaoImpactada(3);

            Integer quantidade = relacao.getCodigoProduto().intValue();
            quantidade = relacao.getEventoGrave();
            quantidade = relacao.getEventoModerado();
            quantidade = relacao.getTransacaoImpactada();

            Assert.notNull(quantidade, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void VisaoGeralCanal() throws Exception {

        try {
            VisaoGeralCanal visao = new VisaoGeralCanal();

            visao.setCodigoCanal(new BigDecimal(3));
            visao.setDescricaoCanal("Teste");
            visao.setEventoGrave(1);
            visao.setEventoModerado(1);
            visao.setNumeroImpacto(3);
            visao.setEventoDisponibilidade(1);
            visao.setEventoFuncional(4);
            visao.setEventoVolumetria(2);
            visao.setListaRelacaoProdutoCanal(new ArrayList<>());

            Integer quantidade = visao.getCodigoCanal().intValue();
            quantidade = visao.getEventoGrave();
            quantidade = visao.getEventoModerado();
            quantidade = visao.getNumeroImpacto();
            quantidade = visao.getEventoDisponibilidade();
            quantidade = visao.getEventoFuncional();
            quantidade = visao.getEventoVolumetria();

            Assert.notNull(quantidade, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ConfiguracaoIntervaloProcessamentoResponse() throws Exception {

        try {
            ConfiguracaoIntervaloProcessamentoResponse configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamentoResponse();

            configuracaoIntervaloProcessamento.setCodigoCanal(new BigDecimal(3));
            configuracaoIntervaloProcessamento.setDescricaoCanal("Teste");
            configuracaoIntervaloProcessamento.setCodigoEmpresa(new BigDecimal(1));
            configuracaoIntervaloProcessamento.setCodigoProduto(new BigDecimal(2));
            configuracaoIntervaloProcessamento.setDataVigenciaFinal("10/10/2021");
            configuracaoIntervaloProcessamento.setDataVigenciaInicio("11/09/2021");
            configuracaoIntervaloProcessamento.setDescricaoCanal("teste");
            configuracaoIntervaloProcessamento.setDescricaoProduto("teste");
            configuracaoIntervaloProcessamento.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamento.setQuantidadeMinutoIntervaloNormal(20);
            configuracaoIntervaloProcessamento.setQuantidadeMinutoIntervaloErro(12);

            configuracaoIntervaloProcessamento.getCodigoCanal();
            configuracaoIntervaloProcessamento.getDescricaoCanal();
            configuracaoIntervaloProcessamento.getCodigoEmpresa();
            configuracaoIntervaloProcessamento.getCodigoProduto();
            configuracaoIntervaloProcessamento.getDataVigenciaFinal();
            configuracaoIntervaloProcessamento.getDataVigenciaInicio();
            configuracaoIntervaloProcessamento.getDescricaoCanal();
            configuracaoIntervaloProcessamento.getDescricaoProduto();
            configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloNormal();
            configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloNormal();
            configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloErro();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ListaConfiguracaoIntervaloProcessamentoResponse() throws Exception {

        try {
            ListaConfiguracaoIntervaloProcessamentoResponse listaConfiguracaoIntervaloProcessamentoResponse = new ListaConfiguracaoIntervaloProcessamentoResponse();

            listaConfiguracaoIntervaloProcessamentoResponse.setListaConfiguracaoIntervalo(new ArrayList<>());

            listaConfiguracaoIntervaloProcessamentoResponse.getListaConfiguracaoIntervalo();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ParametroEvento() throws Exception {

        try {
            ParametroEvento parametroEvento = new ParametroEvento();

            parametroEvento.setQuantidadeTransacaoOnline(1);
            parametroEvento.setQuantidadeTransacaoOffline(1);
            parametroEvento.setQuantidadeMinimaEventoModerado(1);
            parametroEvento.setQuantidadeMaximaEventoModerado(1);
            parametroEvento.setQuantidadeMinimaEventoAlto(1);
            parametroEvento.setQuantidadeMaximaEventoAlto(1);
            parametroEvento.setQuantidadeMinimaEventoVolumeModerado(1);
            parametroEvento.setQuantidadeMaximaEventoVolumeModerado(1);
            parametroEvento.setQuantidadeMinimaEventoVolumeAlto(1);
            parametroEvento.setQuantidadeMaximaEventoVolumeAlto(1);
            parametroEvento.setQuantidadeLimiteEventoVolumeBemBaixo(1);
            parametroEvento.setQuantidadeMetricaEventoVolume(1);
            parametroEvento.setQuantidadeLimiteEventoFuncionalidadeBemBaixo(1);
            parametroEvento.setQuantidadeMetricaEventoFuncionalidade(1);
            parametroEvento.setQuantidadeLimiteEventoImpactoBemBaixo(1);

            parametroEvento.getQuantidadeTransacaoOnline();
            parametroEvento.getQuantidadeTransacaoOffline();
            parametroEvento.getQuantidadeMinimaEventoModerado();
            parametroEvento.getQuantidadeMaximaEventoModerado();
            parametroEvento.getQuantidadeMinimaEventoAlto();
            parametroEvento.getQuantidadeMaximaEventoAlto();
            parametroEvento.getQuantidadeMinimaEventoVolumeModerado();
            parametroEvento.getQuantidadeMaximaEventoVolumeModerado();
            parametroEvento.getQuantidadeMinimaEventoVolumeAlto();
            parametroEvento.getQuantidadeMaximaEventoVolumeAlto();
            parametroEvento.getQuantidadeLimiteEventoVolumeBemBaixo();
            parametroEvento.getQuantidadeMetricaEventoVolume();
            parametroEvento.getQuantidadeLimiteEventoFuncionalidadeBemBaixo();
            parametroEvento.getQuantidadeMetricaEventoFuncionalidade();
            parametroEvento.getQuantidadeLimiteEventoImpactoBemBaixo();
            parametroEvento.getQuantidadeMetricaEventoImpacto();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ParametroEventoResponse() throws Exception {

        try {
            ParametroEventoResponse parametroEventoResponse = new ParametroEventoResponse();

            ParametroEvento parametroEvento = new ParametroEvento();

            parametroEventoResponse.setParametroEvento(parametroEvento);
            parametroEventoResponse.getParametroEvento();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void VisaoGeralProduto() throws Exception {

        try {
            VisaoGeralProduto visaoGeralProduto = new VisaoGeralProduto();

            visaoGeralProduto.setCodigoProduto(new BigDecimal(1));
            visaoGeralProduto.setDescricaoProduto("teste");
            visaoGeralProduto.setEventoGrave(1);
            visaoGeralProduto.setEventoModerado(1);
            visaoGeralProduto.setNumeroImpacto(1);
            visaoGeralProduto.setEventoDisponibilidade(1);
            visaoGeralProduto.setEventoFuncional(1);
            visaoGeralProduto.setEventoVolumetria(1);
            visaoGeralProduto.setListaRelacaoCanalProduto(new ArrayList<>());

            visaoGeralProduto.getCodigoProduto();
            visaoGeralProduto.getDescricaoProduto();
            visaoGeralProduto.getEventoGrave();
            visaoGeralProduto.getEventoModerado();
            visaoGeralProduto.getNumeroImpacto();
            visaoGeralProduto.getEventoDisponibilidade();
            visaoGeralProduto.getEventoFuncional();
            visaoGeralProduto.getEventoVolumetria();
            visaoGeralProduto.getListaRelacaoCanalProduto();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ConfiguracaoIntervaloProcessamento() throws Exception {

        try {
            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento();

            configuracaoIntervaloProcessamento.setNumeroInternoConfiguracaoIntervalo(new BigDecimal(1));
            configuracaoIntervaloProcessamento.setLogin("teste");
            configuracaoIntervaloProcessamento.setCodigoEmpresa(new BigDecimal(1));
            configuracaoIntervaloProcessamento.setDataVigenciaFinal(new Date());
            configuracaoIntervaloProcessamento.setQuantidadeMinutoIntervaloNormal(1);
            configuracaoIntervaloProcessamento.setQuantidadeMinutoIntervaloErro(1);
            configuracaoIntervaloProcessamento.setCodigoProduto(new BigDecimal(1));
            configuracaoIntervaloProcessamento.setDataVigenciaInicio(new Date());
            configuracaoIntervaloProcessamento.setCodigoCanal(new BigDecimal(1));

            configuracaoIntervaloProcessamento.getNumeroInternoConfiguracaoIntervalo();
            configuracaoIntervaloProcessamento.getLogin();
            configuracaoIntervaloProcessamento.getCodigoEmpresa();
            configuracaoIntervaloProcessamento.getDataVigenciaFinal();
            configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloNormal();
            configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloErro();
            configuracaoIntervaloProcessamento.getCodigoProduto();
            configuracaoIntervaloProcessamento.getDataVigenciaInicio();
            configuracaoIntervaloProcessamento.getCodigoCanal();

            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();

            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(1));
            configuracaoIntervaloProcessamentoRequest.setLogin("teste");
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(1));
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(1);
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("Teste");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(1);

            configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento(
                configuracaoIntervaloProcessamentoRequest);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void ConfiguracaoIntervaloProcessamentoDataNull() throws Exception {

        try {
            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento();

            Date data = configuracaoIntervaloProcessamento.getDataVigenciaFinal();
            data = configuracaoIntervaloProcessamento.getDataVigenciaInicio();

            Assert.isNull(data, "Deve ser Nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void RelaciondosDetalheEvento() throws Exception {

        try {
            RelaciondosDetalheEvento relacionados = new RelaciondosDetalheEvento();
            relacionados.setLinha(new BigDecimal(2));
            relacionados.getLinha();
            relacionados.setCod(new BigDecimal(3));
            relacionados.getCod();
            relacionados.setClientes(new BigDecimal(2));
            relacionados.getClientes();
            relacionados.setDuracao("222");
            relacionados.getDuracao();
            relacionados.setProduto("BARE");
            relacionados.getProduto();
            relacionados.setTipo("XXX");
            relacionados.getTipo();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void GraficoDetalheEventoResponseS() throws Exception {

        try {
          GraficoDetalheEventoResponse grafico = new GraficoDetalheEventoResponse();
          grafico.setCodigoRetorno(1);
          grafico.setGraficoDetalheEvento(new ArrayList<>());
          grafico.getGraficoDetalheEvento();
           

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void RelacionadoDetalheEventoResponseS() throws Exception {

        try {
          RelacionadoDetalheEventoResponse grafico = new RelacionadoDetalheEventoResponse();
          grafico.setCodigoRetorno(1);
          grafico.setListaDetalheEventoRelacionados(new ArrayList<RelaciondosDetalheEvento>());
          grafico.getListaDetalheEventoRelacionados();
          grafico.setTotalItensRelacionados(3);
          grafico.getTotalItensRelacionados();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
