package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.CanalServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class CanalServiceTest {

    @Mock
    private Utils utils;
    @Mock
    private CanalDao canalDao;
    @InjectMocks
    private CanalServiceImpl canalServiceImpl;

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterCanal() throws Exception {
        try {
            List<Canal> lista = new ArrayList<>();
            lista.add(new Canal());

            when(canalDao.listarCanal()).thenReturn(lista);

            List<Canal> result = canalServiceImpl.obterCanais();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterCanalEmptyResultDataAccessException() throws Exception {
        try {
            List<Canal> lista = new ArrayList<>();
            lista.add(new Canal());

            doThrow(EmptyResultDataAccessException.class).when(canalDao).listarCanal();
            // when(canalDao.listarCanal()).thenReturn(lista);

            List<Canal> result = canalServiceImpl.obterCanais();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterCanalException() throws Exception {
        try {
            List<Canal> lista = new ArrayList<>();
            lista.add(new Canal());

            doThrow(new RuntimeException()).when(canalDao).listarCanal();
            // when(canalDao.listarCanal()).thenReturn(lista);

            List<Canal> result = canalServiceImpl.obterCanais();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
