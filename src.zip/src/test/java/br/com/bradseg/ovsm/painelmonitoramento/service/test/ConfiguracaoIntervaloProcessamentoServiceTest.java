package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConfiguracaoIntervaloProcessamentoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.ConfiguracaoIntervaloProcessamentoServiceImpl;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConfiguracaoIntervaloProcessamentoServiceTest {

    @Mock
    private ConfiguracaoIntervaloProcessamentoDao configuracaoIntervaloProcessamentoDao;
    @Mock
    private LoginDao loginDao;
    @InjectMocks
    private ConfiguracaoIntervaloProcessamentoServiceImpl configuracaoIntervaloProcessamentoServiceImpl;

    @Test
    void listarConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            List<ConfiguracaoIntervaloProcessamentoResponse> lista = new ArrayList<>();
            ConfiguracaoIntervaloProcessamentoResponse configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamentoResponse();
            configuracaoIntervaloProcessamento.setCodigoCanal(new BigDecimal(2));
            lista.add(configuracaoIntervaloProcessamento);

            when(configuracaoIntervaloProcessamentoDao.obterConfiguracaoIntervaloProcessamento(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(configuracaoIntervaloProcessamento);

            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoServiceImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1), new BigDecimal(2), new BigDecimal(3));

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void listarConfiguracaoIntervaloProcessamentoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(configuracaoIntervaloProcessamentoDao)
                .obterConfiguracaoIntervaloProcessamento(Mockito.any(), Mockito.any(),
                    Mockito.any());
            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoServiceImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1),
                    new BigDecimal(2), new BigDecimal(3));

            Assert.notNull(result, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void listarConfiguracaoIntervaloProcessamentoException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(configuracaoIntervaloProcessamentoDao)
                .obterConfiguracaoIntervaloProcessamento(Mockito.any(), Mockito.any(), Mockito.any());
            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoServiceImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1),
                    new BigDecimal(2), new BigDecimal(4));

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validarParametroConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(2));
            configuracaoIntervaloProcessamentoRequest.setCodigoProduto(new BigDecimal(4));
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("10/10/2021");
            configuracaoIntervaloProcessamentoRequest.setLogin("M232640");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(20);

            configuracaoIntervaloProcessamentoServiceImpl
                .validarParametroConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamentoRequest);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(2));
            configuracaoIntervaloProcessamentoRequest.setCodigoProduto(new BigDecimal(4));
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("10/10/2021");
            configuracaoIntervaloProcessamentoRequest.setLogin("M232640");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(20);

            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento(
                configuracaoIntervaloProcessamentoRequest);

            Usuario usuario = new Usuario();
            usuario.setNumeroInternoUsuario(new BigDecimal(1));

            when(loginDao.obterInformacaoUsuario(Mockito.any(Usuario.class))).thenReturn(usuario);
            when(configuracaoIntervaloProcessamentoDao
                .verificarConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamento)).thenReturn(true);
            configuracaoIntervaloProcessamentoServiceImpl
                .inserirConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamento);

            when(configuracaoIntervaloProcessamentoDao
                .verificarConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamento)).thenReturn(false);
            configuracaoIntervaloProcessamentoServiceImpl
                .inserirConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamento);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamentoException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(2));
            configuracaoIntervaloProcessamentoRequest.setCodigoProduto(new BigDecimal(4));
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("10/10/2021");
            configuracaoIntervaloProcessamentoRequest.setLogin("M232640");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(20);

            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento(
                configuracaoIntervaloProcessamentoRequest);

            Usuario usuario = new Usuario();
            usuario.setNumeroInternoUsuario(new BigDecimal(1));

            when(loginDao.obterInformacaoUsuario(Mockito.any(Usuario.class))).thenReturn(usuario);

            doThrow(AcessoADadosException.class).when(configuracaoIntervaloProcessamentoDao)
                .verificarConfiguracaoIntervaloProcessamento(Mockito.any(ConfiguracaoIntervaloProcessamento.class));
            configuracaoIntervaloProcessamentoServiceImpl
                .inserirConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamento);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validarParametroEvento() throws Exception {
        try {

            ParametroEventoRequest request = new ParametroEventoRequest();
            request.setCodigoEmpresa(new BigDecimal(2));
            request.setCodigoProduto(new BigDecimal(2));
            request.setCodigoCanal(new BigDecimal(2));
            request.setParametroEvento(new ParametroEvento());
            request.getParametroEvento().setQuantidadeTransacaoOnline(1);
            request.getParametroEvento().setQuantidadeTransacaoOffline(2);

            request.getParametroEvento().setQuantidadeMinimaEventoModerado(1);
            request.getParametroEvento().setQuantidadeMaximaEventoModerado(1);

            request.getParametroEvento().setQuantidadeMaximaEventoAlto(2);
            request.getParametroEvento().setQuantidadeMinimaEventoAlto(2);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeModerado(3);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeModerado(3);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeAlto(2);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeAlto(2);

            request.getParametroEvento().setQuantidadeLimiteEventoVolumeBemBaixo(3);
            request.getParametroEvento().setQuantidadeMetricaEventoVolume(1);

            request.getParametroEvento().setQuantidadeLimiteEventoImpactoBemBaixo(1);
            request.getParametroEvento().setQuantidadeMetricaEventoImpacto(1);

            request.getParametroEvento().setQuantidadeLimiteSegundoEventoBemBaixo(1);

            request.getParametroEvento().setQuantidadeSegundoExecucaoEvento(1);

            request.getParametroEvento().setQuantidadeLimiteEventoFuncionalidadeBemBaixo(2);

            request.getParametroEvento().setQuantidadeMetricaEventoFuncionalidade(3);

            configuracaoIntervaloProcessamentoServiceImpl.validarParametroEvento(request);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoTrue() throws Exception {
        try {

            when(configuracaoIntervaloProcessamentoDao.verificarParametroEventoExiste(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

            configuracaoIntervaloProcessamentoServiceImpl.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoFalse() throws Exception {
        try {

            when(configuracaoIntervaloProcessamentoDao.verificarParametroEventoExiste(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Boolean.FALSE);

            configuracaoIntervaloProcessamentoServiceImpl.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoDataViolation() throws Exception {
        try {

            when(configuracaoIntervaloProcessamentoDao.verificarParametroEventoExiste(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

            doThrow(DataIntegrityViolationException.class).when(
                configuracaoIntervaloProcessamentoDao).inserirParametroEvento(Mockito.any());

            configuracaoIntervaloProcessamentoServiceImpl.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoAcessoADadosException() throws Exception {
        try {

            when(configuracaoIntervaloProcessamentoDao.verificarParametroEventoExiste(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Boolean.TRUE);

            doThrow(AcessoADadosException.class).when(
                configuracaoIntervaloProcessamentoDao).inserirParametroEvento(Mockito.any());

            configuracaoIntervaloProcessamentoServiceImpl.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
