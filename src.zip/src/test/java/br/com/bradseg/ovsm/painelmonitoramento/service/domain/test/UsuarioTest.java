package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EmpresaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.EmpresaServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados empresa service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class UsuarioTest {

    @InjectMocks
    private Usuario usuario;

    /**
     * Teste construtorUsuario
     * 
     * @throws Exception
     */
    @Test
    void contrutorUsuario() throws Exception {
        try {
            Usuario usurStatusCancel = new Usuario("Empresa Test", "Departamento Test", 
              "CANCEL", "Nome Test", "MXXXXXXX", "Perfil Test", "01/01/2022");
            Usuario usurStatusNegad = new Usuario("Empresa Test", "Departamento Test", 
              "NEGAD", "Nome Test", "MXXXXXXX", "Perfil Test", "01/01/2022");
            Usuario usurStatusAgard = new Usuario("Empresa Test", "Departamento Test", 
              "AGARD", "Nome Test", "MXXXXXXX", "Perfil Test", "01/01/2022");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void contrutorUsuarioAtualizarStatusPerfilUsuarioRequest() throws Exception {
        try {
          AtualizarStatusPerfilUsuarioRequest attPerfil = new AtualizarStatusPerfilUsuarioRequest();
          attPerfil.setMotivoRecusa("Teste");
            Usuario usur = new Usuario(attPerfil);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void getSetUsuario() throws Exception {
        try {
          Usuario usur = new Usuario();
          usur.setNome(null);
          usur.setMatricula(null);
          usur.setMatricula("MATRICULA");
          usur.setTelefone("999999999");
          usur.setEndereco("Teste");
          usur.setCodigoEmpresa(null);
          usur.setCodigoDepartamento(null);
          usur.getDataSolicitacao();
          usur.setPerfil(null);
          usur.setMotivoRecusa("Teste");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
