package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaVisaoEventoCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ListaVisaoEventoCanalRowMapperTest {

    @InjectMocks
    private ListaVisaoEventoCanalRowMapper listaVisaoEventoCanalRowMapper;

    @Test
    void testeListaVisaoEventoCanalRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CCANAL_DGTAL_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getInt("QNT_TOTAL")).thenReturn(2);
            Mockito.when(resultSetMock.getString("ICANAL_DGTAL_PNEL")).thenReturn("teste");

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<VisaoEventoCanal> visao = listaVisaoEventoCanalRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(visao, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
