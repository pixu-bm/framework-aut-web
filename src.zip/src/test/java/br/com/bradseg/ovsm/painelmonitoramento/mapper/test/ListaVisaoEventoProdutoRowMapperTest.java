package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaVisaoEventoProdutoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ListaVisaoEventoProdutoRowMapperTest {

    @InjectMocks
    private ListaVisaoEventoProdutoRowMapper listaVisaoEventoProdutoRowMapper;

    @Test
    void testeListaRegistroEventoCanalRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CPRODT_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("IPRODT")).thenReturn("teste");
            Mockito.when(resultSetMock.getInt("QNT_TOTAL")).thenReturn(1);

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<VisaoEventoProduto> registro = listaVisaoEventoProdutoRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(registro, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
