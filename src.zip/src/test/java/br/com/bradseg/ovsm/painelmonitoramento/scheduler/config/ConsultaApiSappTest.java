package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiSappDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiSappTest {
    
    @InjectMocks
    private ConsultaApiSapp consultaApiSapp;
    @Mock
    private ConsultaApiSappDao consultaApiSappDao;
    @Mock
    private HttpURLConnection connection;
    
    @Test
    void testeConsultaApiViagem() throws Exception {
        try {
            consultaApiSapp.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiSappDao.obterultimoregistroinseridoSapp()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiSapp.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiSapp.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiSappDao).obterultimoregistroinseridoSapp();
            consultaApiSapp.consultaApi();
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiSapp.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiSappDao).obterultimoregistroinseridoSapp();
            consultaApiSapp.consultaApi();

        } catch (Exception e) {
        }
    }

    @Test
    void testeConsultaSappOk() throws Exception {
        try {
            consultaApiSapp.obterSappNOk("MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",
              LocalDateTime.now(),connection);
            
            consultaApiSapp.obterSappOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSappOkMaximo() throws Exception {
        try {
            consultaApiSapp.obterSappOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiSapp.obterSappNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void testevalidarConexaoSappTemp() throws Exception {
        try{
            LinkedList<TabelaTemp> listaSappTemp = new LinkedList<>();
            TabelaTemp sappTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            sappTemp.setcorrigeDado(850);
            sappTemp.setCindRegProcs("P");
            // Codigo de retorno
            sappTemp.setCerroOrign("teste");
            sappTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            sappTemp.setRenderUrlOrign("endereco");
            sappTemp.setRservcOrign(null);
            sappTemp.setItransOrign("A001");
            sappTemp.setRtransOrign("endereco");
            sappTemp.setIapiOrign("endereco");
            sappTemp.setIcanalOrign("CAP");
            sappTemp.setIemprOrign("CAPI");
            sappTemp.setIprodtOrign("CAPITALIZACAO");
            sappTemp.setIsprodOrign(null);
            sappTemp.setIetapaOfert("TESTE ETAPA");
            sappTemp.setIplatfOrign("API");
            sappTemp.setIsitEvnto("NOK");

            sappTemp.setDinicErro(LocalDateTime.now());
            sappTemp.setDfimErro(null);
            sappTemp.setDinclReg(LocalDateTime.now());
            sappTemp.setDaltReg(null);

            listaSappTemp.add(sappTemp);

            consultaApiSapp.validarConexaoSappTemp(LocalDateTime.now(),connection,"MOBILE",
              "https://svp.dsv"
                + ".bradescoseguros.com"
                + ".br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",
              (LinkedList<TabelaTemp>) listaSappTemp,
              "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv");

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
}
