package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.ProdutoServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ProdutoServiceTest {

    @Mock
    private Utils utils;
    @Mock
    private ProdutoDao produtoDao;
    @InjectMocks
    private ProdutoServiceImpl produtoServiceImpl;

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterProduto() throws Exception {
        try {
            List<Produto> lista = new ArrayList<Produto>();
            lista.add(new Produto());
            when(produtoDao.listarProduto()).thenReturn(lista);
            List<Produto> result = produtoServiceImpl.obterProduto();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterCanaisProduto() throws Exception {
        try {
            Map<String, String> result = produtoServiceImpl.obterCanaisProduto("AUTO");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("VIAGEM");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("SUPERPROTEGIDO");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("CARTAO_DEBITO");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("DENTAL");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("PREVIDENCIA");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("RESIDENCIAL");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("SAPP");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("VIDA");

            Assert.notEmpty(result, "Result não pode ser vazio");

            result = produtoServiceImpl.obterCanaisProduto("CAPITALIZACAO");

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterCanaisProdutoIllegalArgumentException() throws Exception {
        try {
            Map<String, String> result = produtoServiceImpl.obterCanaisProduto("TESTE");

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
