package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.EventoController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EventoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.Mockito.doThrow;

/**
 * Classe implementa test automatizados de EventoDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class EventoControllerTest {

    @Mock
    private EventoService eventoService;
    @InjectMocks
    private EventoController eventoController;

    @Test
    void obterTipoEvento() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = eventoController.obterListaEvento();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(eventoService).obterListaEvento();
            ResponseEntity<ResponseMensagem> result = eventoController.obterListaEvento();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Não pode ser nulo");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEventoAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(eventoService).obterListaEvento();
            ResponseEntity<ResponseMensagem> result = eventoController.obterListaEvento();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Não pode ser nulo");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
