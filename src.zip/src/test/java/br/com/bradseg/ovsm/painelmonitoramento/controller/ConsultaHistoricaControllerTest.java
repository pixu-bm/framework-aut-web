package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.sql.SQLException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.ConsultaHistoricaController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConsultaHistoricaService;

/**
 * Classe implementa test automatizados gestão acesso canal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaControllerTest {

    @Mock
    private ConsultaHistoricaService consultaHistoricaService;
    @InjectMocks
    private ConsultaHistoricaController consultaHistoricaController;

    /**
     * Exportar Excel
     * 
     * @throws Exception
     */
    @Test
    void exportExcel() throws Exception {

        try {

            when(consultaHistoricaService.exportarExcel(Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString()))
                    .thenReturn(new XSSFWorkbook());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterExcelConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportExcelSQLException() throws Exception {

        try {

            doThrow(SQLException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterExcelConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar um internal server error");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportExcelIllegalArgumentException() throws Exception {

        try {

            doThrow(IllegalArgumentException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterExcelConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar um bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void exportExcelEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterExcelConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.NOT_FOUND), "Deve retornar um NOT_FOUND");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Exportar PDF
     * 
     * @throws Exception
     */
    @Test
    void exportPdf() throws Exception {

        try {
            ByteArrayInputStream vlr = new ByteArrayInputStream(new byte[] {1,2});
            when(consultaHistoricaService.exportarPdf(Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString()))
                    .thenReturn(vlr);
            ResponseEntity<InputStreamResource> test = consultaHistoricaController.obterPdfConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

            Assert.notNull(test, "Não deve ser nulo");
        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportPDFSQLException() throws Exception {

        try {

            doThrow(SQLException.class).when(consultaHistoricaService)
                .exportarPdf(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<InputStreamResource> test = consultaHistoricaController.obterPdfConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar um internal server error");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportPDFIllegalArgumentException() throws Exception {

        try {

            doThrow(IllegalArgumentException.class).when(consultaHistoricaService)
                .exportarPdf(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<InputStreamResource> test = consultaHistoricaController.obterPdfConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar um bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportPDFEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaService)
                .exportarPdf(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<InputStreamResource> test = consultaHistoricaController.obterPdfConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.NOT_FOUND), "Deve retornar um not found");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Exportar CSV
     * 
     * @throws Exception
     */
    @Test
    void exportCsv() throws Exception {

        try {

            when(consultaHistoricaService.exportarExcel(Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString()))
                    .thenReturn(new XSSFWorkbook());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterCsvConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportCsvSQLException() throws Exception {

        try {

            doThrow(SQLException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterCsvConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar um internal server error");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportCsvIllegalArgumentException() throws Exception {

        try {

            doThrow(IllegalArgumentException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterCsvConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar um bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportCsvEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaService)
                .exportarExcel(Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString());
            ResponseEntity<StreamingResponseBody> test = consultaHistoricaController.obterCsvConsultaHistorica(
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.NOT_FOUND), "Deve retornar um not found");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

}
