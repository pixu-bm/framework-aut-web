package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.math.BigDecimal;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.TipoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class TipoEventoRowMapperTest {

    @InjectMocks
    private TipoEventoRowMapper tipoEventoRowMapper;

    @Test
    void testeUsuarioRowMapper() throws Exception {
        try {
            
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("SOMA_TOTAL")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("SOMA_DISPONIBILIDADE")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("SOMA_FUNCIONALIDADE")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("SOMA_VOLUMETRIA")).thenReturn(1);

            TipoEvento tipoEventoTest = tipoEventoRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(tipoEventoTest, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
