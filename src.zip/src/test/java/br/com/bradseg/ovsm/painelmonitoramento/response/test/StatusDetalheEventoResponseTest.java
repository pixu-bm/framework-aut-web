package br.com.bradseg.ovsm.painelmonitoramento.response.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.StatusDetalheEventoResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class StatusDetalheEventoResponseTest {

    /**
     * Teste testeException
     *
     * @throws Exception
     */
    
    @InjectMocks
    private StatusDetalheEventoResponse statusDetalheEventoResponseTest;
    @Test
    void testeStatusDetalheEventoResponseTest() throws Exception {
        try {

            StatusDetalheEventoResponse statusDetalheEventoResponseTest = new StatusDetalheEventoResponse();
            StatusDetalheEvento status = new StatusDetalheEvento();
            List<StatusDetalheEvento> lista = new ArrayList<>();
            status.setDisponibilidade(new BigDecimal(1));
            lista.add(status);

            statusDetalheEventoResponseTest.setListaStatusDetalheEvento(lista);
            lista = statusDetalheEventoResponseTest.getListaStatusDetalheEvento();
            Assert.notNull(lista, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
