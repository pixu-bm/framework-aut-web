package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealTransacaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class VolumetriaTempoRealTransacaoEventoRowMapperTest {

    @InjectMocks
    private VolumetriaTempoRealTransacaoEventoRowMapper volumetriaTempoRealTransacaoEventoRowMapper;

    @Test
    void testeVolumetriaTempoRealTransacaoEventoRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CCANAL_DGTAL_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("ICANAL_DGTAL_PNEL")).thenReturn("teste");
            Mockito.when(resultSetMock.getBigDecimal("VOLUME_TRANSACAO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("VOLUME_IMPACTADO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_DISPN")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_FUNC")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_CNXAO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_EVENTO_GRAVE")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_TOTAL_EVENTO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_DURACAO_EVENTO")).thenReturn(new BigDecimal(1));

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<VolumetriaTempoRealTransacaoEvento> visao = volumetriaTempoRealTransacaoEventoRowMapper
                .mapRow(resultSetMock, 0);

            Assert.notNull(visao, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
