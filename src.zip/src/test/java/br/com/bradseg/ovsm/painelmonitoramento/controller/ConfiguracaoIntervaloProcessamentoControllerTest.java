package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.ConfiguracaoIntervaloProcessamentoController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ParametroEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConfiguracaoIntervaloProcessamentoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.sql.SQLException;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso perfil
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConfiguracaoIntervaloProcessamentoControllerTest {

    @Mock
    private ConfiguracaoIntervaloProcessamentoService configuracaoIntervaloService;
    @InjectMocks
    private ConfiguracaoIntervaloProcessamentoController configuracaoIntervaloProcessamentoController;

    @Test
    void obterListaConfiguracaoIntervaloProcessamento() throws Exception {
        try {

            when(configuracaoIntervaloService.obterConfiguracaoIntervaloProcessamento(
                Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(new ConfiguracaoIntervaloProcessamentoResponse());
            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1), new BigDecimal(2),
                    new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaConfiguracaoIntervaloProcessamentoSQLException() throws Exception {
        try {

            doThrow(SQLException.class).when(configuracaoIntervaloService)
                .obterConfiguracaoIntervaloProcessamento(Mockito.any(), Mockito.any(), Mockito.any());
            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1), new BigDecimal(2),
                    new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(2));
            configuracaoIntervaloProcessamentoRequest.setCodigoProduto(new BigDecimal(4));
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("10/10/2021");
            configuracaoIntervaloProcessamentoRequest.setLogin("M232640");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(20);

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamentoRequest);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamentoEmptyResultDataAccessException() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(new ConfiguracaoIntervaloProcessamentoRequest());

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamentoSQLException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest = new ConfiguracaoIntervaloProcessamentoRequest();
            configuracaoIntervaloProcessamentoRequest.setCodigoEmpresa(new BigDecimal(2));
            configuracaoIntervaloProcessamentoRequest.setCodigoProduto(new BigDecimal(4));
            configuracaoIntervaloProcessamentoRequest.setDataVigenciaInicio("10/10/2021");
            configuracaoIntervaloProcessamentoRequest.setLogin("M232640");
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloNormal(10);
            configuracaoIntervaloProcessamentoRequest.setQuantidadeMinutoIntervaloErro(20);

            doThrow(SQLException.class).when(configuracaoIntervaloService)
                .inserirConfiguracaoIntervaloProcessamento(Mockito.any(ConfiguracaoIntervaloProcessamento.class));

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(configuracaoIntervaloProcessamentoRequest);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEvento() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .atualizarParametroEvento(new ParametroEventoRequest());

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoIllegal() throws Exception {
        try {

            doThrow(IllegalArgumentException.class).when(configuracaoIntervaloService)
                .validarParametroEvento(Mockito.any());
            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .atualizarParametroEvento(new ParametroEventoRequest());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoDataIntegrityViolationException() throws Exception {
        try {

            doThrow(DataIntegrityViolationException.class).when(configuracaoIntervaloService)
                .atualizarParametroEvento(Mockito.any());
            configuracaoIntervaloProcessamentoController.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarParametroEventoSQL() throws Exception {
        try {

            doThrow(SQLException.class).when(configuracaoIntervaloService).atualizarParametroEvento(Mockito.any());
            configuracaoIntervaloProcessamentoController.atualizarParametroEvento(new ParametroEventoRequest());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterParametroEvento() throws Exception {
        try {

            ParametroEventoResponse mensagem = new ParametroEventoResponse();
            mensagem.setCodigoRetorno(0);
            mensagem.setMensagem("SUCESSO");
            mensagem.setParametroEvento(
                configuracaoIntervaloService.obterParametroEvento(Mockito.any(), Mockito.any(), Mockito.any()));

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController.obterParametroEvento(
                new BigDecimal(1), new BigDecimal(2),
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterParametroEventoEmptyResultDataAccessException() throws Exception {
        try {
            ParametroEventoResponse mensagem = new ParametroEventoResponse();
            mensagem.setCodigoRetorno(0);
            mensagem.setMensagem("SUCESSO");
            mensagem.setParametroEvento(
                configuracaoIntervaloService.obterParametroEvento(new BigDecimal(0), new BigDecimal(0),
                    new BigDecimal(0)));

            doThrow(EmptyResultDataAccessException.class).when(configuracaoIntervaloService)
                .obterParametroEvento(Mockito.any(), Mockito.any(), Mockito.any());
            configuracaoIntervaloProcessamentoController
                .obterParametroEvento(Mockito.any(), Mockito.any(), Mockito.any());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterParametroEventoSQLException() throws Exception {
        try {

            ParametroEventoResponse mensagem = new ParametroEventoResponse();
            mensagem.setCodigoRetorno(0);
            mensagem.setMensagem("SUCESSO");
            mensagem.setParametroEvento(
                configuracaoIntervaloService.obterParametroEvento(new BigDecimal(0), new BigDecimal(0),
                    new BigDecimal(0)));

            doThrow(SQLException.class).when(configuracaoIntervaloService)
                .obterParametroEvento(Mockito.any(), Mockito.any(), Mockito.any());
            configuracaoIntervaloProcessamentoController
                .obterParametroEvento(Mockito.any(), Mockito.any(), Mockito.any());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

}
