package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.FaqDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.FaqServiceImpl;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class FaqServiceTest {

    @Mock
    private FaqDao faqDao;
    @InjectMocks
    private FaqServiceImpl faqServiceImpl;

    @Test
    void carregar() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            when(faqDao.listarPerguntasFaq()).thenReturn(lista);

            List<Faq> result = faqServiceImpl.carregar();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(EmptyResultDataAccessException.class).when(faqDao).listarPerguntasFaq();

            faqServiceImpl.carregar();

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.RESULTADO_NAO_ENCONTRADO), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarAcessoADadosExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(AcessoADadosException.class).when(faqDao).listarPerguntasFaq();

            faqServiceImpl.carregar();

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisar() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            when(faqDao.pesquisar(Mockito.anyString())).thenReturn(lista);

            List<Faq> result = faqServiceImpl.pesquisar(Mockito.anyString());

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(EmptyResultDataAccessException.class).when(faqDao).pesquisar(Mockito.anyString());

            faqServiceImpl.pesquisar(Mockito.anyString());

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.RESULTADO_NAO_ENCONTRADO), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarAcessoADadosExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(AcessoADadosException.class).when(faqDao).pesquisar(Mockito.anyString());

            faqServiceImpl.pesquisar(Mockito.anyString());

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editar() throws Exception {
        try {

            faqServiceImpl.editar(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(EmptyResultDataAccessException.class).when(faqDao).editar(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            faqServiceImpl.editar(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.RESULTADO_NAO_ENCONTRADO), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarAcessoADadosExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(AcessoADadosException.class).when(faqDao).editar(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any());

            faqServiceImpl.editar(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());
        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvar() throws Exception {
        try {
            faqServiceImpl.salvar(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(EmptyResultDataAccessException.class).when(faqDao).salvar(Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any());

            faqServiceImpl.salvar(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.RESULTADO_NAO_ENCONTRADO), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarAcessoADadosExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(AcessoADadosException.class).when(faqDao).salvar(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            faqServiceImpl.salvar(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());
        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluir() throws Exception {
        try {
            faqServiceImpl.excluir(Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(EmptyResultDataAccessException.class).when(faqDao).excluir(Mockito.any(), Mockito.any());

            faqServiceImpl.excluir(Mockito.any(), Mockito.any());

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.RESULTADO_NAO_ENCONTRADO), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirAcessoADadosExceptionTest() throws Exception {
        try {
            List<Faq> lista = new ArrayList<>();
            lista.add(new Faq());

            doThrow(AcessoADadosException.class).when(faqDao).excluir(Mockito.any(), Mockito.any());

            faqServiceImpl.excluir(Mockito.any(), Mockito.any());
        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equalsIgnoreCase(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
