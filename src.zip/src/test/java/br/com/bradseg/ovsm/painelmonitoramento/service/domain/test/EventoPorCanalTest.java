package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;

@ExtendWith(MockitoExtension.class)
public class EventoPorCanalTest {

    @InjectMocks
    private EventoPorCanal eventoPorCanal;

    @Test
    void eventoPorCanal () throws Exception {
        try {
            Canal canal = new Canal();
            canal.setCodigo(new BigDecimal(1));
            canal.setDescricao("Teste");
            EventoPorCanal eventoPorCanal = new EventoPorCanal();
            eventoPorCanal.setCanal(canal);
            eventoPorCanal.setQuantidadeEventoCanal(100);
            eventoPorCanal.setPorcentagem((double) 20);
            
            eventoPorCanal.getCanal();
            eventoPorCanal.getPorcentagem();
            eventoPorCanal.getQuantidadeEventoCanal();
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
