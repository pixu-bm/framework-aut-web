package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.ConfiguracaoIntervaloProcessamentoDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ParametroEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.Date;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados de CentralEventosDaoTest
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConfiguracaoIntervaloProcessamentoDaoTest {
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private ConfiguracaoIntervaloProcessamentoDaoImpl configuracaoIntervaloProcessamentoDaoImpl;

    @Test
    void listarConfiguracaoIntervaloProcessamento() throws Exception {
        try {

            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoDaoImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(2), new BigDecimal(1),
                    new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void listarConfiguracaoIntervaloProcessamentoEmptyResultDataAccessException() throws Exception {
        try {

            // doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).query(Mockito.anyString(),
            // Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaConfiguracaoIntervaloProcessamentoRowMapper.class));
            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoDaoImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(2), new BigDecimal(1),
                    new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {
        }
    }

    @Test
    void listarConfiguracaoIntervaloProcessamentoException() throws Exception {
        try {

            // doThrow(new RuntimeException()).when(jdbcTemplate).query(Mockito.anyString(),
            // Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaConfiguracaoIntervaloProcessamentoRowMapper.class));
            ConfiguracaoIntervaloProcessamentoResponse result = configuracaoIntervaloProcessamentoDaoImpl
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(2), new BigDecimal(1),
                    new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {
        }
    }

    @Test
    void inserirConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamento configuracao = new ConfiguracaoIntervaloProcessamento();
            configuracao.setCodigoCanal(new BigDecimal(1));
            configuracao.setCodigoEmpresa(new BigDecimal(3));
            configuracao.setCodigoProduto(new BigDecimal(2));
            configuracao.setDataVigenciaInicio(new Date());
            configuracao.setDataVigenciaFinal(new Date());
            configuracaoIntervaloProcessamentoDaoImpl.inserirConfiguracaoIntervaloProcessamento(configuracao);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void inserirConfiguracaoIntervaloProcessamentoException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamento configuracao = new ConfiguracaoIntervaloProcessamento();
            configuracao.setCodigoCanal(new BigDecimal(1));
            configuracao.setCodigoEmpresa(new BigDecimal(3));
            configuracao.setCodigoProduto(new BigDecimal(2));
            configuracao.setDataVigenciaInicio(new Date());
            configuracao.setDataVigenciaFinal(new Date());

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            configuracaoIntervaloProcessamentoDaoImpl.inserirConfiguracaoIntervaloProcessamento(configuracao);

        } catch (AcessoADadosException e) {
        }
    }

    @Test
    void verificarConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(0);
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl
                .verificarConfiguracaoIntervaloProcessamento(new ConfiguracaoIntervaloProcessamento());

            Assert.isTrue(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void verificarConfiguracaoIntervaloProcessamentoRetornandoFalse() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(1);
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl
                .verificarConfiguracaoIntervaloProcessamento(new ConfiguracaoIntervaloProcessamento());

            Assert.isTrue(!result, "Deve ser False");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void verificarConfiguracaoIntervaloProcessamentoException() throws Exception {
        try {
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl
                .verificarConfiguracaoIntervaloProcessamento(new ConfiguracaoIntervaloProcessamento());

            Assert.isTrue(result, "Não pode ser nulo");
        } catch (Exception e) {
        }
    }


    void atualizarDataFimVigencia() throws Exception {
        try {

            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento = new ConfiguracaoIntervaloProcessamento();
            configuracaoIntervaloProcessamento.setCodigoCanal(new BigDecimal(1));
            configuracaoIntervaloProcessamento.setCodigoProduto(new BigDecimal(2));
            configuracaoIntervaloProcessamento.setCodigoEmpresa(new BigDecimal(3));
            configuracaoIntervaloProcessamento.setDataVigenciaFinal(new Date(1));
            configuracaoIntervaloProcessamento.setDataVigenciaInicio(new Date(1));

            configuracaoIntervaloProcessamentoDaoImpl.atualizarDataFimVigencia(configuracaoIntervaloProcessamento);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void atualizarDataFimVigenciaException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamento configuracao = new ConfiguracaoIntervaloProcessamento();
            configuracao.setCodigoCanal(new BigDecimal(1));
            configuracao.setCodigoEmpresa(new BigDecimal(3));
            configuracao.setCodigoProduto(new BigDecimal(2));
            configuracao.setDataVigenciaInicio(new Date());
            configuracao.setDataVigenciaFinal(new Date());

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            configuracaoIntervaloProcessamentoDaoImpl.atualizarDataFimVigencia(configuracao);

        } catch (AcessoADadosException e) {
        }
    }

    @Test
    void obterParametroEvento() throws Exception {
        try {

            ParametroEvento result = configuracaoIntervaloProcessamentoDaoImpl.obterParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterParametroEventoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ParametroEventoRowMapper.class));
            ParametroEvento result = configuracaoIntervaloProcessamentoDaoImpl.obterParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {
        }
    }

    @Test
    void obterParametroEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ParametroEventoRowMapper.class));
            ParametroEvento result = configuracaoIntervaloProcessamentoDaoImpl.obterParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        }
    }

    @Test
    void verificarParametroEventoExistePrimeiroCaso() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(0);
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl.verificarParametroEventoExiste(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void verificarParametroEventoExisteSegundoCaso() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(1);
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl.verificarParametroEventoExiste(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void verificarParametroEventoExisteException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class));
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl.verificarParametroEventoExiste(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {
        }
    }

    @Test
    void verificarParametroEventoExisteEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class));
            Boolean result = configuracaoIntervaloProcessamentoDaoImpl.verificarParametroEventoExiste(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

            Assert.isNull(result, "Não pode ser nulo");

        } catch (Exception e) {
        }
    }

    @Test
    void atualizarDataFimVigenciaParametroEvento() throws Exception {
        try {

            configuracaoIntervaloProcessamentoDaoImpl.atualizarDataFimVigenciaParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarDataFimVigenciaParametroEventoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            configuracaoIntervaloProcessamentoDaoImpl.atualizarDataFimVigenciaParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

        } catch (Exception e) {
        }
    }

    @Test
    void atualizarDataFimVigenciaParametroEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            configuracaoIntervaloProcessamentoDaoImpl.atualizarDataFimVigenciaParametroEvento(new BigDecimal(2),
                new BigDecimal(1), new BigDecimal(3));

        } catch (Exception e) {
        }
    }

    @Test
    void inserirParametroEvento() throws Exception {
        try {
            ParametroEventoRequest request = new ParametroEventoRequest();
            request.setCodigoEmpresa(new BigDecimal(2));
            request.setCodigoProduto(new BigDecimal(2));
            request.setCodigoCanal(new BigDecimal(2));
            request.setParametroEvento(new ParametroEvento());
            request.getParametroEvento().setQuantidadeTransacaoOnline(1);
            request.getParametroEvento().setQuantidadeTransacaoOffline(2);

            request.getParametroEvento().setQuantidadeMinimaEventoModerado(1);
            request.getParametroEvento().setQuantidadeMaximaEventoModerado(1);

            request.getParametroEvento().setQuantidadeMaximaEventoAlto(2);
            request.getParametroEvento().setQuantidadeMinimaEventoAlto(2);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeModerado(3);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeModerado(3);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeAlto(2);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeAlto(2);

            request.getParametroEvento().setQuantidadeLimiteEventoVolumeBemBaixo(3);
            request.getParametroEvento().setQuantidadeMetricaEventoVolume(1);

            request.getParametroEvento().setQuantidadeLimiteEventoImpactoBemBaixo(1);
            request.getParametroEvento().setQuantidadeMetricaEventoImpacto(1);

            request.getParametroEvento().setQuantidadeLimiteSegundoEventoBemBaixo(1);

            request.getParametroEvento().setQuantidadeSegundoExecucaoEvento(1);

            request.getParametroEvento().setQuantidadeLimiteEventoFuncionalidadeBemBaixo(2);

            request.getParametroEvento().setQuantidadeMetricaEventoFuncionalidade(3);

            configuracaoIntervaloProcessamentoDaoImpl.inserirParametroEvento(request);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirParametroEventoDataViolation() throws Exception {
        try {
            ParametroEventoRequest request = new ParametroEventoRequest();
            request.setCodigoEmpresa(new BigDecimal(2));
            request.setCodigoProduto(new BigDecimal(2));
            request.setCodigoCanal(new BigDecimal(2));
            request.setParametroEvento(new ParametroEvento());
            request.getParametroEvento().setQuantidadeTransacaoOnline(1);
            request.getParametroEvento().setQuantidadeTransacaoOffline(2);

            request.getParametroEvento().setQuantidadeMinimaEventoModerado(1);
            request.getParametroEvento().setQuantidadeMaximaEventoModerado(1);

            request.getParametroEvento().setQuantidadeMaximaEventoAlto(2);
            request.getParametroEvento().setQuantidadeMinimaEventoAlto(2);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeModerado(3);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeModerado(3);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeAlto(2);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeAlto(2);

            request.getParametroEvento().setQuantidadeLimiteEventoVolumeBemBaixo(3);
            request.getParametroEvento().setQuantidadeMetricaEventoVolume(1);

            request.getParametroEvento().setQuantidadeLimiteEventoImpactoBemBaixo(1);
            request.getParametroEvento().setQuantidadeMetricaEventoImpacto(1);

            request.getParametroEvento().setQuantidadeLimiteSegundoEventoBemBaixo(1);

            request.getParametroEvento().setQuantidadeSegundoExecucaoEvento(1);

            request.getParametroEvento().setQuantidadeLimiteEventoFuncionalidadeBemBaixo(2);

            request.getParametroEvento().setQuantidadeMetricaEventoFuncionalidade(3);

            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate)
                .update(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            configuracaoIntervaloProcessamentoDaoImpl.inserirParametroEvento(request);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
    void inserirParametroEventoAcessoADadosException() throws Exception {
        try {
            ParametroEventoRequest request = new ParametroEventoRequest();
            request.setCodigoEmpresa(new BigDecimal(2));
            request.setCodigoProduto(new BigDecimal(2));
            request.setCodigoCanal(new BigDecimal(2));
            request.setCodigoEmpresa(new BigDecimal(2));
            request.setCodigoProduto(new BigDecimal(2));
            request.setCodigoCanal(new BigDecimal(2));
            request.setParametroEvento(new ParametroEvento());
            request.getParametroEvento().setQuantidadeTransacaoOnline(1);
            request.getParametroEvento().setQuantidadeTransacaoOffline(2);

            request.getParametroEvento().setQuantidadeMinimaEventoModerado(1);
            request.getParametroEvento().setQuantidadeMaximaEventoModerado(1);

            request.getParametroEvento().setQuantidadeMaximaEventoAlto(2);
            request.getParametroEvento().setQuantidadeMinimaEventoAlto(2);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeModerado(3);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeModerado(3);

            request.getParametroEvento().setQuantidadeMinimaEventoVolumeAlto(2);
            request.getParametroEvento().setQuantidadeMaximaEventoVolumeAlto(2);

            request.getParametroEvento().setQuantidadeLimiteEventoVolumeBemBaixo(3);
            request.getParametroEvento().setQuantidadeMetricaEventoVolume(1);

            request.getParametroEvento().setQuantidadeLimiteEventoImpactoBemBaixo(1);
            request.getParametroEvento().setQuantidadeMetricaEventoImpacto(1);

            request.getParametroEvento().setQuantidadeLimiteSegundoEventoBemBaixo(1);

            request.getParametroEvento().setQuantidadeSegundoExecucaoEvento(1);

            request.getParametroEvento().setQuantidadeLimiteEventoFuncionalidadeBemBaixo(2);

            request.getParametroEvento().setQuantidadeMetricaEventoFuncionalidade(3);

            doThrow(new RuntimeException()).when(jdbcTemplate)
                .update(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            configuracaoIntervaloProcessamentoDaoImpl.inserirParametroEvento(request);

        } catch (AcessoADadosException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}
