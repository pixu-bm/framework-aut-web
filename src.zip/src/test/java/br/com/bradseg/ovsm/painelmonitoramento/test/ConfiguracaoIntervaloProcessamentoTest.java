package br.com.bradseg.ovsm.painelmonitoramento.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.ConfiguracaoIntervaloProcessamentoController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConfiguracaoIntervaloProcessamentoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.sql.SQLException;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso perfil
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConfiguracaoIntervaloProcessamentoTest {

    @Mock
    private ConfiguracaoIntervaloProcessamentoService configuracaoIntervaloProcessamentoService;
    @InjectMocks
    private ConfiguracaoIntervaloProcessamentoController configuracaoIntervaloProcessamentoController;

    /**
     * Teste listar configuracao intervalo
     * 
     * @throws Exception
     */
    @Test
    void obterListaConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            when(configuracaoIntervaloProcessamentoService
                .obterConfiguracaoIntervaloProcessamento(Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(new ConfiguracaoIntervaloProcessamentoResponse());
            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .obterConfiguracaoIntervaloProcessamento(new BigDecimal(1), new BigDecimal(2), new BigDecimal(3));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listar configuracao intervalo
     * obterListaConfiguracaoIntervaloProcessamentoSQLException
     * 
     * @throws Exception
     */
    @Test
    void obterListaConfiguracaoIntervaloProcessamentoSQLException() throws Exception {
        try {

            doThrow(SQLException.class).when(configuracaoIntervaloProcessamentoService)
                .obterConfiguracaoIntervaloProcessamento(
                    Mockito.any(), Mockito.any(), Mockito.any());
            configuracaoIntervaloProcessamentoController.obterConfiguracaoIntervaloProcessamento(
                new BigDecimal(1), new BigDecimal(2), new BigDecimal(3));

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste listar configuracao intervalo EmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void obterListaConfiguracaoIntervaloProcessamentoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(configuracaoIntervaloProcessamentoService)
                .obterConfiguracaoIntervaloProcessamento(
                    Mockito.any(), Mockito.any(), Mockito.any());
            configuracaoIntervaloProcessamentoController.obterConfiguracaoIntervaloProcessamento(
                new BigDecimal(1), new BigDecimal(2), new BigDecimal(3));

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * Teste listar configuracao intervalo EmptyResultDataAccessException
     * 
     * @throws Exception
     */

    /**
     * inserir configuracao intervalo
     * 
     * @throws Exception
     */
    @Test
    void inserirConfiguracaoIntervaloProcessamentoIllegalArgumentException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest request = new ConfiguracaoIntervaloProcessamentoRequest();
            request.setCodigoEmpresa(new BigDecimal(1));
            request.setCodigoProduto(new BigDecimal(1));
            request.setLogin("M232640");
            request.setQuantidadeMinutoIntervaloNormal(10);
            request.setQuantidadeMinutoIntervaloErro(5);

            doThrow(IllegalArgumentException.class).when(configuracaoIntervaloProcessamentoService)
                .validarParametroConfiguracaoIntervaloProcessamento(
                    Mockito.any(ConfiguracaoIntervaloProcessamentoRequest.class));

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * inserir configuracao intervalo
     * 
     * @throws Exception
     */
    @Test
    void inserirConfiguracaoIntervaloProcessamento() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest request = new ConfiguracaoIntervaloProcessamentoRequest();
            request.setCodigoEmpresa(new BigDecimal(1));
            request.setCodigoProduto(new BigDecimal(1));
            request.setLogin("M232640");
            request.setQuantidadeMinutoIntervaloNormal(10);
            request.setQuantidadeMinutoIntervaloErro(5);
            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * inserir configuracao intervalo
     * 
     * @throws Exception
     */
    @Test
    void inserirConfiguracaoIntervaloProcessamentoSqlException() throws Exception {
        try {
            ConfiguracaoIntervaloProcessamentoRequest request = new ConfiguracaoIntervaloProcessamentoRequest();
            request.setCodigoEmpresa(new BigDecimal(1));
            request.setCodigoProduto(new BigDecimal(1));
            request.setLogin("M232640");
            request.setQuantidadeMinutoIntervaloNormal(10);
            request.setQuantidadeMinutoIntervaloErro(5);

            doThrow(SQLException.class).when(configuracaoIntervaloProcessamentoService)
                .inserirConfiguracaoIntervaloProcessamento(Mockito.any(ConfiguracaoIntervaloProcessamento.class));

            ResponseEntity<ResponseMensagem> result = configuracaoIntervaloProcessamentoController
                .inserirConfiguracaoIntervaloProcessamento(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }
}
