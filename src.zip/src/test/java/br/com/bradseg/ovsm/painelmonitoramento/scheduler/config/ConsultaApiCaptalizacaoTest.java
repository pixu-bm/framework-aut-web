package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiCaptalizacaoDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConsultaApiCaptalizacaoTest {

    @InjectMocks
    private ConsultaApiCaptalizacao consultaApiCapitalizacao;
    @Mock
    private ConsultaApiCaptalizacaoDaoImpl consultaApiCaptalizacaoDao;
    @Mock
    private HttpURLConnection connection;

    @Test
    void testeConsultaApi() throws Exception {
        try {
            consultaApiCapitalizacao.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiCaptalizacaoDao.obterultimoregistroinserido()).thenReturn(null);
            consultaApiCapitalizacao.consultaApi();
            consultaApiCapitalizacao.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiCapitalizacao.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiCaptalizacaoDao).obterultimoregistroinserido();
            consultaApiCapitalizacao.consultaApi(); 
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosSQLException() throws Exception {
        try {
            consultaApiCapitalizacao.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiCaptalizacaoDao).obterultimoregistroinserido();
            consultaApiCapitalizacao.consultaApi(); 
        

        } catch (Exception e) {

           
        }
    }
    
    
    @Test
    void testeBuscaTempoParametrizado() throws Exception {
        try {
            
            consultaApiCapitalizacao.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaCapOk() throws Exception {
        try {
            consultaApiCapitalizacao.obterCapitalizacaoOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
            
            consultaApiCapitalizacao.obterCapitalizacaoNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now(),connection);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaCapOkMaximo() throws Exception {
        try {
            consultaApiCapitalizacao.obterCapitalizacaoOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiCapitalizacao.obterCapitalizacaoNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarConexaoTemp() throws Exception {
        try {
            when(connection.getResponseCode()).thenReturn(500);
            consultaApiCapitalizacao.validarConexaoCapitalizacaoTemp(
                LocalDateTime.now(), connection, "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443", new LinkedList<>(), "x");
            
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarConexaoTempApi() throws Exception {
        try {
            when(connection.getResponseCode()).thenReturn(500);
            consultaApiCapitalizacao.validarConexaoCapitalizacaoTempApi(
                LocalDateTime.now(), connection, "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443", new LinkedList<>());
            
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
