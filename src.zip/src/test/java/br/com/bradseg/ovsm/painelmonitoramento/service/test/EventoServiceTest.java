package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EventoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.EventoServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import java.util.List;

import static org.mockito.Mockito.doThrow;

/**
 * Classe implementa test automatizados de EventoDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class EventoServiceTest {

    @Mock
    private EventoDao eventoDao;
    @InjectMocks
    private EventoServiceImpl eventoServiceImpl;

    @Test
    void obterTipoEvento() throws Exception {
        try {

            List<Evento> result = eventoServiceImpl.obterListaEvento();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(eventoDao).obterListaEvento();
            eventoServiceImpl.obterListaEvento();

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEventoException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(eventoDao).obterListaEvento();
            eventoServiceImpl.obterListaEvento();

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
