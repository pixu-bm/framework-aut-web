package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaConfiguracaoIntervaloProcessamentoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.sql.ResultSet;

@ExtendWith(MockitoExtension.class)
public class ListaConfiguracaoIntervaloProcessamentoRowMapperTest {

    @InjectMocks
    private ListaConfiguracaoIntervaloProcessamentoRowMapper listaConfiguracaoIntervaloProcessamentoRowMapper;

    @Test
    void testeListaUsuarioRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("QMNUTO_INTVL_ERRO")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("QMNUTO_INTVL_NORML")).thenReturn(1);

            ConfiguracaoIntervaloProcessamentoResponse configuracaoIntervaloProcessamento = listaConfiguracaoIntervaloProcessamentoRowMapper
                .mapRow(resultSetMock, 0);

            Assert.notNull(configuracaoIntervaloProcessamento, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
