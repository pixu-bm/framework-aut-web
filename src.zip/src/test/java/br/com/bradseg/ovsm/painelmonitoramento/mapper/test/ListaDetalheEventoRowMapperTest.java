package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaDetalheEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;

@ExtendWith(MockitoExtension.class)
public class ListaDetalheEventoRowMapperTest {

    @InjectMocks
    private ListaDetalheEventoRowMapper listaDetalheEventoRowMapper;

    @Test
    void testeListaDetalheEventoRowMapper() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CERRO_CNXAO_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("IPRODT")).thenReturn("email@email.com");
            Mockito.when(resultSetMock.getString("ICANAL_DGTAL_PNEL")).thenReturn("teste");
            Mockito.when(resultSetMock.getString("ITPO_EVNTO_PNEL")).thenReturn("teste");
            Mockito.when(resultSetMock.getInt("QRCRRC_ERRO_EVNTO")).thenReturn(2);
            Mockito.when(resultSetMock.getBigDecimal("QTRANS_EXECT_INSUC")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("ITPO_EVNTO_PNEL")).thenReturn("teste");

            Mockito.when(resultSetMock.getBigDecimal("QEVNTO_NORML_FUNCL")).thenReturn(new BigDecimal(1))
                .thenReturn(new BigDecimal(0)).thenReturn(null);
            Mockito.when(resultSetMock.getBigDecimal("CSIT_FUNCL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getDate("DINIC_ERRO_FUNCL")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.getBigDecimal("QEVNTO_NORML_DISPN")).thenReturn(new BigDecimal(1))
                .thenReturn(new BigDecimal(0)).thenReturn(null);
            Mockito.when(resultSetMock.getBigDecimal("CSIT_DISPN")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getDate("DINIC_ERRO_DISPN")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.getBigDecimal("QEVNTO_NORML_CNXAO")).thenReturn(new BigDecimal(1))
                .thenReturn(new BigDecimal(0)).thenReturn(null);
            Mockito.when(resultSetMock.getBigDecimal("CSIT_VOLUM")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getDate("DINIC_ERRO_VOLUM")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.getInt("QSEGDA_EVNTO")).thenReturn(0);

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);

            List<RegistroEvento> registro = listaDetalheEventoRowMapper.mapRow(resultSetMock, 0);
            Assert.notNull(registro, "nao pode nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
