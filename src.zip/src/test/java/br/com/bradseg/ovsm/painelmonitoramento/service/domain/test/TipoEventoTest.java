package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;

@ExtendWith(MockitoExtension.class)
public class TipoEventoTest {

    @InjectMocks
    private TipoEvento tipoEvento;

    @Test
    void tipoEvento () throws Exception {
        try {
            TipoEvento tipoEvento = new TipoEvento();
            tipoEvento.setQuantidadeTotalDisponibilidade(100);
            tipoEvento.setQuantidadeTotalFuncionalidade(100);
            tipoEvento.setQuantidadeTotalTipoEvento(100);
            tipoEvento.setQuantidadeTotalVolumetria(100);
            tipoEvento.setPorcentagemDisponibilidade((double) 20);
            tipoEvento.setPorcentagemFuncionalidade((double) 20);
            tipoEvento.setPorcentagemVolumetria((double) 20);
            
            tipoEvento.getPorcentagemDisponibilidade();
            tipoEvento.getPorcentagemFuncionalidade();
            tipoEvento.getPorcentagemVolumetria();
            tipoEvento.getQuantidadeTotalDisponibilidade();
            tipoEvento.getQuantidadeTotalFuncionalidade();
            tipoEvento.getQuantidadeTotalTipoEvento();
            tipoEvento.getQuantidadeTotalVolumetria();
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
