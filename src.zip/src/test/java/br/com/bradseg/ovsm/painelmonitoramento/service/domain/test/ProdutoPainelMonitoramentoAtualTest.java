package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EmpresaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ProdutoPainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.EmpresaServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados empresa service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ProdutoPainelMonitoramentoAtualTest {

    @InjectMocks
    private ProdutoPainelMonitoramentoAtual arodutoPainelMonitoramentoAtualTest;

    /**
     * Teste construtorProdutoPainelMonitoramentoAtualTest
     * 
     * @throws Exception
     */
    @Test
    void contrutorProdutoPainelMonitoramentoAtualTest() throws Exception {
        try {
            ProdutoPainelMonitoramentoAtual produtoPainelMonitoramentoAtualTest = new ProdutoPainelMonitoramentoAtual();
            produtoPainelMonitoramentoAtualTest.getDataAlteracaoRegistro();
            produtoPainelMonitoramentoAtualTest.getDataInclusaoRegistro();
            produtoPainelMonitoramentoAtualTest.getListaCanal();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
