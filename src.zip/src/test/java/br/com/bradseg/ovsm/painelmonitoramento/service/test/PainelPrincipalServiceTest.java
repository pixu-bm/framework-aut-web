package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.PainelPrincipalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.PainelPrincipalServiceImpl;

/**
 * Classe implementa test login service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class PainelPrincipalServiceTest {

    @Mock
    private PainelPrincipalDao painelPrincipalDao;
    @InjectMocks
    private PainelPrincipalServiceImpl painelPrincipalServiceImpl;

    @Test
    void obterPainelMonitoramentoTest() throws Exception {
        try {
            PainelMonitoramentoAtual painel = new PainelMonitoramentoAtual();
            painel.setCodigoRetorno(1);

            when(painelPrincipalDao.obterPainelMonitoramento()).thenReturn(painel);

            PainelMonitoramentoAtual result = painelPrincipalServiceImpl.obterPainelMonitoramento();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterPainelMonitoramentoAcessoADadosExceptionTest() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(painelPrincipalDao).obterPainelMonitoramento();

            painelPrincipalServiceImpl.obterPainelMonitoramento();

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoTest() throws Exception {
        try {
            VisaoEvento visao = new VisaoEvento();
            visao.setCodigoRetorno(1);

            when(painelPrincipalDao.obterVisaoEvento(1)).thenReturn(visao);

            VisaoEvento result = painelPrincipalServiceImpl.obterVisaoEvento(1);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoIllegalArgumentExceptionTest() throws Exception {
        try {

            doThrow(IllegalArgumentException.class).when(painelPrincipalDao).obterVisaoEvento(Mockito.anyInt());

            painelPrincipalServiceImpl.obterVisaoEvento(1);

        } catch (IllegalArgumentException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAcessoADadosExceptionTest() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(painelPrincipalDao).obterVisaoEvento(Mockito.anyInt());

            painelPrincipalServiceImpl.obterVisaoEvento(1);

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealVolumetriaMaximaTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            VolumetriaTempoRealVolumetriaMaxima volumetria = new VolumetriaTempoRealVolumetriaMaxima();
            volumetria.setMediaHistoricaTransacao(new BigDecimal(1));

            when(painelPrincipalDao.obterVolumetriaTempoRealVolumetriaMaxima(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(volumetria);

            VolumetriaTempoRealVolumetriaMaxima result = painelPrincipalServiceImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(1, lista,
                    lista, lista);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealVolumetriaMaximaAcessoADadosExceptionTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(painelPrincipalDao)
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any());

            painelPrincipalServiceImpl.obterVolumetriaTempoRealVolumetriaMaxima(1, lista,
                lista, lista);

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            List<VolumetriaTempoReal> listaTest = new ArrayList<>();
            VolumetriaTempoReal test = new VolumetriaTempoReal();
            test.setCodigoCanal(new BigDecimal(1));
            listaTest.add(test);

            when(painelPrincipalDao.obterVolumetriaTempoRealFaixaTempo(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(listaTest);

            List<VolumetriaTempoReal> result = painelPrincipalServiceImpl
                .obterVolumetriaTempoRealFaixaTempo(1, lista,
                    lista, lista);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoEmptyTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            List<VolumetriaTempoReal> listaTest = new ArrayList<>();

            when(painelPrincipalDao.obterVolumetriaTempoRealFaixaTempo(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(listaTest);

            painelPrincipalServiceImpl
                .obterVolumetriaTempoRealFaixaTempo(1, lista,
                    lista, lista);

        } catch (EmptyResultDataAccessException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAcessoADadosExceptionTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(painelPrincipalDao)
                .obterVolumetriaTempoRealFaixaTempo(
                    Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any());

            painelPrincipalServiceImpl.obterVolumetriaTempoRealFaixaTempo(1, lista,
                lista, lista);

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEventoTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            List<VolumetriaTempoRealTransacaoEvento> listaTest = new ArrayList<>();
            VolumetriaTempoRealTransacaoEvento test = new VolumetriaTempoRealTransacaoEvento();
            test.setCodigoCanal(new BigDecimal(1));
            listaTest.add(test);

            when(painelPrincipalDao.obterVolumetriaTempoRealTransacaoEvento(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(listaTest);

            List<VolumetriaTempoRealTransacaoEvento> result = painelPrincipalServiceImpl
                .obterVolumetriaTempoRealTransacaoEvento(1, lista,
                    lista, lista);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEventoEmptyTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            List<VolumetriaTempoRealTransacaoEvento> listaTest = new ArrayList<>();

            when(painelPrincipalDao.obterVolumetriaTempoRealTransacaoEvento(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(listaTest);

            painelPrincipalServiceImpl
                .obterVolumetriaTempoRealTransacaoEvento(1, lista,
                    lista, lista);

        } catch (EmptyResultDataAccessException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEventoAcessoADadosExceptionTest() throws Exception {
        try {
            List<BigDecimal> lista = new ArrayList<>();
            lista.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(painelPrincipalDao)
                .obterVolumetriaTempoRealTransacaoEvento(
                    Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any());

            painelPrincipalServiceImpl.obterVolumetriaTempoRealTransacaoEvento(1, lista,
                lista, lista);

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarParametroEventoTest() throws Exception {
        try {

            painelPrincipalServiceImpl
                .validarParametroEvento(1);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
