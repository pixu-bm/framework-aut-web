package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.IndicadoresNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class IndicadoresNegocioRowMapperTest {

    @InjectMocks
    private IndicadoresNegocioRowMapper indicadoresNegocioRowMapper;

    @Test
    void testeIndicadoresNegocioRowMapper() throws Exception {
        try {
            
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("SOMA_TRANSACOES")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("SOMA_EVENTOS")).thenReturn(1);
            Mockito.when(resultSetMock.getLong("SOMA_TEMPO_EVENTOS")).thenReturn(100000L);
            Mockito.when(resultSetMock.getInt("TRANSACOES_IMPACTADAS")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("FREQUENCIA_EVENTOS")).thenReturn(1);
            Mockito.when(resultSetMock.getLong("MEDIA_TEMPO_EVENTOS")).thenReturn(18305L);

            IndicadoresNegocio numeroTransacoes = indicadoresNegocioRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(numeroTransacoes, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
