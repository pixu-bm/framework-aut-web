package br.com.bradseg.ovsm.painelmonitoramento.service.export.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.CentralEventosServiceExport;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class CentralEventosServiceExportTest {

    @Mock
    private LoginDao loginDao;
    @Mock
    private ProdutoDao produtoDao;
    @Mock
    private CanalDao canalDao;
    @InjectMocks
    private CentralEventosServiceExport centralEventosServiceExport;

    @Test
    void obterRegistroEventoExcel() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);
            registro.setWebService("teste");
            registro.setStatus("Ok");
            registro.setMainframe("Cobol");
            registro.setApi("www.susc.bradseg.com.br");
            registro.setUrl("ss");
            registro.setQtdEventoUltimo30("2");
            registro.setEtapaEvento("x");
            registro.setMsgQtd("1");

            registro.getStatus();
            registro.getMainframe();
            registro.getApi();
            registro.getUrl();
            registro.getQtdEventoUltimo30();
            registro.getEtapaEvento();
            registro.getMsgQtd();

            lista.add(registro);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), listaProduto, listaCanal);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelSqlException() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);

            lista.add(registro);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));

            doThrow(SQLException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), listaProduto, listaCanal);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelNull() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);

            lista.add(registro);

            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), null, null);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterArquivoRegistroEventoPDFTest() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("EVENTO GRAVE");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);
            registro.setWebService("teste");
            registro.setStatus("Ok");
            registro.setMainframe("Cobol");
            registro.setApi("www.susc.bradseg.com.br");
            registro.setUrl("ss");
            registro.setQtdEventoUltimo30("2");
            registro.setEtapaEvento("x");
            registro.setMsgQtd("1");

            registro.getStatus();
            registro.getMainframe();
            registro.getApi();
            registro.getUrl();
            registro.getQtdEventoUltimo30();
            registro.getEtapaEvento();
            registro.getMsgQtd();

            RegistroEvento registro2 = new RegistroEvento();
            registro2.setCodigo(new BigDecimal(1));
            registro2.setNumeroTransacao(new BigDecimal(2));
            registro2.setCodigoGravidade(new BigDecimal(2));
            registro2.setDataInicioEvento("10/10/2021");
            registro2.setDescricaoCanal("Teste");
            registro2.setDescricaoGravidade("EVENTO MODERADO");
            registro2.setDescricaoProduto("Teste");
            registro2.setDescricaoTipo("Teste");
            registro2.setRecorrencia(10);
            registro2.setWebService("teste");
            registro2.setStatus("Ok");
            registro2.setMainframe("Cobol");
            registro2.setApi("www.susc.bradseg.com.br");
            registro2.setUrl("ss");
            registro2.setQtdEventoUltimo30("2");
            registro2.setEtapaEvento("x");
            registro2.setMsgQtd("1");

            registro2.getStatus();
            registro2.getMainframe();
            registro2.getApi();
            registro2.getUrl();
            registro2.getQtdEventoUltimo30();
            registro2.getEtapaEvento();
            registro2.getMsgQtd();

            lista.add(registro);
            lista.add(registro2);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            ByteArrayInputStream listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoPDF(
                lista, "M232640", new Date(), new Date(), listaProduto, listaCanal);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterArquivoRegistroProdutoCanalEventoPDFTest() throws Exception {
        try {
            List<VisaoDetalhadaProdutoCanal> lista = new ArrayList<>();
            VisaoDetalhadaProdutoCanal visao = new VisaoDetalhadaProdutoCanal();
            visao.setCanal("Teste");
            visao.setProduto("Produto");
            visao.setEventoAberto(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setEventoDisponibilidade(new BigDecimal(500));
            visao.setEventoFuncional(new BigDecimal(500));
            visao.setEventoVolumetria(new BigDecimal(500));
            visao.setEventoFechado(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setTotal(new BigDecimal(500));
            visao.setPeriodo("Teste");
            lista.add(visao);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            ByteArrayInputStream listaRegistro = centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoPDF(
                lista, 1, listaProduto, listaCanal, "M232640");

            lista = new ArrayList<>();
            visao = new VisaoDetalhadaProdutoCanal();
            visao.setCanal("Teste");
            visao.setProduto("Produto");
            visao.setEventoAberto(null);
            visao.setEventoGrave(null);
            visao.setEventoModerado(null);
            visao.setEventoDisponibilidade(null);
            visao.setEventoFuncional(null);
            visao.setEventoVolumetria(null);
            visao.setEventoFechado(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setTotal(new BigDecimal(500));
            visao.setPeriodo("Teste");
            lista.add(visao);

            listaRegistro = centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoPDF(
                lista, 1, listaProduto, listaCanal, "M232640");

            listaRegistro = centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoPDF(
                null, 1, listaProduto, listaCanal, "M232640");

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterArquivoRegistroEventoDetalhadoPDFTest() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("EVENTO GRAVE");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);
            registro.setWebService("teste");
            registro.setStatus("2");
            registro.setMainframe("Cobol");
            registro.setApi("www.susc.bradseg.com.br");
            registro.setUrl("ss");
            registro.setQtdEventoUltimo30("2");
            registro.setEtapaEvento("x");
            registro.setMsgQtd("1");

            RegistroEvento registro2 = new RegistroEvento();
            registro2.setCodigo(new BigDecimal(1));
            registro2.setNumeroTransacao(new BigDecimal(2));
            registro2.setCodigoGravidade(new BigDecimal(2));
            registro2.setDataInicioEvento("10/10/2021");
            registro2.setDescricaoCanal("Teste");
            registro2.setDescricaoGravidade("EVENTO MODERADO");
            registro2.setDescricaoProduto("Teste");
            registro2.setDescricaoTipo("Teste");
            registro2.setRecorrencia(10);
            registro2.setWebService("teste");
            registro2.setStatus("1");
            registro2.setMainframe("Cobol");
            registro2.setApi("www.susc.bradseg.com.br");
            registro2.setUrl("ss");
            registro2.setQtdEventoUltimo30("2");
            registro2.setEtapaEvento("x");
            registro2.setMsgQtd("1");

            lista.add(registro);
            lista.add(registro2);

            List<StatusDetalheEvento> listaStatusDetalheEvento = new ArrayList<>();
            StatusDetalheEvento status = new StatusDetalheEvento();
            status.setListaEvento(lista);
            status.setSomaEventoGrave(new BigDecimal(500));
            status.setSomaEventoModerado(new BigDecimal(500));
            listaStatusDetalheEvento.add(status);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            ByteArrayInputStream listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoDetalhadoPDF(
                listaStatusDetalheEvento, "M232640", 1, new BigDecimal(1), new BigDecimal(1), new BigDecimal(1),
                new Date(), 1, 1);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterArquivoRegistroProdutoCanalEventoExcelCsvTest() throws Exception {
        try {
            List<VisaoDetalhadaProdutoCanal> lista = new ArrayList<>();
            VisaoDetalhadaProdutoCanal visao = new VisaoDetalhadaProdutoCanal();
            visao.setCanal("Teste");
            visao.setProduto("Produto");
            visao.setEventoAberto(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setEventoDisponibilidade(new BigDecimal(500));
            visao.setEventoFuncional(new BigDecimal(500));
            visao.setEventoVolumetria(new BigDecimal(500));
            visao.setEventoFechado(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setTotal(new BigDecimal(500));
            visao.setPeriodo("Teste");
            lista.add(visao);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoExcelCsv(
                lista, 1, listaProduto, listaCanal, "M232640");

            lista = new ArrayList<>();
            visao = new VisaoDetalhadaProdutoCanal();
            visao.setCanal("Teste");
            visao.setProduto("Produto");
            visao.setEventoAberto(null);
            visao.setEventoDisponibilidade(null);
            visao.setEventoFuncional(null);
            visao.setEventoVolumetria(null);
            visao.setEventoFechado(new BigDecimal(500));
            visao.setEventoGrave(new BigDecimal(500));
            visao.setEventoModerado(new BigDecimal(500));
            visao.setTotal(new BigDecimal(500));
            visao.setPeriodo("Teste");
            lista.add(visao);

            centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoExcelCsv(
                lista, 2, listaProduto, listaCanal, "M232640");

            centralEventosServiceExport.obterArquivoRegistroProdutoCanalEventoExcelCsv(
                lista, 3, listaProduto, listaCanal, "M232640");

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterArquivoRegistroEventoDetalhadoExcelCsvTest() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("EVENTO GRAVE");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);
            registro.setWebService("teste");
            registro.setStatus("2");
            registro.setMainframe("Cobol");
            registro.setApi("www.susc.bradseg.com.br");
            registro.setUrl("ss");
            registro.setQtdEventoUltimo30("2");
            registro.setEtapaEvento("x");
            registro.setMsgQtd("1");

            RegistroEvento registro2 = new RegistroEvento();
            registro2.setCodigo(new BigDecimal(1));
            registro2.setNumeroTransacao(new BigDecimal(2));
            registro2.setCodigoGravidade(new BigDecimal(2));
            registro2.setDataInicioEvento("10/10/2021");
            registro2.setDescricaoCanal("Teste");
            registro2.setDescricaoGravidade("EVENTO MODERADO");
            registro2.setDescricaoProduto("Teste");
            registro2.setDescricaoTipo("Teste");
            registro2.setRecorrencia(10);
            registro2.setWebService("teste");
            registro2.setStatus("1");
            registro2.setMainframe("Cobol");
            registro2.setApi("www.susc.bradseg.com.br");
            registro2.setUrl("ss");
            registro2.setQtdEventoUltimo30("2");
            registro2.setEtapaEvento("x");
            registro2.setMsgQtd("1");

            lista.add(registro);
            lista.add(registro2);

            List<StatusDetalheEvento> listaStatusDetalheEvento = new ArrayList<>();
            StatusDetalheEvento status = new StatusDetalheEvento();
            status.setListaEvento(lista);
            status.setSomaEventoGrave(new BigDecimal(500));
            status.setSomaEventoModerado(new BigDecimal(500));
            listaStatusDetalheEvento.add(status);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoDetalhadoExcelCsv(
                listaStatusDetalheEvento, "M232640", new BigDecimal(1), new BigDecimal(1),
                1);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
