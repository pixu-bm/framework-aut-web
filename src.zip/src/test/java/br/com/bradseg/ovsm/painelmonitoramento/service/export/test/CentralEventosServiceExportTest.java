package br.com.bradseg.ovsm.painelmonitoramento.service.export.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.CentralEventosServiceExport;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class CentralEventosServiceExportTest {

    @Mock
    private LoginDao loginDao;
    @Mock
    private ProdutoDao produtoDao;
    @Mock
    private CanalDao canalDao;
    @InjectMocks
    private CentralEventosServiceExport centralEventosServiceExport;

    @Test
    void obterRegistroEventoExcel() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);
            registro.setWebService("teste");
            registro.setStatus("Ok");
            registro.setMainframe("Cobol");
            registro.setApi("www.susc.bradseg.com.br");
            registro.setUrl("ss");
            registro.setQtdEventoUltimo30("2");
            registro.setEtapaEvento("x");
            registro.setMsgQtd("1");
            
            registro.getStatus();
            registro.getMainframe();
            registro.getApi();
            registro.getUrl();
            registro.getQtdEventoUltimo30();
            registro.getEtapaEvento();
            registro.getMsgQtd();

            lista.add(registro);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));
            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), listaProduto, listaCanal);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelSqlException() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);

            lista.add(registro);

            List<BigDecimal> listaProduto = new ArrayList<BigDecimal>();
            listaProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCanal = new ArrayList<BigDecimal>();
            listaCanal.add(new BigDecimal(1));

            doThrow(SQLException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), listaProduto, listaCanal);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelNull() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);

            lista.add(registro);

            Usuario usuario = new Usuario();
            usuario.setNome("Teste");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            Workbook listaRegistro = centralEventosServiceExport.obterArquivoRegistroEventoExcel(
                lista, "M232640", new Date(), new Date(), null, null);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
