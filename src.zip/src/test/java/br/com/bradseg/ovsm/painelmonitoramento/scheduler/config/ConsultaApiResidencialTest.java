package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiResidencialDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiResidencialTest {
    
    @InjectMocks
    private ConsultaApiResidencial consultaApiResidencial;
    @Mock
    private ConsultaApiResidencialDao consultaApiResidencialDao;
    @Mock
    private HttpURLConnection connection;
    
    
    @Test
    void testeConsultaApiResidencial() throws Exception {
        try {
            consultaApiResidencial.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiResidencialDao.obterultimoregistroinserido()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiResidencial.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiResidencial.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiResidencialDao).obterultimoregistroinserido();
            consultaApiResidencial.consultaApi(); 
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiResidencial.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiResidencialDao).obterultimoregistroinserido();
            consultaApiResidencial.consultaApi(); 

        } catch (Exception e) {
        }
    }
    
    @Test
    void testeConsultaResidencialOk() throws Exception {
        try {
            consultaApiResidencial.obterResidencialOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
            
            consultaApiResidencial.obterResidencialNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now(),connection);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaResidencialOkMaximo() throws Exception {
        try {
            consultaApiResidencial.obterResidencialOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiResidencial.obterResidencialNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testevalidarConexaoResidencialTemp() throws Exception {
        try{
            LinkedList<TabelaTemp> listaResidencialTemp = new LinkedList<>();
            TabelaTemp residencialTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            residencialTemp.setcorrigeDado(850);
            residencialTemp.setCindRegProcs("P");
            // Codigo de retorno
            residencialTemp.setCerroOrign("teste");
            residencialTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            residencialTemp.setRenderUrlOrign("endereco");
            residencialTemp.setRservcOrign(null);
            residencialTemp.setItransOrign("A001");
            residencialTemp.setRtransOrign("endereco");
            residencialTemp.setIapiOrign("endereco");
            residencialTemp.setIcanalOrign("CAP");
            residencialTemp.setIemprOrign("CAPI");
            residencialTemp.setIprodtOrign("CAPITALIZACAO");
            residencialTemp.setIsprodOrign(null);
            residencialTemp.setIetapaOfert("TESTE ETAPA");
            residencialTemp.setIplatfOrign("API");
            residencialTemp.setIsitEvnto("NOK");

            residencialTemp.setDinicErro(LocalDateTime.now());
            residencialTemp.setDfimErro(null);
            residencialTemp.setDinclReg(LocalDateTime.now());
            residencialTemp.setDaltReg(null);

            listaResidencialTemp.add(residencialTemp);

            consultaApiResidencial.validarConexaoResidencialTemp(LocalDateTime.now(),connection,"MOBILE",
              "https://svp.dsv"
                + ".bradescoseguros.com"
                + ".br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",
              (LinkedList<TabelaTemp>) listaResidencialTemp,
              "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv");

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

}
