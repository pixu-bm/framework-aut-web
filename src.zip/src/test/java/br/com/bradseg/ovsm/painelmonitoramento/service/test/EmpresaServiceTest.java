package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EmpresaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.EmpresaServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados empresa service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class EmpresaServiceTest {

    @Mock
    private Utils utils;
    @Mock
    private EmpresaDao empresaDao;
    @InjectMocks
    private EmpresaServiceImpl empresaServiceImpl;

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterEmpresa() throws Exception {
        try {
            List<Empresa> lista = new ArrayList<>();
            lista.add(new Empresa());

            when(empresaDao.listarEmpresa()).thenReturn(lista); 

            List<Empresa> result = empresaServiceImpl.obterEmpresas();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    @Test
    void obterEmpresaEmptyResultDataAccessException() throws Exception {
        try {
            List<Empresa> lista = new ArrayList<>();
            lista.add(new Empresa());

            doThrow(EmptyResultDataAccessException.class).when(empresaDao).listarEmpresa();

            List<Empresa> result = empresaServiceImpl.obterEmpresas();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterEmpresaAcessoADadosException() throws Exception {
        try {
            List<Empresa> lista = new ArrayList<>();
            lista.add(new Empresa());

            doThrow(AcessoADadosException.class).when(empresaDao).listarEmpresa();

            List<Empresa> result = empresaServiceImpl.obterEmpresas();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    void obterCanalException() throws Exception {
        try {
            List<Empresa> lista = new ArrayList<>();
            lista.add(new Empresa());

            doThrow(new RuntimeException()).when(empresaDao).listarEmpresa();

            List<Empresa> result = empresaServiceImpl.obterEmpresas();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
