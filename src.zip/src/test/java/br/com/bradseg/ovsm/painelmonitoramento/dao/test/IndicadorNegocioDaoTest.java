package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.IndicadorNegocioDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.IndicadoresNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaEventoPorCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaIndicadoresNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.NumeroTransacoesRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.TipoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealVolumetriaMaximaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaVisaoNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@ExtendWith(MockitoExtension.class)
public class IndicadorNegocioDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;

    @InjectMocks
    private IndicadorNegocioDaoImpl indicadorNegocioDaoImpl;

    @Test
    void obterVolumetriaTempoRealVolumetriaMaxima() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealVolumetriaMaximaRowMapper.class))).thenReturn(null);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));

            VolumetriaTempoRealVolumetriaMaxima result = indicadorNegocioDaoImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(3, listaProduto, listaCanal, "01/01/2021", "15/03/2022");

            Assert.isNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(2, listaProduto, listaCanal,
                "01/01/2021", "15/03/2022");

            Assert.isNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(1, listaProduto, listaCanal,
                "01/01/2021", "15/03/2022");

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVolumetriaTempoRealVolumetriaMaximaAcessoADadosException
     * 
     * @throws Exception
     */
    @Test
    void obterVolumetriaTempoRealVolumetriaMaximaAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealVolumetriaMaximaRowMapper.class));
            indicadorNegocioDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(2, null, null, "", "");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoTest() throws Exception {
        try {

            List<VolumetriaTempoReal> listaIndicadoresVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal test = new VolumetriaTempoReal();
            test.setCodigoCanal(new BigDecimal(1));
            test.setCodigoEmpresa(new BigDecimal(1));
            test.setCodigoProduto(new BigDecimal(1));
            test.setDescCanal("Test");
            test.setDescProduto("Test");
            test.setHoraOcorrencia("02/02/2022");
            test.setMediaHistoricaTransacao(new BigDecimal(1));
            test.setTransacaoEvento(new BigDecimal(1));
            test.setTransacaoSemEvento(new BigDecimal(1));
            test.setVolumetriaAtualTransacao(new BigDecimal(1));
            listaIndicadoresVolumetriaTempoReal.add(test);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealRowMapper.class))).thenReturn(listaIndicadoresVolumetriaTempoReal);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            listaProduto.add(new BigDecimal(4));
            listaProduto.add(new BigDecimal(3));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));
            List<BigDecimal> listTipoEvento = new ArrayList<>();
            listTipoEvento.add(new BigDecimal(1));

            List<VolumetriaTempoReal> result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(3,
                listaProduto, listaCanal, "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(2, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(1, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoNullAndEmptyTest() throws Exception {
        try {

            List<VolumetriaTempoReal> listaIndicadoresVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal test = new VolumetriaTempoReal();
            test.setCodigoCanal(new BigDecimal(1));
            test.setCodigoEmpresa(new BigDecimal(1));
            test.setCodigoProduto(new BigDecimal(1));
            test.setDescCanal("Test");
            test.setDescProduto("Test");
            test.setHoraOcorrencia("02/02/2022");
            test.setMediaHistoricaTransacao(new BigDecimal(1));
            test.setTransacaoEvento(new BigDecimal(1));
            test.setTransacaoSemEvento(new BigDecimal(1));
            test.setVolumetriaAtualTransacao(new BigDecimal(1));
            listaIndicadoresVolumetriaTempoReal.add(test);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealRowMapper.class))).thenReturn(listaIndicadoresVolumetriaTempoReal);

            List<BigDecimal> listaProduto = new ArrayList<>();

            List<BigDecimal> listaCanal = new ArrayList<>();

            List<VolumetriaTempoReal> result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(3,
                null, null, "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(2, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(3,
                null, null, "02/02/20222", "02/02/20222");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Nenhum resultado encontrado."), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempo(3,
                null, null, "02/02/20222", "02/02/20222");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoRelatorioTest() throws Exception {
        try {

            List<VolumetriaTempoReal> listaIndicadoresVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal test = new VolumetriaTempoReal();
            test.setCodigoCanal(new BigDecimal(1));
            test.setCodigoEmpresa(new BigDecimal(1));
            test.setCodigoProduto(new BigDecimal(1));
            test.setDescCanal("Test");
            test.setDescProduto("Test");
            test.setHoraOcorrencia("02/02/2022");
            test.setMediaHistoricaTransacao(new BigDecimal(1));
            test.setTransacaoEvento(new BigDecimal(1));
            test.setTransacaoSemEvento(new BigDecimal(1));
            test.setVolumetriaAtualTransacao(new BigDecimal(1));
            listaIndicadoresVolumetriaTempoReal.add(test);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealRowMapper.class))).thenReturn(listaIndicadoresVolumetriaTempoReal);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            listaProduto.add(new BigDecimal(4));
            listaProduto.add(new BigDecimal(3));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));
            List<BigDecimal> listTipoEvento = new ArrayList<>();
            listTipoEvento.add(new BigDecimal(1));

            List<VolumetriaTempoReal> result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(3,
                listaProduto, listaCanal, "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(2, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(1, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoRelatorioNullAndEmptyTest() throws Exception {
        try {

            List<VolumetriaTempoReal> listaIndicadoresVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal test = new VolumetriaTempoReal();
            test.setCodigoCanal(new BigDecimal(1));
            test.setCodigoEmpresa(new BigDecimal(1));
            test.setCodigoProduto(new BigDecimal(1));
            test.setDescCanal("Test");
            test.setDescProduto("Test");
            test.setHoraOcorrencia("02/02/2022");
            test.setMediaHistoricaTransacao(new BigDecimal(1));
            test.setTransacaoEvento(new BigDecimal(1));
            test.setTransacaoSemEvento(new BigDecimal(1));
            test.setVolumetriaAtualTransacao(new BigDecimal(1));
            listaIndicadoresVolumetriaTempoReal.add(test);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealRowMapper.class))).thenReturn(listaIndicadoresVolumetriaTempoReal);

            List<BigDecimal> listaProduto = new ArrayList<>();

            List<BigDecimal> listaCanal = new ArrayList<>();

            List<VolumetriaTempoReal> result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(3,
                null, null, "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(2, listaProduto, listaCanal,
                "02/02/20222", "02/02/20222");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoRelatorioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(3,
                null, null, "02/02/20222", "02/02/20222");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Nenhum resultado encontrado."), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoRelatorioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoRelatorio(3,
                null, null, "02/02/20222", "02/02/20222");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAnteriorAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoAnterior(2,
                null, null, "20/20/2022", "20/20/2022");
        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAnteriorEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            Assert.isTrue(
                indicadorNegocioDaoImpl
                    .obterVolumetriaTempoRealFaixaTempoAnterior(2, null, null, "20/20/2022", "20/20/2022").isEmpty(),
                "Deve retornar Vazio");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAnteriorRelatorioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaTempoRealFaixaTempoAnteriorRelatorio(2,
                null, null, "20/20/2022", "20/20/2022");
        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoAnteriorRelatorioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            Assert.isTrue(
                indicadorNegocioDaoImpl
                    .obterVolumetriaTempoRealFaixaTempoAnteriorRelatorio(2, null, null, "20/20/2022", "20/20/2022")
                    .isEmpty(),
                "Deve retornar Vazio");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaVisaoNegocio() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaVisaoNegocioRowMapper.class))).thenReturn(null);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            listaProduto.add(new BigDecimal(4));
            listaProduto.add(new BigDecimal(3));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));

            List<VolumetriaVisaoNegocio> result = indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(3,
                listaProduto, listaCanal, new Date(), new Date());

            Assert.isNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(2, listaProduto, listaCanal,
                new Date(), new Date());

            Assert.isNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(1, listaProduto, listaCanal,
                new Date(), new Date());

            Assert.isNull(result, "Result não pode ser vazio");

            result = indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(1, listaProduto, listaCanal,
                null, null);

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaVisaoNegocioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaVisaoNegocioRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(1, null, null, null, null);

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaVisaoNegocioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaVisaoNegocioRowMapper.class));

            indicadorNegocioDaoImpl.obterVolumetriaVisaoNegocio(1, null, null, null, null);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventos() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("PRODUTO", "Teste");
            mapa.put("CANAL", "Teste");
            mapa.put("DURACAO", new BigDecimal(500));
            mapa.put("IMPACTO", new BigDecimal(500));
            mapa.put("RECORRENCIA", new BigDecimal(500));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);
            List<ComboRankingEventos> result = indicadorNegocioDaoImpl.obterRankingEventos(1, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

            result = indicadorNegocioDaoImpl.obterRankingEventos(2, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

            result = indicadorNegocioDaoImpl.obterRankingEventos(3, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosListaVazia() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);
            indicadorNegocioDaoImpl.obterRankingEventos(1, new Date(), new Date());

        } catch (EmptyResultDataAccessException e) {
            Assert.notNull(e, "deve ser erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            indicadorNegocioDaoImpl.obterRankingEventos(3, new Date(), new Date());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            indicadorNegocioDaoImpl.obterRankingEventos(3, new Date(), new Date());

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void relatorioRankingEventosTest() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("PRODUTO", "Teste");
            mapa.put("CANAL", "Teste");
            mapa.put("DURACAO", new BigDecimal(500));
            mapa.put("IMPACTO", new BigDecimal(500));
            mapa.put("RECORRENCIA", new BigDecimal(500));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);
            List<ComboRankingEventos> result = indicadorNegocioDaoImpl.relatorioRankingEventos(1, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

            result = indicadorNegocioDaoImpl.relatorioRankingEventos(2, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

            result = indicadorNegocioDaoImpl.relatorioRankingEventos(3, new Date(), new Date());

            Assert.notNull(result, "Deve retornar uma lista de Ranking Eventos");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioRankingEventosListaVazia() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);
            indicadorNegocioDaoImpl.relatorioRankingEventos(1, new Date(), new Date());

        } catch (EmptyResultDataAccessException e) {
            Assert.notNull(e, "deve ser erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioRankingEventosEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            indicadorNegocioDaoImpl.relatorioRankingEventos(3, new Date(), new Date());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioRankingEventosAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            indicadorNegocioDaoImpl.relatorioRankingEventos(3, new Date(), new Date());

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocio() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
            indicadoresNegocioTest.setTotalTransacoes(1000);
            indicadoresNegocioTest.setVendas(1000);
            indicadoresNegocioTest.setTempoTotalEventos("40:00:00");
            indicadoresNegocioTest.setTempoMedioEventos("20:00:00");
            indicadoresNegocioTest.setQtdEventos(1000);
            indicadoresNegocioTest.setTransacoesImpactadas(1000);
            indicadoresNegocioTest.setFrequenciaEventos(1000);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(IndicadoresNegocioRowMapper.class)))
                    .thenReturn(indicadoresNegocioTest);

            IndicadoresNegocio result = indicadorNegocioDaoImpl.obterIndicadoresNegocio(canal,
                produto, "01/01/2021", "15/03/2022");

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            canal = new ArrayList<>();
            produto = new ArrayList<>();

            result = indicadorNegocioDaoImpl.obterIndicadoresNegocio(canal,
                produto, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            result = indicadorNegocioDaoImpl.obterIndicadoresNegocio(null,
                null, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioEmptyResultDataAccessException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(IndicadoresNegocioRowMapper.class));

            indicadorNegocioDaoImpl.obterIndicadoresNegocio(canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioIndicadoresNegocioTest() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            List<IndicadoresNegocio> listaTest = new ArrayList<>();
            IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
            indicadoresNegocioTest.setTotalTransacoes(1000);
            indicadoresNegocioTest.setVendas(1000);
            indicadoresNegocioTest.setTempoTotalEventos("40:00:00");
            indicadoresNegocioTest.setTempoMedioEventos("20:00:00");
            indicadoresNegocioTest.setQtdEventos(1000);
            indicadoresNegocioTest.setTransacoesImpactadas(1000);
            indicadoresNegocioTest.setFrequenciaEventos(1000);
            listaTest.add(indicadoresNegocioTest);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaIndicadoresNegocioRowMapper.class)))
                    .thenReturn(listaTest);

            List<IndicadoresNegocio> result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocio(canal,
                produto, "01/01/2021", "15/03/2022");

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            canal = new ArrayList<>();
            produto = new ArrayList<>();

            result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocio(canal,
                produto, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocio(null,
                null, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioIndicadoresNegocioAcessoADadosException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaIndicadoresNegocioRowMapper.class));

            indicadorNegocioDaoImpl.relatorioIndicadoresNegocio(canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioComparacao() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
            indicadoresNegocioTest.setTotalTransacoes(1000);
            indicadoresNegocioTest.setVendas(1000);
            indicadoresNegocioTest.setTempoTotalEventos("40:00:00");
            indicadoresNegocioTest.setTempoMedioEventos("20:00:00");
            indicadoresNegocioTest.setQtdEventos(1000);
            indicadoresNegocioTest.setTransacoesImpactadas(1000);
            indicadoresNegocioTest.setFrequenciaEventos(1000);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(IndicadoresNegocioRowMapper.class)))
                    .thenReturn(indicadoresNegocioTest);

            IndicadoresNegocio result = indicadorNegocioDaoImpl.obterIndicadoresNegocioComparacao(canal,
                produto, "01/01/2021", "15/03/2022");

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioComparacaoEmptyResultDataAccessException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(IndicadoresNegocioRowMapper.class));

            indicadorNegocioDaoImpl.obterIndicadoresNegocioComparacao(canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioIndicadoresNegocioComparacaoTest() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            List<IndicadoresNegocio> listaTest = new ArrayList<>();
            IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
            indicadoresNegocioTest.setTotalTransacoes(1000);
            indicadoresNegocioTest.setVendas(1000);
            indicadoresNegocioTest.setTempoTotalEventos("40:00:00");
            indicadoresNegocioTest.setTempoMedioEventos("20:00:00");
            indicadoresNegocioTest.setQtdEventos(1000);
            indicadoresNegocioTest.setTransacoesImpactadas(1000);
            indicadoresNegocioTest.setFrequenciaEventos(1000);
            listaTest.add(indicadoresNegocioTest);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaIndicadoresNegocioRowMapper.class)))
                    .thenReturn(listaTest);

            List<IndicadoresNegocio> result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocioComparacao(canal,
                produto, "01/01/2021", "15/03/2022");

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            canal = new ArrayList<>();
            produto = new ArrayList<>();

            result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocioComparacao(canal,
                produto, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

            result = indicadorNegocioDaoImpl.relatorioIndicadoresNegocioComparacao(null,
                null, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioIndicadoresNegocioComparacaoAcessoADadosException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaIndicadoresNegocioRowMapper.class));

            indicadorNegocioDaoImpl.relatorioIndicadoresNegocioComparacao(canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Deve ser Verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void relatorioIndicadoresNegocioComparacaoEmptyResultDataAccessException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaIndicadoresNegocioRowMapper.class));

            indicadorNegocioDaoImpl.relatorioIndicadoresNegocioComparacao(canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (EmptyResultDataAccessException e) {

            Assert.notNull(e, "Deve retornar vazio");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterNumeroTransacao() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            NumeroTransacoes numeroTransacoesTest = new NumeroTransacoes();
            numeroTransacoesTest.setTotalTransacoes(500);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(NumeroTransacoesRowMapper.class)))
                    .thenReturn(numeroTransacoesTest);

            NumeroTransacoes result = indicadorNegocioDaoImpl.obterNumeroTransacao(1, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterNumeroTransacao(1, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterNumeroTransacao(2, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterNumeroTransacao(2, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterNumeroTransacao(3, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterNumeroTransacao(3, canal,
                produto, null, null);
            
            result = indicadorNegocioDaoImpl.obterNumeroTransacao(3, canal,
                produto, "", "");
            
            canal = new ArrayList<>();
            produto = new ArrayList<>();
            
            result = indicadorNegocioDaoImpl.obterNumeroTransacao(3, canal,
                produto, "", "");

            Assert.notNull(result, "Deve retornar um objeto NumeroTransacao");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterNumeroTransacaoAcessoADadosException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(NumeroTransacoesRowMapper.class));

            indicadorNegocioDaoImpl.obterNumeroTransacao(1, canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaEventoCanal() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            Canal canalTest = new Canal();
            canalTest.setCodigo(new BigDecimal(1));
            canalTest.setDescricao("Teste");

            EventoPorCanal eventoPorCanalTest = new EventoPorCanal();
            eventoPorCanalTest.setCanal(canalTest);
            eventoPorCanalTest.setQuantidadeEventoCanal(500);

            List<EventoPorCanal> listaEventoPorCanal = new ArrayList<>();
            listaEventoPorCanal.add(eventoPorCanalTest);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaEventoPorCanalRowMapper.class)))
                    .thenReturn(listaEventoPorCanal);

            List<EventoPorCanal> result = indicadorNegocioDaoImpl.obterListaEventoCanal(1, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterListaEventoCanal(1, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterListaEventoCanal(2, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterListaEventoCanal(2, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterListaEventoCanal(3, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterListaEventoCanal(3, canal,
                produto, null, null);

            Assert.notNull(result, "Deve retornar uma lista ListaEventoCanal");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaEventoCanalAcessoADadosException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaEventoPorCanalRowMapper.class));

            indicadorNegocioDaoImpl.obterListaEventoCanal(1, canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEvento() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            TipoEvento tipoEventoTest = new TipoEvento();
            tipoEventoTest.setQuantidadeTotalDisponibilidade(500);
            tipoEventoTest.setQuantidadeTotalFuncionalidade(500);
            tipoEventoTest.setQuantidadeTotalTipoEvento(500);
            tipoEventoTest.setQuantidadeTotalVolumetria(500);

            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(TipoEventoRowMapper.class)))
                    .thenReturn(tipoEventoTest);

            TipoEvento result = indicadorNegocioDaoImpl.obterTipoEvento(1, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterTipoEvento(1, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterTipoEvento(2, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterTipoEvento(2, canal,
                produto, null, null);

            result = indicadorNegocioDaoImpl.obterTipoEvento(3, canal,
                produto, "01/01/2021", "15/03/2022");
            
            result = indicadorNegocioDaoImpl.obterTipoEvento(3, canal,
                produto, null, null);

            Assert.notNull(result, "Deve retornar um objeto Indicador Negocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTipoEventoAcessoADadosException() throws Exception {
        try {
            List<BigDecimal> canal = new ArrayList<>();
            List<BigDecimal> produto = new ArrayList<>();
            canal.add(new BigDecimal(1));
            produto.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(TipoEventoRowMapper.class));

            indicadorNegocioDaoImpl.obterTipoEvento(1, canal,
                produto, "01/01/2021", "15/03/2022");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
