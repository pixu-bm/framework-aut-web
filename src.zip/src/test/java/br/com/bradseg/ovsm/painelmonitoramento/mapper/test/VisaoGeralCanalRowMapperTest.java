package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoGeralCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class VisaoGeralCanalRowMapperTest {

    @InjectMocks
    private VisaoGeralCanalRowMapper visaoGeralCanalRowMapper;

    @Test
    void testeVisaoGeralCanalRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CCANAL_DGTAL_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("ICANAL_DGTAL_PNEL")).thenReturn("email@email.com");
            Mockito.when(resultSetMock.getInt("SOMA_EVENTO_GRAVE")).thenReturn(2);
            Mockito.when(resultSetMock.getInt("SOMA_EVENTO_MODERADO")).thenReturn(2);
            Mockito.when(resultSetMock.getInt("SOMA_EVENTO_VOLUMETRIA")).thenReturn(2);
            Mockito.when(resultSetMock.getInt("SOMA_EVENTO_DISP")).thenReturn(2);
            Mockito.when(resultSetMock.getInt("SOMA_EVENTO_FUNC")).thenReturn(2);
            Mockito.when(resultSetMock.getInt("SOMA_TRANSACAO")).thenReturn(2);
            VisaoGeralCanal visao = visaoGeralCanalRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(visao, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
