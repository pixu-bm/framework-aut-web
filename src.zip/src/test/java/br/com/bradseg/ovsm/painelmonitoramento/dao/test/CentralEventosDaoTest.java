package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.CentralEventosDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados de CentralEventosDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
class CentralEventosDaoTest {
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private CentralEventosDaoImpl centralEventosDaoImpl;


    void obterVisaoEventoAberto() throws Exception {
        try {
            VisaoEvento evento = new VisaoEvento();
            evento.setPorcentagemEventosDisponibilidade(100);
            evento.setPorcentagemEventosFuncionalidade(100);
            evento.setPorcentagemEventosVolumetria(200);
            evento.setPorcentagemTransacaoImpactada(120);
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoEventoRowMapper.class))).thenReturn(evento);

            String dataStrinInicio = "30/11/2021";
            String dataStringFim = "23/12/2021";

            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(
                    Utils.strDateFmtBrasilToJavaDate(dataStrinInicio), Utils.strDateFmtBrasilToJavaDate(dataStringFim));

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterPorcentagemVisaoEventoAbertoEmptyResultDataAccessException() throws Exception {

        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterPorcentagemVisaoEventoAbertoException() throws Exception {

        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
              Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterPorcentagemVisaoEventoAbertoAnterior(new Date(), new Date());

        } catch (RuntimeException e) {
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }


    @Test
    void obterPorcentagemVisaoEventoAbertoAcessoADadosException () throws Exception {

        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
              Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterPorcentagemVisaoEventoAbertoAnterior(new Date(), new Date());

        } catch (RuntimeException  e) {
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoAnteriorEmptyResultDataAccessException() throws Exception {

        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new Date(), new Date());

        } catch (RuntimeException e) {
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoProdutoAnteriorException() throws Exception {

        try {
            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoEmptyResultDataAccessException() throws Exception {
        try {

            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoAbertoException() throws Exception {
        try {
            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProduto() throws Exception {
        try {
            List<VisaoEventoProduto> listaVisaoEventoProduto = new ArrayList<>();
            VisaoEventoProduto visao = new VisaoEventoProduto();
            visao.setCodigoProduto(new BigDecimal(1));
            visao.setQuantidadeOcorrencia(12);
            visao.setPorcentagemOcorrencia(1);
            listaVisaoEventoProduto.add(visao);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoProdutoRowMapper.class))).thenReturn(listaVisaoEventoProduto);

            String dataStrinInicio = "30/11/2021";
            String dataStringFim = "23/12/2021";

            List<VisaoEventoProduto> lista = centralEventosDaoImpl.obterVisaoEventoProduto(
                    Utils.strDateFmtBrasilToJavaDate(dataStrinInicio), Utils.strDateFmtBrasilToJavaDate(dataStringFim));
            // VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new
            // Date(), new Date());

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoProdutoListaEmpty() throws Exception {
        try {
            List<VisaoEventoProduto> listaVisaoEventoProduto = new ArrayList<>();

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoProdutoRowMapper.class))).thenReturn(listaVisaoEventoProduto);

            String dataStrinInicio = "30/11/2021";
            String dataStringFim = "23/12/2021";

            List<VisaoEventoProduto> lista = centralEventosDaoImpl.obterVisaoEventoProduto(
                    Utils.strDateFmtBrasilToJavaDate(dataStrinInicio), Utils.strDateFmtBrasilToJavaDate(dataStringFim));

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (AcessoADadosException ex) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoProdutoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoProdutoRowMapper.class));
            List<VisaoEventoProduto> lista = centralEventosDaoImpl.obterVisaoEventoProduto(new Date(), new Date());
            // VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new
            // Date(), new Date());

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoProdutoRowMapper.class));
            List<VisaoEventoProduto> lista = centralEventosDaoImpl.obterVisaoEventoProduto(new Date(), new Date());
            // VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new
            // Date(), new Date());

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanal() throws Exception {
        try {
            List<VisaoEventoCanal> listaVisaoEventoCanal = new ArrayList<>();
            VisaoEventoCanal visao = new VisaoEventoCanal();
            visao.setCodigoCanal(new BigDecimal(1));
            visao.setQuantidadeOcorrencia(12);
            visao.setPorcentagemOcorrencia(1);
            listaVisaoEventoCanal.add(visao);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoCanalRowMapper.class))).thenReturn(listaVisaoEventoCanal);

            String dataStrinInicio = "30/11/2021";
            String dataStringFim = "23/12/2021";

            List<VisaoEventoCanal> lista = centralEventosDaoImpl.obterVisaoEventoCanal(
                    Utils.strDateFmtBrasilToJavaDate(dataStrinInicio), Utils.strDateFmtBrasilToJavaDate(dataStringFim));

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalListaEmpty() throws Exception {
        try {
            List<VisaoEventoCanal> listaVisaoEventoCanal = new ArrayList<>();

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoCanalRowMapper.class))).thenReturn(listaVisaoEventoCanal);

            String dataStrinInicio = "30/11/2021";
            String dataStringFim = "23/12/2021";

            List<VisaoEventoCanal> lista = centralEventosDaoImpl.obterVisaoEventoCanal(
                    Utils.strDateFmtBrasilToJavaDate(dataStrinInicio), Utils.strDateFmtBrasilToJavaDate(dataStringFim));

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (AcessoADadosException ex) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoCanalRowMapper.class));
            List<VisaoEventoCanal> lista = centralEventosDaoImpl.obterVisaoEventoCanal(new Date(), new Date());
            // VisaoEvento visaoEvento = centralEventosDaoImpl.obterVisaoEventoAberto(new
            // Date(), new Date());

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoCanalException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaVisaoEventoCanalRowMapper.class));
            List<VisaoEventoCanal> lista = centralEventosDaoImpl.obterVisaoEventoCanal(new Date(), new Date());

            Assert.notNull(lista, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEvento() throws Exception {
        try {

            List<BigDecimal> listaCodigoProduto = new ArrayList<>();
            listaCodigoProduto.add(new BigDecimal(1));
            listaCodigoProduto.add(new BigDecimal(5));

            List<BigDecimal> listaCodigoCanal = new ArrayList<>();
            listaCodigoCanal.add(new BigDecimal(1));
            listaCodigoCanal.add(new BigDecimal(4));
            Integer statusEvento = 1;
            Date dataInicio = new Date();
            Date dataFim = new Date();
            BigDecimal codigoTipoEvento = new BigDecimal(3);

            List<RegistroEvento> listaRegistroTest = new ArrayList<>();
            RegistroEvento evento = new RegistroEvento();
            evento.setCodigo(new BigDecimal(1));

            listaRegistroTest.add(evento);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaRegistroEventoRowMapper.class))).thenReturn(listaRegistroTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CSIT_EVNTO_PNEL", new BigDecimal(1));
            mapa.put("ISIT_EVNTO_PNEL", "Teste");
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);

            List<RegistroEvento> listaRegistro = centralEventosDaoImpl.obterRegistroEvento(listaCodigoProduto,
                    listaCodigoCanal, statusEvento,
                    dataInicio, dataFim, codigoTipoEvento);

            // List<VisaoEventoCanal> lista =
            // centralEventosDaoImpl.obterVisaoEventoCanal(new Date(), new Date());

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoEmptyDataResult() throws Exception {
        try {

            List<BigDecimal> listaCodigoProduto = new ArrayList<>();
            listaCodigoProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCodigoCanal = new ArrayList<>();
            listaCodigoCanal.add(new BigDecimal(1));
            Integer statusEvento = 1;
            Date dataInicio = new Date();
            Date dataFim = new Date();
            BigDecimal codigoTipoEvento = new BigDecimal(3);

            List<RegistroEvento> listaRegistroTest = new ArrayList<>();
            RegistroEvento evento = new RegistroEvento();
            evento.setCodigo(new BigDecimal(1));

            listaRegistroTest.add(evento);

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaRegistroEventoRowMapper.class));
            List<RegistroEvento> listaRegistro = centralEventosDaoImpl.obterRegistroEvento(listaCodigoProduto,
                    listaCodigoCanal, statusEvento,
                    dataInicio, dataFim, codigoTipoEvento);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoException() throws Exception {
        try {

            List<BigDecimal> listaCodigoProduto = new ArrayList<>();
            listaCodigoProduto.add(new BigDecimal(1));

            List<BigDecimal> listaCodigoCanal = new ArrayList<>();
            listaCodigoCanal.add(new BigDecimal(1));
            Integer statusEvento = 1;
            Date dataInicio = new Date();
            Date dataFim = new Date();
            BigDecimal codigoTipoEvento = new BigDecimal(3);

            List<RegistroEvento> listaRegistroTest = new ArrayList<>();
            RegistroEvento evento = new RegistroEvento();
            evento.setCodigo(new BigDecimal(1));

            listaRegistroTest.add(evento);

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ListaRegistroEventoRowMapper.class));
            List<RegistroEvento> listaRegistro = centralEventosDaoImpl.obterRegistroEvento(listaCodigoProduto,
                    listaCodigoCanal, statusEvento,
                    dataInicio, dataFim, codigoTipoEvento);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalhe() throws Exception {
        try {

            VisaoGeralProduto visaoTest = new VisaoGeralProduto();
            visaoTest.setCodigoProduto(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralProdutoRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(1));
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);

            VisaoGeralProduto visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(3));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(2, new BigDecimal(2));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(4, new BigDecimal(3));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheEmptyResultDataAccessException() throws Exception {
        try {

            VisaoGeralProduto visaoTest = new VisaoGeralProduto();
            visaoTest.setCodigoProduto(new BigDecimal(2));

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralProdutoRowMapper.class));

            VisaoGeralProduto visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheException() throws Exception {
        try {

            VisaoGeralProduto visaoTest = new VisaoGeralProduto();
            visaoTest.setCodigoProduto(new BigDecimal(2));

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralProdutoRowMapper.class));

            VisaoGeralProduto visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalhe() throws Exception {
        try {

            VisaoGeralCanal visaoTest = new VisaoGeralCanal();
            visaoTest.setCodigoCanal(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralCanalRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CPRODT_PNEL", new BigDecimal(1));
            mapa.put("IPRODT", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class))).thenReturn(listaMapa);

            VisaoGeralCanal visao = centralEventosDaoImpl
                    .obterVisaoEventoCanalDetalhe(1, new BigDecimal(1));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));
            visao = centralEventosDaoImpl
                    .obterVisaoEventoCanalDetalhe(1, new BigDecimal(3));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralCanalRowMapper.class));

            VisaoGeralCanal visao = centralEventosDaoImpl
                    .obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoCanalDetalheException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralCanalRowMapper.class));

            VisaoGeralCanal visao = centralEventosDaoImpl
                    .obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheAnteriorEmpty() throws Exception {
        try {

            VisaoGeralProduto visaoTest = new VisaoGeralProduto();
            visaoTest.setCodigoProduto(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralProdutoRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(1));
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            doThrow(EmptyResultDataAccessException.class).when(
                    jdbcTemplate).queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            VisaoGeralProduto visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheAnteriorException() throws Exception {
        try {

            VisaoGeralProduto visaoTest = new VisaoGeralProduto();
            visaoTest.setCodigoProduto(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralProdutoRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(1));
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            doThrow(new RuntimeException()).when(
                    jdbcTemplate).queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            VisaoGeralProduto visao = centralEventosDaoImpl
                    .obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.notNull(visao, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheAnteriorEmpty() throws Exception {
        try {

            VisaoGeralCanal visaoTest = new VisaoGeralCanal();
            visaoTest.setCodigoCanal(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralCanalRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CPRODT_PNEL", new BigDecimal(1));
            mapa.put("IPRODT", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class));

            centralEventosDaoImpl.obterVisaoEventoCanalDetalhe(1, new BigDecimal(1));

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoCanalDetalheAnteriorException() throws Exception {
        try {

            VisaoGeralCanal visaoTest = new VisaoGeralCanal();
            visaoTest.setCodigoCanal(new BigDecimal(2));

            when(jdbcTemplate.queryForObject(
                    Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(VisaoGeralCanalRowMapper.class))).thenReturn(visaoTest);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CPRODT_PNEL", new BigDecimal(1));
            mapa.put("IPRODT", "Teste");
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            mapa.put("SOMA_EVENTO_GRAVE", new BigDecimal(2));
            mapa.put("SOMA_EVENTO_MODERADO", new BigDecimal(2));
            mapa.put("SOMA_TRANSACAO", new BigDecimal(2));
            listaMapa.add(mapa);

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForList(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class));

            centralEventosDaoImpl.obterVisaoEventoCanalDetalhe(1, new BigDecimal(1));

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterStatusDetalheEvento() throws Exception {
        try {

            centralEventosDaoImpl.obterStatusDetalheEvento(1, new BigDecimal(1), new BigDecimal(1),
                    new BigDecimal(1), new Date(), 1, 1);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalheEventoRelacionados() throws Exception {
        try {

            centralEventosDaoImpl.obterDetalheEventoRelacionados(1, 1, 1);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterTotalEventoRelacionados() throws Exception {
        try {

            centralEventosDaoImpl.obterTotalEventoRelacionados(1);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterGraficoDetalheEvento() throws Exception {
        try {

            centralEventosDaoImpl.obterGraficoDetalheEvento(1, new BigDecimal(1),
                    new BigDecimal(1), new BigDecimal(1), new Date());

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaSituacaoEventoEmpty() throws Exception {
        try {

            centralEventosDaoImpl.obterListaSituacaoEvento();

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

        void obterListaSituacaoEventoException() throws Exception {
        try {
            doThrow(new RuntimeException()).when(jdbcTemplate)
                    .queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            centralEventosDaoImpl.obterListaSituacaoEvento();

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void avaliarListaVisaoEventoCanalTest() throws Exception {
        try {
            List<VisaoEventoCanal> listaVisaoEventoProduto = new ArrayList<>();
            VisaoEventoCanal visaoEventoCanalTeste = new VisaoEventoCanal();
            visaoEventoCanalTeste.setCodigoCanal(new BigDecimal(1));
            visaoEventoCanalTeste.setPorcentagemOcorrencia(1);
            listaVisaoEventoProduto.add(visaoEventoCanalTeste);

            centralEventosDaoImpl.avaliarListaVisaoEventoCanal(listaVisaoEventoProduto, listaVisaoEventoProduto);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
