 package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaVisaoNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

@ExtendWith(MockitoExtension.class)
public class VolumetriaVisaoNegocioRowMapperTest {

    @InjectMocks
    private VolumetriaVisaoNegocioRowMapper volumetriaVisaoNegocioRowMapper;

    
    @Test
    void testeRelacionadosDetalheEventoRowMapper() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CCANAL_DGTAL_PNEL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("ICANAL_DGTAL_PNEL")).thenReturn("teste");
            Mockito.when(resultSetMock.getBigDecimal("VOLUME_TRANSACAO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("HISTORICO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("VOLUMETRIA_MAXIMA")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_TOTAL_EVENTO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_DISPN")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_FUNC")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("EVNTO_NORML_CNXAO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_EVENTO_GRAVE")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);
            
            List<VolumetriaVisaoNegocio> registro = volumetriaVisaoNegocioRowMapper.mapRow(resultSetMock, 0);
            Assert.notNull(registro, "nao pode nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

}
