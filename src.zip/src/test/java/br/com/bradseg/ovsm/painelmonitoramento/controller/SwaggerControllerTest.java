package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.SwaggerController;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.util.Assert;
import org.springframework.web.servlet.ModelAndView;

@ExtendWith(MockitoExtension.class)
public class SwaggerControllerTest {

    @InjectMocks
    SwaggerController swagger;

    /**
     * Teste login usuario portal
     * @throws Exception
     */

    @Test
    void testeSwager() throws Exception {

        try {

            ModelAndView view = swagger.open();

            Assert.isTrue(view.getStatus().equals(HttpStatus.OK), "Não retornou com sucesso");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
