package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiCaptalizacaoRowMapperTest {

    @InjectMocks
    private ConsultaApiCaptalizacaoRowMapper consultaApiRowMapper;

    @Test
    void testeConsultaApi() throws Exception {
        try {

            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("DINCL_REG")).thenReturn("Teste");

            String teste = consultaApiRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(teste, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
