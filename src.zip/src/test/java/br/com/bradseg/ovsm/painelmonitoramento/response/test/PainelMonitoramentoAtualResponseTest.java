package br.com.bradseg.ovsm.painelmonitoramento.response.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.PainelMonitoramentoAtualResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.StatusDetalheEventoResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class PainelMonitoramentoAtualResponseTest {

    /**
     * Teste testeException
     *
     * @throws Exception
     */
    
    @InjectMocks
    private PainelMonitoramentoAtualResponse painelMonitoramentoAtualResponseTest;
    @Test
    void testeStatusDetalheEventoResponseTest() throws Exception {
        try {

            PainelMonitoramentoAtualResponse painelMonitoramentoAtualResponseTest = new PainelMonitoramentoAtualResponse();
            PainelMonitoramentoAtual painel = new PainelMonitoramentoAtual();
            painel.setCodigoRetorno(1);

            painelMonitoramentoAtualResponseTest.setPainel(painel);;
            painel = painelMonitoramentoAtualResponseTest.getPainel();
            Assert.notNull(painel, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
