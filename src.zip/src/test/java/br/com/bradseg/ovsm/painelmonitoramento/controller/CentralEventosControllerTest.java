package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.CentralEventosController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CentralEventosService;

/**
 * Classe implementa test automatizados gestão acesso perfil
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
class CentralEventosControllerTest {

    @Mock
    private CentralEventosService centralEventosService;
    @InjectMocks
    private CentralEventosController centralEventosController;

    @Test
    void obterVisaoEventoAberto() throws Exception {

        try {

            when(centralEventosService.obterVisaoEventoAberto(Mockito.any(), Mockito.any()))
                .thenReturn(new VisaoEvento());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAberto("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoAberto(Mockito.any(), Mockito.any());
            centralEventosController.obterVisaoEventoAberto("10/10/2021", "10/11/2021");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoAcessoADadosException() throws Exception {

        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoAberto(Mockito.any(), Mockito.any());
            centralEventosController.obterVisaoEventoAberto("10/10/2021", "10/11/2021");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProduto() throws Exception {

        try {

            when(centralEventosService.obterVisaoEventoProduto(Mockito.any(), Mockito.any()))
                .thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProdutoEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProduto(Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProdutoAcessoADadosException() throws Exception {

        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterVisaoEventoProduto(Mockito.any(),
                Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanal() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoCanal(Mockito.any(), Mockito.any()))
                .thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanalEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoCanal(Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanalAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService).obterVisaoEventoCanal(Mockito.any(),
                Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEvento() throws Exception {
        try {

            when(centralEventosService.obterRegistroEvento(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalhe() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any()))
                .thenReturn(new VisaoGeralProduto());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalhe() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any()))
                .thenReturn(new VisaoGeralCanal());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcel() throws Exception {
        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");
            int count = 0;
            int countSheet = 0;
            Row row = sheet.createRow(countSheet);

            row.createCell(count).setCellValue("Gravidade");
            count++;
            row.createCell(count).setCellValue("Produto");
            count++;
            row.createCell(count).setCellValue("Canal");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Transação");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Data Inicio Evento");
            count++;
            row.createCell(count).setCellValue("Recorrencia");

            when(centralEventosService.obterRegistroEventoExcel(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(wb);
            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelAcessoADadoEx() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEventoExcel(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelEmpty() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEventoExcel(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsv() throws Exception {
        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");
            int count = 0;
            int countSheet = 0;
            Row row = sheet.createRow(countSheet);

            row.createCell(count).setCellValue("Gravidade");
            count++;
            row.createCell(count).setCellValue("Produto");
            count++;
            row.createCell(count).setCellValue("Canal");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Transação");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Data Inicio Evento");
            count++;
            row.createCell(count).setCellValue("Recorrencia");

            when(centralEventosService.obterRegistroEventoExcel(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(wb);
            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv(
                "10/10/2021", "10/11/2021", new ArrayList<>(), new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsvAcessoADadoEx() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEventoExcel(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsvEmpty() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEventoExcel(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterStatusDetalhesEventoTest() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterStatusDetalhesEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()), 10, 10);

            Assert.isTrue(result.getBody().getMensagem().equals(Constantes.SUCESSO), "sucesso");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterStatusDetalhesEventoAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterStatusDetalheEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            centralEventosController.obterStatusDetalhesEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()), 10, 10);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterStatusDetalhesEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterStatusDetalheEvento(
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            centralEventosController.obterStatusDetalhesEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()), 10, 10);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterGraficoDetalheEventoTest() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterGraficoDetalheEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()));

            Assert.isTrue(result.getBody().getMensagem().equals(Constantes.SUCESSO), "sucesso");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterGraficoDetalheEventoAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterGraficoDetalheEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any());

            centralEventosController.obterGraficoDetalheEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()));

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterGraficoDetalheEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterGraficoDetalheEvento(
                Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(),
                Mockito.any());

            centralEventosController.obterGraficoDetalheEvento(10,
                new BigDecimal(10), new BigDecimal(10), new BigDecimal(10), Date.from(Instant.now()));

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalheEventoRelacionadosTest() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterDetalheEventoRelacionados(10, 10, 10);

            Assert.isTrue(result.getBody().getMensagem().equals(Constantes.SUCESSO), "sucesso");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalheEventoRelacionadosAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterTotalEventoRelacionados(Mockito.any());

            centralEventosController.obterDetalheEventoRelacionados(10, 10, 10);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalheEventoRelacionadosEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterTotalEventoRelacionados(Mockito.any());

            centralEventosController.obterDetalheEventoRelacionados(10, 10, 10);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoPDFTest() throws Exception {
        try {

            ByteArrayInputStream bt = new ByteArrayInputStream(new byte[] {(byte) 0xe0, 0x4f, (byte) 0xd0,
                0x20, (byte) 0xea, 0x3a, 0x69, 0x10, (byte) 0xa2, (byte) 0xd8, 0x08, 0x00, 0x2b,
                0x30, 0x30, (byte) 0x9d});

            when(centralEventosService.obterRegistroEventoPDF(Mockito.anyList(), Mockito.anyList(), Mockito.anyInt(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(bt);

            ResponseEntity<InputStreamResource> result = centralEventosController
                .obterRegistroEventoPDF("teste", "teste", new ArrayList<>(), new ArrayList<>(),
                    10, new BigDecimal(10), "Teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Ok");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoPDFAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterRegistroEventoPDF(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any());

            centralEventosController.obterRegistroEventoPDF("teste", "teste",
                new ArrayList<>(), new ArrayList<>(),
                10, new BigDecimal(10), "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoPDFEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterRegistroEventoPDF(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any());

            centralEventosController.obterRegistroEventoPDF("teste", "teste",
                new ArrayList<>(), new ArrayList<>(),
                10, new BigDecimal(10), "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalhePDFTest() throws Exception {
        try {

            ByteArrayInputStream bt = new ByteArrayInputStream(new byte[] {(byte) 0xe0, 0x4f, (byte) 0xd0,
                0x20, (byte) 0xea, 0x3a, 0x69, 0x10, (byte) 0xa2, (byte) 0xd8, 0x08, 0x00, 0x2b,
                0x30, 0x30, (byte) 0x9d});

            when(centralEventosService.obterVisaoEventoProdutoCanalDetalhePDF(Mockito.anyInt(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyString())).thenReturn(bt);

            ResponseEntity<InputStreamResource> result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalhePDF(1, new ArrayList<>(), new ArrayList<>(), "Teste");

            result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalhePDF(2, new ArrayList<>(), new ArrayList<>(), "Teste");

            result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalhePDF(3, new ArrayList<>(), new ArrayList<>(), "Teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Ok");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalhePDFAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoCanalDetalhePDF(Mockito.anyInt(), Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoProdutoCanalDetalhePDF(1, new ArrayList<>(), new ArrayList<>(),
                "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalhePDFEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProdutoCanalDetalhePDF(Mockito.anyInt(), Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoProdutoCanalDetalhePDF(1, new ArrayList<>(), new ArrayList<>(),
                "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalheExcelCsvTest() throws Exception {
        try {

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));

            when(centralEventosService.obterVisaoEventoProdutoCanalDetalheExcelCsv(Mockito.anyInt(),
                Mockito.anyList(), Mockito.anyList(),
                Mockito.anyString())).thenReturn(new HSSFWorkbook());

            ResponseEntity<StreamingResponseBody> result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalheExcelCsv(1, 1, list, list, "Teste");

            result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalheExcelCsv(2, 2, list, list, "Teste");

            result = centralEventosController
                .obterVisaoEventoProdutoCanalDetalheExcelCsv(3, 1, list, list, "Teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Ok");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalheExcelCsvAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoCanalDetalheExcelCsv(Mockito.anyInt(), Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoProdutoCanalDetalheExcelCsv(1, 1, new ArrayList<>(),
                new ArrayList<>(),
                "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoCanalDetalheExcelCsvEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProdutoCanalDetalheExcelCsv(Mockito.anyInt(), Mockito.anyList(), Mockito.anyList(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoProdutoCanalDetalheExcelCsv(1, 1, new ArrayList<>(),
                new ArrayList<>(),
                "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalhePDFTest() throws Exception {
        try {

            ByteArrayInputStream bt = new ByteArrayInputStream(new byte[] {(byte) 0xe0, 0x4f, (byte) 0xd0,
                0x20, (byte) 0xea, 0x3a, 0x69, 0x10, (byte) 0xa2, (byte) 0xd8, 0x08, 0x00, 0x2b,
                0x30, 0x30, (byte) 0x9d});

            when(centralEventosService.obterVisaoEventoDetalhadoPDF(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.anyString())).thenReturn(bt);

            ResponseEntity<InputStreamResource> result = centralEventosController
                .obterVisaoEventoDetalhePDF(1, new BigDecimal(1), new BigDecimal(1), new BigDecimal(1),
                    Date.from(Instant.now()), 1, 1, "Teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Ok");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalhePDFAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoDetalhadoPDF(Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoDetalhePDF(1, new BigDecimal(1), new BigDecimal(1),
                new BigDecimal(1),
                Date.from(Instant.now()), 1, 1, "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalhePDFEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoDetalhadoPDF(Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoDetalhePDF(1, new BigDecimal(1), new BigDecimal(1),
                new BigDecimal(1),
                Date.from(Instant.now()), 1, 1, "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalheExcelCsvTest() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoDetalhadoExcelCsv(Mockito.anyInt(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.anyString())).thenReturn(new HSSFWorkbook());

            ResponseEntity<StreamingResponseBody> result = centralEventosController
                .obterVisaoEventoDetalheExcelCsv(1, 1, new BigDecimal(1), new BigDecimal(1), new BigDecimal(1),
                    Date.from(Instant.now()), 1, 1, "Teste");

            result = centralEventosController
                .obterVisaoEventoDetalheExcelCsv(2, 1, new BigDecimal(1), new BigDecimal(1), new BigDecimal(1),
                    Date.from(Instant.now()), 1, 1, "Teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Ok");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalheExcelCsvAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoDetalhadoExcelCsv(Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoDetalheExcelCsv(1, 1, new BigDecimal(1), new BigDecimal(1),
                new BigDecimal(1),
                Date.from(Instant.now()), 1, 1, "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoDetalheExcelCsvEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoDetalhadoExcelCsv(Mockito.anyInt(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(),
                    Mockito.anyString());

            centralEventosController.obterVisaoEventoDetalheExcelCsv(1, 1, new BigDecimal(1), new BigDecimal(1),
                new BigDecimal(1),
                Date.from(Instant.now()), 1, 1, "Teste");

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
