package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.CentralEventosController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CentralEventosService;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.lowagie.text.DocumentException;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso perfil
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
class CentralEventosControllerTest {

    @Mock
    private CentralEventosService centralEventosService;
    @InjectMocks
    private CentralEventosController centralEventosController;

    @Test
    void obterVisaoEventoAberto() throws Exception {

        try {

            when(centralEventosService.obterVisaoEventoAberto(Mockito.any(), Mockito.any()))
                .thenReturn(new VisaoEvento());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAberto("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoAberto(Mockito.any(), Mockito.any());
            // when(centralEventosService.obterVisaoEventoAberto(Mockito.any(), Mockito.any())).thenReturn(new VisaoEvento());
            centralEventosController.obterVisaoEventoAberto("10/10/2021", "10/11/2021");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProduto() throws Exception {

        try {

            when(centralEventosService.obterVisaoEventoProduto(Mockito.any(), Mockito.any()))
                .thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProdutoEmptyResultDataAccessException() throws Exception {

        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProduto(Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProdutoAcessoADadosException() throws Exception {

        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterVisaoEventoProduto(Mockito.any(),
                Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController
                .obterVisaoEventoAbertoProduto("10/10/2021", "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void obterVisaoEventoAbertoCanal() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoCanal(Mockito.any(), Mockito.any()))
                .thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanalEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoCanal(Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanalAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService).obterVisaoEventoCanal(Mockito.any(),
                Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoAbertoCanal("10/10/2021",
                "10/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void obterRegistroEvento() throws Exception {
        try {

            when(centralEventosService.obterRegistroEvento(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEvento(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterRegistroEvento("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalhe() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any()))
                .thenReturn(new VisaoGeralProduto());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoProdutoDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoProdutoDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalhe() throws Exception {
        try {

            when(centralEventosService.obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any()))
                .thenReturn(new VisaoGeralCanal());
            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService)
                .obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService)
                .obterVisaoEventoCanalDetalhe(Mockito.anyInt(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = centralEventosController.obterVisaoEventoCanalDetalhe(2,
                new BigDecimal(1));

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void obterRegistroEventoExcel() throws Exception {
        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");
            int count = 0;
            int countSheet = 0;
            Row row = sheet.createRow(countSheet);

            row.createCell(count).setCellValue("Gravidade");
            count++;
            row.createCell(count).setCellValue("Produto");
            count++;
            row.createCell(count).setCellValue("Canal");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Transação");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Data Inicio Evento");
            count++;
            row.createCell(count).setCellValue("Recorrencia");

            when(centralEventosService.obterRegistroEventoExcel(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(wb);
            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelAcessoADadoEx() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEventoExcel(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcelEmpty() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEventoExcel(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<StreamingResponseBody> result = centralEventosController.obterRegistroEventoExcel(
                "10/10/2021", "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsv() throws Exception {
        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");
            int count = 0;
            int countSheet = 0;
            Row row = sheet.createRow(countSheet);

            row.createCell(count).setCellValue("Gravidade");
            count++;
            row.createCell(count).setCellValue("Produto");
            count++;
            row.createCell(count).setCellValue("Canal");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Transação");
            count++;
            row.createCell(count).setCellValue("Tipo");
            count++;
            row.createCell(count).setCellValue("Data Inicio Evento");
            count++;
            row.createCell(count).setCellValue("Recorrencia");

            when(centralEventosService.obterRegistroEventoExcel(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(wb);
            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv(
                "10/10/2021", "10/11/2021", new ArrayList<>(), new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsvAcessoADadoEx() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(centralEventosService).obterRegistroEventoExcel(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoCsvEmpty() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosService).obterRegistroEventoExcel(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<InputStreamResource> result = centralEventosController.obterRegistroEventoCsv("10/10/2021",
                "10/11/2021", new ArrayList<>(),
                new ArrayList<>(), 2, new BigDecimal(2), "M232640");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), "Falhou");
        } catch (ResponseStatusException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
