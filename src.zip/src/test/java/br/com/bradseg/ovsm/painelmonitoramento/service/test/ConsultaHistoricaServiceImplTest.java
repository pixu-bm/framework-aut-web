package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConsultaHistoricaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.ConsultaHistoricaServiceExport;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.ConsultaHistoricaServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaServiceImplTest {

    @Mock
    private ConsultaHistoricaServiceExport export;

    @Mock
    private ConsultaHistoricaDao consultaHistoricaDao;

    @InjectMocks
    private ConsultaHistoricaServiceImpl consultaHistoricaServiceImpl;

    @Test
    void exportarExcelTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            List<ConsultaHistorica> lista = new ArrayList<>();
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setDuracaoDisp(10000L);
            consulta.setDuracaoFunc(10000L);
            consulta.setDuracaoVolu(10000L);

            lista.add(consulta);

            when(consultaHistoricaDao.obterHistorico(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            consultaHistoricaServiceImpl.exportarExcel(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarExcelParseSubrotina() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            List<ConsultaHistorica> lista = new ArrayList<>();
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setDuracaoDisp(10000L);
            consulta.setDuracaoFunc(10000L);
            consulta.setDuracaoVolu(10000L);

            lista.add(consulta);

            when(consultaHistoricaDao.obterHistorico(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            consultaHistoricaServiceImpl.exportarExcel(listBD, listBD, listBD, "a", "a", "10:00:00", "10:00:00",
                "a", "a", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarExcelAcessoADadosExceptionTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(consultaHistoricaDao).obterHistorico(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            consultaHistoricaServiceImpl.exportarExcel(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarExcelEmptyResultDataAccessExceptionTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaDao).obterHistorico(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            consultaHistoricaServiceImpl.exportarExcel(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (EmptyResultDataAccessException e) {
            // Teste OK
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarPdfTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            List<ConsultaHistorica> lista = new ArrayList<>();
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setDuracaoDisp(10000L);
            consulta.setDuracaoFunc(10000L);
            consulta.setDuracaoVolu(10000L);

            lista.add(consulta);

            when(consultaHistoricaDao.obterHistorico(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            consultaHistoricaServiceImpl.exportarPdf(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarPdfAcessoADadosExceptionTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            doThrow(AcessoADadosException.class).when(consultaHistoricaDao).obterHistorico(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            consultaHistoricaServiceImpl.exportarPdf(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void exportarPdfEmptyResultDataAccessExceptionTest() throws Exception {

        try {

            List<BigDecimal> listBD = new ArrayList<>();
            listBD.add(new BigDecimal(1));

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaDao).obterHistorico(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            consultaHistoricaServiceImpl.exportarPdf(listBD, listBD, listBD, "1", "1", "10:00:00", "10:00:00",
                "1", "1", "Test", "02/02/2022", "02/02/2022", "M227576");

        } catch (EmptyResultDataAccessException e) {
            // Test
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}
