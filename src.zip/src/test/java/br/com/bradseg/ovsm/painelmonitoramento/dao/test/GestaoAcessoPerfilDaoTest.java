package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.GestaoAcessoPerfilDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaFuncionalidadeRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaUsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test login service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class GestaoAcessoPerfilDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private GestaoAcessoPerfilDaoImpl gestaoAcessoPerfilDaoImpl;

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            // doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
            // params, BigDecimal.class);
            BigDecimal result = gestaoAcessoPerfilDaoImpl.obterNumeroUsuario(usuario);

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuarioEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(BigDecimal.class));
            BigDecimal result = gestaoAcessoPerfilDaoImpl.obterNumeroUsuario(usuario);

            Assert.isTrue(result.equals(new BigDecimal(0)), "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuarioEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuarioSqlException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(BigDecimal.class));

            gestaoAcessoPerfilDaoImpl.obterNumeroUsuario(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void listarPerfilUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CTPO_PRFIL", "CTPO_PRFIL");
            mapa.put("RTPO_PRFIL", "RTPO_PRFIL");
            lista.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(lista);
            List<PerfilUsuario> result = gestaoAcessoPerfilDaoImpl.listarPerfilUsuario();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void listarPerfilUsuarioListaVazia() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            
            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(lista);
            List<PerfilUsuario> result = gestaoAcessoPerfilDaoImpl.listarPerfilUsuario();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch(EmptyResultDataAccessException e) {
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void listarPerfilUsuarioAcessoADadosException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CTPO_PRFIL", "CTPO_PRFIL");
            mapa.put("RTPO_PRFIL", "RTPO_PRFIL");
            lista.add(mapa);

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.listarPerfilUsuario();

        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void listarUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("APROV");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaUsuarioRowMapper.class))).thenReturn(listaTeste);

            List<Usuario> result = gestaoAcessoPerfilDaoImpl.listarUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void listarUsuarioVazio() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setDataSolicitacao(new Date());
            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaUsuarioRowMapper.class))).thenReturn(listaTeste);

            List<Usuario> result = gestaoAcessoPerfilDaoImpl.listarUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarUsuarioEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void listarUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("APROV");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).query(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaUsuarioRowMapper.class));

            List<Usuario> result = gestaoAcessoPerfilDaoImpl.listarUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarUsuarioEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void listarUsuarioEmptySQLException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("APROV");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            doThrow(new RuntimeException()).when(jdbcTemplate).query(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ListaUsuarioRowMapper.class));

            List<Usuario> result = gestaoAcessoPerfilDaoImpl.listarUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("APROV");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            // when(jdbcTemplate.update(Mockito.anyString(),
            // Mockito.any(MapSqlParameterSource.class))).thenReturn(listaTeste);

            gestaoAcessoPerfilDaoImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarStatusPerfilUsuarioSQLException
     *
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuarioSQLException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("APROV");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            List<Usuario> listaTeste = new ArrayList<Usuario>();
            listaTeste.add(usuario);

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            // when(jdbcTemplate.update(Mockito.anyString(),
            // Mockito.any(MapSqlParameterSource.class))).thenReturn(listaTeste);

            gestaoAcessoPerfilDaoImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuario
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuarioCanceladoRejeitado() throws Exception {
        try {
            BigDecimal result = gestaoAcessoPerfilDaoImpl.obterNumeroUsuarioCanceladoRejeitado(new BigDecimal(1));

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuarioCanceladoRejeitadoEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuarioCanceladoRejeitadoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(BigDecimal.class));

            gestaoAcessoPerfilDaoImpl.obterNumeroUsuarioCanceladoRejeitado(new BigDecimal(1));

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterNumeroUsuarioCanceladoRejeitadoSqlException
     *
     * @throws Exception
     */
    @Test
    void obterNumeroUsuarioCanceladoRejeitadoSqlException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.eq(BigDecimal.class));

            gestaoAcessoPerfilDaoImpl.obterNumeroUsuarioCanceladoRejeitado(new BigDecimal(1));

        } catch (SQLException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarStatusPerfilUsuarioSQLException
     *
     * @throws Exception
     */
    @Test
    void inserirUsuarioCancelado() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            gestaoAcessoPerfilDaoImpl.inserirUsuarioCancelado(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirPerfilFuncionalidade
     *
     * @throws Exception
     */
    @Test
    void inserirPerfilFuncionalidade() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            gestaoAcessoPerfilDaoImpl.inserirPerfilFuncionalidade(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioCanceladoDataIntegrityViolationException
     *
     * @throws Exception
     */
    @Test
    void inserirUsuarioCanceladoDataIntegrityViolationException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.inserirUsuarioCancelado(usuario);

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirPerfilFuncionalidadeDataIntegrityViolationException
     *
     * @throws Exception
     */
    @Test
    void inserirPerfilFuncionalidadeDataIntegrityViolationException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.inserirPerfilFuncionalidade(usuario);

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void inserirUsuarioCanceladoSqlException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.inserirUsuarioCancelado(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void inserirPerfilFuncionalidadeSqlException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            usuario.setListaFuncionalidades(listaFuncionalidade);

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.inserirPerfilFuncionalidade(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarUsuarioCancelado
     *
     * @throws Exception
     */
    @Test
    void atualizarUsuarioCancelado() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            gestaoAcessoPerfilDaoImpl.atualizarUsuarioCancelado(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarUsuarioCanceladoDataIntegrityViolationException
     *
     * @throws Exception
     */
    @Test
    void atualizarUsuarioCanceladoDataIntegrityViolationException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            gestaoAcessoPerfilDaoImpl.atualizarUsuarioCancelado(usuario);

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void atualizarUsuarioCanceladoSqlException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            doThrow(new RuntimeException()).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            gestaoAcessoPerfilDaoImpl.atualizarUsuarioCancelado(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterListaFuncionalidadePerfil
     *
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadePerfil() throws Exception {
        try {
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class))).thenReturn(listaFuncionalidade);

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidadePerfil("teste");

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadePerfilSQLException() throws Exception {
        try {

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class))).thenReturn(new ArrayList<Funcionalidade>());

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidadePerfil("teste");

            Assert.notNull(result, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterListaFuncionalidadePerfilSQLAcesso() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class));
            

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidadePerfil("teste");

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterListaFuncionalidade
     *
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidade() throws Exception {
        try {
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("FNC");
            funcionalidade.setDescricaoFuncionalidade("FNC");

            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            listaFuncionalidade.add(funcionalidade);

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class))).thenReturn(listaFuncionalidade);

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidade();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadeSQLException() throws Exception {
        try {

            when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class))).thenReturn(new ArrayList<>());

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidade();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    /**
     * Teste inserirUsuarioCanceladoSqlException
     *
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadeSQLAcesso() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).query(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ListaFuncionalidadeRowMapper.class));
           

            List<Funcionalidade> result = gestaoAcessoPerfilDaoImpl.obterListaFuncionalidade();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterListaFuncionalidade
     *
     * @throws Exception
     */
    @Test
    void removerPerfilFuncionalidade() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            gestaoAcessoPerfilDaoImpl.removerPerfilFuncionalidade(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste removerPerfilFuncionalidadeDataIntegrityViolationException
     *
     * @throws Exception
     */
    @Test
    void removerPerfilFuncionalidadeDataIntegrityViolationException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            doThrow(DataIntegrityViolationException.class)
                .when(jdbcTemplate).update(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.removerPerfilFuncionalidade(usuario);

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste removerPerfilFuncionalidadeDataIntegrityViolationException
     *
     * @throws Exception
     */
    @Test
    void removerPerfilFuncionalidadeSqlException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setCodigoDepartamento("TI");
            usuario.setDataSolicitacao(new Date());
            usuario.setStatus("NEGAD");
            usuario.setNome("Teste");
            usuario.setCodigoEmpresa("BS");
            usuario.setNomeEmpresa("TESTE BS");
            usuario.setPerfil("ADM");
            usuario.setLoginAprovador("M225321");

            doThrow(new RuntimeException())
                .when(jdbcTemplate).update(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            gestaoAcessoPerfilDaoImpl.removerPerfilFuncionalidade(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
