package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiTopClubDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiTopClubTest {
    
    @InjectMocks
    private ConsultaApiTopClub consultaApiTopClub;
    @Mock
    private ConsultaApiTopClubDao consultaApiTopClubDao;
    @Mock
    private HttpURLConnection connection;
    
    @Test
    void testeConsultaApiTopClub() throws Exception {
        try {
            consultaApiTopClub.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiTopClubDao.obterultimoregistroinseridoTopClub()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiTopClub.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiTopClub.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiTopClubDao).obterultimoregistroinseridoTopClub();
            consultaApiTopClub.consultaApi();
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiTopClub.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiTopClubDao).obterultimoregistroinseridoTopClub();
            consultaApiTopClub.consultaApi();

        } catch (Exception e) {
        }
    }

    @Test
    void testeConsultaViagemOk() throws Exception {
        try {
            consultaApiTopClub.obterViagemNOk("MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",
              LocalDateTime.now(),connection);
            
            consultaApiTopClub.obterViagemOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSaudeOkMaximo() throws Exception {
        try {
            consultaApiTopClub.obterViagemOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiTopClub.obterViagemNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testevalidarConexaoTopClubTemp() throws Exception {
        try{
            LocalDateTime datahoraregistro = null;
            LinkedList<TabelaTemp> listaTopClubTemp = new LinkedList<>();
            TabelaTemp topClubTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            topClubTemp.setcorrigeDado(850);
            topClubTemp.setCindRegProcs("P");
            // Codigo de retorno
            topClubTemp.setCerroOrign("teste");
            topClubTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            topClubTemp.setRenderUrlOrign("endereco");
            topClubTemp.setRservcOrign(null);
            topClubTemp.setItransOrign("A001");
            topClubTemp.setRtransOrign("endereco");
            topClubTemp.setIapiOrign("endereco");
            topClubTemp.setIcanalOrign("CAP");
            topClubTemp.setIemprOrign("CAPI");
            topClubTemp.setIprodtOrign("CAPITALIZACAO");
            topClubTemp.setIsprodOrign(null);
            topClubTemp.setIetapaOfert("TESTE ETAPA");
            topClubTemp.setIplatfOrign("API");
            topClubTemp.setIsitEvnto("NOK");

            topClubTemp.setDinicErro(LocalDateTime.now());
            topClubTemp.setDfimErro(null);
            topClubTemp.setDinclReg(LocalDateTime.now());
            topClubTemp.setDaltReg(null);

            listaTopClubTemp.add(topClubTemp);

            consultaApiTopClub.validarConexaoTopClubTemp(LocalDateTime.now(),connection,"MOBILE",
              "https://svp.dsv"
              + ".bradescoseguros.com"
              + ".br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",
              (LinkedList<TabelaTemp>) listaTopClubTemp,
              "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv");

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

}
