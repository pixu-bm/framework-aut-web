package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;

/**
 * Classe implementa test automatizados empresa service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class VisaoDetalhadaProdutoCanalTest {

    @InjectMocks
    private VisaoDetalhadaProdutoCanal visaoDetalhadaProdutoCanal ;

    /**
     * Teste construtorUsuario
     * 
     * @throws Exception
     */
    @Test
    void testVisaoDetalhadaProdutoCanal () throws Exception {
        try {
            BigDecimal bd = new BigDecimal(1);
            VisaoDetalhadaProdutoCanal visao = new VisaoDetalhadaProdutoCanal();
            visao.setProduto("Teste");
            visao.setCanal("Teste");
            visao.setEventoAberto(bd);
            visao.setEventoFechado(bd);
            visao.setEventoGrave(bd);
            visao.setEventoModerado(bd);
            visao.setNumeroImpacto(bd);
            visao.setEventoDisponibilidade(bd);
            visao.setEventoFuncional(bd);
            visao.setEventoVolumetria(bd);
            visao.setTotal(bd);
            visao.setPeriodo("Teste");
            
            visao.getProduto();
            visao.getCanal();
            visao.getEventoAberto();
            visao.getEventoFechado();
            visao.getEventoGrave();
            visao.getEventoModerado();
            visao.getNumeroImpacto();
            visao.getEventoDisponibilidade();
            visao.getEventoFuncional();
            visao.getEventoVolumetria();
            visao.getTotal();
            visao.getPeriodo();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
