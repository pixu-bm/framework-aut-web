package br.com.bradseg.ovsm.painelmonitoramento.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.LoginController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.LoginRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.LoginService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;

import static org.mockito.Mockito.doThrow;

/**
 * Classe implementa test automatizados Login test
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class LoginTest {

    @Mock
    LoginService loginService;

    @InjectMocks
    private LoginController loginController;

    /**
     * Teste para logar usuario.
     * 
     * @throws Exception
     */
    @Test
    void logar() throws Exception {
        try {
            LoginRequest login = new LoginRequest();
            login.setLogin("M227576");

            ResponseEntity<ResponseMensagem> result = loginController.logar(login);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void testeLoginUsuarioIllegalArgumentException() throws Exception {
        try {
            LoginRequest login = new LoginRequest();
            login.setLogin("M2275760987");

            doThrow(IllegalArgumentException.class).when(loginService).logar(Mockito.any(Usuario.class));
            loginController.logar(login);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void testeLoginUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            LoginRequest login = new LoginRequest();
            login.setLogin("M2275760987");

            doThrow(EmptyResultDataAccessException.class).when(loginService).logar(Mockito.any(Usuario.class));
            loginController.logar(login);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.NOT_FOUND), e.getMessage());
        }
    }

    @Test
    void testeLoginUsuarioSQLException() throws Exception {
        try {
            LoginRequest login = new LoginRequest();
            login.setLogin("M2275760987");

            doThrow(SQLException.class).when(loginService).logar(Mockito.any(Usuario.class));
            loginController.logar(login);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }


    /**
     * Teste listar empresa da companhia para usuarios.
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuario() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = loginController.listarEmpresaUsuario();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    /**
     * Teste listar empresa da companhia para usuarios SQL exception
     * 
     * @throws ResponseStatusException
     */
    @Test
    void listarEmpresaUsuarioSqlException() throws Exception {
        try {

            doThrow(SQLException.class).when(loginService).listarEmpresaUsuario();
            loginController.listarEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste listar empresa da companhia para usuarios exception
     * 
     * @throws ResponseStatusException
     */
    @Test
    void listarEmpresaUsuarioResponseStatusException() throws Exception {
        try {

            doThrow(ResponseStatusException.class).when(loginService).listarEmpresaUsuario();
            loginController.listarEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste de solicitação de acesso.
     * 
     * @throws Exception
     */
    @Test
    void solicitarAcesso() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitacaoAcesso = new SolicitacaoAcessoRequest();
            solicitacaoAcesso.setNome("Pedro");
            solicitacaoAcesso.setLogin("M232640");
            solicitacaoAcesso.setEmail("pedro.paulo@wipro.com");
            solicitacaoAcesso.setTelefone("(21)999988881");
            solicitacaoAcesso.setEndereco("Rua das camelias");
            solicitacaoAcesso.setCodigoEmpresa("BSP");
            solicitacaoAcesso.setCodigoDepartamento("TI");

            ResponseEntity<ResponseMensagem> result = loginController.solicitarAcesso(solicitacaoAcesso);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste de solicitação de acesso.
     * IllegalArgumentException
     * @throws Exception
     */
    @Test
    void solicitarAcessoIllegalArgumentException() throws Exception {
        try {

          SolicitacaoAcessoRequest solicitacaoAcesso = new SolicitacaoAcessoRequest();
          solicitacaoAcesso.setNome("Pedro");
          solicitacaoAcesso.setLogin("M232640");
          solicitacaoAcesso.setEmail("pedro.paulo@wipro.com");
          solicitacaoAcesso.setTelefone("(21)999988881");
          solicitacaoAcesso.setEndereco("Rua das camelias");
          solicitacaoAcesso.setCodigoEmpresa("BSP");
          solicitacaoAcesso.setCodigoDepartamento("TI");

          doThrow(IllegalArgumentException.class).when(loginService).inserirUsuarioAprovacao(Mockito.any(Usuario.class));
          loginController.solicitarAcesso(solicitacaoAcesso);

        } catch(IllegalArgumentException e){
        } catch (ResponseStatusException e) {        
        }
    }

    /**
     * Teste de solicitação de acesso.
     * IllegalArgumentException
     * @throws Exception
     */
    @Test
    void solicitarAcessoDataIntegrityViolationException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitacaoAcesso = new SolicitacaoAcessoRequest();
            solicitacaoAcesso.setNome("Pedro");
            solicitacaoAcesso.setLogin("M232640");
            solicitacaoAcesso.setEmail("pedro.paulo@wipro.com");
            solicitacaoAcesso.setTelefone("(21)999988881");
            solicitacaoAcesso.setEndereco("Rua das camelias");
            solicitacaoAcesso.setCodigoEmpresa("BSP");
            solicitacaoAcesso.setCodigoDepartamento("TI");

            doThrow(DataIntegrityViolationException.class).when(loginService)
                .inserirUsuarioAprovacao(Mockito.any(Usuario.class));
            loginController.solicitarAcesso(solicitacaoAcesso);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * Teste de solicitação de acesso.
     * IllegalArgumentException
     * @throws Exception
     */
    @Test
    void solicitarAcessoSqlException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitacaoAcesso = new SolicitacaoAcessoRequest();
            solicitacaoAcesso.setNome("Pedro");
            solicitacaoAcesso.setLogin("M232640");
            solicitacaoAcesso.setEmail("pedro.paulo@wipro.com");
            solicitacaoAcesso.setTelefone("(21)999988881");
            solicitacaoAcesso.setEndereco("Rua das camelias");
            solicitacaoAcesso.setCodigoEmpresa("BSP");
            solicitacaoAcesso.setCodigoDepartamento("TI");

            doThrow(SQLException.class).when(loginService).inserirUsuarioAprovacao(Mockito.any(Usuario.class));
            loginController.solicitarAcesso(solicitacaoAcesso);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste de solicitação de acesso.
     * IllegalArgumentException
     * @throws Exception
     */
    @Test
    void solicitarAcessoResponseStatusException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitacaoAcesso = new SolicitacaoAcessoRequest();
            solicitacaoAcesso.setNome("Pedro");
            solicitacaoAcesso.setLogin("M232640");
            solicitacaoAcesso.setEmail("pedro.paulo@wipro.com");
            solicitacaoAcesso.setTelefone("(21)999988881");
            solicitacaoAcesso.setEndereco("Rua das camelias");
            solicitacaoAcesso.setCodigoEmpresa("BSP");
            solicitacaoAcesso.setCodigoDepartamento("TI");

            doThrow(ResponseStatusException.class).when(loginService).inserirUsuarioAprovacao(Mockito.any(Usuario.class));
            loginController.solicitarAcesso(solicitacaoAcesso);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Lista os departamentos de usuario empresa
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresa() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = loginController.listarDepartamentoUsuarioEmpresa("BSP");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Lista os departamentos de usuario empresa
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresaIllegalArgumentException() throws Exception {
        try {

            loginController.listarDepartamentoUsuarioEmpresa(null);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * Lista os departamentos de usuario empresa Data integrity violation
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresaDataIntegrityViolationException() throws Exception {
        try {

            doThrow(DataIntegrityViolationException.class).when(loginService)
                .listarDepartamentoUsuarioEmpresa(Mockito.anyString());
            loginController.listarDepartamentoUsuarioEmpresa("BSP");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * Lista os departamentos de usuario empresa SQL
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresaSqlException() throws Exception {
        try {

            doThrow(SQLException.class).when(loginService)
                .listarDepartamentoUsuarioEmpresa(Mockito.anyString());
            loginController.listarDepartamentoUsuarioEmpresa("BSP");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Lista os departamentos de usuario empresa 
     * Exception
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresaException() throws Exception {
        try {

            doThrow(ResponseStatusException.class).when(loginService)
                .listarDepartamentoUsuarioEmpresa(Mockito.anyString());
            loginController.listarDepartamentoUsuarioEmpresa("BSP");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }
}
