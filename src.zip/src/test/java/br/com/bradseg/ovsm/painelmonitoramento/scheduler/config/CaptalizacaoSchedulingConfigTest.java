package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

@ExtendWith(MockitoExtension.class)
public class CaptalizacaoSchedulingConfigTest {
    
    @Mock
    private ConsultaApiCaptalizacao consultaApiCaptalizacao;
    @InjectMocks
    private CaptalizacaoSchedulingConfig captalizacaoSchedulingConfig;
    
    
    @Test
    void captalizacaoSchedulingConfig() throws Exception {
        try {
            
            ScheduledTaskRegistrar scheduler = new ScheduledTaskRegistrar();
            scheduler.setTriggerTasks(new HashMap<Runnable, Trigger>());
            captalizacaoSchedulingConfig.configureTasks(scheduler);
            

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
