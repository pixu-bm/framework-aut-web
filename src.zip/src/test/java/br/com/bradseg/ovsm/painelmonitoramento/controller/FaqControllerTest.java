package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.FaqController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.FaqRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.FaqService;

/**
 * Classe implementa test automatizados gestão acesso canal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class FaqControllerTest {

    @Mock
    private FaqService faqService;
    @InjectMocks
    private FaqController faqController;

    @Test
    void carregar() throws Exception {

        try {

            Faq faq = new Faq();
            faq.setCod(new BigDecimal(1));
            List<Faq> lista = new ArrayList<>();
            lista.add(faq);

            when(faqService.carregar()).thenReturn(lista);

            ResponseEntity<ResponseMensagem> result = faqController.carregar();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarEmptyResultDataAccessExceptionTest() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(faqService).carregar();

            faqController.carregar();

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarAcessoADadosExceptionTest() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(faqService).carregar();

            faqController.carregar();
        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisar() throws Exception {

        try {

            Faq faq = new Faq();
            faq.setCod(new BigDecimal(1));
            List<Faq> lista = new ArrayList<>();
            lista.add(faq);

            when(faqService.pesquisar(Mockito.anyString())).thenReturn(lista);

            ResponseEntity<ResponseMensagem> result = faqController.pesquisar(Mockito.anyString());

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarEmptyResultDataAccessExceptionTest() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(faqService).pesquisar(Mockito.anyString());

            faqController.pesquisar(Mockito.anyString());

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarAcessoADadosExceptionTest() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(faqService).pesquisar(Mockito.anyString());

            faqController.pesquisar(Mockito.anyString());
        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editar() throws Exception {

        try {

            FaqRequest faq = new FaqRequest();
            faq.setCodSeq(new BigDecimal(10));
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            ResponseEntity<ResponseMensagem> result = faqController.editar(faq);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarEmptyResultDataAccessExceptionTest() throws Exception {
        try {

            FaqRequest faq = new FaqRequest();
            faq.setCodSeq(new BigDecimal(10));
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            doThrow(EmptyResultDataAccessException.class).when(faqService).editar(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            faqController.editar(faq);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarAcessoADadosExceptionTest() throws Exception {
        try {
            FaqRequest faq = new FaqRequest();
            faq.setCodSeq(new BigDecimal(10));
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            doThrow(AcessoADadosException.class).when(faqService).editar(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            faqController.editar(faq);
        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvar() throws Exception {

        try {

            FaqRequest faq = new FaqRequest();
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            ResponseEntity<ResponseMensagem> result = faqController.salvar(faq);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            FaqRequest faq = new FaqRequest();
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            doThrow(EmptyResultDataAccessException.class).when(faqService).salvar(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            faqController.salvar(faq);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarAcessoADadosExceptionTest() throws Exception {
        try {
            FaqRequest faq = new FaqRequest();
            faq.setPergunta("Teste");
            faq.setResposta("teste");
            faq.setPrioridade(0.5F);
            faq.setImagem("teste");
            faq.setLogin("teste");

            doThrow(AcessoADadosException.class).when(faqService).salvar(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            faqController.salvar(faq);
        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluir() throws Exception {

        try {

            FaqRequest faq = new FaqRequest();
            faq.setCodData("teste");
            faq.setCodSeq(new BigDecimal(10));

            ResponseEntity<ResponseMensagem> result = faqController.excluir(faq);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirrEmptyResultDataAccessExceptionTest() throws Exception {
        try {

            FaqRequest faq = new FaqRequest();
            faq.setCodData("teste");
            faq.setCodSeq(new BigDecimal(10));

            doThrow(EmptyResultDataAccessException.class).when(faqService).excluir(Mockito.any(), Mockito.any());

            faqController.excluir(faq);

        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirAcessoADadosExceptionTest() throws Exception {
        try {

            FaqRequest faq = new FaqRequest();
            faq.setCodData("teste");
            faq.setCodSeq(new BigDecimal(10));

            doThrow(AcessoADadosException.class).when(faqService).excluir(Mockito.any(), Mockito.any());

            faqController.excluir(faq);
        } catch (ResponseStatusException e) {

            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR),
                "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
