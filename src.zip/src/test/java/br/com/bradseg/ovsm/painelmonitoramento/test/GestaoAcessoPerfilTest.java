package br.com.bradseg.ovsm.painelmonitoramento.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.GestaoAcessoPerfilController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.GestaoAcessoPerfilService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso perfil
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class GestaoAcessoPerfilTest {

    @Mock
    GestaoAcessoPerfilService gestaoAcessoPerfilService;

    @InjectMocks
    private GestaoAcessoPerfilController gestaoAcessoPerfilController;

    /**
     * Teste lista de empresa usuario
     * 
     * @throws Exception
     */
    @Test
    void obterListaEmpresaUsuario() throws Exception {
        try {
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterListaEmpresaUsuario();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaEmpresaUsuarioEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService).listarPerfilUsuario();
            gestaoAcessoPerfilController.obterListaEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterListaEmpresaUsuarioSQLException() throws Exception {
        try {

            doThrow(SQLException.class).when(gestaoAcessoPerfilService).listarPerfilUsuario();
            gestaoAcessoPerfilController.obterListaEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }


    /**
     * Teste obter status para gestão de perfil
     * 
     * @throws Exception
     */
    @Test
    void obterStatusIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(gestaoAcessoPerfilService).obterStatus();
            gestaoAcessoPerfilController.obterStatus();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterStatusException() throws Exception {
        try {
            doThrow(ResponseStatusException.class).when(gestaoAcessoPerfilService).obterStatus();
            gestaoAcessoPerfilController.obterStatus();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterStatus() throws Exception {
        try {
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterStatus();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obter lista de usuarios do sistema.
     * 
     * @throws Exception
     */
    @Test
    void obterListaUsuario() throws Exception {
        try {

            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M232640");
            atualizarStatusPerfilUsuarioRequest.setPerfil("MSTER");
            atualizarStatusPerfilUsuarioRequest.setStatus("ATIVO");

            List<Usuario> lista = new ArrayList<>();
            lista.add(new Usuario(atualizarStatusPerfilUsuarioRequest));

            when(gestaoAcessoPerfilService.listarUsuario(Mockito.any(Usuario.class))).thenReturn(lista);

            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterListaUsuario("1", "1", "ATIVO",
                "Carlos", "", "MSTER", "13/11/2021");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaUsuarioFor() throws Exception {
        try {

            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setLoginAprovador("M232640");
            usuario.setPerfil("MSTER");
            usuario.setStatus("ATIVO");

            List<Usuario> usuarios = new ArrayList<Usuario>();

            usuarios.add(usuario);

            gestaoAcessoPerfilService.listarUsuario(Mockito.any(Usuario.class));
            gestaoAcessoPerfilController.obterListaUsuario("Teste", "3", "ATIVO", "Carlos", "", "MSTER", "16/11/2021");

        } catch (EmptyResultDataAccessException e) {

            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obter lista de usuarios do sistema.
     * 
     * @throws Exception
     */
    @Test
    void obterListaUsuarioEmptyResultDataAccessExceptionException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService)
                .listarUsuario(Mockito.any(Usuario.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterListaUsuario(null, null, null,
                null, null, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    /**
     * Teste obter lista de usuarios do sistema.
     * 
     * @throws Exception
     */
    @Test
    void obterListaUsuarioSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(gestaoAcessoPerfilService).listarUsuario(Mockito.any(Usuario.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterListaUsuario(null, null, null,
                null, null, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste obter lista de usuarios do sistema.
     * 
     * @throws Exception
     */


    void obterListaUsuarioException() throws Exception {
        try {
            doThrow(new RuntimeException()).when(gestaoAcessoPerfilService).listarUsuario(Mockito.any(Usuario.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterListaUsuario(null, null, null,
                null, null, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterListaUsuarioEmptyResultDataAccessException() throws Exception {

        try {
            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService).listarPerfilUsuario();
            gestaoAcessoPerfilController.obterListaEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterListaUsuarioEmpresaSQLException() throws Exception {

        try {
            doThrow(SQLException.class).when(gestaoAcessoPerfilService).listarPerfilUsuario();
            gestaoAcessoPerfilController.obterListaEmpresaUsuario();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    /**
     * Teste obter lista de usuarios do sistema.
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuario() throws Exception {
        try {
            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M232640");
            atualizarStatusPerfilUsuarioRequest.setPerfil("MSTER");
            atualizarStatusPerfilUsuarioRequest.setStatus("ATIVO");

            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController
                .atualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarStatusPerfilUsuarioEmptyResultDataAccessException() throws Exception {

        try {

            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M232640");
            atualizarStatusPerfilUsuarioRequest.setPerfil("MSTER");
            atualizarStatusPerfilUsuarioRequest.setStatus("ATIVO");

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService)
                .atualizarStatusPerfilUsuario(Mockito.any(Usuario.class));
            gestaoAcessoPerfilController.atualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void atualizarStatusPerfilUsuarioSQLException() throws Exception {

        try {

            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M232640");
            atualizarStatusPerfilUsuarioRequest.setPerfil("MSTER");
            atualizarStatusPerfilUsuarioRequest.setStatus("ATIVO");

            doThrow(SQLException.class).when(gestaoAcessoPerfilService)
                .atualizarStatusPerfilUsuario(Mockito.any(Usuario.class));
            gestaoAcessoPerfilController.atualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    void atualizarStatusPerfilUsuarioException() throws Exception {

        try {

            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M232640");
            atualizarStatusPerfilUsuarioRequest.setPerfil("MSTER");
            atualizarStatusPerfilUsuarioRequest.setStatus("ATIVO");

            doThrow(new RuntimeException()).when(gestaoAcessoPerfilService)
                .atualizarStatusPerfilUsuario(Mockito.any(Usuario.class));
            gestaoAcessoPerfilController.atualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesPerfil() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidadesPerfil(null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesPerfilIllegalArgumentException() throws Exception {
        try {

            AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest = new AtualizarPerfilFuncionalidadeRequest();
            atualizarPerfilFuncionalidadeRequest.setLogin(null);
            atualizarPerfilFuncionalidadeRequest.setPerfil(null);

            doThrow(IllegalArgumentException.class).when(gestaoAcessoPerfilService)
                .validarParametroAtualizarPerfilFuncionalidade(atualizarPerfilFuncionalidadeRequest);
            gestaoAcessoPerfilController.atualizarPerfilFuncionalidade(atualizarPerfilFuncionalidadeRequest);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesPerfilEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService)
                .obterListaFuncionalidadePerfil(Mockito.any(String.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidadesPerfil("ADM");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesPerfilSqlAccessException() throws Exception {
        try {

            doThrow(SQLException.class).when(gestaoAcessoPerfilService)
                .obterListaFuncionalidadePerfil(Mockito.any(String.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidadesPerfil("ADM");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    void obterFuncionalidadesPerfilException() throws Exception {
        try {

            doThrow(RuntimeException.class).when(gestaoAcessoPerfilService)
                .obterListaFuncionalidadePerfil(Mockito.any(String.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidadesPerfil("ADM");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterFuncionalidades() throws Exception {
        try {

            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidades();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService).obterListaFuncionalidade();
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController.obterFuncionalidades();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterFuncionalidadesSqlAccessException() throws Exception {
        try {

            doThrow(SQLException.class).when(gestaoAcessoPerfilService).obterListaFuncionalidade();
            gestaoAcessoPerfilController.obterFuncionalidades();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    void obterFuncionalidadesException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(gestaoAcessoPerfilService).obterListaFuncionalidade();
            gestaoAcessoPerfilController.obterFuncionalidades();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void atualizarPerfilFuncionalidade() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController
                .atualizarPerfilFuncionalidade(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void atualizarPerfilFuncionalidadeIllegalArgumentException() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService)
                .validarParametroAtualizarPerfilFuncionalidade(
                    Mockito.any(AtualizarPerfilFuncionalidadeRequest.class));
            ResponseEntity<ResponseMensagem> result = gestaoAcessoPerfilController
                .atualizarPerfilFuncionalidade(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void atualizarPerfilFuncionalidadeEmptyResultDataAccessException() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilService)
                .atualizarPerfilFuncionalidade(Mockito.any(Usuario.class));

            gestaoAcessoPerfilController.atualizarPerfilFuncionalidade(request);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void atualizarPerfilFuncionalidadeDataIntegrityViolationException() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            doThrow(DataIntegrityViolationException.class).when(gestaoAcessoPerfilService)
                .atualizarPerfilFuncionalidade(Mockito.any(Usuario.class));

            gestaoAcessoPerfilController.atualizarPerfilFuncionalidade(request);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void atualizarPerfilFuncionalidadeSQLException() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            doThrow(SQLException.class).when(gestaoAcessoPerfilService)
                .atualizarPerfilFuncionalidade(Mockito.any(Usuario.class));

            gestaoAcessoPerfilController.atualizarPerfilFuncionalidade(request);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    void atualizarPerfilFuncionalidadeException() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest request = new AtualizarPerfilFuncionalidadeRequest();
            request.setLogin("M232640");
            request.setPerfil("ADM");
            request.setListaFuncionalidade(new ArrayList<>());
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("1");
            funcionalidade.setDescricaoFuncionalidade("Adequar gestao perfil");
            request.getListaFuncionalidade().add(funcionalidade);

            doThrow(new RuntimeException()).when(gestaoAcessoPerfilService)
                .atualizarPerfilFuncionalidade(Mockito.any(Usuario.class));

            gestaoAcessoPerfilController.atualizarPerfilFuncionalidade(request);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }
}
