package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import java.sql.ResultSet;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class VisaoEventoRowMapperTest {

    @InjectMocks
    private VisaoEventoRowMapper visaoEventoRowMapper;

    /**
     * Teste testeUsuarioRowMapper
     * 
     * @throws Exception
     */
    @Test
    void testeVisaoEvento() throws Exception {
        try {

            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_DISPN")).thenReturn(10);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_FUNCL")).thenReturn(5);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_VOLUM")).thenReturn(6);
            Mockito.when(resultSetMock.getInt("QNT_TOTAL")).thenReturn(4);
            Mockito.when(resultSetMock.getInt("TRANSACAO")).thenReturn(10);
            Mockito.when(resultSetMock.getInt("TRANSACAO_TOTAL")).thenReturn(20);

            VisaoEvento evento = visaoEventoRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(evento, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste testeUsuarioRowMapper
     * 
     * @throws Exception
     */
    @Test
    void testeVisaoEventoException() throws Exception {
        try {

            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_DISPN")).thenReturn(10);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_FUNCL")).thenReturn(5);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_VOLUM")).thenReturn(6);
            Mockito.when(resultSetMock.getInt("QNT_TOTAL")).thenReturn(0);

            VisaoEvento evento = visaoEventoRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(evento, "nao pode nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testeVisaoEventoIfInterno() throws Exception {
        try {

            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_DISPN")).thenReturn(10);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_FUNCL")).thenReturn(5);
            Mockito.when(resultSetMock.getInt("QNT_EVENTO_VOLUM")).thenReturn(6);
            Mockito.when(resultSetMock.getInt("QNT_TOTAL")).thenReturn(4);
            Mockito.when(resultSetMock.getInt("TRANSACAO")).thenReturn(0);
            Mockito.when(resultSetMock.getInt("TRANSACAO_TOTAL")).thenReturn(20);

            VisaoEvento evento = visaoEventoRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(evento, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
