package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.UsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class UsuarioRowMapperTest {

    @InjectMocks
    private UsuarioRowMapper usuarioRowMapper;

    /**
     * Teste testeUsuarioRowMapper
     * 
     * @throws Exception
     */
    @Test
    void testeUsuarioRowMapper() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("x");

            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("CUSUAR")).thenReturn("2");
            Mockito.when(resultSetMock.getString("REMAIL_CORP")).thenReturn("email@email.com");
            Mockito.when(resultSetMock.getString("IUSUAR")).thenReturn("Pedro");
            Mockito.when(resultSetMock.getBigDecimal("NUSUAR")).thenReturn(new BigDecimal(2));

            Usuario usuarioTeste = usuarioRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(usuarioTeste, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
