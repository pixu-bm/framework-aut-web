package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiViagemDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiViagemTest {
    
    @InjectMocks
    private ConsultaApiViagem consultaApiViagem;
    @Mock
    private ConsultaApiViagemDao consultaApiViagemDao;
    @Mock
    private HttpURLConnection connection;
    
    @Test
    void testeConsultaApiViagem() throws Exception {
        try {
            consultaApiViagem.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiViagemDao.obterultimoregistroinseridoViagem()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiViagem.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiViagem.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiViagemDao).obterultimoregistroinseridoViagem();
            consultaApiViagem.consultaApi();
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiViagem.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiViagemDao).obterultimoregistroinseridoViagem();
            consultaApiViagem.consultaApi();

        } catch (Exception e) {
        }
    }

    @Test
    void testeConsultaViagemOk() throws Exception {
        try {
            consultaApiViagem.obterViagemNOk("MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",
              LocalDateTime.now(),connection);
            
            consultaApiViagem.obterViagemOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSaudeOkMaximo() throws Exception {
        try {
            consultaApiViagem.obterViagemOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiViagem.obterViagemNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void testevalidarConexaoViagemTemp() throws Exception {
        try{
            LinkedList<TabelaTemp> listaViagemTemp = new LinkedList<>();
            TabelaTemp viagemTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            viagemTemp.setcorrigeDado(850);
            viagemTemp.setCindRegProcs("P");
            // Codigo de retorno
            viagemTemp.setCerroOrign("teste");
            viagemTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            viagemTemp.setRenderUrlOrign("endereco");
            viagemTemp.setRservcOrign(null);
            viagemTemp.setItransOrign("A001");
            viagemTemp.setRtransOrign("endereco");
            viagemTemp.setIapiOrign("endereco");
            viagemTemp.setIcanalOrign("CAP");
            viagemTemp.setIemprOrign("CAPI");
            viagemTemp.setIprodtOrign("CAPITALIZACAO");
            viagemTemp.setIsprodOrign(null);
            viagemTemp.setIetapaOfert("TESTE ETAPA");
            viagemTemp.setIplatfOrign("API");
            viagemTemp.setIsitEvnto("NOK");

            viagemTemp.setDinicErro(LocalDateTime.now());
            viagemTemp.setDfimErro(null);
            viagemTemp.setDinclReg(LocalDateTime.now());
            viagemTemp.setDaltReg(null);

            listaViagemTemp.add(viagemTemp);

            consultaApiViagem.validarConexaoViagemTemp(LocalDateTime.now(),connection,"MOBILE",
              "https://svp.dsv"
                + ".bradescoseguros.com"
                + ".br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",
              (LinkedList<TabelaTemp>) listaViagemTemp,
              "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv");

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
}
