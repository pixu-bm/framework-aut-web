package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.FaqDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados de EventoDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class FaqDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private FaqDaoImpl faqDaoImpl;

    @Test
    void carregarTest() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CFAQ", new BigDecimal(1));
            mapa.put("AINIC_PUBL", new Timestamp((long) 10));
            mapa.put("NPRIOR_VSLAO", new BigDecimal(1));
            mapa.put("RPGNTA", "Teste");
            mapa.put("RRESPT", "Teste");
            mapa.put("DINCL_REG", Utils.strDateFmtBrasilToJavaDate("01/01/2022"));
            mapa.put("RENDER_IMAGE", "Teste");

            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<Faq> result = faqDaoImpl.listarPerguntasFaq();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.listarPerguntasFaq();

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void carregarAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.listarPerguntasFaq();

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarTest() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CFAQ", new BigDecimal(1));
            mapa.put("AINIC_PUBL", new Timestamp((long) 10));
            mapa.put("NPRIOR_VSLAO", new BigDecimal(1));
            mapa.put("RPGNTA", "Teste");
            mapa.put("RRESPT", "Teste");
            mapa.put("DINCL_REG", Utils.strDateFmtBrasilToJavaDate("01/01/2022"));
            mapa.put("RENDER_IMAGE", "Teste");

            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<Faq> result = faqDaoImpl.pesquisar("Test");

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.pesquisar("Test");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pesquisarAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.pesquisar("Test");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarTest() throws Exception {
        try {

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CFAQ", new BigDecimal(1));
            mapa.put("AINIC_PUBL", new Timestamp((long) 10));

            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            faqDaoImpl.editar(new BigDecimal(1), "Teste", "Teste",
                10F, "Teste", "Teste");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarEmptyResultDataAccessException() throws Exception {
        try {

            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            faqDaoImpl.editar(new BigDecimal(1), "Teste", "Teste",
                10F, "Teste", "Teste");

        } catch (EmptyResultDataAccessException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void editarAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.editar(new BigDecimal(1), "Teste", "Teste",
                10F, "Teste", "Teste");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarTest() throws Exception {
        try {

            faqDaoImpl.salvar("Teste", "Teste",
                10F, "Teste", "Teste");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void salvarAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.salvar("Teste", "Teste",
                10F, "Teste", "Teste");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirTest() throws Exception {
        try {

            faqDaoImpl.excluir(new BigDecimal(1), "2022-05-13 14:11:41.90500");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).update(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            faqDaoImpl.excluir(new BigDecimal(1), "2022-05-13 14:11:41.90500");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
