package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.IndicadorNegocioController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.IndicadorNegocioService;

@ExtendWith(MockitoExtension.class)
public class InidicadorNegocioControllerTest {

    @Mock
    private IndicadorNegocioService indicadorNegocioService;

    @InjectMocks
    private IndicadorNegocioController indicadorNegocioController;

    @Test
    void obterVolumetriaTempoRealGrafico() throws Exception {
        try {

            when(indicadorNegocioService.obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new VolumetriaTempoRealVolumetriaMaxima());
            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterVolumetriaTempoRealGrafico(3,
                null,
                null, "test", "test");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealGraficoSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(indicadorNegocioService).obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterVolumetriaTempoRealGrafico(3,
                null,
                null, "", "");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealGraficoIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(indicadorNegocioService)
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterVolumetriaTempoRealGrafico(3,
                null,
                null, "", "");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocio() throws Exception {
        try {

            when(indicadorNegocioService.obterVolumetriaVisaoNegocio(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new ArrayList<VolumetriaVisaoNegocio>());
            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterVisaoNegocios(3, null,
                null, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(indicadorNegocioService)
                .obterVolumetriaVisaoNegocio(
                    Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            indicadorNegocioController.obterVisaoNegocios(3, null, null, null, null);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocioAcessoADadosException() throws Exception {

        try {

            doThrow(AcessoADadosException.class).when(indicadorNegocioService).obterVolumetriaVisaoNegocio(
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController
                .obterVisaoNegocios(3, null, null, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventos() throws Exception {
        try {

            when(indicadorNegocioService.obterRankingEventos(
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterRankingEventos(3, null,
                null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(indicadorNegocioService)
                .obterRankingEventos(
                    Mockito.anyInt(), Mockito.any(), Mockito.any());

            indicadorNegocioController.obterRankingEventos(3, null, null);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "Tem que ser Bad request");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(indicadorNegocioService).obterRankingEventos(
                Mockito.any(),
                Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController
                .obterRankingEventos(3, null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "Tem que ser Bad request");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocio() throws Exception {
        try {

            when(indicadorNegocioService.obterIndicadoresNegocio(Mockito.any(), 
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new IndicadoresNegocio());
            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterIndicadoresNegocio(
                null, null, "test", "test");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(indicadorNegocioService).obterIndicadoresNegocio(Mockito.any(), 
                Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterIndicadoresNegocio(
                null, null, " teste", " teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(indicadorNegocioService)
            .obterIndicadoresNegocio(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterIndicadoresNegocio(
                null, null, "teste", "teste");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterDetalhamentoTransacaoEvento() throws Exception {
        try {

            when(indicadorNegocioService.obterNumeroTransacao(Mockito.any(), 
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new NumeroTransacoes());
            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterDetalhamentoTransacaoEvento(1,
                null, null, "test", "test");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalhamentoTransacaoEventoSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(indicadorNegocioService).obterNumeroTransacao(Mockito.any(), 
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterDetalhamentoTransacaoEvento(1,
                null, null, "test", "test");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDetalhamentoTransacaoEventoIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(indicadorNegocioService)
            .obterNumeroTransacao(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = indicadorNegocioController.obterDetalhamentoTransacaoEvento(1,
                null, null, "test", "test");

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
