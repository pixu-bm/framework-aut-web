package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.ComentarioDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe implementa test automatizados de ComentarioDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ComentarioDaoTest {
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;

    @InjectMocks
    private ComentarioDaoImpl comentarioDaoImpl;

    @Test
    void obterDadosPainelMonitoramento() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(1);
            Boolean result = comentarioDaoImpl
                .obterDadosPainelMonitoramento(new Comentario());

            Assert.isTrue(result, "Deve retornar true");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDadosPainelMonitoramentoRetornoZero() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.eq(Integer.class))).thenReturn(0);
            Boolean result = comentarioDaoImpl
                .obterDadosPainelMonitoramento(new Comentario());

            Assert.isTrue(!result, "Deve retornar false");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterDadosPainelMonitoramentoAcessoADadosException() throws Exception {
        try {

            doThrow(
                AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                    Mockito.any(MapSqlParameterSource.class),
                    Mockito.eq(Integer.class));
            comentarioDaoImpl
                .obterDadosPainelMonitoramento(new Comentario());

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getClass().equals(AcessoADadosException.class), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void inserirComentario() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataVerificacao(new Date());
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setComentario("Lorem Ipsum");
            comentario.setLogin("M227576");
            comentario.setNomeUsuario("Maiky");
            comentario.setPerfilUsuario("MSTER");
            comentario.setDataInclusao(new Date());

            comentarioDaoImpl.inserirComentario(comentario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void inserirComentarioAcessoADadosException() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataVerificacao(new Date());
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setComentario("Lorem Ipsum");
            comentario.setLogin("M227576");
            comentario.setNomeUsuario("Maiky");
            comentario.setPerfilUsuario("MSTER");
            comentario.setDataInclusao(new Date());

            doThrow(AcessoADadosException.class).when(jdbcTemplate).update(
                Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            comentarioDaoImpl.inserirComentario(comentario);

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getClass().equals(AcessoADadosException.class), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterComentario() throws Exception {
        try {

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CEMPR_PNEL", new BigDecimal(3));
            mapa.put("CPRODT_PNEL", new BigDecimal(7));
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(2));
            mapa.put("DVERIF_APLIC", new Date());
            mapa.put("DPROCS_APLIC", new Date());
            mapa.put("CERRO_CNXAO_PNEL", new BigDecimal(500));
            mapa.put("RMSGEM_EVNTO", "Lorem Ipsum");
            mapa.put("IUSUAR_INCL_MSGEM_APLIC", "M259277");
            mapa.put("IUSUAR", "Maiky");
            mapa.put("CTPO_PRFIL", "MSTER");
            mapa.put("DINCL_REG", new Date());
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);
            List<Comentario> result = comentarioDaoImpl.obterComentario("3",
                "7", "2", new Date(), "500");

            Assert.notNull(result, "Deve retornar uma lista de Comentários");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterComentarioEmptyResultDataAccessException() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class)))
                    .thenReturn(listaMapa);

            List<Comentario> result = comentarioDaoImpl.obterComentario("3",
                "7", "2", new Date(), "500");

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterComentarioAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(
                Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            comentarioDaoImpl.obterComentario("3",
                "7", "2", new Date(), "500");

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getMessage().equals("Ocorreu um erro inesperado"), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void alterarComentarioTest() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setComentario("Lorem Ipsum");
            comentario.setLogin("M227576");
            comentario.setNomeUsuario("Maiky");
            comentario.setPerfilUsuario("MSTER");
            comentario.setDataInclusao(new Date());

            comentarioDaoImpl.alterarComentario(comentario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void alterarComentarioAcessoADadosException() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setComentario("Lorem Ipsum");
            comentario.setLogin("M227576");
            comentario.setNomeUsuario("Maiky");
            comentario.setPerfilUsuario("MSTER");
            comentario.setDataInclusao(new Date());

            doThrow(AcessoADadosException.class).when(jdbcTemplate).update(
                Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            comentarioDaoImpl.alterarComentario(comentario);

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getClass().equals(AcessoADadosException.class), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excluirComentarioTest() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setLogin("M227576");
            comentario.setDataInclusao(new Date());

            comentarioDaoImpl.excluirComentario(comentario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void excluirComentarioAcessoADadosException() throws Exception {
        try {
            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataProcs(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setLogin("M227576");
            comentario.setDataInclusao(new Date());

            doThrow(AcessoADadosException.class).when(jdbcTemplate).update(
                Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));
            comentarioDaoImpl.excluirComentario(comentario);

        } catch (AcessoADadosException e) {

            Assert.isTrue(e.getClass().equals(AcessoADadosException.class), "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
