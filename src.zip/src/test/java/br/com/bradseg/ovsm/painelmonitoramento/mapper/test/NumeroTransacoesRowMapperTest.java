package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.NumeroTransacoesRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class NumeroTransacoesRowMapperTest {

    @InjectMocks
    private NumeroTransacoesRowMapper numeroTransacoesRowMapper;

    @Test
    void testeNumeroTransacoesRowMapper() throws Exception {
        try {
            
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getInt("SOMA_TRANSACOES")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("TRANSACOES_SCESS")).thenReturn(1);
            Mockito.when(resultSetMock.getInt("TRANSACOES_INSUC")).thenReturn(1);

            NumeroTransacoes numeroTransacoes = numeroTransacoesRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(numeroTransacoes, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
