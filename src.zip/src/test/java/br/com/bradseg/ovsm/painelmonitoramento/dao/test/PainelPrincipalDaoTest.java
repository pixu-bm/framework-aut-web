package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.PainelPrincipalDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealTransacaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealVolumetriaMaximaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class PainelPrincipalDaoTest {
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private PainelPrincipalDaoImpl painelPrincipalDaoImpl;

    /**
     * Teste obterVisaoEvento
     * 
     * @throws Exception
     */
    @Test
    void obterVisaoEvento() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VisaoEventoRowMapper.class))).thenReturn(null);
            VisaoEvento result = painelPrincipalDaoImpl.obterVisaoEvento(3);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVisaoEvento(1);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVisaoEvento(2);

            Assert.isNull(result, "Result não pode ser vazio");
            
            result = painelPrincipalDaoImpl.obterVisaoEvento(null);

            Assert.isNull(result, "Result não pode ser vazio");

            VisaoEvento visao = new VisaoEvento();
            visao.setCodigoRetorno(0);
            visao.setPorcentagemEventosDisponibilidade(100);
            visao.setPorcentagemEventosFuncionalidade(100);
            visao.setPorcentagemEventosVolumetria(100);
            visao.setQuantidadeEventosDisponibilidade(10);
            visao.setQuantidadeEventosDisponibilidade(10);
            visao.setQuantidadeEventosVolumetria(10);
            visao.setQuantidadeTotalEventos(2);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VisaoEventoRowMapper.class))).thenReturn(visao);
            result = painelPrincipalDaoImpl.obterVisaoEvento(1);
            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVisaoEventoEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void obterVisaoEventoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            painelPrincipalDaoImpl.obterVisaoEvento(3);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVisaoEventoException
     * 
     * @throws Exception
     */
    @Test
    void obterVisaoEventoException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VisaoEventoRowMapper.class));
            painelPrincipalDaoImpl.obterVisaoEvento(3);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVisaoEvento
     * 
     * @throws Exception
     */
    @Test
    void obterPainelMonitoramento() throws Exception {
        try {
            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CEMPR_PNEL", new BigDecimal(2));
            mapa.put("IEMPR_PNEL", "Bradesco");
            mapa.put("CPRODT_PNEL", new BigDecimal(3));
            mapa.put("IPRODT", "MOBILE");
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(3));
            mapa.put("ICANAL_DGTAL_PNEL", "MOBILE");
            mapa.put("CSIT_DISPN", new BigDecimal(1));
            mapa.put("CSIT_FUNCL", new BigDecimal(1));
            mapa.put("CSIT_VOLUM", new BigDecimal(1));

            lista.add(mapa);

            mapa = new HashMap<>();
            mapa.put("CEMPR_PNEL", new BigDecimal(2));
            mapa.put("IEMPR_PNEL", "Bradesco");
            mapa.put("CPRODT_PNEL", new BigDecimal(3));
            mapa.put("IPRODT", "MOBILE");
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(3));
            mapa.put("ICANAL_DGTAL_PNEL", "MOBILE");
            mapa.put("CSIT_DISPN", new BigDecimal(1));
            mapa.put("CSIT_FUNCL", new BigDecimal(1));
            mapa.put("CSIT_VOLUM", new BigDecimal(1));

            lista.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.any(), Mockito.any(MapSqlParameterSource.class))).thenReturn(lista);
            PainelMonitoramentoAtual result = painelPrincipalDaoImpl.obterPainelMonitoramento();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVisaoEvento
     * 
     * @throws Exception
     */
    @Test
    void obterPainelMonitoramentoEmptyResultDataAccessException() throws Exception {
        try {

            painelPrincipalDaoImpl.obterPainelMonitoramento();

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVisaoEvento
     * 
     * @throws Exception
     */
    @Test
    void obterPainelMonitoramentoException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.any(),
                Mockito.any(MapSqlParameterSource.class));
            painelPrincipalDaoImpl.obterPainelMonitoramento();

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealVolumetriaMaxima() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealVolumetriaMaximaRowMapper.class))).thenReturn(null);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));
            List<BigDecimal> listTipoEvento = new ArrayList<>();
            listTipoEvento.add(new BigDecimal(1));

            VolumetriaTempoRealVolumetriaMaxima result = painelPrincipalDaoImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(3, listaProduto, listaCanal, listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(2, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(1, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterVolumetriaTempoRealVolumetriaMaximaException
     * 
     * @throws Exception
     */

    void obterVolumetriaTempoRealVolumetriaMaximaEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealVolumetriaMaximaRowMapper.class));
            painelPrincipalDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(2, null, null, null);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVolumetriaTempoRealVolumetriaMaximaException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealVolumetriaMaximaRowMapper.class));
            painelPrincipalDaoImpl.obterVolumetriaTempoRealVolumetriaMaxima(2, null, null, null);

        } catch (AcessoADadosException e) {
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempo() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealRowMapper.class))).thenReturn(null);

            ProdutoPainelMonitoramentoAtual produtoPainel = new ProdutoPainelMonitoramentoAtual();
            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            listaProduto.add(new BigDecimal(4));
            listaProduto.add(new BigDecimal(3));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));
            List<BigDecimal> listTipoEvento = new ArrayList<>();
            listTipoEvento.add(new BigDecimal(1));

            List<VolumetriaTempoReal> result = painelPrincipalDaoImpl.obterVolumetriaTempoRealFaixaTempo(3,
                listaProduto, listaCanal, listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealFaixaTempo(2, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealFaixaTempo(1, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            painelPrincipalDaoImpl.obterVolumetriaTempoRealFaixaTempo(2, null, null, null);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVolumetriaTempoRealFaixaTempoException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(VolumetriaTempoRealRowMapper.class));

            painelPrincipalDaoImpl.obterVolumetriaTempoRealFaixaTempo(2, null, null, null);

        } catch (AcessoADadosException e) {
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEvento() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealTransacaoEventoRowMapper.class))).thenReturn(null);

            List<BigDecimal> listaProduto = new ArrayList<>();
            listaProduto.add(new BigDecimal(2));
            listaProduto.add(new BigDecimal(4));
            listaProduto.add(new BigDecimal(3));
            List<BigDecimal> listaCanal = new ArrayList<>();
            listaCanal.add(new BigDecimal(1));
            listaCanal.add(new BigDecimal(2));
            List<BigDecimal> listTipoEvento = new ArrayList<>();
            listTipoEvento.add(new BigDecimal(1));

            List<VolumetriaTempoRealTransacaoEvento> result = painelPrincipalDaoImpl
                .obterVolumetriaTempoRealTransacaoEvento(3, listaProduto, listaCanal, listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealTransacaoEvento(2, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

            result = painelPrincipalDaoImpl.obterVolumetriaTempoRealTransacaoEvento(1, listaProduto, listaCanal,
                listTipoEvento);

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEventoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealTransacaoEventoRowMapper.class));

            painelPrincipalDaoImpl.obterVolumetriaTempoRealTransacaoEvento(1, null, null, null);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTransacaoEventoException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class),
                Mockito.any(VolumetriaTempoRealTransacaoEventoRowMapper.class));

            painelPrincipalDaoImpl.obterVolumetriaTempoRealTransacaoEvento(1, null, null, null);

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
