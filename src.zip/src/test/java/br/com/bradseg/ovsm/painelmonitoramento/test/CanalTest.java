package br.com.bradseg.ovsm.painelmonitoramento.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.CanalController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CanalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.Mockito.doThrow;

/**
 * Classe implementa test automatizados gestão acesso canal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class CanalTest {

    @Mock
    private CanalService canalService;
    @InjectMocks
    private CanalController canalController;

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterCanal() throws Exception {
        try {
            ResponseEntity<ResponseMensagem> result = canalController.obterCanal();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Obter canal IllegalArgument exception
     * @throws ResponseStatusException
     */
    @Test
    void obterCanalIllegalArgumentException() throws Exception {
        try {

            doThrow(IllegalArgumentException.class).when(canalService).obterCanais();
            canalController.obterCanal();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }
}
