package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.GestaoAcessoPerfilDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmailService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.GestaoAcessoPerfilServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test login service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class GestaoAcessoPerfilServiceTest {

    @Mock
    private GestaoAcessoPerfilDao gestaoAcessoPerfilDao;
    @Mock
    private LoginDao loginDao;
    @Mock
    private EmailService emailService;
    @Mock
    private Utils utils;
    @InjectMocks
    private GestaoAcessoPerfilServiceImpl gestaoAcessoPerfilServiceImpl;

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarPerfilUsuario() throws Exception {
        try {
            List<PerfilUsuario> result = gestaoAcessoPerfilServiceImpl.listarPerfilUsuario();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuarioEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void listarPerfilUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilDao).listarPerfilUsuario();
            List<PerfilUsuario> result = gestaoAcessoPerfilServiceImpl.listarPerfilUsuario();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuarioSQLException
     * 
     * @throws Exception
     */

    @Test
    void listarPerfilUsuarioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(gestaoAcessoPerfilDao).listarPerfilUsuario();
            gestaoAcessoPerfilServiceImpl.listarPerfilUsuario();

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void obterStatus() throws Exception {
        try {
            List<Status> result = gestaoAcessoPerfilServiceImpl.obterStatus();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarUsuario() throws Exception {
        try {
            List<Usuario> listaUsuario = new ArrayList<Usuario>();
            listaUsuario.add(new Usuario());
            when(gestaoAcessoPerfilDao.listarUsuario(Mockito.any())).thenReturn(listaUsuario);
            List<Usuario> result = gestaoAcessoPerfilServiceImpl.listarUsuario(new Usuario());

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    
    @Test
    void atualizarStatusPerfilUsuarioif() throws Exception {
        try {

            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            usuario.setLoginAprovador("M236621");
            usuario.setPerfil("ADM");
            usuario.setStatus("CANCEL");


            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarUsuarioEmptyResultDataAccessException() throws Exception {
        try {

            gestaoAcessoPerfilServiceImpl.listarUsuario(new Usuario());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarUsuarioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(gestaoAcessoPerfilDao).listarUsuario(Mockito.any());
            gestaoAcessoPerfilServiceImpl.listarUsuario(new Usuario());

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarParametrosAtualizarStatusPerfilUsuario() throws Exception {
        try {
            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M236621");
            atualizarStatusPerfilUsuarioRequest.setPerfil("ADM");
            atualizarStatusPerfilUsuarioRequest.setStatus("REJEITADO");
            atualizarStatusPerfilUsuarioRequest.setMotivoRecusa("Teste");

            List<PerfilUsuario> listaPerfilUsuario = new ArrayList<>();
            PerfilUsuario perfil = new PerfilUsuario();
            perfil.setCodigoTipoPerfil("ADM");
            perfil.setDescricaoTipoPerfil("ADM");
            listaPerfilUsuario.add(perfil);

            when(gestaoAcessoPerfilDao.listarPerfilUsuario()).thenReturn(listaPerfilUsuario);

            gestaoAcessoPerfilServiceImpl
                .validarParametrosAtualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarParametrosAtualizarStatusPerfilUsuarioIllegal() throws Exception {
        try {
            AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest = new AtualizarStatusPerfilUsuarioRequest();
            atualizarStatusPerfilUsuarioRequest.setLogin("M232640");
            atualizarStatusPerfilUsuarioRequest.setLoginAprovador("M236621");
            atualizarStatusPerfilUsuarioRequest.setPerfil("ADM");
            atualizarStatusPerfilUsuarioRequest.setStatus("APROVADO");
            atualizarStatusPerfilUsuarioRequest.setMotivoRecusa("Teste");

            List<PerfilUsuario> listaPerfilUsuario = new ArrayList<>();
            PerfilUsuario perfil = new PerfilUsuario();
            perfil.setCodigoTipoPerfil("ADM");
            perfil.setDescricaoTipoPerfil("ADM");
            listaPerfilUsuario.add(perfil);

            when(gestaoAcessoPerfilDao.listarPerfilUsuario()).thenReturn(listaPerfilUsuario);

            gestaoAcessoPerfilServiceImpl
                .validarParametrosAtualizarStatusPerfilUsuario(atualizarStatusPerfilUsuarioRequest);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void validarParametroPerfil() throws Exception {
        try {

            List<PerfilUsuario> listaPerfilUsuario = new ArrayList<>();
            PerfilUsuario perfil = new PerfilUsuario();
            perfil.setCodigoTipoPerfil("ADM");
            perfil.setDescricaoTipoPerfil("ADM");
            listaPerfilUsuario.add(perfil);

            when(gestaoAcessoPerfilDao.listarPerfilUsuario()).thenReturn(listaPerfilUsuario);

            gestaoAcessoPerfilServiceImpl.validarParametroPerfil("ADM");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarPerfilUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarPerfilExistenteAcessoADadosException() throws Exception {
        try {

            List<PerfilUsuario> listaPerfilUsuario = new ArrayList<>();
            PerfilUsuario perfil = new PerfilUsuario();
            perfil.setCodigoTipoPerfil("ADM");
            perfil.setDescricaoTipoPerfil("ADM");
            listaPerfilUsuario.add(perfil);

            // when(gestaoAcessoPerfilDao.listarPerfilUsuario()).thenReturn(listaPerfilUsuario);
            doThrow(SQLException.class).when(gestaoAcessoPerfilDao).listarPerfilUsuario();

            gestaoAcessoPerfilServiceImpl.validarParametroPerfil("ADM");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadePerfil() throws Exception {
        try {

            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidadePerfil("ADM");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadePerfilEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilDao)
                .obterListaFuncionalidadePerfil(Mockito.any());
            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidadePerfil("ADM");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadePerfilSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(gestaoAcessoPerfilDao).obterListaFuncionalidadePerfil(Mockito.any());
            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidadePerfil("ADM");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidade() throws Exception {
        try {

            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidade();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadeEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(gestaoAcessoPerfilDao).obterListaFuncionalidade();
            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidade();

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroPerfil
     * 
     * @throws Exception
     */
    @Test
    void obterListaFuncionalidadeSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(gestaoAcessoPerfilDao).obterListaFuncionalidade();
            List<Funcionalidade> result = gestaoAcessoPerfilServiceImpl.obterListaFuncionalidade();

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroAtualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void validarParametroAtualizarPerfilFuncionalidade() throws Exception {
        try {
            AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest = new AtualizarPerfilFuncionalidadeRequest();
            atualizarPerfilFuncionalidadeRequest.setLogin("M232640");
            List<Funcionalidade> listaFuncionalidade = new ArrayList<Funcionalidade>();
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade("Cadastrar");
            listaFuncionalidade.add(funcionalidade);
            atualizarPerfilFuncionalidadeRequest.setListaFuncionalidade(listaFuncionalidade);
            atualizarPerfilFuncionalidadeRequest.setPerfil("ADM");

            List<PerfilUsuario> listaPerfilUsuario = new ArrayList<>();
            PerfilUsuario perfil = new PerfilUsuario();
            perfil.setCodigoTipoPerfil("ADM");
            perfil.setDescricaoTipoPerfil("ADM");
            listaPerfilUsuario.add(perfil);

            when(gestaoAcessoPerfilDao.listarPerfilUsuario()).thenReturn(listaPerfilUsuario);

            gestaoAcessoPerfilServiceImpl
                .validarParametroAtualizarPerfilFuncionalidade(atualizarPerfilFuncionalidadeRequest);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarPerfilFuncionalidade() throws Exception {
        try {

            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("MSTER");
            gestaoAcessoPerfilServiceImpl.atualizarPerfilFuncionalidade(new Usuario());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarPerfilFuncionalidadeEmptyResultDataAccessException() throws Exception {
        try {

            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("ADM");
            gestaoAcessoPerfilServiceImpl.atualizarPerfilFuncionalidade(new Usuario());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarPerfilFuncionalidadeDataIntegrityViolationException() throws Exception {
        try {

            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("MSTER");
            doThrow(DataIntegrityViolationException.class).when(gestaoAcessoPerfilDao)
                .removerPerfilFuncionalidade(Mockito.any());
            gestaoAcessoPerfilServiceImpl.atualizarPerfilFuncionalidade(new Usuario());

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarPerfilFuncionalidadeSQLException() throws Exception {
        try {

            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("MSTER");
            doThrow(SQLException.class).when(gestaoAcessoPerfilDao).removerPerfilFuncionalidade(Mockito.any());
            gestaoAcessoPerfilServiceImpl.atualizarPerfilFuncionalidade(new Usuario());

        } catch (RuntimeException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuarioCanceladoRejeitado() throws Exception {
        try {

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(loginDao.validarLoginAprovador(Mockito.any())).thenReturn(true);
            when(gestaoAcessoPerfilDao.obterNumeroUsuarioCanceladoRejeitado(Mockito.any()))
                .thenReturn(new BigDecimal(1));
            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("MSTER");
            Usuario usuario = new Usuario();
            usuario.setStatus("NEGAD");
            usuario.setLogin("M232640");
            usuario.setNome("Teste");
            
            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuario() throws Exception {
        try {

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(loginDao.validarLoginAprovador(Mockito.any())).thenReturn(true);
            when(gestaoAcessoPerfilDao.obterNumeroUsuarioCanceladoRejeitado(Mockito.any()))
                .thenReturn(new BigDecimal(0));
            when(gestaoAcessoPerfilDao.obterNumeroUsuario(Mockito.any())).thenReturn(new BigDecimal(1));

            Usuario usuario = new Usuario();
            usuario.setStatus("NEGAD");
            usuario.setLogin("M232640");
            usuario.setNome("Teste");
            
            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusPerfilUsuarioEmptyResultDataAccessException() throws Exception {
        try {

            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);

            Usuario usuario = new Usuario();
            usuario.setStatus("APROV");
            
            usuario.setLogin("M232640");
            usuario.setNome("Teste");
            
            //when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (EmptyResultDataAccessException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarPerfilFuncionalidade
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusEmptyResultDataAccessExceptionObterUsuario() throws Exception {
        try {

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(loginDao.validarLoginAprovador(Mockito.any())).thenReturn(true);
            when(gestaoAcessoPerfilDao.obterNumeroUsuarioCanceladoRejeitado(Mockito.any()))
                .thenReturn(new BigDecimal(1));
            when(gestaoAcessoPerfilDao.obterNumeroUsuario(Mockito.any())).thenReturn(new BigDecimal(1));
            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("ADM");
            Usuario usuario = new Usuario();
            usuario.setStatus("NEGAD");
            
            usuario.setLogin("M232640");
            usuario.setNome("Teste");
            
            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usuario);

            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (EmptyResultDataAccessException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste atualizarStatusSQLException
     * 
     * @throws Exception
     */
    @Test
    void atualizarStatusSQLException() throws Exception {
        try {

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(loginDao.validarLoginAprovador(Mockito.any())).thenReturn(true);
            when(gestaoAcessoPerfilDao.obterNumeroUsuarioCanceladoRejeitado(Mockito.any()))
                .thenReturn(new BigDecimal(1));
            when(loginDao.obterTipoUsuario(Mockito.any())).thenReturn("MSTER");
            Usuario usuario = new Usuario();
            usuario.setStatus("NEGAD");

            doThrow(SQLException.class).when(gestaoAcessoPerfilDao).atualizarUsuarioCancelado(Mockito.any());
            gestaoAcessoPerfilServiceImpl.atualizarStatusPerfilUsuario(usuario);

        } catch (RuntimeException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
