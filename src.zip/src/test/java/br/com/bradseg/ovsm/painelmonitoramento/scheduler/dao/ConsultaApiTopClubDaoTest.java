package br.com.bradseg.ovsm.painelmonitoramento.scheduler.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiTopClubDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaApiTopClubDaoTest {
    
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private ConsultaApiTopClubDaoImpl consultaApiTopClubDaoImpl;
    
    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void inserirConsultaApi() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiTopClubDaoImpl.inserirConsultaApiTopClub(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiTopClubDaoImpl.inserirConsultaApiTopClub(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiTopClubDaoImpl.inserirConsultaApiTopClub(listaCapitalizacaoTemp);

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void liberarProcessamento() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiTopClubDaoImpl.liberarProcessamentoTopClub(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaTopClubTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaTopClubTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiTopClubDaoImpl.liberarProcessamentoTopClub(listaTopClubTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp topClubTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            topClubTemp.setcorrigeDado(850);
            topClubTemp.setCindRegProcs("P");
            // Codigo de retorno
            topClubTemp.setCerroOrign("teste");
            topClubTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            topClubTemp.setRenderUrlOrign("endereco");
            topClubTemp.setRservcOrign(null);
            topClubTemp.setItransOrign("A001");
            topClubTemp.setRtransOrign("endereco");
            topClubTemp.setIapiOrign("endereco");
            topClubTemp.setIcanalOrign("CAP");
            topClubTemp.setIemprOrign("CAPI");
            topClubTemp.setIprodtOrign("CAPITALIZACAO");
            topClubTemp.setIsprodOrign(null);
            topClubTemp.setIetapaOfert("TESTE ETAPA");
            topClubTemp.setIplatfOrign("API");
            topClubTemp.setIsitEvnto("NOK");

            topClubTemp.setDinicErro(LocalDateTime.now());
            topClubTemp.setDfimErro(null);
            topClubTemp.setDinclReg(LocalDateTime.now());
            topClubTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(topClubTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiTopClubDaoImpl.liberarProcessamentoTopClub(listaCapitalizacaoTemp);

        } catch (Exception e) {
        }
    }

    @Test
    void obterultimoregistroinserido() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class))).thenReturn("Teste");
            consultaApiTopClubDaoImpl.obterultimoregistroinseridoTopClub();

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterultimoregistroinseridoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ConsultaApiCaptalizacaoRowMapper.class));

            consultaApiTopClubDaoImpl.obterultimoregistroinseridoTopClub();

        } catch (Exception e) {

        }
    }

    @Test
    void obterultimoregistroinseridoEmptyResultDataAccessException() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class)));
            String teste = consultaApiTopClubDaoImpl.obterultimoregistroinseridoTopClub();

            Assert.isNull(teste, "é nulo");

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void validaDuplicados() throws Exception {
        try {
            List<TabelaTemp> listaTopClubTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaTopClubTemp.add(capitalizacaoTemp);

            consultaApiTopClubDaoImpl.validarDuplicadosTopClub(listaTopClubTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaTopClubTemp = new ArrayList<>();
            TabelaTemp topClubTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            topClubTemp.setcorrigeDado(850);
            topClubTemp.setCindRegProcs("P");
            // Codigo de retorno
            topClubTemp.setCerroOrign("teste");
            topClubTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            topClubTemp.setRenderUrlOrign("endereco");
            topClubTemp.setRservcOrign(null);
            topClubTemp.setItransOrign("A001");
            topClubTemp.setRtransOrign("endereco");
            topClubTemp.setIapiOrign("endereco");
            topClubTemp.setIcanalOrign("CAP");
            topClubTemp.setIemprOrign("CAPI");
            topClubTemp.setIprodtOrign("CAPITALIZACAO");
            topClubTemp.setIsprodOrign(null);
            topClubTemp.setIetapaOfert("TESTE ETAPA");
            topClubTemp.setIplatfOrign("API");
            topClubTemp.setIsitEvnto("NOK");

            topClubTemp.setDinicErro(LocalDateTime.now());
            topClubTemp.setDfimErro(null);
            topClubTemp.setDinclReg(LocalDateTime.now());
            topClubTemp.setDaltReg(null);

            listaTopClubTemp.add(topClubTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiTopClubDaoImpl.validarDuplicadosTopClub(listaTopClubTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosException() throws Exception {
        try {
            List<TabelaTemp> listaTopClubTemp = new ArrayList<>();
            TabelaTemp topClubTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            topClubTemp.setcorrigeDado(850);
            topClubTemp.setCindRegProcs("P");
            // Codigo de retorno
            topClubTemp.setCerroOrign("teste");
            topClubTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            topClubTemp.setRenderUrlOrign("endereco");
            topClubTemp.setRservcOrign(null);
            topClubTemp.setItransOrign("A001");
            topClubTemp.setRtransOrign("endereco");
            topClubTemp.setIapiOrign("endereco");
            topClubTemp.setIcanalOrign("CAP");
            topClubTemp.setIemprOrign("CAPI");
            topClubTemp.setIprodtOrign("CAPITALIZACAO");
            topClubTemp.setIsprodOrign(null);
            topClubTemp.setIetapaOfert("TESTE ETAPA");
            topClubTemp.setIplatfOrign("API");
            topClubTemp.setIsitEvnto("NOK");

            topClubTemp.setDinicErro(LocalDateTime.now());
            topClubTemp.setDfimErro(null);
            topClubTemp.setDinclReg(LocalDateTime.now());
            topClubTemp.setDaltReg(null);

            listaTopClubTemp.add(topClubTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiTopClubDaoImpl.validarDuplicadosTopClub(listaTopClubTemp);

        } catch (Exception e) {

        }
    }
}
