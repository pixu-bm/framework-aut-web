package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.IndicadorNegocioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.IndicadorNegocioServiceImpl;

@ExtendWith(MockitoExtension.class)
public class IndicadorNegocioServiceTest {

    @Mock
    private IndicadorNegocioDao indicadorNegocioDao;

    @InjectMocks
    private IndicadorNegocioServiceImpl indicadorNegocioServiceImpl;

    @Test
    void obterVolumetriaTempoRealVolumetriaMaxima() throws Exception {
        try {

            VolumetriaTempoRealVolumetriaMaxima result = indicadorNegocioServiceImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    3, null, null, "", "");

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterPainelMonitoramento
     * 
     * @throws Exception
     */
    @Test
    void obterVolumetriaTempoRealVolumetriaMaximaEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(indicadorNegocioDao).obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            VolumetriaTempoRealVolumetriaMaxima result = indicadorNegocioServiceImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    3, null, null, "", "");

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterPainelMonitoramento
     * 
     * @throws Exception
     */
    @Test
    void obterVolumetriaTempoRealVolumetriaMaximaException() throws Exception {
        try {
            doThrow(new RuntimeException()).when(indicadorNegocioDao).obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            VolumetriaTempoRealVolumetriaMaxima result = indicadorNegocioServiceImpl
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    3, null, null, "", "");

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterPainelMonitoramento
     * 
     * @throws Exception
     */
    @Test
    void obterVolumetriaTempoRealFaixaTempo() throws Exception {
        try {
            List<VolumetriaTempoReal> lista = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoEmpresa(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(2));
            volumetria.setVolumetriaAtualTransacao(new BigDecimal(12));
            lista.add(volumetria);

            when(indicadorNegocioDao.obterVolumetriaTempoRealFaixaTempo(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VolumetriaTempoReal> result = indicadorNegocioServiceImpl.obterVolumetriaTempoRealFaixaTempo(3, null,
                null, "", "");

            Assert.notNull(result, "Resultado tem que ser null");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterPainelMonitoramento
     * 
     * @throws Exception
     */
    @Test
    void obterVolumetriaTempoRealFaixaTempoListaVazia() throws Exception {
        try {
            List<VolumetriaTempoReal> lista = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoEmpresa(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(2));
            volumetria.setVolumetriaAtualTransacao(new BigDecimal(12));

            when(indicadorNegocioDao.obterVolumetriaTempoRealFaixaTempo(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VolumetriaTempoReal> result = indicadorNegocioServiceImpl.obterVolumetriaTempoRealFaixaTempo(3, null,
                null, "", "");

            Assert.notNull(result, "Resultado tem que ser null");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoEmptyResultDataAccessException() throws Exception {
        try {
            List<VolumetriaTempoReal> lista = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoEmpresa(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(2));
            volumetria.setVolumetriaAtualTransacao(new BigDecimal(12));
            lista.add(volumetria);

            doThrow(AcessoADadosException.class).when(indicadorNegocioDao).obterVolumetriaTempoRealFaixaTempo(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<VolumetriaTempoReal> result = indicadorNegocioServiceImpl.obterVolumetriaTempoRealFaixaTempo(3, null,
                null, "", "");

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealFaixaTempoException() throws Exception {
        try {
            List<VolumetriaTempoReal> lista = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoEmpresa(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(2));
            volumetria.setVolumetriaAtualTransacao(new BigDecimal(12));
            lista.add(volumetria);

            doThrow(new RuntimeException()).when(indicadorNegocioDao).obterVolumetriaTempoRealFaixaTempo(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<VolumetriaTempoReal> result = indicadorNegocioServiceImpl.obterVolumetriaTempoRealFaixaTempo(3, null,
                null, "", "");

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (Exception e) {
        }
    }

    @Test
    void obterVisaoNegocio() throws Exception {
        try {
            List<VolumetriaVisaoNegocio> lista = new ArrayList<>();
            VolumetriaVisaoNegocio volumetria = new VolumetriaVisaoNegocio();
            volumetria.setCodigoCanal(new BigDecimal(1));

            lista.add(volumetria);

            when(indicadorNegocioDao.obterVolumetriaVisaoNegocio(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            List<VolumetriaVisaoNegocio> result = indicadorNegocioServiceImpl
                .obterVolumetriaVisaoNegocio(3, null, null, null, null);

            Assert.notNull(result, "Resultado tem que ser null");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(indicadorNegocioDao).obterVolumetriaVisaoNegocio(Mockito.anyInt(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<VolumetriaVisaoNegocio> result = indicadorNegocioServiceImpl
                .obterVolumetriaVisaoNegocio(3, null, null, null, null);

            Assert.isNull(result, "Resultado tem que ser null");

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocioListaVazia() throws Exception {
        try {
            List<VolumetriaVisaoNegocio> lista = new ArrayList<>();
            VolumetriaVisaoNegocio volumetria = new VolumetriaVisaoNegocio();
            volumetria.setCodigoCanal(new BigDecimal(1));

            when(indicadorNegocioDao.obterVolumetriaVisaoNegocio(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            List<VolumetriaVisaoNegocio> result = indicadorNegocioServiceImpl
                .obterVolumetriaVisaoNegocio(3, null, null, null, null);

            Assert.notNull(result, "Resultado tem que ser null");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoNegocioException() throws Exception {
        try {
            List<VolumetriaVisaoNegocio> lista = new ArrayList<>();
            VolumetriaVisaoNegocio volumetria = new VolumetriaVisaoNegocio();
            volumetria.setCodigoCanal(new BigDecimal(1));

            lista.add(volumetria);

            doThrow(new RuntimeException()).when(indicadorNegocioDao).obterVolumetriaVisaoNegocio(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<VolumetriaVisaoNegocio> result = indicadorNegocioServiceImpl
                .obterVolumetriaVisaoNegocio(3, null, null, null, null);

            Assert.notNull(result, "Resultado tem que ser null");

        } catch (Exception e) {
        }
    }

    @Test
    void obterRankingEventos() throws Exception {
        try {
            List<ComboRankingEventos> obterComboRankingEventos = indicadorNegocioServiceImpl.obterRankingEventos(1,
                null, null);
            Assert.notNull(obterComboRankingEventos, "result tem que trazer uma lista de Rank Eventos");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterRankingEventosEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(
                indicadorNegocioDao).obterRankingEventos(Mockito.any(), Mockito.any(), Mockito.any());

            List<ComboRankingEventos> obterComboRankingEventos = indicadorNegocioServiceImpl.obterRankingEventos(
                Mockito.any(), Mockito.any(),
                Mockito.any());
            Assert.notNull(obterComboRankingEventos, "Resultado tem que ser null");
        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(
                indicadorNegocioDao).obterRankingEventos(Mockito.any(), Mockito.any(), Mockito.any());

            List<ComboRankingEventos> obterComboRankingEventos = indicadorNegocioServiceImpl.obterRankingEventos(
                Mockito.any(), Mockito.any(),
                Mockito.any());
            Assert.notNull(obterComboRankingEventos, "Resultado tem que ser null");
        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRankingEventosSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(
                indicadorNegocioDao).obterRankingEventos(Mockito.any(), Mockito.any(), Mockito.any());

            List<ComboRankingEventos> obterComboRankingEventos = indicadorNegocioServiceImpl.obterRankingEventos(
                Mockito.any(), Mockito.any(),
                Mockito.any());
            Assert.notNull(obterComboRankingEventos, "Resultado tem que ser null");
        } catch (SQLException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocio() throws Exception {

        List<BigDecimal> canal = new ArrayList<>();
        List<BigDecimal> produto = new ArrayList<>();
        canal.add(new BigDecimal(1));
        produto.add(new BigDecimal(1));

        IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
        indicadoresNegocioTest.setTotalTransacoes(500);
        indicadoresNegocioTest.setVendas(500);
        indicadoresNegocioTest.setTempoTotalEventos("20:00:00");
        indicadoresNegocioTest.setTempoMedioEventos("10:00:00");
        indicadoresNegocioTest.setQtdEventos(500);
        indicadoresNegocioTest.setTransacoesImpactadas(500);
        indicadoresNegocioTest.setFrequenciaEventos(500);

        IndicadoresNegocio indicadoresNegocioTestComparacao = new IndicadoresNegocio();
        indicadoresNegocioTestComparacao.setTotalTransacoes(1000);
        indicadoresNegocioTestComparacao.setVendas(1000);
        indicadoresNegocioTestComparacao.setTempoTotalEventos("40:00:00");
        indicadoresNegocioTestComparacao.setTempoMedioEventos("20:00:00");
        indicadoresNegocioTestComparacao.setQtdEventos(1000);
        indicadoresNegocioTestComparacao.setTransacoesImpactadas(1000);
        indicadoresNegocioTestComparacao.setFrequenciaEventos(1000);

        try {
            when(indicadorNegocioDao.obterIndicadoresNegocio(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(indicadoresNegocioTest);

            when(indicadorNegocioDao.obterIndicadoresNegocioComparacao(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(indicadoresNegocioTestComparacao);

            IndicadoresNegocio indicadoresNegocio = indicadorNegocioServiceImpl.obterIndicadoresNegocio(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(indicadoresNegocio, "result tem que trazer um objeto IndicadoresNegocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterIndicadoresNegocioTeste() throws Exception {

        List<BigDecimal> canal = new ArrayList<>();
        List<BigDecimal> produto = new ArrayList<>();
        canal.add(new BigDecimal(1));
        produto.add(new BigDecimal(1));

        IndicadoresNegocio indicadoresNegocioTest = new IndicadoresNegocio();
        indicadoresNegocioTest.setTotalTransacoes(1000);
        indicadoresNegocioTest.setVendas(1000);
        indicadoresNegocioTest.setTempoTotalEventos("40:00:00");
        indicadoresNegocioTest.setTempoMedioEventos("20:00:00");
        indicadoresNegocioTest.setQtdEventos(1000);
        indicadoresNegocioTest.setTransacoesImpactadas(1000);
        indicadoresNegocioTest.setFrequenciaEventos(1000);

        IndicadoresNegocio indicadoresNegocioTestComparacao = new IndicadoresNegocio();
        indicadoresNegocioTestComparacao.setTotalTransacoes(500);
        indicadoresNegocioTestComparacao.setVendas(500);
        indicadoresNegocioTestComparacao.setTempoTotalEventos("20:00:00");
        indicadoresNegocioTestComparacao.setTempoMedioEventos("10:00:00");
        indicadoresNegocioTestComparacao.setQtdEventos(500);
        indicadoresNegocioTestComparacao.setTransacoesImpactadas(500);
        indicadoresNegocioTestComparacao.setFrequenciaEventos(500);

        try {
            when(indicadorNegocioDao.obterIndicadoresNegocio(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(indicadoresNegocioTest);

            when(indicadorNegocioDao.obterIndicadoresNegocioComparacao(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(indicadoresNegocioTestComparacao);

            IndicadoresNegocio indicadoresNegocio = indicadorNegocioServiceImpl.obterIndicadoresNegocio(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(indicadoresNegocio, "result tem que trazer um objeto IndicadoresNegocio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterIndicadoresNegocioSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(
                indicadorNegocioDao)
                .obterIndicadoresNegocio(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            IndicadoresNegocio indicadoresNegocio = indicadorNegocioServiceImpl.obterIndicadoresNegocio(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
            Assert.isNull(indicadoresNegocio, "Resultado tem que ser null");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterIndicadoresNegocioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(
                indicadorNegocioDao)
                .obterIndicadoresNegocio(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            IndicadoresNegocio indicadoresNegocio = indicadorNegocioServiceImpl.obterIndicadoresNegocio(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());
            Assert.isNull(indicadoresNegocio, "Resultado tem que ser null");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testValidarParametro() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametro(1);
            indicadorNegocioServiceImpl.validarParametro(0);
            indicadorNegocioServiceImpl.validarParametro(5);
            indicadorNegocioServiceImpl.validarParametro(null);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametroMaiorQueQuatro() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametro(5);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametroNull() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametro(null);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro periodoVisaoEvento diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametroRanking() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametroRanking(1);
            indicadorNegocioServiceImpl.validarParametroRanking(0);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametroRankingMaiorQueQuatro() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametroRanking(4);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametroRankingNull() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametroRanking(null);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não deve ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa não pode ser 0(Zero)")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Parametro codigoPesquisa diferente dos número validos")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametrosDatas() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametrosDatas("01/01/2000", "01/01/2000");
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("dataInicio não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("dataFim não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataInicio errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataFim errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametrosDatasInicioNull() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametrosDatas(null, "01/01/2000");
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("dataInicio não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("dataFim não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataInicio errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataFim errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametrosDatasFimNull() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametrosDatas("01/01/2000", null);
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("dataInicio não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("dataFim não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataInicio errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataFim errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametrosDatasFormatoErradoInicio() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametrosDatas("01012000", "01/01/2000");
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("dataInicio não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("dataFim não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataInicio errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataFim errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testValidarParametrosDatasFormatoErradoFim() throws Exception {
        try {
            indicadorNegocioServiceImpl.validarParametrosDatas("01/01/2000", "01012000");
        } catch (AcessoADadosException e) {
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase("dataInicio não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("dataFim não pode ser nulo.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataInicio errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else if (e.getMessage().equalsIgnoreCase("Formato de dataFim errado.")) {
                Assert.isTrue(true, "Erro previsto");
            } else {
                throw new Exception(e.getMessage());
            }
        }
    }

    @Test
    void testObterNumeroTransacao() throws Exception {
        try {
            NumeroTransacoes valorTest = new NumeroTransacoes();
            valorTest.setTotalTransacoes(1000);
            valorTest.setTotalTransacoesComEvento(500);
            valorTest.setTotalTransacoesSemEvento(500);

            when(indicadorNegocioDao.obterNumeroTransacao(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(valorTest);

            NumeroTransacoes test = indicadorNegocioServiceImpl.obterNumeroTransacao(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testObterNumeroTransacaoTotalZero() throws Exception {
        try {
            NumeroTransacoes valorTest = new NumeroTransacoes();
            valorTest.setTotalTransacoes(0);

            when(indicadorNegocioDao.obterNumeroTransacao(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(valorTest);

            NumeroTransacoes test = indicadorNegocioServiceImpl.obterNumeroTransacao(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testObterEventoPorCanal() throws Exception {
        try {
            Canal canalTest = new Canal();
            canalTest.setCodigo(new BigDecimal(1));
            canalTest.setDescricao("Test 1");

            EventoPorCanal valorTest = new EventoPorCanal();
            valorTest.setCanal(canalTest);
            valorTest.setQuantidadeEventoCanal(1000);

            List<EventoPorCanal> listaTest = new ArrayList<>();
            listaTest.add(valorTest);

            canalTest.setCodigo(new BigDecimal(2));
            canalTest.setDescricao("Test 2");

            valorTest.setCanal(canalTest);
            valorTest.setQuantidadeEventoCanal(1000);

            listaTest.add(valorTest);

            when(indicadorNegocioDao.obterListaEventoCanal(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(listaTest);

            List<EventoPorCanal> test = indicadorNegocioServiceImpl.obterEventoPorCanal(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testObterEventoPorCanalTotalZero() throws Exception {
        try {
            Canal canalTest = new Canal();
            canalTest.setCodigo(new BigDecimal(1));
            canalTest.setDescricao("Test 1");

            EventoPorCanal valorTest = new EventoPorCanal();
            valorTest.setCanal(canalTest);
            valorTest.setQuantidadeEventoCanal(0);

            List<EventoPorCanal> listaTest = new ArrayList<>();
            listaTest.add(valorTest);

            canalTest.setCodigo(new BigDecimal(2));
            canalTest.setDescricao("Test 2");

            valorTest.setCanal(canalTest);
            valorTest.setQuantidadeEventoCanal(0);

            listaTest.add(valorTest);

            when(indicadorNegocioDao.obterListaEventoCanal(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(listaTest);

            List<EventoPorCanal> test = indicadorNegocioServiceImpl.obterEventoPorCanal(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testObterTipoEvento() throws Exception {
        try {
            TipoEvento valorTest = new TipoEvento();
            valorTest.setQuantidadeTotalTipoEvento(1500);
            valorTest.setQuantidadeTotalDisponibilidade(500);
            valorTest.setQuantidadeTotalFuncionalidade(500);
            valorTest.setQuantidadeTotalVolumetria(500);

            when(indicadorNegocioDao.obterTipoEvento(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(valorTest);

            TipoEvento test = indicadorNegocioServiceImpl.obterTipoEvento(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testObterTipoEventoTotalZero() throws Exception {
        try {
            TipoEvento valorTest = new TipoEvento();
            valorTest.setQuantidadeTotalTipoEvento(0);
            valorTest.setQuantidadeTotalDisponibilidade(0);
            valorTest.setQuantidadeTotalFuncionalidade(0);
            valorTest.setQuantidadeTotalVolumetria(0);

            when(indicadorNegocioDao.obterTipoEvento(
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(valorTest);

            TipoEvento test = indicadorNegocioServiceImpl.obterTipoEvento(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.notNull(test, "Não deve ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
