package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;

@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaTest {

    @InjectMocks
    private ConsultaHistorica consultaHistorica;

    @Test
    void eventoPorCanal () throws Exception {
        try {
            ConsultaHistorica test = new ConsultaHistorica();
            test.setCodigoEvento(new BigDecimal(1));
            test.setGravidade("Gravidade");
            test.setProduto("Produto");
            test.setCanal("Canal");
            test.setTipoEvento("Tipo Evento");
            test.setTransacoesImpactadas(new BigDecimal(1));
            test.setDuracaoDisp(1L);
            test.setDuracaoFunc(1L);
            test.setDuracaoVolu(1L);
            test.setDuracaoDispFmt("Teste");
            test.setDuracaoFuncFmt("Teste");
            test.setDuracaoVoluFmt("Teste");
            test.setData("Teste");
            test.setRecorrencia(new BigDecimal(1));
            
            test.getCodigoEvento();
            test.getGravidade();
            test.getProduto();
            test.getCanal();
            test.getTipoEvento();
            test.getTransacoesImpactadas();
            test.getDuracaoFunc();
            test.getDuracaoDisp();
            test.getDuracaoVolu();
            test.getDuracaoFuncFmt();
            test.getDuracaoDispFmt();
            test.getDuracaoVoluFmt();
            test.getData();
            test.getRecorrencia();
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
