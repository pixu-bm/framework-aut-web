package br.com.bradseg.ovsm.painelmonitoramento.service.export.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.IndicadorNegocioServiceExport;
import io.jsonwebtoken.lang.Assert;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class IndicadorNegocioServiceExportTest {

    @Mock
    private Document document;
    @Mock
    private LoginDao loginDao;
    @Mock
    private ProdutoDao produtoDao;
    @Mock
    private CanalDao canalDao;
    @InjectMocks
    private IndicadorNegocioServiceExport indicadorNegocioServiceExport;

    @Test
    void excelCsvMonitorVisaoTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            Object[] objectArray = {"Test", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal};

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            Workbook wbResult = indicadorNegocioServiceExport.excelCsvMonitorVisao(volu, listaVolumetriaTempoReal,
                1, objectArray);

            wbResult = indicadorNegocioServiceExport.excelCsvMonitorVisao(volu, listaVolumetriaTempoReal,
                2, objectArray);

            volu.setMediaHistoricaTransacao(null);
            volu.setVolumetriaAtualTransacao(null);

            wbResult = indicadorNegocioServiceExport.excelCsvMonitorVisao(volu, listaVolumetriaTempoReal,
                3, objectArray);

            Assert.notNull(wbResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excelCsvMonitorVisaoAcessoADadosExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            Object[] objectArray = {"Test", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal};

            doThrow(AcessoADadosException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            indicadorNegocioServiceExport.excelCsvMonitorVisao(volu, listaVolumetriaTempoReal,
                1, objectArray);
        } catch (AcessoADadosException e) {

            // Teste ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void excelCsvMonitorVisaoSQLExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            Object[] objectArray = {"Test", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal};

            doThrow(SQLException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            indicadorNegocioServiceExport.excelCsvMonitorVisao(volu, listaVolumetriaTempoReal,
                1, objectArray);
        } catch (AcessoADadosException e) {

            // Teste ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excelCsvIndicadorTest() throws Exception {
        try {

            List<IndicadoresNegocio> listaIndicadoresNegocio = new ArrayList<>();
            IndicadoresNegocio indicadoresNegocio = new IndicadoresNegocio();
            indicadoresNegocio.setCanal("Test");
            indicadoresNegocio.setProduto("Test");
            indicadoresNegocio.setFrequenciaEventos(10);
            indicadoresNegocio.setQtdEventos(10);
            indicadoresNegocio.setTotalTransacoes(10);
            indicadoresNegocio.setTransacoesImpactadas(10);
            indicadoresNegocio.setPorcentagemfrequenciaEventos("10%");
            indicadoresNegocio.setPorcentagemqtdEventos("10%");
            indicadoresNegocio.setPorcentagemtempoMedioEventos("10%");
            indicadoresNegocio.setPorcentagemtempoTotalEventos("10%");
            indicadoresNegocio.setPorcentagemtotalTransacoes("10%");
            indicadoresNegocio.setPorcentagemtransacoesImpactadas("10%");
            indicadoresNegocio.setTempoMedioEventos("20:00:00");
            indicadoresNegocio.setTempoTotalEventos("20:00:00");
            listaIndicadoresNegocio.add(indicadoresNegocio);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            Object[] objectArray = {"Test", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal};

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            Workbook wbResult = indicadorNegocioServiceExport.excelCsvIndicador(listaIndicadoresNegocio, objectArray);

            Assert.notNull(wbResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void excelCsvRankingTest() throws Exception {
        try {

            List<ComboRankingEventos> listaComboRankingEventos = new ArrayList<>();
            ComboRankingEventos comboRankingEventos = new ComboRankingEventos();
            comboRankingEventos.setDescricaoCanal("Test");
            comboRankingEventos.setDescricaoProduto("Test");
            comboRankingEventos.setDuracao(new BigDecimal(10000));
            comboRankingEventos.setDuracaoFmt("20:00:00");
            comboRankingEventos.setImpacto(new BigDecimal(10000));
            comboRankingEventos.setRecorrencia(new BigDecimal(10000));
            listaComboRankingEventos.add(comboRankingEventos);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            Object[] objectArray = {"Test", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal};

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            Workbook wbResult = indicadorNegocioServiceExport.excelCsvRanking(listaComboRankingEventos,
                1, 1, objectArray);

            wbResult = indicadorNegocioServiceExport.excelCsvRanking(listaComboRankingEventos,
                2, 2, objectArray);

            comboRankingEventos.setRecorrencia(null);

            wbResult = indicadorNegocioServiceExport.excelCsvRanking(listaComboRankingEventos,
                3, 3, objectArray);

            Assert.notNull(wbResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pdfMonitorVisaoTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            ByteArrayInputStream baResult = indicadorNegocioServiceExport.pdfMonitorVisao(volu,
                listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            baResult = indicadorNegocioServiceExport.pdfMonitorVisao(volu, listaVolumetriaTempoReal,
                2, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            baResult = indicadorNegocioServiceExport.pdfMonitorVisao(volu, listaVolumetriaTempoReal,
                3, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void pdfMonitorVisaoAcessoADadosExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            doThrow(AcessoADadosException.class).when(document).close();

            indicadorNegocioServiceExport.pdfMonitorVisao(volu,
                listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

        } catch (AcessoADadosException e) {
            // Test Ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void pdfMonitorVisaoEmptyResultDataAccessExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            doThrow(EmptyResultDataAccessException.class).when(document).close();

            indicadorNegocioServiceExport.pdfMonitorVisao(volu,
                listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

        } catch (EmptyResultDataAccessException e) {
            // Test Ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void pdfMonitorVisaoDocumentExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            doThrow(DocumentException.class).when(document).close();

            ByteArrayInputStream result = indicadorNegocioServiceExport.pdfMonitorVisao(volu,
                listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            Assert.isNull(result, "Deve ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void montarCabecalhoPDFAcessoADadosExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            doThrow(AcessoADadosException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            indicadorNegocioServiceExport.pdfMonitorVisao(volu, listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

        } catch (AcessoADadosException e) {
            // Test Ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void montarCabecalhoPDFSQLExceptionTest() throws Exception {
        try {
            VolumetriaTempoRealVolumetriaMaxima volu = new VolumetriaTempoRealVolumetriaMaxima();
            volu.setMediaHistoricaTransacao(new BigDecimal(500));
            volu.setTransacaoEvento(new BigDecimal(500));
            volu.setTransacaoSemEvento(new BigDecimal(500));
            volu.setVolumetriaAtualTransacao(new BigDecimal(500));

            List<VolumetriaTempoReal> listaVolumetriaTempoReal = new ArrayList<>();
            VolumetriaTempoReal volumetria = new VolumetriaTempoReal();
            volumetria.setCodigoCanal(new BigDecimal(1));
            volumetria.setCodigoProduto(new BigDecimal(1));
            volumetria.setDescCanal("Teste");
            volumetria.setDescProduto("Teste");
            volumetria.setTransacaoEvento(new BigDecimal(500));
            volumetria.setTransacaoSemEvento(new BigDecimal(500));
            listaVolumetriaTempoReal.add(volumetria);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            doThrow(SQLException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            indicadorNegocioServiceExport.pdfMonitorVisao(volu, listaVolumetriaTempoReal,
                1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

        } catch (AcessoADadosException e) {
            // Test Ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void pdfIndicadorTest() throws Exception {
        try {
            List<IndicadoresNegocio> listaIndicadoresNegocio = new ArrayList<>();
            IndicadoresNegocio indicadoresNegocio = new IndicadoresNegocio();
            indicadoresNegocio.setCanal("Test");
            indicadoresNegocio.setProduto("Test");
            indicadoresNegocio.setFrequenciaEventos(10);
            indicadoresNegocio.setQtdEventos(10);
            indicadoresNegocio.setTotalTransacoes(10);
            indicadoresNegocio.setTransacoesImpactadas(10);
            indicadoresNegocio.setPorcentagemfrequenciaEventos("10%");
            indicadoresNegocio.setPorcentagemqtdEventos("10%");
            indicadoresNegocio.setPorcentagemtempoMedioEventos("10%");
            indicadoresNegocio.setPorcentagemtempoTotalEventos("10%");
            indicadoresNegocio.setPorcentagemtotalTransacoes("10%");
            indicadoresNegocio.setPorcentagemtransacoesImpactadas("10%");
            indicadoresNegocio.setTempoMedioEventos("20:00:00");
            indicadoresNegocio.setTempoTotalEventos("20:00:00");
            listaIndicadoresNegocio.add(indicadoresNegocio);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            ByteArrayInputStream baResult = indicadorNegocioServiceExport.pdfIndicador(listaIndicadoresNegocio,
                listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void pdfRankingTest() throws Exception {
        try {
            List<ComboRankingEventos> listaComboRankingEventos = new ArrayList<>();
            ComboRankingEventos comboRankingEventos = new ComboRankingEventos();
            comboRankingEventos.setDescricaoCanal("Test");
            comboRankingEventos.setDescricaoProduto("Test");
            comboRankingEventos.setDuracao(new BigDecimal(10000));
            comboRankingEventos.setDuracaoFmt("20:00:00");
            comboRankingEventos.setImpacto(new BigDecimal(10000));
            comboRankingEventos.setRecorrencia(new BigDecimal(10000));
            listaComboRankingEventos.add(comboRankingEventos);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            ByteArrayInputStream baResult = indicadorNegocioServiceExport.pdfRanking(listaComboRankingEventos,
                1, 1, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");
            
            baResult = indicadorNegocioServiceExport.pdfRanking(listaComboRankingEventos,
                2, 2, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");
            
            comboRankingEventos.setRecorrencia(null);
            
            baResult = indicadorNegocioServiceExport.pdfRanking(listaComboRankingEventos,
                3, 3, listaBigDecimal, listaBigDecimal, "01/01/2022", "01/01/2022", "Test");

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
