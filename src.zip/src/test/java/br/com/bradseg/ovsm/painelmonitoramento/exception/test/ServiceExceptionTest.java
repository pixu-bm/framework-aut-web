package br.com.bradseg.ovsm.painelmonitoramento.exception.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.ServiceExcecao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ServiceExceptionTest {

    @InjectMocks
    private ServiceExcecao exception;

    /**
     * Teste testeException
     * 
     * @throws Exception
     */
    @Test
    void testeException() throws Exception {
        try {

            ResponseStatusException e = new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                "teste" + ";" + "1");

            ResponseEntity<ResponseMensagem> result = exception.handleNotFoundException(e, null);

            Assert.notNull(result, "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
