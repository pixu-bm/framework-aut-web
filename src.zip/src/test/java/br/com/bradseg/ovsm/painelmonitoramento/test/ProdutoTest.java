package br.com.bradseg.ovsm.painelmonitoramento.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.ProdutoController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ProdutoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.Mockito.doThrow;

/**
 * Classe implementa test automatizados Produto test
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ProdutoTest {

    @Mock
    ProdutoService produtoService;

    @InjectMocks
    private ProdutoController produtoController;

    @Test
    void obterProduto() throws Exception {
        try {
            ResponseEntity<ResponseMensagem> produto = produtoController.obterProduto();

            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterProdutoIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(produtoService).obterProduto();
            produtoController.obterProduto();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }


    @Test
    void obterCanais() throws Exception {
        try {
            ResponseEntity<ResponseMensagem> produto = produtoController.obterCanal("VIDA");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
            produto = produtoController.obterCanal("VIAGEM");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
            produto = produtoController.obterCanal("AUTO");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
            produto = produtoController.obterCanal("CAPITALIZACAO");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
            produto = produtoController.obterCanal("DENTAL");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
            produto = produtoController.obterCanal("SUPERPROTEGIDO");
            Assert.isTrue(produto.getStatusCode().equals(HttpStatus.OK), produto.getBody().getMensagem());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterCanaisIllegalArgumentException() throws Exception {

        try {
            doThrow(IllegalArgumentException.class).when(produtoService).obterCanaisProduto("TESTE");
            produtoController.obterCanal("TESTE");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterCanaisException() throws Exception {

        try {
            doThrow(ResponseStatusException.class).when(produtoService).obterCanaisProduto("TESTE");
            produtoController.obterCanal("TESTE");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

}
