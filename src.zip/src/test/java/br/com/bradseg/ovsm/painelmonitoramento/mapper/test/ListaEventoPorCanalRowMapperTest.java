package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaEventoPorCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;

/**
 * Classe implementa test automatizados gestão acesso canal service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ListaEventoPorCanalRowMapperTest {

    @InjectMocks
    private ListaEventoPorCanalRowMapper listaEventoPorCanalRowMapper;

    @Test
    void testeListaEventoPorCanalRowMapper() throws Exception {
        try {
            
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("CANAL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getString("DESC_CANAL")).thenReturn("teste");
            Mockito.when(resultSetMock.getInt("SOMAS_EVENTOS")).thenReturn(1);
            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<EventoPorCanal> eventoPorCanal = listaEventoPorCanalRowMapper.mapRow(resultSetMock, 0);

            Assert.notNull(eventoPorCanal, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
