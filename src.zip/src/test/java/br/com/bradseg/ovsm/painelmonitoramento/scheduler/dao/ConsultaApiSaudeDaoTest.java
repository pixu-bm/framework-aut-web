package br.com.bradseg.ovsm.painelmonitoramento.scheduler.dao;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiCaptalizacaoDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiSaudeDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaApiSaudeDaoTest {
    
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private ConsultaApiSaudeDaoImpl consultaApiSaudeDaoImpl;
    
    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void inserirConsultaApi() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiSaudeDaoImpl.inserirConsultaApiSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiSaudeDaoImpl.inserirConsultaApiSaude(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiSaudeDaoImpl.inserirConsultaApiSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void liberarProcessamento() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiSaudeDaoImpl.liberarProcessamentoSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiSaudeDaoImpl.liberarProcessamentoSaude(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiSaudeDaoImpl.liberarProcessamentoSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {
        }
    }

    @Test
    void obterultimoregistroinserido() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class))).thenReturn("Teste");
            consultaApiSaudeDaoImpl.obterultimoregistroinseridoSaude();

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterultimoregistroinseridoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ConsultaApiCaptalizacaoRowMapper.class));

            consultaApiSaudeDaoImpl.obterultimoregistroinseridoSaude();

        } catch (Exception e) {

        }
    }

    @Test
    void obterultimoregistroinseridoEmptyResultDataAccessException() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class)));
            String teste = consultaApiSaudeDaoImpl.obterultimoregistroinseridoSaude();

            Assert.isNull(teste, "é nulo");

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void validaDuplicados() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiSaudeDaoImpl.validarDuplicadosSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiSaudeDaoImpl.validarDuplicadosSaude(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiSaudeDaoImpl.validarDuplicadosSaude(listaCapitalizacaoTemp);

        } catch (Exception e) {

        }
    }
}
