package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ProdutoCombo;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;

@ExtendWith(MockitoExtension.class)
public class ProdutoComboTest {

    @InjectMocks
    private ProdutoCombo produtoCombo;

    @Test
    void produtoCombo () throws Exception {
        try {
            ProdutoCombo produtoCombo = new ProdutoCombo();
            Produto produto = new Produto();
            List<Produto> lista = new ArrayList<>();
            produto.setDescricao("Teste");
            lista.add(produto);
            produtoCombo.setProdutosCombo(lista);
            lista = produtoCombo.getProdutosCombo();
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
