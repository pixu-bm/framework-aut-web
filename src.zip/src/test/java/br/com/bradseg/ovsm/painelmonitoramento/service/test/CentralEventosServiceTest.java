package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CentralEventosDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.CentralEventosServiceExport;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.CentralEventosServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
class CentralEventosServiceTest {

    @Mock
    private Utils utils;
    @Mock
    private CentralEventosDao centralEventosDao;
    @Mock
    private CentralEventosServiceExport centralEventosServiceExport;
    @InjectMocks
    private CentralEventosServiceImpl centralEventosServiceImpl;

    @Test
    void validarParametroCentralEvento() throws Exception {
        try {
            centralEventosServiceImpl.validarParametrosVisaoEventoAberto("10/10/2021", "10/11/2021");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAberto() throws Exception {
        try {
            when(centralEventosDao.obterVisaoEventoAberto(Mockito.any(), Mockito.any())).thenReturn(new VisaoEvento());
            VisaoEvento visaoEvento = centralEventosServiceImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(centralEventosDao).obterVisaoEventoAberto(Mockito.any(),
                Mockito.any());

            VisaoEvento visaoEvento = centralEventosServiceImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(centralEventosDao).obterVisaoEventoAberto(Mockito.any(),
                Mockito.any());

            VisaoEvento visaoEvento = centralEventosServiceImpl.obterVisaoEventoAberto(new Date(), new Date());

            Assert.notNull(visaoEvento, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProduto() throws Exception {
        try {
            List<VisaoEventoProduto> lista = new ArrayList<>();
            lista.add(new VisaoEventoProduto());

            when(centralEventosDao.obterVisaoEventoProduto(Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VisaoEventoProduto> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoProduto(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoProdutoEmptyResultDataAccessException() throws Exception {
        try {
            List<VisaoEventoProduto> lista = new ArrayList<>();

            when(centralEventosDao.obterVisaoEventoProduto(Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VisaoEventoProduto> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoProduto(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoAbertoProdutoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(centralEventosDao).obterVisaoEventoProduto(Mockito.any(),
                Mockito.any());

            List<VisaoEventoProduto> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoProduto(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanal() throws Exception {
        try {
            List<VisaoEventoCanal> lista = new ArrayList<>();
            lista.add(new VisaoEventoCanal());

            when(centralEventosDao.obterVisaoEventoCanal(Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VisaoEventoCanal> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoCanal(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoAbertoCanalEmptyResultDataAccessException() throws Exception {
        try {
            List<VisaoEventoCanal> lista = new ArrayList<>();

            when(centralEventosDao.obterVisaoEventoCanal(Mockito.any(), Mockito.any())).thenReturn(lista);
            List<VisaoEventoCanal> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoCanal(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoAbertoCanalException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(centralEventosDao).obterVisaoEventoCanal(Mockito.any(), Mockito.any());

            List<VisaoEventoCanal> listaVisaoEvento = centralEventosServiceImpl.obterVisaoEventoCanal(new Date(),
                new Date());

            Assert.notNull(listaVisaoEvento, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEvento() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            lista.add(registro);

            when(centralEventosDao.obterRegistroEvento(Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            List<RegistroEvento> listaRegistro = centralEventosServiceImpl.obterRegistroEvento(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2));

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterRegistroEventoListEmpty() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();

            when(centralEventosDao.obterRegistroEvento(Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            List<RegistroEvento> listaRegistro = centralEventosServiceImpl.obterRegistroEvento(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2));

            Assert.notNull(listaRegistro, "Deve retornar erro");

        } catch (EmptyResultDataAccessException e) {
          //teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoEmptyResultDataAccessException() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            lista.add(registro);

            doThrow(EmptyResultDataAccessException.class).when(centralEventosDao).obterRegistroEvento(Mockito.anyList(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<RegistroEvento> listaRegistro = centralEventosServiceImpl.obterRegistroEvento(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2));

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterRegistroEventoException() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            lista.add(registro);

            doThrow(new RuntimeException()).when(centralEventosDao).obterRegistroEvento(Mockito.anyList(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<RegistroEvento> listaRegistro = centralEventosServiceImpl.obterRegistroEvento(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2));

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalhe() throws Exception {
        try {

            VisaoGeralProduto visao = centralEventosServiceImpl.obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoProdutoDetalheEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosDao)
                .obterVisaoEventoProdutoDetalhe(Mockito.any(), Mockito.any());
            VisaoGeralProduto visao = centralEventosServiceImpl.obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoProdutoDetalheException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(centralEventosDao).obterVisaoEventoProdutoDetalhe(Mockito.any(),
                Mockito.any());
            VisaoGeralProduto visao = centralEventosServiceImpl.obterVisaoEventoProdutoDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalhe() throws Exception {
        try {

            VisaoGeralCanal visao = centralEventosServiceImpl.obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoCanalDetalheEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosDao)
                .obterVisaoEventoCanalDetalhe(Mockito.any(), Mockito.any());
            VisaoGeralCanal visao = centralEventosServiceImpl.obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterVisaoEventoCanalException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(centralEventosDao).obterVisaoEventoCanalDetalhe(Mockito.any(),
                Mockito.any());
            VisaoGeralCanal visao = centralEventosServiceImpl.obterVisaoEventoCanalDetalhe(1, new BigDecimal(2));

            Assert.isNull(visao, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterRegistroEventoExcel() throws Exception {
        try {
            List<RegistroEvento> lista = new ArrayList<>();
            RegistroEvento registro = new RegistroEvento();
            registro.setCodigo(new BigDecimal(1));
            registro.setNumeroTransacao(new BigDecimal(2));
            registro.setCodigoGravidade(new BigDecimal(2));
            registro.setDataInicioEvento("10/10/2021");
            registro.setDescricaoCanal("Teste");
            registro.setDescricaoGravidade("Teste");
            registro.setDescricaoProduto("Teste");
            registro.setDescricaoTipo("Teste");
            registro.setRecorrencia(10);

            lista.add(registro);

            when(centralEventosDao.obterRegistroEvento(Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            Workbook listaRegistro = centralEventosServiceImpl.obterRegistroEventoExcel(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2), "M232640");

            Assert.isNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterRegistroEventoExcelException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(centralEventosDao).obterRegistroEvento(Mockito.anyList(),
                Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            Workbook listaRegistro = centralEventosServiceImpl.obterRegistroEventoExcel(new ArrayList<>(),
                new ArrayList<>(), 1, new Date(), new Date(), new BigDecimal(2), "M232640");

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterStatusDetalheEvento() throws Exception {
        try {
            List<StatusDetalheEvento> lista = new ArrayList<>();
            StatusDetalheEvento sde = new StatusDetalheEvento();
            sde.setDisponibilidade(new BigDecimal(1));
            sde.setDisponibilidade(new BigDecimal(1));
            lista.add(sde);

            when(centralEventosDao.obterStatusDetalheEvento(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

            List<StatusDetalheEvento> listaRegistro = centralEventosServiceImpl.obterStatusDetalheEvento(1,
              new BigDecimal(2), new BigDecimal(2), new BigDecimal(2), new Date(), 1, 1);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterStatusDetalheEventoListEmpty() throws Exception {
        try {
          List<StatusDetalheEvento> lista = new ArrayList<>();

          when(centralEventosDao.obterStatusDetalheEvento(Mockito.any(), Mockito.any(),
              Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(lista);

          List<StatusDetalheEvento> listaRegistro = centralEventosServiceImpl.obterStatusDetalheEvento(1,
            new BigDecimal(2), new BigDecimal(2), new BigDecimal(2), new Date(), 1, 1);

          Assert.notNull(listaRegistro, "Deve retornar erro");

        } catch (EmptyResultDataAccessException e) {
          //teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterStatusDetalheEventoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(centralEventosDao).obterStatusDetalheEvento(Mockito.any(), Mockito.any(),
              Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<StatusDetalheEvento> listaRegistro = centralEventosServiceImpl.obterStatusDetalheEvento(1,
              new BigDecimal(2), new BigDecimal(2), new BigDecimal(2), new Date(), 1, 1);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {
          //teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    void obterStatusDetalheEventoException() throws Exception {
        try {
            doThrow(new RuntimeException()).when(centralEventosDao).obterStatusDetalheEvento(Mockito.any(), Mockito.any(),
              Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            List<StatusDetalheEvento> listaRegistro = centralEventosServiceImpl.obterStatusDetalheEvento(1,
              new BigDecimal(2), new BigDecimal(2), new BigDecimal(2), new Date(), 1, 1);

            Assert.notNull(listaRegistro, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterDetalheEventoRelacionados() throws Exception {
        try {
          
            List<RelaciondosDetalheEvento> lista = new ArrayList<>();
            RelaciondosDetalheEvento vo = new RelaciondosDetalheEvento();
            vo.setCanal("XXX");
            vo.setClientes(new BigDecimal(1));
            vo.setDuracao("CCCC");
            lista.add(vo);
            
          when(centralEventosDao.obterDetalheEventoRelacionados(
              Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(lista);

          List<RelaciondosDetalheEvento> result = centralEventosServiceImpl.obterDetalheEventoRelacionados(2,2,2);

            Assert.notNull(result, "Não pode ser nulo");

   
        }catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterDetalheEventoRelacionadosEmpty() throws Exception {
        try {
          
            List<RelaciondosDetalheEvento> lista = new ArrayList<>();
            
          when(centralEventosDao.obterDetalheEventoRelacionados(
              Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(lista);

          List<RelaciondosDetalheEvento> result = centralEventosServiceImpl.obterDetalheEventoRelacionados(2,2,2);

            Assert.notNull(result, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {

          
        }catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterTotalEventoRelacionados() throws Exception {
        try {
            
          when(centralEventosDao.obterTotalEventoRelacionados(Mockito.anyInt())).thenReturn(2);

            Integer result = centralEventosServiceImpl.obterTotalEventoRelacionados(2);

            Assert.notNull(result, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {

          
        }catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterTotalEventoRelacionadosEmpty() throws Exception {
        try {
            
            doThrow(EmptyResultDataAccessException.class).when(
                centralEventosDao).obterTotalEventoRelacionados(Mockito.anyInt());

            Integer result = centralEventosServiceImpl.obterTotalEventoRelacionados(2);

            Assert.notNull(result, "Não pode ser nulo");

        } catch (EmptyResultDataAccessException e) {

          
        }catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterTotalEventoRelacionadosAcesso() throws Exception {
        try {
            
            doThrow(AcessoADadosException.class).when(
                centralEventosDao).obterTotalEventoRelacionados(Mockito.anyInt());

            Integer result = centralEventosServiceImpl.obterTotalEventoRelacionados(2);

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {

          
        }catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
