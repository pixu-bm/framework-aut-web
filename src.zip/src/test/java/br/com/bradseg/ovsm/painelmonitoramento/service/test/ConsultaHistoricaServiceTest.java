package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;
import org.apache.poi.ss.usermodel.Workbook;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConsultaHistoricaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.ConsultaHistoricaServiceImpl;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaServiceTest {

    @Mock
    private ConsultaHistoricaDao consultaHistoricaDao;
    @Mock
    private ConsultaHistoricaServiceImpl ConsultaHistoricaServiceImplMock;
    @InjectMocks
    private ConsultaHistoricaServiceImpl consultaHistoricaServiceImpl;

    @Test
    void testeExportarExcel() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            when(consultaHistoricaDao.obterHistorico(
                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(listaConsulta);

            Workbook result = consultaHistoricaServiceImpl.exportarExcel(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testExportarExcelNullTestes() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            when(consultaHistoricaDao.obterHistorico(
                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(listaConsulta);

            Workbook result = consultaHistoricaServiceImpl.exportarExcel(list, list, list, "", "", "10:00:00",
                "10:00:00", "", "", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testExportarExcelAcessoADadosException() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            doThrow(AcessoADadosException.class).when(consultaHistoricaDao).obterHistorico(

                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            Workbook result = consultaHistoricaServiceImpl.exportarExcel(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Result não pode ser vazio");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testExportarExcelEmptyResultDataAccessException() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaDao).obterHistorico(

                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            Workbook result = consultaHistoricaServiceImpl.exportarExcel(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
            Assert.notNull(e, "Result não pode ser vazio");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeExportarPdf() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            when(consultaHistoricaDao.obterHistorico(
                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn(listaConsulta);

            ByteArrayInputStream result = consultaHistoricaServiceImpl.exportarPdf(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testExportarPdfAcessoADadosException() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            doThrow(AcessoADadosException.class).when(consultaHistoricaDao).obterHistorico(

                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ByteArrayInputStream result = consultaHistoricaServiceImpl.exportarPdf(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
            Assert.notNull(e, "Result não pode ser vazio");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testExportarPdfEmptyResultDataAccessException() throws Exception {
        try {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");
            consulta.setTipoEvento("Teste");
            consulta.setRecorrencia(new BigDecimal(20));
            consulta.setTransacoesImpactadas(new BigDecimal(20));
            consulta.setDuracaoDisp(100000l);
            consulta.setDuracaoFunc(100000l);
            consulta.setDuracaoVolu(100000l);

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            doThrow(EmptyResultDataAccessException.class).when(consultaHistoricaDao).obterHistorico(

                Mockito.anyList(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

            ByteArrayInputStream result = consultaHistoricaServiceImpl.exportarPdf(list, list, list, "10", "20", "10:00:00",
                "10:00:00", "10", "20", "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
            Assert.notNull(e, "Result não pode ser vazio");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
