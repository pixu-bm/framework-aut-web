package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.EmpresaDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe implementa test automatizados de Empresa
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class EmpresaDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private EmpresaDaoImpl empresaDaoImpl;

    @Test
    void obterListaEmpresa() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CEMPR_PNEL", new BigDecimal(1));
            mapa.put("IEMPR_PNEL", "Teste");
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(
                Mockito.anyString(), Mockito.any(MapSqlParameterSource.class))).thenReturn(listaMapa);

            List<Empresa> result = empresaDaoImpl.listarEmpresa();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterListaEmpresaListEmpty() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(
                Mockito.anyString(), Mockito.any(MapSqlParameterSource.class))).thenReturn(listaMapa);

            List<Empresa> result = empresaDaoImpl.listarEmpresa();

            Assert.notNull(result, "Lista deve ser vazia"); 

        } catch (EmptyResultDataAccessException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void obterListaEmpresaException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(
                jdbcTemplate).queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class));

            List<Empresa> result = empresaDaoImpl.listarEmpresa();

            Assert.notNull(result, "Deve retornar erro");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
