package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

/**
 * Classe implementa test automatizados empresa service
 *  
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class VolumetriaVisaoNegocioTest {

    @InjectMocks
    private VolumetriaVisaoNegocio volumetriaVisaoNegocio;

    /**
     * Teste construtorUsuario
     * 
     * @throws Exception
     */
    @Test
    void testVolumetriaVisaoNegocio () throws Exception {
        try {
            BigDecimal bd = new BigDecimal(1);
            VolumetriaVisaoNegocio visao = new VolumetriaVisaoNegocio();
            visao.setCodigoCanal(bd);
            visao.setDescricaoCanal("Teste");
            visao.setVolumetria(bd);
            visao.setHistorico(bd);
            visao.setVolumetriaMaxima(bd);
            visao.setTotalDeEventos(bd);
            visao.setEventoDispo(bd);
            visao.setEventoFunc(bd);
            visao.setEventoVolu(bd);
            visao.setEventosGraves(bd);
            
            visao.getCodigoCanal();
            visao.getDescricaoCanal();
            visao.getVolumetria();
            visao.getHistorico();
            visao.getVolumetriaMaxima();
            visao.getTotalDeEventos();
            visao.getEventoDispo();
            visao.getEventoFunc();
            visao.getEventoVolu();
            visao.getEventosGraves();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
