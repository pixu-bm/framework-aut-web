package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

@ExtendWith(MockitoExtension.class)
public class TabelaTempTest {

    @Test
    void testeCapitalizacaoTemp() throws Exception {
        try {

            LocalDate dataTest = LocalDate.now();
            LocalDateTime dataLocalTest = LocalDateTime.now();

            TabelaTemp capTemp = new TabelaTemp();

            capTemp.setCerroOrign("teste");
            capTemp.setCindRegProcs("Teste");
            capTemp.setcorrigeDado(0);
            capTemp.setDaltReg(dataTest);
            capTemp.setDfimErro(dataTest);
            capTemp.setDinclReg(dataLocalTest);
            capTemp.setDinicErro(dataLocalTest);
            capTemp.setIapiOrign("Teste");
            capTemp.setIcanalOrign("Teste");
            capTemp.setIemprOrign("TESTE");
            capTemp.setIetapaOfert("Teste");
            capTemp.setIplatfOrign("Teste");
            capTemp.setIprodtOrign("Teste");
            capTemp.setIsitEvnto("TESTE");
            capTemp.setIsprodOrign("teste");
            capTemp.setItransOrign("Teste");
            capTemp.setRenderUrlOrign("Teste");
            capTemp.setRmsgemErroOrign("Teste");
            capTemp.setRservcOrign("Teste");
            capTemp.setRtransOrign("Teste");

            String testeString = capTemp.getCerroOrign();
            testeString = capTemp.getCindRegProcs();
            Integer testeInteger = capTemp.getcorrigeDado();
            dataTest = capTemp.getDaltReg();
            dataTest = capTemp.getDfimErro();
            dataLocalTest = capTemp.getDinclReg();
            dataLocalTest = capTemp.getDinicErro();
            testeString = capTemp.getIapiOrign();
            testeString = capTemp.getIcanalOrign();
            testeString = capTemp.getIemprOrign();
            testeString = capTemp.getIetapaOfert();
            testeString = capTemp.getIplatfOrign();
            testeString = capTemp.getIprodtOrign();
            testeString = capTemp.getIsitEvnto();
            testeString = capTemp.getIsprodOrign();
            testeString = capTemp.getItransOrign();
            testeString = capTemp.getRenderUrlOrign();
            testeString = capTemp.getRmsgemErroOrign();
            testeString = capTemp.getRservcOrign();
            testeString = capTemp.getRtransOrign();

            Assert.isTrue(dataLocalTest != null && dataTest != null && testeInteger != null && testeString != null,
                "não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
