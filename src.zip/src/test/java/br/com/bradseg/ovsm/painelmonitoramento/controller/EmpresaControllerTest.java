package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.EmpresaController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmpresaService;

/**
 * Classe implementa test automatizados gestão acesso canal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class EmpresaControllerTest {

    @Mock
    private EmpresaService empresaService;
    @InjectMocks
    private EmpresaController empresaController;

    /**
     * Teste Obter canal
     * 
     * @throws Exception
     */
    @Test
    void obterEmpresa() throws Exception {

        try {
            ResponseEntity<ResponseMensagem> result = empresaController.obterEmpresa();

            Assert.isTrue(
                result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Obter canal IllegalArgument exception
     * @throws ResponseStatusException
     */
    @Test
    void obterEmpresaIllegalArgumentException() throws Exception {

        try {

            doThrow(IllegalArgumentException.class).when(empresaService).obterEmpresas();
            empresaController.obterEmpresa();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    /**
     * Obter canal IllegalArgument exception
     * @throws ResponseStatusException
     */

}
