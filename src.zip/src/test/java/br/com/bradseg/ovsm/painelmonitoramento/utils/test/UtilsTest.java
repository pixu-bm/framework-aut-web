package br.com.bradseg.ovsm.painelmonitoramento.utils.test;

import java.time.DateTimeException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.utils.PlanilhaUtils;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import io.jsonwebtoken.lang.Assert;

@ExtendWith(MockitoExtension.class)
public class UtilsTest {

    @Mock
    private Utils utils;
    @Mock
    private PlanilhaUtils planilhaUtils;

    @Test
    void convertEnumToMap() throws Exception {
        try {
            Utils.convertEnumToMap();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void converterDataLocaldateAnterior() throws Exception {
        String dataString = "31/12/2021";
        try {
            Utils.converterDataLocaldateAnterior(Utils.strDateFmtBrasilToJavaDate(dataString));

        } catch (DateTimeException e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void converterDataLocaldateAnteriorException() throws Exception {

        try {
            String dataString = "31/12/2021";

            Utils.converterDataLocaldateAnterior(Utils.strDateFmtBrasilToJavaDate(dataString));

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void converterCsv() throws Exception {

        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");
            int count = 0;
            int countSheet = 0;
            Row row = sheet.createRow(countSheet);

            count++;
            row.createCell(count).setCellValue("Canal");
            count++;
            row.createCell(count).setCellValue("");
            count++;
            row.createCell(count).setCellValue(1);
            count++;
            row.createCell(count).setCellValue(true);
            count++;

            Utils.csvConverter(wb);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void planilhaUtils() throws Exception {

        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Eventos");

            PlanilhaUtils.createStyleBordaCima(wb);

            PlanilhaUtils.createStyleBordaTopoDireitaCinza(wb);

            PlanilhaUtils.createStyleBordaEsquerda(wb);

            PlanilhaUtils.createStyleBordaDireita(wb);

            PlanilhaUtils.createStyleBordaBaixo(wb);

            PlanilhaUtils.createStyleBordaBaixoDireita(wb);

            PlanilhaUtils.createStyleCinza(wb);

            PlanilhaUtils.createStyleBranco(wb);

            PlanilhaUtils.createStyleCabecalho(wb);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testFormatoHoraMinutoSegundo() throws Exception {

        try {
            String test = Utils.formatoHoraMinutoSegundo(100000);
            test = Utils.formatoHoraMinutoSegundo(18305);
            Assert.notNull(test, "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testConverteHoraMinutoSegundoBig() throws Exception {

        try {
            String test = Utils.converteHoraMinutoSegundoBig("100000");
            test = Utils.converteHoraMinutoSegundoBig("18305");
            Assert.notNull(test, "Não pode ser nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
