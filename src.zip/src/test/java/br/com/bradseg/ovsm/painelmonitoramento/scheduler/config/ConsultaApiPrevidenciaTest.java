package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiPrevidenciaDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiSaudeDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiPrevidenciaTest {
    
    @InjectMocks
    private ConsultaApiPrevidencia consultaApiPrevidencia;
    @Mock
    private ConsultaApiPrevidenciaDao consultaApiPrevidenciaDao;
    @Mock
    private HttpURLConnection connection;
    
    
    @Test
    void testeConsultaApi() throws Exception {
        try {
            consultaApiPrevidencia.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiPrevidenciaDao.obterultimoregistroinserido()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiPrevidencia.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiPrevidencia.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiPrevidenciaDao).obterultimoregistroinserido();
            consultaApiPrevidencia.consultaApi(); 
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiPrevidencia.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiPrevidenciaDao).obterultimoregistroinserido();
            consultaApiPrevidencia.consultaApi(); 

        } catch (Exception e) {
        }
    }
    
    @Test
    void testeBuscaTempoParametrizado() throws Exception {
        try {
            consultaApiPrevidencia.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSaudeOk() throws Exception {
        try {
            consultaApiPrevidencia.obterPrevidenciaOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
            
            consultaApiPrevidencia.obterPrevidenciaNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now(),connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSaudeOkMaximo() throws Exception {
        try {
            consultaApiPrevidencia.obterPrevidenciaOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiPrevidencia.obterPrevidenciaNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarConexaoTemp() throws Exception {
        try {
            when(connection.getResponseCode()).thenReturn(500);
            consultaApiPrevidencia.validarConexaoPrevidenciaTemp(
                LocalDateTime.now(), connection, "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443", new LinkedList<>(), "x");
            
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarConexaoTempApi() throws Exception {
        try {
            when(connection.getResponseCode()).thenReturn(500);
            consultaApiPrevidencia.validarConexaoPrevidenciaTempApi(
                LocalDateTime.now(), connection, "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443", new LinkedList<>());
            
            
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
