package br.com.bradseg.ovsm.painelmonitoramento.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.ComentarioController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ComentarioService;

/**
 * Classe implementa test automatizados ComentarioController
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ComentarioControllerTest {

    @Mock
    ComentarioService comentarioService;

    @InjectMocks
    ComentarioController comentarioController;

    /**
     * Teste adicionarComentario
     * 
     * @throws Exception
     */
    @Test
    void adicionarComentario() throws Exception {

        try {
            ComentarioRequest request = new ComentarioRequest();
            request.setCodigoCanal(new BigDecimal(1));
            request.setCodigoEmpresa(new BigDecimal(1));
            request.setCodigoErroConexaoPainel(new BigDecimal(500));
            request.setCodigoProduto(new BigDecimal(1));
            request.setComentario("Teste");
            request.setDataProcs(new Date());
            request.setLogin("M232640");

            ResponseEntity<ResponseMensagem> result = comentarioController.adicionarComentario(request);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void adicionarComentarioIllegalArgument() throws Exception {

        try {
            doThrow(IllegalArgumentException.class).when(comentarioService).validarComentarioRequest(Mockito.any());
            comentarioController.adicionarComentario(null);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterComentario() throws Exception {

        try {
            when(comentarioService.obterComentario(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(new ArrayList<>());
            ResponseEntity<ResponseMensagem> result = comentarioController.obterComentario(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any());

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (IllegalArgumentException e) {

            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterComentarioIllegalArgumentException() throws Exception {

        try {

            doThrow(IllegalArgumentException.class).when(comentarioService).obterComentario(Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
            comentarioController.obterComentario("3", "7", "2", new Date(), "500");

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }


}
