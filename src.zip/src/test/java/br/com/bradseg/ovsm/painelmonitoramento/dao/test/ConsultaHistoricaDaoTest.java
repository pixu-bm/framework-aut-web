package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.ConsultaHistoricaDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ConsultaHistoricaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private ConsultaHistoricaDaoImpl consultaHistoricaDaoImpl;

    @Test
    void obterHistorico() throws Exception {
        try {

            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaHistoricaRowMapper.class)))
                    .thenReturn(listaConsulta);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("COD_EVENTO", new BigDecimal(1));
            mapa.put("RECORRENCIA", new BigDecimal(10));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            List<ConsultaHistorica> listaTeste = consultaHistoricaDaoImpl.obterHistorico(
                list, list, list, 10, 20, "10:00:00",
                "10:00:00", 10, 20, "Teste", "01/01/2022", "01/03/2022");

            Assert.notNull(listaTeste, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterHistoricoCondicoesNulas() throws Exception {
        try {

            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("Teste");
            consulta.setProduto("Teste");
            consulta.setCanal("Teste");

            List<ConsultaHistorica> listaConsulta = new ArrayList<>();
            listaConsulta.add(consulta);
            listaConsulta.add(consulta);

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaHistoricaRowMapper.class)))
                    .thenReturn(listaConsulta);

            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("COD_EVENTO", new BigDecimal(1));
            mapa.put("RECORRENCIA", new BigDecimal(10));
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<BigDecimal> list = new ArrayList<>();
            list.add(new BigDecimal(1));
            list.add(new BigDecimal(2));
            list.add(new BigDecimal(3));

            List<ConsultaHistorica> listaTeste = consultaHistoricaDaoImpl.obterHistorico(
                null, null, null, null, null, null,
                null, null, null, null, null, null);

            Assert.notNull(listaTeste, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterHistoricoAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(
                jdbcTemplate).queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ConsultaHistoricaRowMapper.class));

            consultaHistoricaDaoImpl.obterHistorico(
                null, null, null, 10, 20, "10:00:00",
                "10:00:00", 10, 20, "Teste", "01/01/2022", "01/03/2022");

        } catch (AcessoADadosException e) {

            Assert.isTrue("Ocorreu um erro inesperado".equalsIgnoreCase(e.getMessage()), "Deve ser verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterHistoricoEmptyResultDataAccessException() throws Exception {
        try {

            doThrow(EmptyResultDataAccessException.class).when(
                jdbcTemplate).queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                    Mockito.any(ConsultaHistoricaRowMapper.class));

            consultaHistoricaDaoImpl.obterHistorico(
                null, null, null, 10, 20, "10:00:00",
                "10:00:00", 10, 20, "Teste", "01/01/2022", "01/03/2022");

        } catch (EmptyResultDataAccessException e) {

            Assert.isTrue("Nenhum dado encontrado".equalsIgnoreCase(e.getMessage()), "Deve ser verdadeiro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
