package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;

@ExtendWith(MockitoExtension.class)
public class NumeroTransacoesTest {

    @InjectMocks
    private NumeroTransacoes numeroTransacoes;

    @Test
    void tipoEvento () throws Exception {
        try {
            NumeroTransacoes numeroTransacoes = new NumeroTransacoes();
            numeroTransacoes.setTotalTransacoes(100);
            numeroTransacoes.setTotalTransacoesComEvento(100);
            numeroTransacoes.setTotalTransacoesSemEvento(100);
            numeroTransacoes.setPorcentagemTotalTransacoesComEvento((double) 20);
            numeroTransacoes.setPorcentagemTotalTransacoesSemEvento((double) 20);
            
            numeroTransacoes.getPorcentagemTotalTransacoesComEvento();
            numeroTransacoes.getPorcentagemTotalTransacoesSemEvento();
            numeroTransacoes.getTotalTransacoes();
            numeroTransacoes.getTotalTransacoesComEvento();
            numeroTransacoes.getTotalTransacoesSemEvento();
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
