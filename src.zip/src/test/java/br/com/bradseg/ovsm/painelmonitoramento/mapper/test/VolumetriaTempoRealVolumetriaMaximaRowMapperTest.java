package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealVolumetriaMaximaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.ResultSet;

@ExtendWith(MockitoExtension.class)
public class VolumetriaTempoRealVolumetriaMaximaRowMapperTest {

    @InjectMocks
    private VolumetriaTempoRealVolumetriaMaximaRowMapper volumetriaTempoRealVolumetriaMaximaRowMapper;

    @Test
    void testeVisaoGeralProdutoRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getBigDecimal("SOMA_VOLUMETRIA_ATUAL")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("MEDIA_VOLUMETRIA_HISTORICA")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_COM_EVENTO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("SOMA_SEM_EVENTO")).thenReturn(new BigDecimal(1));

            VolumetriaTempoRealVolumetriaMaxima visao = volumetriaTempoRealVolumetriaMaximaRowMapper
                .mapRow(resultSetMock, 0);

            Assert.notNull(visao, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
