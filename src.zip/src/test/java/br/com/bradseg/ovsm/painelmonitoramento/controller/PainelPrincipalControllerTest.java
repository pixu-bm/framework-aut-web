package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.PainelPrincipalController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.*;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.PainelPrincipalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;
import java.util.ArrayList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados dos serviços de painel principal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class PainelPrincipalControllerTest {

    @Mock
    PainelPrincipalService painelPrincipalService;

    @InjectMocks
    private PainelPrincipalController painelPrincipalController;

    /**
     * Teste para obter o painel de monitoramento.
     * 
     * @throws Exception
     */
    @Test
    void obterPainelMonitoramento() throws Exception {
        try {

            when(painelPrincipalService.obterPainelMonitoramento()).thenReturn(new PainelMonitoramentoAtual());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterPainelMonitoramento();

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterPainelMonitoramentoSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterPainelMonitoramento();
            painelPrincipalController.obterPainelMonitoramento();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterVisaoEvento() throws Exception {
        try {

            when(painelPrincipalService.obterVisaoEvento(3)).thenReturn(new VisaoEvento());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVisaoEvento(3);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterVisaoEventoIllegalArgumentException() throws Exception {

        try {
            doThrow(IllegalArgumentException.class).when(painelPrincipalService).obterVisaoEvento(3);
            painelPrincipalController.obterVisaoEvento(3);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoSQLException() throws Exception {

        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterVisaoEvento(3);
            painelPrincipalController.obterVisaoEvento(3);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealGrafico() throws Exception {
        try {

            when(painelPrincipalService.obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new VolumetriaTempoRealVolumetriaMaxima());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealGrafico(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealGraficoSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterVolumetriaTempoRealVolumetriaMaxima(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealGrafico(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealGraficoIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(painelPrincipalService)
                .obterVolumetriaTempoRealVolumetriaMaxima(
                    Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealGrafico(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTabela() throws Exception {
        try {

            when(painelPrincipalService.obterVolumetriaTempoRealTransacaoEvento(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
                    new ArrayList<VolumetriaTempoRealTransacaoEvento>());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealTabela(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTabelaSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterVolumetriaTempoRealTransacaoEvento(
                Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealTabela(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterVolumetriaTempoRealTabelaIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(painelPrincipalService)
                .obterVolumetriaTempoRealTransacaoEvento(
                    Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any());

            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVolumetriaTempoRealTabela(3, null,
                null, null);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), "sucesso");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
