package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiSaudeDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.HttpURLConnection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedList;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConsultaApiSaudeTest {
    
    @InjectMocks
    private ConsultaApiSaude consultaApiSaude;
    @Mock
    private ConsultaApiSaudeDao consultaApiSaudeDao;
    @Mock
    private HttpURLConnection connection;

    @Test
    void testeConsultaApi() throws Exception {
        try {
            consultaApiSaude.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            when(consultaApiSaudeDao.obterultimoregistroinseridoSaude()).thenReturn(null);
            //when(connection.getResponseCode()).thenReturn(200);
            consultaApiSaude.consultaApi();
            //consultaApiSaude.buscaTempoParametrizado();

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiAcessoADadosException() throws Exception {
        try {
            consultaApiSaude.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(AcessoADadosException.class).when(consultaApiSaudeDao).obterultimoregistroinseridoSaude();
            consultaApiSaude.consultaApi(); 
        } catch (AcessoADadosException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaApiSQLException() throws Exception {
        try {
            consultaApiSaude.setEnderecoApi("https://svp.dsv.bradescoseguros.com.br:8443/");
            doThrow(SQLException.class).when(consultaApiSaudeDao).obterultimoregistroinseridoSaude();
            consultaApiSaude.consultaApi(); 

        } catch (Exception e) {
        }
    }

    @Test
    void testeConsultaSaudeOk() throws Exception {
        try {
            consultaApiSaude.obterSaudeOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now());
            
            consultaApiSaude.obterSaudeNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/","v2",LocalDateTime.now(),connection);
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void testeConsultaSaudeOkMaximo() throws Exception {
        try {
            consultaApiSaude.obterSaudeOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now());
            
            consultaApiSaude.obterSaudeNOk(
                "MOBILE", "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsqaxxawqqssaasasas",
                "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",LocalDateTime.now(), connection);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }


    @Test
    void testevalidarConexaoSaudeTemp() throws Exception {
        try{
            LinkedList<TabelaTemp> listaSaudeTemp = new LinkedList<>();
            TabelaTemp saudeTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            saudeTemp.setcorrigeDado(850);
            saudeTemp.setCindRegProcs("P");
            // Codigo de retorno
            saudeTemp.setCerroOrign("teste");
            saudeTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            saudeTemp.setRenderUrlOrign("endereco");
            saudeTemp.setRservcOrign(null);
            saudeTemp.setItransOrign("A001");
            saudeTemp.setRtransOrign("endereco");
            saudeTemp.setIapiOrign("endereco");
            saudeTemp.setIcanalOrign("CAP");
            saudeTemp.setIemprOrign("CAPI");
            saudeTemp.setIprodtOrign("CAPITALIZACAO");
            saudeTemp.setIsprodOrign(null);
            saudeTemp.setIetapaOfert("TESTE ETAPA");
            saudeTemp.setIplatfOrign("API");
            saudeTemp.setIsitEvnto("NOK");

            saudeTemp.setDinicErro(LocalDateTime.now());
            saudeTemp.setDfimErro(null);
            saudeTemp.setDinclReg(LocalDateTime.now());
            saudeTemp.setDaltReg(null);

            listaSaudeTemp.add(saudeTemp);

            consultaApiSaude.validarConexaoSaudeTemp(LocalDateTime.now(),connection,"MOBILE",
              "https://svp.dsv"
                + ".bradescoseguros.com"
                + ".br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv",
              (LinkedList<TabelaTemp>) listaSaudeTemp,
              "https://svp.dsv.bradescoseguros.com.br:8443/v2/QSAA/TESTE-Aplicacao/chamaRestTesteSsxasasasasasasasascvv");

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
   
}
