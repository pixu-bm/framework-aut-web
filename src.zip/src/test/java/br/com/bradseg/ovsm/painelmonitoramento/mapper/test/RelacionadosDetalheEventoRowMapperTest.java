package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.RelacionadosDetalheEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;

@ExtendWith(MockitoExtension.class)
public class RelacionadosDetalheEventoRowMapperTest {

    @InjectMocks
    private RelacionadosDetalheEventoRowMapper relacionadoDetalheEventoRowMapper;

    @Test
    void testeRelacionadosDetalheEventoRowMapper() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("PRODUTO")).thenReturn("teste");
            Mockito.when(resultSetMock.getString("CANAL")).thenReturn("teste");
            Mockito.when(resultSetMock.getString("TIPO")).thenReturn("teste");
            Mockito.when(resultSetMock.getString("DURACAO")).thenReturn("3600");
            Mockito.when(resultSetMock.getBigDecimal("QTD")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("CODIGO")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.getBigDecimal("RNUM")).thenReturn(new BigDecimal(1));
            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);
            
            List<RelaciondosDetalheEvento> registro = relacionadoDetalheEventoRowMapper.mapRow(resultSetMock, 0);
            Assert.notNull(registro, "nao pode nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

}
