package br.com.bradseg.ovsm.painelmonitoramento.mapper.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaUsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ListaUsuarioRowMapperTest {

    @InjectMocks
    private ListaUsuarioRowMapper listaUsuarioRowMapper;

    @Test
    void testeListaUsuarioRowMapperTest() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("CUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IEMPR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IDEPTO")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("RTPO_PRFIL")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("CSTTUS_CAD")).thenReturn("AGARD");
            Mockito.when(resultSetMock.getDate("AINCL")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<Usuario> usuario = listaUsuarioRowMapper.extractData(resultSetMock);

            Assert.notNull(usuario, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testeListaUsuarioRowMapperTestCancel() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("CUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IEMPR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IDEPTO")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("RTPO_PRFIL")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("CSTTUS_CAD")).thenReturn("CANCEL");
            Mockito.when(resultSetMock.getDate("AINCL")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<Usuario> usuario = listaUsuarioRowMapper.extractData(resultSetMock);

            Assert.notNull(usuario, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testeListaUsuarioRowMapperTestAprov() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("CUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IEMPR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IDEPTO")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("RTPO_PRFIL")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("CSTTUS_CAD")).thenReturn("APROV");
            Mockito.when(resultSetMock.getDate("AINCL")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<Usuario> usuario = listaUsuarioRowMapper.extractData(resultSetMock);

            Assert.notNull(usuario, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void testeListaUsuarioRowMapperTestNegad() throws Exception {
        try {
            ResultSet resultSetMock = Mockito.mock(ResultSet.class);
            Mockito.when(resultSetMock.getString("CUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IUSUAR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IEMPR")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("IDEPTO")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("RTPO_PRFIL")).thenReturn("Teste");
            Mockito.when(resultSetMock.getString("CSTTUS_CAD")).thenReturn("NEGAD");
            Mockito.when(resultSetMock.getDate("AINCL")).thenReturn(new Date(1));

            Mockito.when(resultSetMock.next()).thenReturn(true).thenReturn(false);

            List<Usuario> usuario = listaUsuarioRowMapper.extractData(resultSetMock);

            Assert.notNull(usuario, "nao pode nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
