package br.com.bradseg.ovsm.painelmonitoramento.service.export.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.ConsultaHistoricaServiceExport;
import io.jsonwebtoken.lang.Assert;

/**
 * Classe implementa test automatizados de central de eventos service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaHistoricaServiceExportTest {

    @Mock
    private LoginDao loginDao;
    @Mock
    private ProdutoDao produtoDao;
    @Mock
    private CanalDao canalDao;
    @InjectMocks
    private ConsultaHistoricaServiceExport consultaHistoricaServiceExport;

    @Test
    void gerarPdfTest() throws Exception {
        try {

            List<ConsultaHistorica> listaConsultaHistorica = new ArrayList<>();
            
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("EVENTO GRAVE");
            consulta.setProduto("Test");
            consulta.setCanal("Test");
            consulta.setTipoEvento("Teste");
            consulta.setTransacoesImpactadas(new BigDecimal(500));
            consulta.setDuracaoDispFmt("20:00:00");
            consulta.setDuracaoFuncFmt("20:00:00");
            consulta.setDuracaoVoluFmt("20:00:00");
            consulta.setData("01/01/2022");
            consulta.setRecorrencia(new BigDecimal(500));
            
            ConsultaHistorica consulta2 = new ConsultaHistorica();
            consulta2.setCodigoEvento(new BigDecimal(1));
            consulta2.setGravidade("EVENTO GRAVE");
            consulta2.setProduto("Test");
            consulta2.setCanal("Test");
            consulta2.setTipoEvento("Teste");
            consulta2.setTransacoesImpactadas(new BigDecimal(500));
            consulta2.setDuracaoDispFmt("20:00:00");
            consulta2.setDuracaoFuncFmt("20:00:00");
            consulta2.setDuracaoVoluFmt("20:00:00");
            consulta2.setData("01/01/2022");
            consulta2.setRecorrencia(new BigDecimal(500));
            
            listaConsultaHistorica.add(consulta);
            listaConsultaHistorica.add(consulta2);

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            ByteArrayInputStream baResult = consultaHistoricaServiceExport.gerarPdf(listaConsultaHistorica,
                "Teste", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal);

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void egerarPdfNullTest() throws Exception {
        try {

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            when(loginDao.obterInformacaoUsuario(Mockito.any())).thenReturn(usur);

            ByteArrayInputStream baResult = consultaHistoricaServiceExport.gerarPdf(null,
                "Teste", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal);

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void gerarPdfAcessoADadosExceptionTest() throws Exception {
        try {

            List<BigDecimal> listaBigDecimal = new ArrayList<>();
            listaBigDecimal.add(new BigDecimal(1));

            Usuario usur = new Usuario();
            usur.setNome("Test");

            doThrow(AcessoADadosException.class).when(loginDao).obterInformacaoUsuario(Mockito.any());

            consultaHistoricaServiceExport.gerarPdf(null,
                "Teste", "01/01/2022", "01/01/2022", listaBigDecimal, listaBigDecimal);
        } catch (AcessoADadosException e) {

            // Teste ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void gerarExcelTest() throws Exception {
        try {

            List<ConsultaHistorica> listaConsultaHistorica = new ArrayList<>();
            
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(1));
            consulta.setGravidade("EVENTO GRAVE");
            consulta.setProduto("Test");
            consulta.setCanal("Test");
            consulta.setTipoEvento("Teste");
            consulta.setTransacoesImpactadas(new BigDecimal(500));
            consulta.setDuracaoDispFmt("20:00:00");
            consulta.setDuracaoFuncFmt("20:00:00");
            consulta.setDuracaoVoluFmt("20:00:00");
            consulta.setData("01/01/2022");
            consulta.setRecorrencia(new BigDecimal(500));
            
            ConsultaHistorica consulta2 = new ConsultaHistorica();
            consulta2.setCodigoEvento(new BigDecimal(1));
            consulta2.setGravidade("EVENTO GRAVE");
            consulta2.setProduto("Test");
            consulta2.setCanal("Test");
            consulta2.setTipoEvento("Teste");
            consulta2.setTransacoesImpactadas(new BigDecimal(500));
            consulta2.setDuracaoDispFmt("20:00:00");
            consulta2.setDuracaoFuncFmt("20:00:00");
            consulta2.setDuracaoVoluFmt("20:00:00");
            consulta2.setData("01/01/2022");
            consulta2.setRecorrencia(new BigDecimal(500));
            
            listaConsultaHistorica.add(consulta);
            listaConsultaHistorica.add(consulta2);

            Workbook baResult = consultaHistoricaServiceExport.gerarExcel(listaConsultaHistorica);

            Assert.notNull(baResult, "Não pode ser Nulo");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
