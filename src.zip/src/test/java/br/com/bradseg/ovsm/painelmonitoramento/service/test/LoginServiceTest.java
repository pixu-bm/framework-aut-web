package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.LoginRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmailService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.LoginServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test login service
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class LoginServiceTest {

    @Mock
    private LoginDao loginDao;
    @Mock
    private EmailService emailService;
    @InjectMocks
    private LoginServiceImpl loginServiceImpl;

    /**
     * Teste logar
     * 
     * @throws Exception
     */
    @Test
    void logar() throws Exception {
        try {
            String result = loginServiceImpl.logar(new Usuario());

            Assert.isNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste logarEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void logarEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(loginDao).obterTipoUsuario(Mockito.any());
            loginServiceImpl.logar(new Usuario());

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste logarEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void logarIllegalArgumentException() throws Exception {
        try {
            doThrow(IllegalArgumentException.class).when(loginDao).obterTipoUsuario(Mockito.any());
            loginServiceImpl.logar(new Usuario());

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste logarEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void logarAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(loginDao).obterTipoUsuario(Mockito.any());
            loginServiceImpl.logar(new Usuario());

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste logarEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void validarLoginIllegalArgumentException() throws Exception {
        try {
            LoginRequest request = new LoginRequest();
            loginServiceImpl.validarLogin(request);

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste logarEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void validarLoginIllegalArgumentExceptionCompleto() throws Exception {
        try {
            loginServiceImpl.validarLogin(null);
        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void validarLogin() throws Exception {
        try {
            LoginRequest request = new LoginRequest();
            request.setLogin("M232640");

            loginServiceImpl.validarLogin(request);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarSolicitacaoAcesso
     * 
     * @throws Exception
     */
    @Test
    void validarSolicitacaoAcesso() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");
            solicitarAcesso.setNomeDepartamento("TEst");
            solicitarAcesso.setNomeEmpresa("TEst");

            loginServiceImpl.validarSolicitacaoAcesso(solicitarAcesso);

        } catch (Exception e) {
        }
    }

    /**
     * Teste validarParametroEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarParametroEmpresaUsuario() throws Exception {
        try {
            loginServiceImpl.validarParametroEmpresaUsuario("BRADSEG");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    /**
     * Teste validarParametroEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarParametroEmpresaUsuarioNull() throws Exception {
        try {
            loginServiceImpl.validarParametroEmpresaUsuario("");

        } catch (Exception e) {

        }
    }

    /**
     * Teste inserirUsuarioAprovacao
     * 
     * @throws Exception
     */

    @Test
    void inserirUsuarioAprovacao() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");
            solicitarAcesso.setNomeDepartamento("TEst");
            solicitarAcesso.setNomeEmpresa("TEst");

            Usuario usuario = new Usuario(solicitarAcesso);
            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);
            when(loginDao.validarEmpresaUsuario(Mockito.any())).thenReturn(false);
            when(loginDao.validarDepartamentoUsuario(Mockito.any())).thenReturn(false);
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (Exception e) {
        }
    }
    
    @Test
    void inserirUsuarioAprovacaoTest() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");
            solicitarAcesso.setNomeDepartamento("TEst");
            solicitarAcesso.setNomeEmpresa("TEst");

            Usuario usuario = new Usuario(solicitarAcesso);
            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);
            when(loginDao.validarEmpresaUsuario(Mockito.any())).thenReturn(true);
            when(loginDao.validarDepartamentoUsuario(Mockito.any())).thenReturn(true);
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (Exception e) {
        }
    }

    /**
     * Teste inserirUsuarioAprovacao
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoEmpty() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");

            Usuario usuario = new Usuario(solicitarAcesso);
            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (IllegalArgumentException e) {

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioAprovacaoIllegalArgumentException
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoIllegalArgumentException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");

            Usuario usuario = new Usuario(solicitarAcesso);
            doThrow(IllegalArgumentException.class).when(loginDao).validarLogin(Mockito.any());
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioAprovacaoEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoEmptyResultDataAccessException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");

            Usuario usuario = new Usuario(solicitarAcesso);
            doThrow(EmptyResultDataAccessException.class).when(loginDao).validarLogin(Mockito.any());
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioAprovacaoEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoDataIntegrityViolationException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");

            Usuario usuario = new Usuario(solicitarAcesso);
            doThrow(DataIntegrityViolationException.class).when(loginDao).validarLogin(Mockito.any());
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (DataIntegrityViolationException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste inserirUsuarioAprovacaoException
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoException() throws Exception {
        try {
            SolicitacaoAcessoRequest solicitarAcesso = new SolicitacaoAcessoRequest();
            solicitarAcesso.setLogin("M232640");
            solicitarAcesso.setCodigoDepartamento("FNC");
            solicitarAcesso.setCodigoEmpresa("BS");
            solicitarAcesso.setEmail("teste@bs.com.br");
            solicitarAcesso.setEndereco("Rua das camelias");
            solicitarAcesso.setNome("Teste");
            solicitarAcesso.setTelefone("2199821212");

            Usuario usuario = new Usuario(solicitarAcesso);
            doThrow(AcessoADadosException.class).when(loginDao).validarLogin(Mockito.any());
            loginServiceImpl.inserirUsuarioAprovacao(usuario);

        } catch (AcessoADadosException e) {
            // Teste OK
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuario() throws Exception {
        try {
            when(loginDao.listarEmpresaUsuario()).thenReturn(new ArrayList<>());
            List<EmpresaUsuario> listarEmpresaUsuario = loginServiceImpl.listarEmpresaUsuario();
            Assert.notNull(listarEmpresaUsuario, "result tem que trazer a lista");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            doThrow(EmptyResultDataAccessException.class).when(loginDao).listarEmpresaUsuario();
            loginServiceImpl.listarEmpresaUsuario();

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarParametroEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuarioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(loginDao).listarEmpresaUsuario();
            loginServiceImpl.listarEmpresaUsuario();

        } catch (AcessoADadosException e) {
            // Teste ok
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarDepartamentoUsuarioEmpresa
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmpresa() throws Exception {
        try {
            when(loginDao.validarEmpresaUsuario(Mockito.any())).thenReturn(true);
            List<DepartamentoUsuario> listarEmpresaUsuario = loginServiceImpl.listarDepartamentoUsuarioEmpresa("BS");
            Assert.notNull(listarEmpresaUsuario, "result tem que trazer a lista");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarDepartamentoUsuarioEmpresaIllegalArgumentException
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmptyResultDataAccessException() throws Exception {
        try {

            when(loginDao.validarEmpresaUsuario(Mockito.any())).thenReturn(false);
            List<DepartamentoUsuario> listarEmpresaUsuario = loginServiceImpl.listarDepartamentoUsuarioEmpresa("BS");
            Assert.notNull(listarEmpresaUsuario, "result tem que trazer a lista");

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarDepartamentoUsuarioEmpresaIllegalArgumentException
     * 
     * @throws Exception
     */

    @Test
    void listarDepartamentoUsuarioAcessoADadosException() throws Exception {
        try {

            when(loginDao.validarEmpresaUsuario(Mockito.any())).thenReturn(true);
            doThrow(AcessoADadosException.class).when(loginDao).listarDepartamentoUsuario(Mockito.anyString());
            List<DepartamentoUsuario> listarEmpresaUsuario = loginServiceImpl.listarDepartamentoUsuarioEmpresa("BS");
            Assert.notNull(listarEmpresaUsuario, "result tem que trazer a lista");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
