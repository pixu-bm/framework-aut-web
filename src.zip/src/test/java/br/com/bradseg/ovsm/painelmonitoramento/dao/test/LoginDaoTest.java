package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.LoginDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.UsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe implementa test automatizados login dao
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class LoginDaoTest {

    @Mock
    private JdbcTemplate jdbcTemplate;
    @InjectMocks
    private LoginDaoImpl loginDaoImpl;

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void validarLogin() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(0);
            Boolean result = loginDaoImpl.validarLogin(usuario);

            Assert.isTrue(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin diferente de 0
     * 
     * @throws Exception
     */
    @Test
    void validarLoginDiferente() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(1);
            Boolean result = loginDaoImpl.validarLogin(usuario);

            Assert.isTrue(!result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterTipoUsuario
     * 
     * @throws Exception
     */
    @Test
    void obterTipoUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(String.class), Mockito.any(Object.class)))
                .thenReturn("MSTER");
            String result = loginDaoImpl.obterTipoUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void obterTipoUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(String.class), Mockito.any(Object.class));

            loginDaoImpl.obterTipoUsuario(usuario);

        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void obterTipoUsuarioException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(String.class), Mockito.any(Object.class));

            loginDaoImpl.obterTipoUsuario(usuario);

        } catch (Exception e) {

        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacao() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(BigDecimal.class)))
                .thenReturn(new BigDecimal(1));

            loginDaoImpl.inserirUsuarioAprovacao(usuario);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void inserirUsuarioAprovacaoAcessoADadosException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(BigDecimal.class));

            loginDaoImpl.inserirUsuarioAprovacao(usuario);

        } catch (AcessoADadosException e) {
            Assert.isTrue("Ocorreu um erro inesperado".equals(e.getMessage()), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirUsuarioAprovacaoDataIntegrityViolationException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(BigDecimal.class));

            loginDaoImpl.inserirUsuarioAprovacao(usuario);

        } catch (DataIntegrityViolationException e) {
            Assert.isTrue("Erro de integridade dos dados.".equals(e.getMessage()), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarEmpresaUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuario() throws Exception {
        try {
            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CEMPR", "CEMPR");
            mapa.put("IEMPR", "IEMPR");
            lista.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString())).thenReturn(lista);

            List<EmpresaUsuario> result = loginDaoImpl.listarEmpresaUsuario();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void listarEmpresaUsuarioAcessoADadosException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString());

            List<EmpresaUsuario> result = loginDaoImpl.listarEmpresaUsuario();

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
            Assert.isTrue("Ocorreu um erro inesperado".equals(e.getMessage()), "Deve retornar erro");
        }
    }

    /**
     * Teste listarDepartamentoUsuario
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuario() throws Exception {
        try {
            List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CDEPTO", "CDEPTO");
            mapa.put("IDEPTO", "IDEPTO");
            lista.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(Object.class))).thenReturn(lista);

            List<DepartamentoUsuario> result = loginDaoImpl.listarDepartamentoUsuario("BS");

            Assert.notEmpty(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLogin
     * 
     * @throws Exception
     */
    @Test
    void listarDepartamentoUsuarioEmptyResultDataAccessException() throws Exception {
        try {

            loginDaoImpl.listarDepartamentoUsuario("BS");

        } catch (Exception e) {
        }
    }

    /**
     * Teste listarDepartamentoUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarEmpresaUsuario() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(1);

            Boolean result = loginDaoImpl.validarEmpresaUsuario("BS");

            Assert.isTrue(result, "Result Tem que ser verdadeiro");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarDepartamentoUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarEmpresaUsuarioIgualZero() throws Exception {
        try {
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(0);

            Boolean result = loginDaoImpl.validarEmpresaUsuario("BS");

            Assert.isTrue(!result, "Result Tem que ser falso");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste listarDepartamentoUsuario
     * 
     * @throws Exception
     */
    @Test
    void validarEmpresaUsuarioAcessoADadosException() throws Exception {
        try {
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(Integer.class), Mockito.any(Object.class));

            loginDaoImpl.validarEmpresaUsuario("BS");

        } catch (AcessoADadosException e) {
            Assert.isTrue("Ocorreu um erro inesperado".equals(e.getMessage()), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLoginAprovador
     * 
     * @throws Exception
     */
    @Test
    void validarLoginAprovador() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLoginAprovador("M232640");

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(1);

            Boolean result = loginDaoImpl.validarLoginAprovador(usuario);

            Assert.isTrue(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void validarLoginAprovadorIgualAZero() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLoginAprovador("M232640");

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(Integer.class), Mockito.any(Object.class)))
                .thenReturn(0);

            Boolean result = loginDaoImpl.validarLoginAprovador(usuario);

            Assert.isTrue(!result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarLoginAprovador
     * 
     * @throws Exception
     */
    @Test
    void validarLoginAprovadorAcessoADadosException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLoginAprovador("M232640");

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.eq(Integer.class), Mockito.any(Object.class));

            loginDaoImpl.validarLoginAprovador(usuario);

        } catch (AcessoADadosException e) {
            Assert.isTrue("Ocorreu um erro inesperado".equals(e.getMessage()), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterTipoUsuario
     * 
     * @throws Exception
     */
    @Test
    void obterInformacaoUsuario() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(UsuarioRowMapper.class),
                Mockito.any(Object.class)))
                    .thenReturn(usuario);

            Usuario result = loginDaoImpl.obterInformacaoUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterInformacaoUsuarioException
     * 
     * @throws Exception
     */
    @Test
    void obterInformacaoUsuarioException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForObject(
                Mockito.anyString(), Mockito.any(UsuarioRowMapper.class), Mockito.any(Object.class));

            Usuario result = loginDaoImpl.obterInformacaoUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (AcessoADadosException e) {
            Assert.isTrue("Ocorreu um erro inesperado".equals(e.getMessage()), "Deve retornar erro");
        }
    }

    /**
     * Teste obterInformacaoUsuarioEmptyResultDataAccessException
     * 
     * @throws Exception
     */
    @Test
    void obterInformacaoUsuarioEmptyResultDataAccessException() throws Exception {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin("M232640");
            doThrow(EmptyResultDataAccessException.class).when(jdbcTemplate).queryForObject(
                Mockito.anyString(), Mockito.any(UsuarioRowMapper.class), Mockito.any(Object.class));

            Usuario result = loginDaoImpl.obterInformacaoUsuario(usuario);

            Assert.notNull(result, "Result não pode ser vazio");

        } catch (EmptyResultDataAccessException e) {
            Assert.isTrue("Consulta sem resultado".equals(e.getMessage()), "Deve retornar erro");
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
