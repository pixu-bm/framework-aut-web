package br.com.bradseg.ovsm.painelmonitoramento.dao.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl.CanalDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados de EventoDaoTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class CanalDaoTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private CanalDaoImpl canalDaoImpl;

    @Test
    void obterListaCanal() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();
            Map<String, Object> mapa = new HashMap<>();
            mapa.put("CCANAL_DGTAL_PNEL", new BigDecimal(1));
            mapa.put("ICANAL_DGTAL_PNEL", "Teste");
            listaMapa.add(mapa);

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<Canal> result = canalDaoImpl.listarCanal();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaCanalEmptyResultDataAccessException() throws Exception {
        try {
            List<Map<String, Object>> listaMapa = new ArrayList<>();

            when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
                .thenReturn(listaMapa);

            List<Canal> result = canalDaoImpl.listarCanal();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterListaCanalException() throws Exception {
        try {

            doThrow(AcessoADadosException.class).when(jdbcTemplate).queryForList(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class));

            List<Canal> result = canalDaoImpl.listarCanal();

            Assert.notNull(result, "Não pode ser nulo");

        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
