package br.com.bradseg.ovsm.painelmonitoramento.service.domain.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;

@ExtendWith(MockitoExtension.class)
public class StatusDetalheEventoTest {

    @InjectMocks
    private StatusDetalheEvento statusDetalheEvento;

    @InjectMocks
    private RegistroEvento listaEvento;

    @Test
    void getSetStatusDetalheEvento() throws Exception {
        try {
            StatusDetalheEvento statusDetalheEvento = new StatusDetalheEvento();
            RegistroEvento registro = new RegistroEvento();
            List<RegistroEvento> lista = new ArrayList<>();
            registro.setApi("teste");
            lista.add(registro);
            statusDetalheEvento.setListaEvento(lista);
            statusDetalheEvento.setDisponibilidade(new BigDecimal(1));
            statusDetalheEvento.setFuncionalidade(new BigDecimal(1));
            statusDetalheEvento.setVolumetria(new BigDecimal(1));
            statusDetalheEvento.setSomaEventoGrave(new BigDecimal(1));
            statusDetalheEvento.setSomaEventoModerado(new BigDecimal(1));
            statusDetalheEvento.setSomaTransacao(new BigDecimal(1));
            statusDetalheEvento.setSomaEventoDisponibilidade(new BigDecimal(1));
            statusDetalheEvento.setSomaEventoFuncionalidade(new BigDecimal(1));
            statusDetalheEvento.setSomaEventoVolumetria(new BigDecimal(1));
            statusDetalheEvento.setNomeProduto("Teste");
            statusDetalheEvento.setNomeCanal("Teste");
            statusDetalheEvento.getSomaEventoFuncionalidade();
            statusDetalheEvento.getNomeCanal();
            statusDetalheEvento.getNomeProduto();
            statusDetalheEvento.getSomaEventoVolumetria();
            statusDetalheEvento.getSomaEventoModerado();
            statusDetalheEvento.getSomaEventoDisponibilidade();
            statusDetalheEvento.getSomaEventoGrave();
            statusDetalheEvento.getVolumetria();
            statusDetalheEvento.getDisponibilidade();
            statusDetalheEvento.getFuncionalidade();
            statusDetalheEvento.getListaEvento();
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

}
