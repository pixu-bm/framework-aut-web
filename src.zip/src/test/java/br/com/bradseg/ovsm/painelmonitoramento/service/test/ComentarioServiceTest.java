package br.com.bradseg.ovsm.painelmonitoramento.service.test;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ComentarioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl.ComentarioServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ComentarioServiceTest {

    @Mock
    private LoginDao loginDao;

    @Mock
    private ComentarioDao comentarioDao;

    @InjectMocks
    private ComentarioServiceImpl comentarioServiceImpl;

    /**
     * Teste validarParametrosVisaoComentarios
     *
     * @throws Exception
     */
    @Test
    void validarParametrosVisaoComentarios() throws Exception {

        try {
            comentarioServiceImpl.validarParametrosVisaoComentarios("3", "7", "2", new Date(), "500");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste validarComentarioRequest
     *
     * @throws Exception
     */
    @Test
    void validarComentarioRequest() throws Exception {

        try {
            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            comentarioServiceImpl.validarComentarioRequest(comentarioRequest);

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste InserirComentario
     *
     * @throws Exception
     */
    @Test
    void inserirComentario() throws Exception {

        try {

            Comentario comentario = new Comentario();
            comentario.setCodigoEmpresa(new BigDecimal(3));
            comentario.setCodigoProduto(new BigDecimal(7));
            comentario.setCodigoCanal(new BigDecimal(2));
            comentario.setDataProcs(new Date());
            comentario.setDataInclusao(new Date());
            comentario.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentario.setComentario("Lorem Ipsum");
            comentario.setLogin("M227576");

            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataInclusao(new Date());
            comentarioRequest.getDataInclusao();
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            Usuario usuario = new Usuario();
            usuario.setLogin(comentarioRequest.getLogin());

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(comentarioDao.obterDadosPainelMonitoramento(Mockito.any())).thenReturn(true);
            comentarioServiceImpl.inserirComentario(comentarioRequest);

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste InserirComentario
     *
     * @throws Exception
     */
    @Test
    void getComentario() throws Exception {

        try {

            Comentario comentario = new Comentario();
            comentario.getDataVerificacao();
            comentario.setDataVerificacao(new Date());
            comentario.getDataVerificacao();
            comentario.getDataInclusao();
            comentario.setDataInclusao(new Date());
            comentario.getDataInclusao();
            comentario.setPerfilUsuario("Teste");
            comentario.setNomeUsuario("Teste");
            comentario.getPerfilUsuario();
            comentario.getNomeUsuario();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste InserirComentarioIllegalArgumentException
     *
     * @throws Exception
     */
    @Test
    void inserirComentarioIllegalArgumentException() throws Exception {

        try {
            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.setDataInclusao(new Date());
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            Usuario usuario = new Usuario();
            usuario.setLogin(comentarioRequest.getLogin());

            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);
            comentarioServiceImpl.inserirComentario(comentarioRequest);

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste InserirComentarioIllegalArgumentExceptionCompleto
     *
     * @throws Exception
     */
    @Test
    void inserirComentarioIllegalArgumentExceptionCompleto() throws Exception {

        try {
            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.setDataInclusao(new Date());
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            Usuario usuario = new Usuario();
            usuario.setLogin(comentarioRequest.getLogin());

            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            when(comentarioDao.obterDadosPainelMonitoramento(Mockito.any())).thenReturn(false);
            comentarioServiceImpl.inserirComentario(comentarioRequest);

        } catch (IllegalArgumentException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste ObterComentario
     *
     * @throws Exception
     */
    @Test
    void obterComentario() throws Exception {

        try {
            List<Comentario> obterComentario = comentarioServiceImpl.obterComentario("3", "7", "2", new Date(), "500");
            Assert.notNull(obterComentario, "result tem que trazer uma lista de Comentários");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    /**
     * Teste obterComentarioEmptyResultDataAccessException
     *
     * @throws Exception
     */
    @Test
    void obterComentarioEmptyResultDataAccessException() throws Exception {

        try {
            doThrow(EmptyResultDataAccessException.class).when(
              comentarioDao).obterComentario(Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());

            List<Comentario> obterComentario = comentarioServiceImpl.obterComentario(Mockito.any(), Mockito.any(),
              Mockito.any(), Mockito.any(), Mockito.any());
            Assert.notNull(obterComentario, "result tem que retornar uma lista de comentários");
        } catch (EmptyResultDataAccessException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    /**
     * Teste obterComentarioException
     *
     * @throws Exception
     */
    @Test
    void obterComentarioAcessoADadosException() throws Exception {

        try {
            doThrow(AcessoADadosException.class).when(
              comentarioDao).obterComentario(Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());
            comentarioServiceImpl.obterComentario(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
              Mockito.any());
        } catch (AcessoADadosException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    /**
     * Teste obterComentarioException
     *
     * @throws Exception
     */
    @Test
    void obterComentarioSQLException () throws Exception {

        try {
            doThrow(new SQLException()).when(
              comentarioDao).obterComentario(Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());
            comentarioServiceImpl.obterComentario(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
              Mockito.any());
        } catch (SQLException e) {
        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }
    
    @Test
    void alterarComentarioTest() throws Exception {

        try {

            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataInclusao(new Date());
            comentarioRequest.getDataInclusao();
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            Usuario usuario = new Usuario();
            usuario.setLogin(comentarioRequest.getLogin());

            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);
            comentarioServiceImpl.alterarComentario(comentarioRequest);
            
            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            comentarioServiceImpl.alterarComentario(comentarioRequest);

        } catch (IllegalArgumentException e) {
            //Teste OK
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
    @Test
    void excluirComentarioTest() throws Exception {

        try {

            ComentarioRequest comentarioRequest = new ComentarioRequest();
            comentarioRequest.setCodigoEmpresa(new BigDecimal(3));
            comentarioRequest.setCodigoProduto(new BigDecimal(7));
            comentarioRequest.setCodigoCanal(new BigDecimal(2));
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataProcs(new Date());
            comentarioRequest.getDataProcs();
            comentarioRequest.setDataInclusao(new Date());
            comentarioRequest.getDataInclusao();
            comentarioRequest.setCodigoErroConexaoPainel(new BigDecimal(500));
            comentarioRequest.setComentario("Lorem Ipsum");
            comentarioRequest.setLogin("M227576");

            Usuario usuario = new Usuario();
            usuario.setLogin(comentarioRequest.getLogin());

            when(loginDao.validarLogin(Mockito.any())).thenReturn(true);
            comentarioServiceImpl.excluirComentario(comentarioRequest);
            
            when(loginDao.validarLogin(Mockito.any())).thenReturn(false);
            comentarioServiceImpl.excluirComentario(comentarioRequest);

        } catch (IllegalArgumentException e) {
            //Teste OK
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}
