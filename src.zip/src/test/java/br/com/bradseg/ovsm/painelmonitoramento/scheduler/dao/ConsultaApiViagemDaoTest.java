package br.com.bradseg.ovsm.painelmonitoramento.scheduler.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiViagemDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados gestão acesso canal service
 *
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class ConsultaApiViagemDaoTest {
    
    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private ConsultaApiViagemDaoImpl consultaApiViagemDaoImpl;
    
    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void inserirConsultaApi() throws Exception {
        try {
            List<TabelaTemp> listaViagemTemp = new ArrayList<>();
            TabelaTemp viagemTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            viagemTemp.setcorrigeDado(850);
            viagemTemp.setCindRegProcs("P");
            // Codigo de retorno
            viagemTemp.setCerroOrign("teste");
            viagemTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            viagemTemp.setRenderUrlOrign("endereco");
            viagemTemp.setRservcOrign(null);
            viagemTemp.setItransOrign("A001");
            viagemTemp.setRtransOrign("endereco");
            viagemTemp.setIapiOrign("endereco");
            viagemTemp.setIcanalOrign("CAP");
            viagemTemp.setIemprOrign("CAPI");
            viagemTemp.setIprodtOrign("CAPITALIZACAO");
            viagemTemp.setIsprodOrign(null);
            viagemTemp.setIetapaOfert("TESTE ETAPA");
            viagemTemp.setIplatfOrign("API");
            viagemTemp.setIsitEvnto("NOK");

            viagemTemp.setDinicErro(LocalDateTime.now());
            viagemTemp.setDfimErro(null);
            viagemTemp.setDinclReg(LocalDateTime.now());
            viagemTemp.setDaltReg(null);

            listaViagemTemp.add(viagemTemp);

            consultaApiViagemDaoImpl.inserirConsultaApiViagem(listaViagemTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiViagemDaoImpl.inserirConsultaApiViagem(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void inserirConsultaApiException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));

            consultaApiViagemDaoImpl.inserirConsultaApiViagem(listaCapitalizacaoTemp);

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void liberarProcessamento() throws Exception {
        try {
            List<TabelaTemp> listaViagemTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaViagemTemp.add(capitalizacaoTemp);

            consultaApiViagemDaoImpl.liberarProcessamentoViagem(listaViagemTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoDataIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiViagemDaoImpl.liberarProcessamentoViagem(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void liberarProcessamentoException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiViagemDaoImpl.liberarProcessamentoViagem(listaCapitalizacaoTemp);

        } catch (Exception e) {
        }
    }

    @Test
    void obterultimoregistroinserido() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class))).thenReturn("Teste");
            consultaApiViagemDaoImpl.obterultimoregistroinseridoViagem();

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void obterultimoregistroinseridoException() throws Exception {
        try {

            doThrow(new RuntimeException()).when(jdbcTemplate).queryForObject(Mockito.anyString(),
                Mockito.any(MapSqlParameterSource.class), Mockito.any(ConsultaApiCaptalizacaoRowMapper.class));

            consultaApiViagemDaoImpl.obterultimoregistroinseridoViagem();

        } catch (Exception e) {

        }
    }

    @Test
    void obterultimoregistroinseridoEmptyResultDataAccessException() throws Exception {
        try {

            when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
                Mockito.any(ConsultaApiCaptalizacaoRowMapper.class)));
            String teste = consultaApiViagemDaoImpl.obterultimoregistroinseridoViagem();

            Assert.isNull(teste, "é nulo");

        } catch (Exception e) {

        }
    }

    /**
     * Teste obterVisaoEvento
     *
     * @throws Exception
     */
    @Test
    void validaDuplicados() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            consultaApiViagemDaoImpl.validarDuplicadosViagem(listaCapitalizacaoTemp);

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosIntegrityViolationException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(DataIntegrityViolationException.class).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiViagemDaoImpl.validarDuplicadosViagem(listaCapitalizacaoTemp);

        } catch (DataIntegrityViolationException e) {

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Test
    void validaDuplicadosException() throws Exception {
        try {
            List<TabelaTemp> listaCapitalizacaoTemp = new ArrayList<>();
            TabelaTemp capitalizacaoTemp = new TabelaTemp();

            // Fluxo para Salvar a API
            capitalizacaoTemp.setcorrigeDado(850);
            capitalizacaoTemp.setCindRegProcs("P");
            // Codigo de retorno
            capitalizacaoTemp.setCerroOrign("teste");
            capitalizacaoTemp.setRmsgemErroOrign("400");
            // Endereco API consultada
            capitalizacaoTemp.setRenderUrlOrign("endereco");
            capitalizacaoTemp.setRservcOrign(null);
            capitalizacaoTemp.setItransOrign("A001");
            capitalizacaoTemp.setRtransOrign("endereco");
            capitalizacaoTemp.setIapiOrign("endereco");
            capitalizacaoTemp.setIcanalOrign("CAP");
            capitalizacaoTemp.setIemprOrign("CAPI");
            capitalizacaoTemp.setIprodtOrign("CAPITALIZACAO");
            capitalizacaoTemp.setIsprodOrign(null);
            capitalizacaoTemp.setIetapaOfert("TESTE ETAPA");
            capitalizacaoTemp.setIplatfOrign("API");
            capitalizacaoTemp.setIsitEvnto("NOK");

            capitalizacaoTemp.setDinicErro(LocalDateTime.now());
            capitalizacaoTemp.setDfimErro(null);
            capitalizacaoTemp.setDinclReg(LocalDateTime.now());
            capitalizacaoTemp.setDaltReg(null);

            listaCapitalizacaoTemp.add(capitalizacaoTemp);

            List<Map<String, Object>> batchValues;
            doThrow(new RuntimeException()).when(jdbcTemplate).batchUpdate(Mockito.anyString(),
                Mockito.any(Map[].class));
            consultaApiViagemDaoImpl.validarDuplicadosViagem(listaCapitalizacaoTemp);

        } catch (Exception e) {

        }
    }
}
