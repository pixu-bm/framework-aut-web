package br.com.bradseg.ovsm.painelmonitoramento.exception.test;

import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.Assert;

/**
 * Classe implementa test automatizados AcessoADadosExceptionTest
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class AcessoADadosExceptionTest {

    /**
     * Teste testeException
     * 
     * @throws Exception
     */
    @Test
    void testeAcessoADadosException() throws Exception {
        try {
            Throwable t = new Throwable("Teste");
            AcessoADadosException exception = new AcessoADadosException(t);
            Assert.notNull(exception, "Não pode ser nulo");

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }
    }
}
