package br.com.bradseg.ovsm.painelmonitoramento.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.controller.PainelPrincipalController;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.PainelPrincipalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Classe implementa test automatizados dos serviços de painel principal
 * 
 * @author Wipro
 */
@ExtendWith(MockitoExtension.class)
public class PainelPrincipalTest {

    @Mock
    PainelPrincipalService painelPrincipalService;

    @InjectMocks
    private PainelPrincipalController painelPrincipalController;

    /**
     * Teste para obter o painel de monitoramento.
     * 
     * @throws Exception
     */
    @Test
    void obterPainelMonitoramento() throws Exception {
        try {

            when(painelPrincipalService.obterPainelMonitoramento()).thenReturn(new PainelMonitoramentoAtual());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterPainelMonitoramento();

            // Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterPainelMonitoramentoSQLException() throws Exception {
        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterPainelMonitoramento();
            painelPrincipalController.obterPainelMonitoramento();

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }

    @Test
    void obterVisaoEvento() throws Exception {
        try {

            when(painelPrincipalService.obterVisaoEvento(3)).thenReturn(new VisaoEvento());
            ResponseEntity<ResponseMensagem> result = painelPrincipalController.obterVisaoEvento(3);

            Assert.isTrue(result.getStatusCode().equals(HttpStatus.OK), result.getBody().getMensagem());

        } catch (Exception e) {

            throw new Exception(e.getMessage());
        }

    }

    @Test
    void obterVisaoEventoIllegalArgumentException() throws Exception {

        try {
            doThrow(IllegalArgumentException.class).when(painelPrincipalService).obterVisaoEvento(3);
            painelPrincipalController.obterVisaoEvento(3);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.BAD_REQUEST), e.getMessage());
        }
    }

    @Test
    void obterVisaoEventoSQLException() throws Exception {

        try {
            doThrow(SQLException.class).when(painelPrincipalService).obterVisaoEvento(3);
            painelPrincipalController.obterVisaoEvento(3);

        } catch (ResponseStatusException e) {
            Assert.isTrue(e.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR), e.getMessage());
        }
    }


}
