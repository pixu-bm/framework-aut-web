package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Classe para implementação dos indicadores
 * 
 * @author Wipro
 */
public class TipoEvento {

    private int quantidadeTotalTipoEvento;
    
    private int quantidadeTotalDisponibilidade;
    private int quantidadeTotalFuncionalidade;
    private int quantidadeTotalVolumetria;
    
    private Double porcentagemDisponibilidade;
    private Double porcentagemFuncionalidade;
    private Double porcentagemVolumetria;
    
    public TipoEvento() {
        super();
    }

    public int getQuantidadeTotalTipoEvento() {
        return quantidadeTotalTipoEvento;
    }

    public void setQuantidadeTotalTipoEvento(int quantidadeTotalTipoEvento) {
        this.quantidadeTotalTipoEvento = quantidadeTotalTipoEvento;
    }

    public int getQuantidadeTotalDisponibilidade() {
        return quantidadeTotalDisponibilidade;
    }

    public void setQuantidadeTotalDisponibilidade(int quantidadeTotalDisponibilidade) {
        this.quantidadeTotalDisponibilidade = quantidadeTotalDisponibilidade;
    }

    public int getQuantidadeTotalFuncionalidade() {
        return quantidadeTotalFuncionalidade;
    }

    public void setQuantidadeTotalFuncionalidade(int quantidadeTotalFuncionalidade) {
        this.quantidadeTotalFuncionalidade = quantidadeTotalFuncionalidade;
    }

    public int getQuantidadeTotalVolumetria() {
        return quantidadeTotalVolumetria;
    }

    public void setQuantidadeTotalVolumetria(int quantidadeTotalVolumetria) {
        this.quantidadeTotalVolumetria = quantidadeTotalVolumetria;
    }

    public Double getPorcentagemDisponibilidade() {
        return porcentagemDisponibilidade;
    }

    public void setPorcentagemDisponibilidade(Double porcentagemDisponibilidade) {
        this.porcentagemDisponibilidade = porcentagemDisponibilidade;
    }

    public Double getPorcentagemFuncionalidade() {
        return porcentagemFuncionalidade;
    }

    public void setPorcentagemFuncionalidade(Double porcentagemFuncionalidade) {
        this.porcentagemFuncionalidade = porcentagemFuncionalidade;
    }

    public Double getPorcentagemVolumetria() {
        return porcentagemVolumetria;
    }

    public void setPorcentagemVolumetria(Double porcentagemVolumetria) {
        this.porcentagemVolumetria = porcentagemVolumetria;
    }
}
