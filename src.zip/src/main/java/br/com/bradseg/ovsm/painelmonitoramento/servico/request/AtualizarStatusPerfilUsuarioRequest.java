package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

/**
 * Atualizar status usuario request de serviço
 * @author Wipro
 *
 */
public class AtualizarStatusPerfilUsuarioRequest {

    private String login;
    private String status;
    private String perfil;
    private String motivoRecusa;
    private String loginAprovador;

    public AtualizarStatusPerfilUsuarioRequest() {
        super();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMotivoRecusa() {
        return motivoRecusa;
    }

    public void setMotivoRecusa(String motivoRecusa) {
        this.motivoRecusa = motivoRecusa;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getLoginAprovador() {
        return loginAprovador;
    }

    public void setLoginAprovador(String loginAprovador) {
        this.loginAprovador = loginAprovador;
    }
}
