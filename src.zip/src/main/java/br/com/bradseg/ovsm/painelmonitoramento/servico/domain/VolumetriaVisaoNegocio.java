package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Volumetria em tempo real eventos e transações para construção de grid
 * informativa a consulta paineis OV
 * 
 * @author Wipro
 */
public class VolumetriaVisaoNegocio {

    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private BigDecimal volumetria;
    private BigDecimal historico;
    private BigDecimal volumetriaMaxima;
    private BigDecimal totalDeEventos;
    private BigDecimal eventoDispo;
    private BigDecimal eventoFunc;
    private BigDecimal eventoVolu;
    private BigDecimal eventosGraves;   
 
    public VolumetriaVisaoNegocio() {
        super();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public BigDecimal getVolumetria() {
        return volumetria;
    }

    public void setVolumetria(BigDecimal volumetria) {
        this.volumetria = volumetria;
    }

    public BigDecimal getEventoDispo() {
        return eventoDispo;
    }

    public void setEventoDispo(BigDecimal eventoDispo) {
        this.eventoDispo = eventoDispo;
    }

    public BigDecimal getEventoFunc() {
        return eventoFunc;
    }

    public void setEventoFunc(BigDecimal eventoFunc) {
        this.eventoFunc = eventoFunc;
    }

    public BigDecimal getEventoVolu() {
        return eventoVolu;
    }

    public void setEventoVolu(BigDecimal eventoVolu) {
        this.eventoVolu = eventoVolu;
    }

    public BigDecimal getEventosGraves() {
        return eventosGraves;
    }

    public void setEventosGraves(BigDecimal eventosGraves) {
        this.eventosGraves = eventosGraves;
    }

    public BigDecimal getTotalDeEventos() {
        return totalDeEventos;
    }

    public void setTotalDeEventos(BigDecimal totalDeEventos) {
        this.totalDeEventos = totalDeEventos;
    }

    public BigDecimal getHistorico() {
        return historico;
    }

    public void setHistorico(BigDecimal historico) {
        this.historico = historico;
    }

    public BigDecimal getVolumetriaMaxima() {
        return volumetriaMaxima;
    }

    public void setVolumetriaMaxima(BigDecimal volumetriaMaxima) {
        this.volumetriaMaxima = volumetriaMaxima;
    }

   
}
