package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class TabelaTempSuper {

    private String iemprOrign;
    private String iprodtOrign;
    private String isprodOrign;
    private String ietapaOfert;
    private String iplatfOrign;
    private String isitEvnto;
    private LocalDateTime dinicErro;
    private LocalDate dfimErro;
    private LocalDateTime dinclReg;
    private LocalDate daltReg;

    public TabelaTempSuper() {
        super();
    }

    public String getIemprOrign() {
        return iemprOrign;
    }

    public void setIemprOrign(String iemprOrign) {
        this.iemprOrign = iemprOrign;
    }

    public String getIprodtOrign() {
        return iprodtOrign;
    }

    public void setIprodtOrign(String iprodtOrign) {
        this.iprodtOrign = iprodtOrign;
    }

    public String getIsprodOrign() {
        return isprodOrign;
    }

    public void setIsprodOrign(String isprodOrign) {
        this.isprodOrign = isprodOrign;
    }

    public String getIetapaOfert() {
        return ietapaOfert;
    }

    public void setIetapaOfert(String ietapaOfert) {
        this.ietapaOfert = ietapaOfert;
    }

    public String getIplatfOrign() {
        return iplatfOrign;
    }

    public void setIplatfOrign(String iplatfOrign) {
        this.iplatfOrign = iplatfOrign;
    }

    public String getIsitEvnto() {
        return isitEvnto;
    }

    public void setIsitEvnto(String isitEvnto) {
        this.isitEvnto = isitEvnto;
    }

    public LocalDateTime getDinicErro() {
        return dinicErro;
    }

    public void setDinicErro(LocalDateTime dinicErro) {
        this.dinicErro = dinicErro;
    }

    public LocalDate getDfimErro() {
        return dfimErro;
    }

    public void setDfimErro(LocalDate dfimErro) {
        this.dfimErro = dfimErro;
    }

    public LocalDateTime getDinclReg() {
        return dinclReg;
    }

    public void setDinclReg(LocalDateTime dinclReg) {
        this.dinclReg = dinclReg;
    }

    public LocalDate getDaltReg() {
        return daltReg;
    }

    public void setDaltReg(LocalDate daltReg) {
        this.daltReg = daltReg;
    }

}
