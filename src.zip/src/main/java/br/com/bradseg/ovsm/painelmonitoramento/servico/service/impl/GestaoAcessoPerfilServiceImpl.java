package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.enums.StatusEnum;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.GestaoAcessoPerfilDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmailService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.GestaoAcessoPerfilService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Gestao acesso perfil service implementador
 * 
 * @author Wipro
 */
@Service
public class GestaoAcessoPerfilServiceImpl
    implements GestaoAcessoPerfilService {

    private GestaoAcessoPerfilDao gestaoAcessoPerfilDao;

    private LoginDao loginDao;

    private EmailService emailService;

    private static final Logger LOGGER = LogManager
        .getLogger(GestaoAcessoPerfilServiceImpl.class);
    public static final String ERRO = "erro: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    @Autowired
    public GestaoAcessoPerfilServiceImpl(
        GestaoAcessoPerfilDao gestaoAcessoPerfilDao,
        LoginDao loginDao, EmailService emailService) {
        this.gestaoAcessoPerfilDao = gestaoAcessoPerfilDao;
        this.loginDao = loginDao;
        this.emailService = emailService;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public List<PerfilUsuario> listarPerfilUsuario() throws SQLException {
        try {

            return gestaoAcessoPerfilDao.listarPerfilUsuario();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<Status> obterStatus() {
        return Utils.convertEnumToMapStatus();
    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public List<Usuario> listarUsuario(Usuario usuario) throws SQLException {
        try {
            List<Usuario> listaUsuario = gestaoAcessoPerfilDao
                .listarUsuario(usuario);

            if (listaUsuario.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    "Nenhum dado encontrado na pesquisa", 1);
            }

            return listaUsuario;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarStatusPerfilUsuario(Usuario usuario)
        throws SQLException {
        try {
            String compareCancel = "CANCEL";
            String compareNegad = "NEGAD";
            String compareAprod = "APROV";

            if ((!loginDao.validarLogin(usuario)
                && loginDao.validarLoginAprovador(usuario))
                && (compareCancel.equals(usuario.getStatus())
                    || compareNegad.equals(usuario.getStatus()))) {

                BigDecimal numeroUsuario = gestaoAcessoPerfilDao
                    .obterNumeroUsuario(usuario);
                BigDecimal numeroUsuarioCanceladoRejeitado = gestaoAcessoPerfilDao
                    .obterNumeroUsuarioCanceladoRejeitado(numeroUsuario);

                Usuario usuarioAprovador = new Usuario();
                usuarioAprovador.setLogin(usuario.getLoginAprovador());

                String compareMster = "MSTER";
                if (numeroUsuarioCanceladoRejeitado.intValue() > 0 &&
                    compareMster
                        .equals(loginDao.obterTipoUsuario(usuarioAprovador))) {

                    usuario.setNumeroInternoUsuario(
                        numeroUsuarioCanceladoRejeitado);
                    gestaoAcessoPerfilDao.atualizarUsuarioCancelado(usuario);
                    gestaoAcessoPerfilDao.atualizarStatusPerfilUsuario(usuario);
                    
                } else {
                    usuario.setNumeroInternoUsuario(numeroUsuario);
                    gestaoAcessoPerfilDao.inserirUsuarioCancelado(usuario);
                    gestaoAcessoPerfilDao.atualizarStatusPerfilUsuario(usuario);
                }
                
                emailService.enviarEmail(usuario.getEmail(),
                    atualizarPerfilFuncionalidadeTextoEmailCancelado(usuario),
                    "[OVSM]- Solicitação de acesso.");
                
            } else if ((!loginDao.validarLogin(usuario)
                && loginDao.validarLoginAprovador(usuario))
                && compareAprod.equals(usuario.getStatus())) {
                    gestaoAcessoPerfilDao.atualizarStatusPerfilUsuario(usuario);
                    
                    emailService.enviarEmail(usuario.getEmail(),
                        atualizarPerfilFuncionalidadeTextoEmailAprovado(usuario),
                        "[OVSM]- Solicitação de acesso.");
                } else {
                    throw new EmptyResultDataAccessException(
                        "Este usuário não pode dar acesso.", 1);
                }

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (SQLException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public void validarParametrosAtualizarStatusPerfilUsuario(
        AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest)
        throws SQLException {
        Assert.notNull(atualizarStatusPerfilUsuarioRequest.getLogin(),
            "É obrigatório o preenchimento do login");
        Assert.notNull(atualizarStatusPerfilUsuarioRequest.getLoginAprovador(),
            "É obrigatório o preenchimento do login aprovador");
        Assert.notNull(atualizarStatusPerfilUsuarioRequest.getStatus(),
            "É obrigatório o preenchimento do Status");
        Assert.notNull(atualizarStatusPerfilUsuarioRequest.getPerfil(),
            "É obrigatório o preenchimento do perfil");

        if (atualizarStatusPerfilUsuarioRequest.getStatus()
            .equals(StatusEnum.REJEITADO.getDescricao())
            || atualizarStatusPerfilUsuarioRequest.getStatus()
                .equals(StatusEnum.CANCELADO.getDescricao())) {

            Assert.notNull(
                atualizarStatusPerfilUsuarioRequest.getMotivoRecusa(),
                "É obrigatorio preenchimento do motivo de recusa");
        }

        validarPerfilExistente(atualizarStatusPerfilUsuarioRequest.getPerfil());
    }

    public void validarParametroPerfil(String perfil) throws SQLException {
        Assert.notNull(perfil, "É obrigatório o preenchimento do perfil");
        validarPerfilExistente(perfil);

    }

    /**
     * Método responsável por validar se há cadastro do perfil em base de dados.
     * 
     * @param perfil
     * @throws SQLException
     */
    private void validarPerfilExistente(String perfil) throws SQLException {

        List<PerfilUsuario> listaPerfil = null;
        try {
            listaPerfil = gestaoAcessoPerfilDao.listarPerfilUsuario();

        } catch (SQLException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

        Boolean perfilExiste = false;
        for (int i = 0; i < listaPerfil.size(); i++) {
            if (listaPerfil.get(i).getCodigoTipoPerfil()
                .equalsIgnoreCase(perfil)) {
                perfilExiste = true;
            }
        }

        Assert.isTrue(perfilExiste, "Esse perfil não é cadastrado no sistema");
    }

    /**
     * {@inheritDoc}
     */
    public List<Funcionalidade> obterListaFuncionalidadePerfil(String perfil)
        throws SQLException {
        try {
            return gestaoAcessoPerfilDao.obterListaFuncionalidadePerfil(perfil);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (SQLException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<Funcionalidade> obterListaFuncionalidade() throws SQLException {
        try {
            return gestaoAcessoPerfilDao.obterListaFuncionalidade();
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (SQLException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void validarParametroAtualizarPerfilFuncionalidade(
        AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest)
        throws SQLException {

        Assert.notNull(atualizarPerfilFuncionalidadeRequest.getLogin(),
            "É obrigatório preencher o login do usuario"
                + " que solicita a atualização do perfil funcionalidade.");
        Assert.notNull(
            atualizarPerfilFuncionalidadeRequest.getListaFuncionalidade(),
            "É obrigatório preencher lista de funcionalidades.");
        Assert.notEmpty(
            atualizarPerfilFuncionalidadeRequest.getListaFuncionalidade(),
            "É obrigatório preencher valores na lista de funcionalidades");

        for (int i = 0; i < atualizarPerfilFuncionalidadeRequest
            .getListaFuncionalidade().size(); i++) {
            Assert.notNull(
                atualizarPerfilFuncionalidadeRequest.getListaFuncionalidade()
                    .get(i).getCodigoFuncionalidade(),
                "É obrigatório preencher o codigo da funcionalidade de todas as ocorrencias da lista.");
        }

        validarPerfilExistente(
            atualizarPerfilFuncionalidadeRequest.getPerfil());
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarPerfilFuncionalidade(Usuario usuario)
        throws SQLException {
        try {
            if (loginDao.obterTipoUsuario(usuario).equals("MSTER")) {
                gestaoAcessoPerfilDao.removerPerfilFuncionalidade(usuario);
                gestaoAcessoPerfilDao.inserirPerfilFuncionalidade(usuario);
            } else {
                throw new EmptyResultDataAccessException(
                    "Este usuário não pode atualizar as funcionalidades do perfil, apenas usuario Master.",
                    0);
            }
        } catch (DataIntegrityViolationException e) {
            LOGGER.error(ERRO, e);
            throw new DataIntegrityViolationException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (SQLException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }
    
    private String atualizarPerfilFuncionalidadeTextoEmailCancelado(Usuario usuario) throws SQLException {
        Usuario usuarioCompleto = loginDao.obterInformacaoUsuario(usuario);
        StringBuilder texto = new StringBuilder();
        texto.append("Olá, ");
        texto.append("(" + usuarioCompleto.getLogin() + " - " + usuarioCompleto.getNome() + ")");
        
        texto.append("O seu cadastro no sistema Painel de Monitoramento - OV Digital, foi indeferido,");
        texto.append("Para mais informações, entre em contato com o SuporteCM@bradescoseguros.com.br");
        
        return texto.toString();
    }
    
    private String atualizarPerfilFuncionalidadeTextoEmailAprovado(Usuario usuario) throws SQLException {
        Usuario usuarioCompleto = loginDao.obterInformacaoUsuario(usuario);
        StringBuilder textoAprovacao = new StringBuilder();
        textoAprovacao.append("Olá, ");
        textoAprovacao.append("(" + usuarioCompleto.getLogin() + " - " + usuarioCompleto.getNome() + ") ");
        
        textoAprovacao.append("O seu cadastro no sistema Painel de Monitoramento - OV Digital, foi deferido, ");
        textoAprovacao.append("Para mais informações, entre em contato com o SuporteCM@bradescoseguros.com.br ");
        
        return textoAprovacao.toString();
    }
}
