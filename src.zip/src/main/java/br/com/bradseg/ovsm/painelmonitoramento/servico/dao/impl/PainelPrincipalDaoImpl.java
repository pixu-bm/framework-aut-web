package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.PainelPrincipalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealTransacaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealVolumetriaMaximaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.CanalPainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaPainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ProdutoPainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.lang3.tuple.Triple;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Classe responsável por implementar a busca a base de dados informações
 * relacionadas ao painel de monitamento
 *
 * @author Wipro
 */
@Repository
public class PainelPrincipalDaoImpl implements PainelPrincipalDao {

    public static final String ERROR = "Error: ";
    public static final String CCANAL_DGTAL_PNEL = "CCANAL_DGTAL_PNEL";
    public static final String ICANAL_DGTAL_PNEL = "ICANAL_DGTAL_PNEL";
    public static final String CEMPR_PNEL = "CEMPR_PNEL";
    public static final String IEMPR_PNEL = "IEMPR_PNEL";
    public static final String CPRODT_PNEL = "CPRODT_PNEL";
    public static final String IPRODT = "IPRODT";
    public static final String CSIT_DISPN = "CSIT_DISPN";
    public static final String CSIT_FUNCL = "CSIT_FUNCL";
    public static final String CSIT_VOLUM = "CSIT_VOLUM";
    public static final String CONSULTA_SEM_RESULTADO = "Consulta sem resultado";
    public static final String ERRO_INTERNO = "Erro interno.";
    public static final int INT = 1;
    public static final int INT1 = 2;
    public static final int INT2 = 3;
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final String HORA_ATUAL_ANTERIOR = "horaAtualAnterior";
    private static final String HORA_ATUAL = "horaAtual";
    private static final Logger LOGGER = LogManager.getLogger(PainelPrincipalDaoImpl.class);
    private static final int INT_7 = 7;
    private static final int INT_30 = 30;
    private static final String FROM = " FROM ";
    private static final String AND_CCANAL_DGTAL_PNEL_IN = " AND CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO_IN = " AND CPRODT_PNEL IN ( ";
    private static final String WHERE_DPROCS_APLIC_SYSTIMESTAMP_PERIODO_AND_DPROCS_APLIC_SYSTIMESTAMP = " WHERE "
      + "DPROCS_APLIC >= :horaAtualAnterior AND DPROCS_APLIC <= :horaAtual ";
    private static final String FROM_OVSM_PNEL_MNTRD_HORA = " FROM OVSM.PNEL_MNTRD_HORA ";
    private static final String ROUND_SUM_QMED_TRANS_PARMD_AS_MEDIA_HISTORICA = " SUM(QTRANS_EXECT_INSUC + "
      + " QTRANS_EXECT_INSUC ) " + "AS MEDIA_HISTORICA ";
    private static final String SUM_QEVNTO_NORML_CNXAO_AS_SOMA_SEM_EVENTO_SUM_QTRANS_EXECT_INSUC_AS_SOMA = " SUM"
      + " (QTRANS_EXECT_SCESS) AS SOMA_SEM_EVENTO, SUM(QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO,  ";
    private static final int INT_2 = 2;
    private static final int INT_1 = 1;
    private static final String PERIODO = "periodo";
    private static final String SELECT_PAINEL_MONITORAMENTO_POSIC_ATUAL = " SELECT PAINEL.CEMPR_PNEL,"
      + " EMPRESA.IEMPR_PNEL,"
      + " PAINEL.CPRODT_PNEL, PRODUTO.IPRODT, PAINEL.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL,"
      + " PAINEL.CSIT_DISPN, PAINEL.CSIT_FUNCL, PAINEL.CSIT_VOLUM"

      + " FROM OVSM.PNEL_MNTRD_POSIC_ATUAL PAINEL, OVSM.CANAL_DGTAL_PNEL CANAL,"
      + " OVSM.PRODT_PNEL PRODUTO, OVSM.EMPR_PNEL EMPRESA"

      + " WHERE PRODUTO.CPRODT_PNEL = PAINEL.CPRODT_PNEL" + " AND EMPRESA.CEMPR_PNEL = PAINEL.CEMPR_PNEL"
      + " AND CANAL.CCANAL_DGTAL_PNEL = PAINEL.CCANAL_DGTAL_PNEL"
      + " AND PAINEL.DINCL_REG >= (SELECT MAX(PAINEL_TEMP.DINCL_REG)"
      + " FROM OVSM.PNEL_MNTRD_POSIC_ATUAL PAINEL_TEMP" + " WHERE PAINEL_TEMP.CPRODT_PNEL = PAINEL.CPRODT_PNEL"
      + " AND PAINEL_TEMP.CEMPR_PNEL = PAINEL.CEMPR_PNEL"
      + " AND PAINEL_TEMP.CCANAL_DGTAL_PNEL = PAINEL.CCANAL_DGTAL_PNEL)"
      + " ORDER BY PAINEL.CEMPR_PNEL, PAINEL.CPRODT_PNEL, PAINEL.CCANAL_DGTAL_PNEL";
    private static final String SELECT_VISAO_EVENTO = " SELECT SUM(QEVNTO_NORML_DISPN ) AS QNT_EVENTO_DISPN, "
      + "SUM(QEVNTO_NORML_FUNCL ) AS QNT_EVENTO_FUNCL, SUM(QEVNTO_NORML_CNXAO ) AS QNT_EVENTO_VOLUM, "
      + "SUM(QEVNTO_NORML_DISPN + QEVNTO_NORML_FUNCL + QEVNTO_NORML_CNXAO) AS QNT_TOTAL , SUM(QTRANS_EXECT_INSUC) "
      + "AS TRANSACAO, " + " SUM(QTRANS_EXECT_INSUC + QTRANS_EXECT_SCESS) AS TRANSACAO_TOTAL " + FROM
      + Constantes.OWNER_TABELA + " PNEL_MNTRD_POSIC_ATUAL" + " WHERE 1=1";
    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_VOLUMETRIA_MAXIMA = " SELECT SUM"
      + " (QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC)" + " AS SOMA_VOLUMETRIA_ATUAL,"
      + " SUM(QEVNTO_NORML_CNXAO) AS SOMA_SEM_EVENTO,"
      + " SUM(QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO, ROUND(SUM(QMED_TRANS_PARMD)) AS MEDIA_VOLUMETRIA_HISTORICA "
      + FROM + Constantes.OWNER_TABELA + " PNEL_MNTRD_HORA"
      + " WHERE DPROCS_APLIC >= SYSTIMESTAMP - :periodo AND DPROCS_APLIC <= SYSTIMESTAMP ";
    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO = "SELECT TO_CHAR(DPROCS_APLIC,"
      + "'yyyy-mm-dd HH24:MI')  "
      + "AS HORA_OCORRENCIA  , SUM(QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
      + SUM_QEVNTO_NORML_CNXAO_AS_SOMA_SEM_EVENTO_SUM_QTRANS_EXECT_INSUC_AS_SOMA
      + ROUND_SUM_QMED_TRANS_PARMD_AS_MEDIA_HISTORICA + FROM_OVSM_PNEL_MNTRD_HORA
      + WHERE_DPROCS_APLIC_SYSTIMESTAMP_PERIODO_AND_DPROCS_APLIC_SYSTIMESTAMP;
    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL = " SELECT TO_CHAR"
      + "(DPROCS_APLIC,'yyyy-mm-dd') "
      + "AS HORA_OCORRENCIA,  SUM(QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
      + SUM_QEVNTO_NORML_CNXAO_AS_SOMA_SEM_EVENTO_SUM_QTRANS_EXECT_INSUC_AS_SOMA
      + ROUND_SUM_QMED_TRANS_PARMD_AS_MEDIA_HISTORICA + FROM_OVSM_PNEL_MNTRD_HORA
      + WHERE_DPROCS_APLIC_SYSTIMESTAMP_PERIODO_AND_DPROCS_APLIC_SYSTIMESTAMP;
    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES = " SELECT TO_CHAR"
      + "(DPROCS_APLIC,'yyyy-mm-dd')  AS HORA_OCORRENCIA,"
      + " SUM(QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
      + SUM_QEVNTO_NORML_CNXAO_AS_SOMA_SEM_EVENTO_SUM_QTRANS_EXECT_INSUC_AS_SOMA
      + ROUND_SUM_QMED_TRANS_PARMD_AS_MEDIA_HISTORICA + FROM_OVSM_PNEL_MNTRD_HORA
      + WHERE_DPROCS_APLIC_SYSTIMESTAMP_PERIODO_AND_DPROCS_APLIC_SYSTIMESTAMP;
    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_TRANSACAO_EVENTO = " SELECT PNEL_HORA.CCANAL_DGTAL_PNEL,"
      + " CANAL.ICANAL_DGTAL_PNEL, " + "  SUM(PNEL_HORA.QTRANS_EXECT_SCESS) AS VOLUME_TRANSACAO,"
      + " SUM(PNEL_HORA.QTRANS_EXECT_INSUC) AS VOLUME_IMPACTADO, SUM(PNEL_HORA.QEVNTO_NORML_DISPN)"
      + " AS EVNTO_NORML_DISPN , " + "  SUM(PNEL_HORA.QEVNTO_NORML_FUNCL) AS EVNTO_NORML_FUNC,"
      + " SUM(PNEL_HORA.QEVNTO_NORML_CNXAO) AS EVNTO_NORML_CNXAO,"
      + " SUM(PNEL_HORA.QEVNTO_GRAVE_FUNCL + PNEL_HORA.QEVNTO_GRAVE_DISPN +"
      + " PNEL_HORA.QEVNTO_GRAVE_CNXAO) AS SOMA_EVENTO_GRAVE,  "
      + " SUM(PNEL_HORA.QEVNTO_NORML_DISPN + PNEL_HORA.QEVNTO_NORML_FUNCL +"
      + " PNEL_HORA.QEVNTO_NORML_CNXAO)  AS SOMA_TOTAL_EVENTO,"
      + " SUM(PNEL_HORA.QSEGDA_IDISP_FUNCL + PNEL_HORA.QSEGDA_IDISP_VOLUM +"
      + " PNEL_HORA.QSEGDA_INATV_DISPN) AS SOMA_DURACAO_EVENTO"
      + " FROM OVSM.PNEL_MNTRD_HORA PNEL_HORA, OVSM.CANAL_DGTAL_PNEL CANAL"
      + " WHERE PNEL_HORA.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL"
      + " AND DPROCS_APLIC >= SYSTIMESTAMP - :periodo AND DPROCS_APLIC <= SYSTIMESTAMP"
      + " AND PNEL_HORA.CCANAL_DGTAL_PNEL <> -2";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public PainelPrincipalDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static Boolean validarCodigoEmpresaProdutoCanal(BigDecimal codigoEmpresa, BigDecimal codigoEmpresaTemp,
      BigDecimal codigoProduto, BigDecimal codigoProdutoTemp, BigDecimal codigoCanal,
      BigDecimal codigoCanalTemp) {

        if (codigoEmpresa.equals(codigoEmpresaTemp) && codigoProduto.equals(codigoProdutoTemp)
          && codigoCanal.equals(codigoCanalTemp)) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    /**
     * {@inheritDoc}
     */
    public PainelMonitoramentoAtual obterPainelMonitoramento() throws SQLException {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_PAINEL_MONITORAMENTO_POSIC_ATUAL,
              new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(1);
            }
            PainelMonitoramentoAtual painel = new PainelMonitoramentoAtual();
            List<EmpresaPainelMonitoramentoAtual> listaEmpresa = new ArrayList<>();
            gerarEmpresa(lista, painel, listaEmpresa);
            gerarProduto(lista, painel, listaEmpresa);
            gerarCanal(lista, painel);
            gerarEvento(lista, painel);

            return painel;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    private static void gerarEmpresa(List<Map<String, Object>> lista,
      PainelMonitoramentoAtual painelMonitoramentoAtual,
      List<EmpresaPainelMonitoramentoAtual> listaEmpresa) {

        Map<String, Object> mapa = lista.get(0);

        EmpresaPainelMonitoramentoAtual empresa = new EmpresaPainelMonitoramentoAtual();
        empresa.setCodigoEmpresa((BigDecimal) mapa.get(CEMPR_PNEL));
        empresa.setDescricaoEmpresa((String) mapa.get(IEMPR_PNEL));
        listaEmpresa.add(empresa);
        painelMonitoramentoAtual.setEmpresa(listaEmpresa);

        int count = 1;
        for (int i = 1; i < lista.size(); i++) {

            mapa = lista.get(i);
            BigDecimal codigoEmpresaTemporario = (BigDecimal) mapa.get(CEMPR_PNEL);

            if (!painelMonitoramentoAtual.getEmpresa().get(i - count).getCodigoEmpresa()
              .equals(codigoEmpresaTemporario)) {
                empresa = new EmpresaPainelMonitoramentoAtual();
                empresa.setCodigoEmpresa((BigDecimal) mapa.get(CEMPR_PNEL));
                empresa.setDescricaoEmpresa((String) mapa.get(IEMPR_PNEL));
                listaEmpresa.add(empresa);
                painelMonitoramentoAtual.setEmpresa(listaEmpresa);
            } else {
                count++;
            }

        }
    }

    private static void gerarProduto(List<Map<String, Object>> lista,
      PainelMonitoramentoAtual painelMonitoramentoAtual,
      List<EmpresaPainelMonitoramentoAtual> listaEmpresa) {


        for (int i = 0; i < painelMonitoramentoAtual.getEmpresa().size(); i++) {

            Map<String, Object> mapa = lista.get(0);

            List<ProdutoPainelMonitoramentoAtual> listaProduto = new ArrayList<>();

            ProdutoPainelMonitoramentoAtual produto = new ProdutoPainelMonitoramentoAtual();

            BigDecimal codigoEmpresaTemp = (BigDecimal) mapa.get(CEMPR_PNEL);

            int count = 0;
            if (painelMonitoramentoAtual.getEmpresa().get(i).getCodigoEmpresa().equals(codigoEmpresaTemp)) {
                produto.setCodigoProduto((BigDecimal) mapa.get(CPRODT_PNEL));
                produto.setDescricaoProduto((String) mapa.get(IPRODT));
                listaProduto.add(produto);

                listaEmpresa.get(i).setListaProduto(listaProduto);
                painelMonitoramentoAtual.setEmpresa(listaEmpresa);
            } else {
                count++;
            }

            for (int j = 0; j < lista.size(); j++) {

                mapa = lista.get(j);

                BigDecimal codigoEmpresaTemporario = (BigDecimal) mapa.get(CEMPR_PNEL);
                BigDecimal codigoProdutoTemporario = (BigDecimal) mapa.get(CPRODT_PNEL);
                if (painelMonitoramentoAtual.getEmpresa().get(i).getCodigoEmpresa().equals(codigoEmpresaTemporario)
                  && (painelMonitoramentoAtual.getEmpresa().get(i).getListaProduto().isEmpty()
                  || !painelMonitoramentoAtual.getEmpresa().get(i).getListaProduto().get(j - count)
                  .getCodigoProduto().equals(codigoProdutoTemporario))) {

                    produto = new ProdutoPainelMonitoramentoAtual();
                    produto.setCodigoProduto((BigDecimal) mapa.get(CPRODT_PNEL));
                    produto.setDescricaoProduto((String) mapa.get(IPRODT));
                    listaProduto.add(produto);

                    listaEmpresa.get(i).setListaProduto(listaProduto);
                    painelMonitoramentoAtual.setEmpresa(listaEmpresa);

                } else {
                    count++;
                }

            }

        }

    }

    private static void gerarCanal(List<Map<String, Object>> lista, PainelMonitoramentoAtual painelMonitoramentoAtual) {
        List<Triple<ProdutoPainelMonitoramentoAtual, BigDecimal, BigDecimal>> produtos;
        produtos = new ArrayList<>();

        painelMonitoramentoAtual.getEmpresa().forEach((EmpresaPainelMonitoramentoAtual empresa) ->
          produtos.addAll(empresa.getListaProduto().stream()
          .map(produto -> Triple.of(produto, empresa.getCodigoEmpresa(), empresa.getCodigoEmpresa()))
          .collect(Collectors.toList())));

        produtos.forEach(triple -> {
            ProdutoPainelMonitoramentoAtual produto = triple.getLeft();
            BigDecimal codigoEmpresa = triple.getMiddle();
            BigDecimal codigoProduto = produto.getCodigoProduto();

            produto.setListaCanal(interarListaCanal(lista, codigoEmpresa, codigoProduto));
        });
    }

    private static List<CanalPainelMonitoramentoAtual> interarListaCanal(List<Map<String, Object>> lista,
      BigDecimal codigoEmpresa, BigDecimal codigoProduto) {

        List<CanalPainelMonitoramentoAtual> listaCanal = new ArrayList<>();

        for (int i = 0; i < lista.size(); i++) {
            Map<String, Object> mapa = lista.get(i);

            BigDecimal codigoEmpresaTemporario = (BigDecimal) mapa.get(CEMPR_PNEL);
            BigDecimal codigoProdutoTemporario = (BigDecimal) mapa.get(CPRODT_PNEL);
            BigDecimal codigoCanalTemporario = (BigDecimal) mapa.get(CCANAL_DGTAL_PNEL);
            CanalPainelMonitoramentoAtual ultimoCanalInserido = new CanalPainelMonitoramentoAtual();

            if (!listaCanal.isEmpty()) {
                ultimoCanalInserido = listaCanal.get(listaCanal.size() - 1);
            }

            if (codigoEmpresa.equals(codigoEmpresaTemporario) && codigoProduto.equals(codigoProdutoTemporario)

              && (listaCanal.isEmpty() || !ultimoCanalInserido.getCodigoCanal().equals(codigoCanalTemporario))) {

                CanalPainelMonitoramentoAtual canal = new CanalPainelMonitoramentoAtual();
                canal.setCodigoCanal((BigDecimal) mapa.get(CCANAL_DGTAL_PNEL));
                canal.setDescricaoCanal((String) mapa.get(ICANAL_DGTAL_PNEL));
                listaCanal.add(canal);
            }
        }

        return listaCanal;
    }

    private static void gerarEvento(
        List<Map<String, Object>> lista, PainelMonitoramentoAtual painelMonitoramentoAtual) {
        
        List<Triple<CanalPainelMonitoramentoAtual, BigDecimal, BigDecimal>> canais;
        canais = new ArrayList<>();

        painelMonitoramentoAtual.getEmpresa().forEach((EmpresaPainelMonitoramentoAtual empresa) ->
          empresa.getListaProduto().forEach((ProdutoPainelMonitoramentoAtual produto) ->
            canais.addAll(produto.getListaCanal().stream()
            .map(canal -> Triple.of(canal, empresa.getCodigoEmpresa(), produto.getCodigoProduto()))
            .collect(Collectors.toList()))));

        canais.forEach(triple -> {
            CanalPainelMonitoramentoAtual canal = triple.getLeft();
            BigDecimal codigoEmpresa = triple.getMiddle();
            BigDecimal codigoProduto = triple.getRight();
            BigDecimal codigoCanal = canal.getCodigoCanal();

            canal.setListaEvento(interarListaEvento(lista, codigoEmpresa, codigoProduto, codigoCanal));
        });

    }

    private static List<EventoPainelMonitoramentoAtual> interarListaEvento(List<Map<String, Object>> lista,
      BigDecimal codigoEmpresa, BigDecimal codigoProduto, BigDecimal codigoCanal) {

        List<EventoPainelMonitoramentoAtual> listaEvento = new ArrayList<>();

        for (int k = 0; k < lista.size(); k++) {
            Map<String, Object> mapa = lista.get(k);
            BigDecimal codigoEmpresaTemp = (BigDecimal) mapa.get(CEMPR_PNEL);
            BigDecimal codigoProdutoTemp = (BigDecimal) mapa.get(CPRODT_PNEL);
            BigDecimal codigoCanalTemp = (BigDecimal) mapa.get(CCANAL_DGTAL_PNEL);
            BigDecimal codigoEventoDisponibilidadeTemporario = (BigDecimal) mapa.get(CSIT_DISPN);
            BigDecimal codigoEventoFuncionalidadeTemporario = (BigDecimal) mapa.get(CSIT_FUNCL);
            BigDecimal codigoEventoVolumetriaTemporario = (BigDecimal) mapa.get(CSIT_FUNCL);
            EventoPainelMonitoramentoAtual ultimoEventoInserido = new EventoPainelMonitoramentoAtual();

            if (!listaEvento.isEmpty()) {
                ultimoEventoInserido = listaEvento.get(listaEvento.size() - 1);
            }

            if (Boolean.TRUE.equals(validarCodigoEmpresaProdutoCanal(codigoEmpresa, codigoEmpresaTemp, codigoProduto,
              codigoProdutoTemp, codigoCanal, codigoCanalTemp))

              && Boolean.TRUE.equals(
              validarListaEvento(listaEvento, ultimoEventoInserido, codigoEventoDisponibilidadeTemporario,
                codigoEventoVolumetriaTemporario, codigoEventoFuncionalidadeTemporario))) {

                EventoPainelMonitoramentoAtual evento = new EventoPainelMonitoramentoAtual();
                evento.setCodigoEventoDisponibilidade((BigDecimal) mapa.get(CSIT_DISPN));
                evento.setCodigoEventoFuncionalidade((BigDecimal) mapa.get(CSIT_FUNCL));
                evento.setCodigoEventoVolumetria((BigDecimal) mapa.get(CSIT_VOLUM));
                listaEvento.add(evento);
            }
        }

        return listaEvento;
    }

    private static Boolean validarListaEvento(List<EventoPainelMonitoramentoAtual> listaEvento,
      EventoPainelMonitoramentoAtual ultimoEventoInserido, BigDecimal codigoEventoDisponibilidadeTemporario,
      BigDecimal codigoEventoVolumetriaTemporario, BigDecimal codigoEventoFuncionalidadeTemporario) {

        if (listaEvento.isEmpty() || (!ultimoEventoInserido.getCodigoEventoDisponibilidade()
          .equals(codigoEventoDisponibilidadeTemporario)
          && !ultimoEventoInserido.getCodigoEventoFuncionalidade().equals(codigoEventoFuncionalidadeTemporario)
          && !ultimoEventoInserido.getCodigoEventoVolumetria().equals(codigoEventoVolumetriaTemporario))) {

            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    /**
     * {@inheritDoc}
     */
    public VisaoEvento obterVisaoEvento(Integer periodoVisaoEvento) throws SQLException {

        try {
            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO);

            if (periodoVisaoEvento != null && periodoVisaoEvento == INT) {
                sql.append(" AND TO_CHAR(DVERIF_APLIC ,'yyyy-mm-dd') = TO_CHAR(SYSDATE ,'yyyy-mm-dd') ");
            } else if (periodoVisaoEvento != null && periodoVisaoEvento == INT1) {
                sql.append(" AND DVERIF_APLIC BETWEEN SYSDATE - 7 AND SYSDATE ");
            } else if (periodoVisaoEvento != null && periodoVisaoEvento == INT2) {
                sql.append(" AND DVERIF_APLIC BETWEEN SYSDATE - 30 AND SYSDATE ");
            } else {
                sql.append(" ");
            }

            return jdbcTemplate.queryForObject(sql.toString(), new MapSqlParameterSource(), new VisaoEventoRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodoVisaoEvento,
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
      throws SQLException {

        try {
            StringBuilder sql = new StringBuilder(SELECT_VOLUMETRIA_TEMPO_REAL_VOLUMETRIA_MAXIMA);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (periodoVisaoEvento == INT_1) {
                params.addValue(PERIODO, INT_1);
            } else if (periodoVisaoEvento == INT_2) {
                params.addValue(PERIODO, INT_7);
            } else {
                params.addValue(PERIODO, INT_30);
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProduto = new StringBuilder();
                textoProduto.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProduto.append(",");
                    textoProduto.append(listaCodigoProduto.get(i).toString());
                }

                sql.append(AND_CPRODT_PNEL_CODIGO_PRODUTO_IN + textoProduto.toString() + " )");

            }

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder texto = new StringBuilder();
                texto.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    texto.append(",");
                    texto.append(listaCodigoCanal.get(i).toString());
                }

                sql.append(AND_CCANAL_DGTAL_PNEL_IN + texto.toString() + " )");

            }

            return jdbcTemplate.queryForObject(sql.toString(), params,
              new VolumetriaTempoRealVolumetriaMaximaRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodoVisaoEvento,
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
      throws SQLException {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();
            Date dataAtual = Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());

            Object[] objectParams = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixa(periodoVisaoEvento, objectParams, sql, sqlGroup, params, dataAtual);

            List<VolumetriaTempoReal> lista = jdbcTemplate.queryForObject(sql.toString() + sqlGroup.toString(), params,
              new VolumetriaTempoRealRowMapper());

            List<VolumetriaTempoReal> listaAnterior = obterVolumetriaTempoRealFaixaTempoAnterior(periodoVisaoEvento,
              listaCodigoProduto, listaCodigoCanal);

            if (listaAnterior != null && listaAnterior.isEmpty()) {
                for (int i = 0; i < lista.size(); i++) {
                    lista.get(i).setMediaHistoricaTransacao(BigDecimal.ZERO);
                }
            }

            return lista;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("Nenhum resultado encontrado.");
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private static void obterParametrosVolumetriaTempoRealFaixa(Integer periodoVisaoEvento, Object[] objectParams,
      StringBuilder sql, StringBuilder sqlGroup, MapSqlParameterSource params, Date horaAtual) {
        LocalDateTime dataLocal;

        List<BigDecimal> listaCodigoProduto = (List<BigDecimal>) objectParams[0];
        List<BigDecimal> listaCodigoCanal = (List<BigDecimal>) objectParams[1];

        if (periodoVisaoEvento == INT_1) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO);
            sqlGroup.append(" GROUP BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd HH24:MI') ");
            sqlGroup.append(" ORDER BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd HH24:MI') ");

            dataLocal = horaAtual.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusDays(-1);

            params.addValue(HORA_ATUAL_ANTERIOR, dataLocal);
            params.addValue(HORA_ATUAL, horaAtual);
        } else if (periodoVisaoEvento == INT_2) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL);
            sqlGroup.append(" GROUP BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd') ");
            sqlGroup.append(" ORDER BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd') ");

            dataLocal = horaAtual.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusDays(-INT_7);
            params.addValue(HORA_ATUAL_ANTERIOR, dataLocal);
            params.addValue(HORA_ATUAL, horaAtual);
        } else {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES);
            sqlGroup.append(" GROUP BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd')");
            sqlGroup.append(" ORDER BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd') ");

            dataLocal = horaAtual.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusMonths(-1);
            params.addValue(HORA_ATUAL_ANTERIOR, dataLocal);
            params.addValue(HORA_ATUAL, horaAtual);
        }

        if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

            StringBuilder textoProduto = new StringBuilder();
            textoProduto.append(listaCodigoProduto.get(0).toString());
            for (int i = 0; i < listaCodigoProduto.size(); i++) {

                textoProduto.append(",");
                textoProduto.append(listaCodigoProduto.get(i).toString());

            }

            sql.append(AND_CPRODT_PNEL_CODIGO_PRODUTO_IN + textoProduto + " )");
        }

        if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

            StringBuilder texto = new StringBuilder();
            texto.append(listaCodigoCanal.get(0).toString());
            for (int i = 0; i < listaCodigoCanal.size(); i++) {

                texto.append(",");
                texto.append(listaCodigoCanal.get(i).toString());

            }

            sql.append(AND_CCANAL_DGTAL_PNEL_IN + texto + " )");
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoAnterior(Integer periodoVisaoEvento,
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal) {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();

            Date dataAtual = Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
            LocalDateTime dataLocal = dataAtual.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
              .plusMonths(-1);

            Object[] objectParam = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixa(periodoVisaoEvento, objectParam, sql, sqlGroup, params,
              Date.from(dataLocal.atZone(ZoneId.systemDefault()).toInstant()));

            return jdbcTemplate.queryForObject(sql.toString() + sqlGroup.toString(), params,
              new VolumetriaTempoRealRowMapper());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoRealTransacaoEvento> obterVolumetriaTempoRealTransacaoEvento(Integer periodoVisaoEvento,
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
      throws SQLException {

        try {
            StringBuilder sql = new StringBuilder(SELECT_VOLUMETRIA_TEMPO_REAL_TRANSACAO_EVENTO);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder texto = new StringBuilder();
                texto.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    texto.append(",");
                    texto.append(listaCodigoCanal.get(i).toString());
                }

                sql.append(" AND PNEL_HORA.CCANAL_DGTAL_PNEL IN (" + texto + " ) ");

            }

            if (periodoVisaoEvento == INT_1) {
                params.addValue(PERIODO, INT_1);
            } else if (periodoVisaoEvento == INT_2) {
                params.addValue(PERIODO, INT_7);
            } else {
                params.addValue(PERIODO, INT_30);
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProd = new StringBuilder();
                textoProd.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProd.append(",");
                    textoProd.append(listaCodigoProduto.get(i).toString());
                }

                sql.append(" AND PNEL_HORA.CPRODT_PNEL IN ( " + textoProd + " ) ");
            }

            sql.append(" GROUP BY PNEL_HORA.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL ");

            return jdbcTemplate.queryForObject(sql.toString(), params,
              new VolumetriaTempoRealTransacaoEventoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("Nenhum dado encontrado");
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
