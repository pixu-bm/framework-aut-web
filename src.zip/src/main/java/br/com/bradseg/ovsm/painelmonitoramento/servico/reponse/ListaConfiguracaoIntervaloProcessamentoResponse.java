package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Configuração de intervalo response
 * 
 * @author Wipro
 */
public class ListaConfiguracaoIntervaloProcessamentoResponse extends ResponseMensagem {

    private List<ConfiguracaoIntervaloProcessamentoResponse> listaConfiguracaoIntervalo;

    public ListaConfiguracaoIntervaloProcessamentoResponse() {
        super();
    }

    public List<ConfiguracaoIntervaloProcessamentoResponse> getListaConfiguracaoIntervalo() {
        return  Collections.unmodifiableList(listaConfiguracaoIntervalo);
    }

    public void setListaConfiguracaoIntervalo(
        List<ConfiguracaoIntervaloProcessamentoResponse> listaConfiguracaoIntervalo) {
        this.listaConfiguracaoIntervalo = 
            Collections.unmodifiableList(listaConfiguracaoIntervalo);
    }

}
