package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

public class ConsultaHistorica {
    
    private BigDecimal codigoEvento;
    private String gravidade;
    private String produto;
    private String canal;
    private String tipoEvento;
    private BigDecimal transacoesImpactadas;
    private Long duracaoFunc;
    private Long duracaoDisp;
    private Long duracaoVolu;
    private String duracaoFuncFmt;
    private String duracaoDispFmt;
    private String duracaoVoluFmt;
    private String data;
    private BigDecimal recorrencia;

    public ConsultaHistorica() {
        super();
    }

    public BigDecimal getCodigoEvento() {
        return codigoEvento;
    }

    public void setCodigoEvento(BigDecimal codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public String getGravidade() {
        return gravidade;
    }

    public void setGravidade(String gravidade) {
        this.gravidade = gravidade;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public BigDecimal getTransacoesImpactadas() {
        return transacoesImpactadas;
    }

    public void setTransacoesImpactadas(BigDecimal transacoesImpactadas) {
        this.transacoesImpactadas = transacoesImpactadas;
    }

    public Long getDuracaoFunc() {
        return duracaoFunc;
    }

    public void setDuracaoFunc(Long duracaoFunc) {
        this.duracaoFunc = duracaoFunc;
    }

    public Long getDuracaoDisp() {
        return duracaoDisp;
    }

    public void setDuracaoDisp(Long duracaoDisp) {
        this.duracaoDisp = duracaoDisp;
    }

    public Long getDuracaoVolu() {
        return duracaoVolu;
    }

    public void setDuracaoVolu(Long duracaoVolu) {
        this.duracaoVolu = duracaoVolu;
    }

    public String getDuracaoFuncFmt() {
        return duracaoFuncFmt;
    }

    public void setDuracaoFuncFmt(String duracaoFuncFmt) {
        this.duracaoFuncFmt = duracaoFuncFmt;
    }

    public String getDuracaoDispFmt() {
        return duracaoDispFmt;
    }

    public void setDuracaoDispFmt(String duracaoDispFmt) {
        this.duracaoDispFmt = duracaoDispFmt;
    }

    public String getDuracaoVoluFmt() {
        return duracaoVoluFmt;
    }

    public void setDuracaoVoluFmt(String duracaoVoluFmt) {
        this.duracaoVoluFmt = duracaoVoluFmt;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public BigDecimal getRecorrencia() {
        return recorrencia;
    }

    public void setRecorrencia(BigDecimal recorrencia) {
        this.recorrencia = recorrencia;
    }
    
}
