package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Relacao canal produto
 * 
 * @author Wipro
 */
public class RelacaoCanalProduto {

    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private Integer eventoGrave;
    private Integer eventoModerado;
    private Integer transacaoImpactada;

    public RelacaoCanalProduto() {
        super();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public Integer getEventoGrave() {
        return eventoGrave;
    }

    public void setEventoGrave(Integer eventoGrave) {
        this.eventoGrave = eventoGrave;
    }

    public Integer getEventoModerado() {
        return eventoModerado;
    }

    public void setEventoModerado(Integer eventoModerado) {
        this.eventoModerado = eventoModerado;
    }

    public Integer getTransacaoImpactada() {
        return transacaoImpactada;
    }

    public void setTransacaoImpactada(Integer transacaoImpactada) {
        this.transacaoImpactada = transacaoImpactada;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

}
