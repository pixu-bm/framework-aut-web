package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista registro evento row mapper
 * 
 * @author Wipro
 */
public class ListaRegistroEventoRowMapper implements RowMapper<List<RegistroEvento>> {

    @Override
    public List<RegistroEvento> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<RegistroEvento> lista = new ArrayList<>();

        do {
            RegistroEvento registroEvento = new RegistroEvento();
            registroEvento.setCodigo(rs.getBigDecimal("CERRO_CNXAO_PNEL"));
            registroEvento.setDescricaoProduto(rs.getString("IPRODT"));
            registroEvento.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
            registroEvento.setDescricaoTipo(rs.getString("ITPO_EVNTO_PNEL"));
            registroEvento.setRecorrencia(rs.getInt("QRCRRC_ERRO_EVNTO"));
            registroEvento.setNumeroTransacao(rs.getBigDecimal("QTRANS_EXECT_INSUC"));
            registroEvento.setDescricaoGravidade(rs.getString("ITPO_EVNTO_PNEL"));

            BigDecimal evento = rs.getBigDecimal("QEVNTO_NORML_FUNCL");

            if (evento != null && !evento.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_FUNCL"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_FUNCL")));
            }

            evento = rs.getBigDecimal("QEVNTO_NORML_DISPN");

            if (evento != null && !evento.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_DISPN"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_DISPN")));
            }

            evento = rs.getBigDecimal("QEVNTO_NORML_CNXAO");

            if (evento != null && !evento.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_VOLUM"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_VOLUM")));
            }

            registroEvento.setDuracao(Utils.formatoHoraMinutoSegundo(rs.getInt("QSEGDA_EVNTO")));
            registroEvento.setCodigoEmpresa(rs.getString("CEMPR_PNEL"));
            registroEvento.setCodigoProduto(rs.getString("CPRODT_PNEL"));
            registroEvento.setCodigoCanal(rs.getString("CCANAL_DGTAL_PNEL"));
            registroEvento.setDataProcessamento(rs.getString("DPROCS_APLIC"));
            registroEvento.setMsgQtd(rs.getString("MSGS"));
            String detalhe = rs.getString("ETAPA");
            if (detalhe != null) {
                registroEvento.setStatus(rs.getString("OSIT_ABERT_EVNTO"));
                registroEvento.setEtapaEvento(rs.getString("ETAPA"));
                registroEvento.setQtdEventoUltimo30(rs.getString("QTD_30_DIAS"));
                registroEvento.setUrl(rs.getString("URL"));
                registroEvento.setApi(rs.getString("API"));
                registroEvento.setMainframe(rs.getString("MAINFRAME"));
                registroEvento.setWebService(rs.getString("WEB_SERVICE"));
            }

            lista.add(registroEvento);

        } while (rs.next());

        return lista;
    }

}
