package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;

import java.util.List;

/**
 * Classe responsável por trazer valores referentes  canais
 * @author Wipro
 */
public interface CanalService {

    /**
     * Obter canais
     * @return Map<String, String>
     */
    List<Canal> obterCanais();
}
