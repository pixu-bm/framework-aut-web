package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Classe para implementação dos indicadores
 * 
 * @author Wipro
 */
public class IndicadoresNegocio {

    private int totalTransacoes;
    private int qtdEventos;
    private String tempoTotalEventos;
    private int transacoesImpactadas;
    private int vendas;
    private int frequenciaEventos;
    private String tempoMedioEventos;
    private String porcentagemtotalTransacoes;
    private String porcentagemqtdEventos;
    private String porcentagemtempoTotalEventos;
    private String porcentagemtransacoesImpactadas;
    private String porcentagemvendas;
    private String porcentagemfrequenciaEventos;
    private String porcentagemtempoMedioEventos;
    
    public IndicadoresNegocio() {
        super();
    }

    public int getTotalTransacoes() {
        return totalTransacoes;
    }

    public void setTotalTransacoes(int totalTransacoes) {
        this.totalTransacoes = totalTransacoes;
    }

    public int getQtdEventos() {
        return qtdEventos;
    }

    public void setQtdEventos(int qtdEventos) {
        this.qtdEventos = qtdEventos;
    }

    public String getTempoTotalEventos() {
        return tempoTotalEventos;
    }

    public void setTempoTotalEventos(String tempoTotalEventos) {
        this.tempoTotalEventos = tempoTotalEventos;
    }

    public int getTransacoesImpactadas() {
        return transacoesImpactadas;
    }

    public void setTransacoesImpactadas(int transacoesImpactadas) {
        this.transacoesImpactadas = transacoesImpactadas;
    }

    public int getVendas() {
        return vendas;
    }

    public void setVendas(int vendas) {
        this.vendas = vendas;
    }

    public int getFrequenciaEventos() {
        return frequenciaEventos;
    }

    public void setFrequenciaEventos(int frequenciaEventos) {
        this.frequenciaEventos = frequenciaEventos;
    }

    public String getTempoMedioEventos() {
        return tempoMedioEventos;
    }

    public void setTempoMedioEventos(String tempoMedioEventos) {
        this.tempoMedioEventos = tempoMedioEventos;
    }

    public String getPorcentagemtotalTransacoes() {
        return porcentagemtotalTransacoes;
    }

    public void setPorcentagemtotalTransacoes(String porcentagemtotalTransacoes) {
        this.porcentagemtotalTransacoes = porcentagemtotalTransacoes;
    }

    public String getPorcentagemqtdEventos() {
        return porcentagemqtdEventos;
    }

    public void setPorcentagemqtdEventos(String porcentagemqtdEventos) {
        this.porcentagemqtdEventos = porcentagemqtdEventos;
    }

    public String getPorcentagemtempoTotalEventos() {
        return porcentagemtempoTotalEventos;
    }

    public void setPorcentagemtempoTotalEventos(String porcentagemtempoTotalEventos) {
        this.porcentagemtempoTotalEventos = porcentagemtempoTotalEventos;
    }

    public String getPorcentagemtransacoesImpactadas() {
        return porcentagemtransacoesImpactadas;
    }

    public void setPorcentagemtransacoesImpactadas(String porcentagemtransacoesImpactadas) {
        this.porcentagemtransacoesImpactadas = porcentagemtransacoesImpactadas;
    }

    public String getPorcentagemvendas() {
        return porcentagemvendas;
    }

    public void setPorcentagemvendas(String porcentagemvendas) {
        this.porcentagemvendas = porcentagemvendas;
    }

    public String getPorcentagemfrequenciaEventos() {
        return porcentagemfrequenciaEventos;
    }

    public void setPorcentagemfrequenciaEventos(String porcentagemfrequenciaEventos) {
        this.porcentagemfrequenciaEventos = porcentagemfrequenciaEventos;
    }

    public String getPorcentagemtempoMedioEventos() {
        return porcentagemtempoMedioEventos;
    }

    public void setPorcentagemtempoMedioEventos(String porcentagemtempoMedioEventos) {
        this.porcentagemtempoMedioEventos = porcentagemtempoMedioEventos;
    }
    
}
