package br.com.bradseg.ovsm.painelmonitoramento.utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import br.com.bradseg.ovsm.painelmonitoramento.enums.CanalEnum;
import br.com.bradseg.ovsm.painelmonitoramento.enums.ProdutoEnum;
import br.com.bradseg.ovsm.painelmonitoramento.enums.StatusEnum;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe de utilidades para apoio ao desenvolvimento
 *
 * @author Wipro
 */
public class Utils {

    private static final int INT_12 = 12;
    private static final int INT_10 = 10;
    private static final int INT_3600 = 3600;
    private static final int INT_60 = 60;
    public static final int INT = 100;

    private static final String FORMATO_DATA_BRASIL = "dd/MM/yyyy";
    private static final Log LOGGER = LogFactory.getLog(Utils.class);
    public static final String ERROR = "Error: ";

    private Utils() {
        throw new IllegalStateException("Classe não pode ser instanciada.");
    }

    /**
     * Calcula porcentagem de dados
     *
     * @param valorObtido Integer
     * @param valorTotal  Integer
     * @return
     */
    public static Integer calcularPorcentagem(Integer valorObtido, Integer valorTotal) {

        Integer porcentagem;

        porcentagem = (valorObtido * INT) / valorTotal;

        return porcentagem;
    }

    /**
     * Converter enum para mapa
     *
     * @param enums Enum
     * @return Map<String, String>
     */
    public static Map<String, String> convertEnumToMap() {
        Map<String, String> mapa = new HashMap<String, String>();
        for (Object constante : ProdutoEnum.class.getEnumConstants()) {
            Enum<?> enumConstant = (Enum<?>) constante;
            String name = enumConstant.name();
            try {
                Method method = ProdutoEnum.class.getDeclaredMethod("getDescricao");
                mapa.put(name, (String) method.invoke(enumConstant));
            } catch (Exception e) {
                LOGGER.error(ERROR + e);
                mapa.put(name, name);
            }
        }
        return mapa;

    }

    /**
     * Converter enum para mapa
     *
     * @param enums Enum
     * @return Map<String, String>
     */
    public static List<Status> convertEnumToMapStatus() {
        List<Status> listaStatus = new ArrayList<Status>();

        for (Object constante : StatusEnum.class.getEnumConstants()) {
            Enum<?> enumConstant = (Enum<?>) constante;
            String name = enumConstant.name();
            try {
                Method method = ProdutoEnum.class.getDeclaredMethod("getDescricao");
                Status status = new Status();
                status.setCodigo(name);
                status.setDescricao((String) method.invoke(enumConstant));

                listaStatus.add(status);

            } catch (AcessoADadosException | NoSuchMethodException | SecurityException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
                LOGGER.error(ERROR + e);
                Status status = new Status();
                status.setCodigo(name);
                status.setDescricao(name);

                listaStatus.add(status);
            }
        }

        return listaStatus;
    }

    /**
     * Convert enum em array to map
     *
     * @param canal
     * @return Map<String, String>
     */
    public static Map<String, String> convertEnumArrayToMap(CanalEnum[] canal) {
        Map<String, String> mapa = new HashMap<String, String>();

        for (int i = 0; i < canal.length; i++) {
            mapa.put(canal[i].name(), canal[i].getDescricao());
        }

        return mapa;
    }

    /**
     * Método: javaDateFormatoBrasil
     * Objetivo: Pega uma Data no formato Java e converte para o formato Date
     * Brasileiro - dd/MM/yyyy.
     *
     * @param data Date
     * @return String
     */
    public static String javaDateFormatoBrasil(Date data) {
        String result;
        SimpleDateFormat formatoDateBrasil = new SimpleDateFormat(FORMATO_DATA_BRASIL);
        result = formatoDateBrasil.format(data);

        return result;
    }

    /**
     * Transforma data em horario Brasil em um Date
     *
     * @param strData String
     * @return Date
     */
    public static Date strDateFmtBrasilToJavaDate(String strData) {
        Date result;

        try {
            SimpleDateFormat formatoDateBrasil = new SimpleDateFormat(FORMATO_DATA_BRASIL);
            result = formatoDateBrasil.parse(strData);
        } catch (Exception e) {
            LOGGER.error(ERROR + e);
            return null;
        }
        return result;
    }

    /**
     * Formato hora minuto segundo
     *
     * @param segundos Integer
     * @return String
     */
    public static String formatoHoraMinutoSegundo(Integer segundos) {

        Integer hours = (segundos / INT_3600);

        Integer minutes = ((segundos - (hours * INT_60 * INT_60)) / INT_60);

        Integer seconds = segundos - (hours * INT_60 * INT_60) - (minutes * INT_60);

        return geraStringHoraMinutoSegundo(hours, minutes, seconds);
    }

    /**
     * Formato hora minuto segundo
     *
     * @param segundos String
     * @return String
     */
    public static String converteHoraMinutoSegundoBig(String segundos) {
        BigInteger segundo = new BigInteger(segundos);

        Integer hours = (segundo.intValue() / INT_3600);

        Integer minutes = ((segundo.intValue() - (hours * INT_60 * INT_60)) / INT_60);

        Integer seconds = segundo.intValue() - (hours * INT_60 * INT_60) - (minutes * INT_60);

        return geraStringHoraMinutoSegundo(hours, minutes, seconds);
    }

    public static LocalDate converterDataLocaldateAnterior(Date data) {
        String dataStartString;
        String[] dataStartStringArray;

        try {
            dataStartString = javaDateFormatoBrasil(data);
            dataStartStringArray = dataStartString.split("/");

            return LocalDate.of(Integer.parseInt(dataStartStringArray[Constantes.INT_2]),
                Integer.parseInt(dataStartStringArray[Constantes.INT_1]) - Constantes.INT_1,
                Integer.parseInt(dataStartStringArray[Constantes.INT_0]));

        } catch (DateTimeException eDate) {
            LOGGER.error(ERROR, eDate);
            dataStartString = javaDateFormatoBrasil(data);
            dataStartStringArray = dataStartString.split("/");

            return LocalDate.of(Integer.parseInt(dataStartStringArray[Constantes.INT_2]) - Constantes.INT_1,
                INT_12,
                Integer.parseInt(dataStartStringArray[Constantes.INT_0]));
        }

    }

    public static InputStream csvConverter(Workbook workbook) {

        StringBuilder data = new StringBuilder();
        Row row;
        Cell cell;
        // Iterate through each rows from first sheet
        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();

        while (rowIterator.hasNext()) {
            row = rowIterator.next();
            // For each row, iterate through each columns
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {

                cell = cellIterator.next();

                switch (cell.getCellType()) {
                    case BOOLEAN:
                        data.append(cell.getBooleanCellValue() + ";");

                        break;
                    case NUMERIC:
                        data.append(cell.getNumericCellValue() + ";");

                        break;
                    case STRING:
                        data.append(cell.getStringCellValue() + ";");
                        break;

                    case BLANK:
                        data.append("" + ";");
                        break;
                    default:
                        data.append(cell + ";");

                }
            }
            data.append('\n');
        }

        return new ByteArrayInputStream(data.toString().getBytes());
    }

    private static String geraStringHoraMinutoSegundo(Integer hours, Integer minutes, Integer seconds) {
        String strHours = "";
        String srtMinutes = "";
        String srtSeconds = "";

        if (hours < INT_10) {
            strHours = "0" + hours;
        } else {
            strHours = hours.toString();
        }

        if (minutes < INT_10) {
            srtMinutes = "0" + minutes;
        } else {
            srtMinutes = minutes.toString();
        }

        if (seconds < INT_10) {
            srtSeconds = "0" + seconds;
        } else {
            srtSeconds = seconds.toString();
        }

        return strHours + ":" + srtMinutes + ":" + srtSeconds;
    }

}
