package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConfiguracaoIntervaloProcessamentoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaConfiguracaoIntervaloProcessamentoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ParametroEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Gestao acesso perfil dao Classe configuracao intervalo processamento.
 * 
 * @author Wipro
 */
@Repository
public class ConfiguracaoIntervaloProcessamentoDaoImpl implements ConfiguracaoIntervaloProcessamentoDao {

    private static final Logger LOGGER = LogManager.getLogger(ConfiguracaoIntervaloProcessamentoDaoImpl.class);

    private static final String PARM_EVNTO = "PARM_EVNTO ";
    private static final String AND_DFIM_VGCIA_IS_NULL = "AND DFIM_VGCIA IS NULL";
    private static final String AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL = "AND CCANAL_DGTAL_PNEL = :codigoCanal ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO = "AND CPRODT_PNEL = :codigoProduto ";
    private static final String WHERE_CEMPR_PNEL_CODIGO_EMPRESA = "WHERE CEMPR_PNEL = :codigoEmpresa ";
    private static final String RESULTADO_NAO_ENCONTRADO = "Resultado não encontrado.";
    public static final String ERROR = "Error: ";
    public static final String ERRO_INTERNO = "Erro interno.";
    public static final String CODIGO_EMPRESA = "codigoEmpresa";
    public static final String CODIGO_PRODUTO = "codigoProduto";
    public static final String CODIGO_CANAL = "codigoCanal";

    private NamedParameterJdbcTemplate jdbcTemplate;

    public static final String SELECT_CONFIGURACAO_INTERVALO = " SELECT CONFIG.CEMPR_PNEL,CONFIG.AVGCIA_FNAL,"
        + "CONFIG.NUSUAR,CONFIG.QMNUTO_INTVL_NORML,CONFIG.QMNUTO_INTVL_ERRO,CONFIG.CPRODT_PNEL "
        + ",CONFIG.CCANAL_DGTAL_PNEL,EMPRESA.IEMPR_PNEL, PRODUTO.IPRODT, CONFIG.AVGCIA_FNAL, "
        + "CONFIG.AVGCIA_INIC , CANAL.ICANAL_DGTAL_PNEL "

        + " FROM " + Constantes.OWNER_TABELA + "CONFG_INTVL CONFIG , " + Constantes.OWNER_TABELA
        + "EMPR_PNEL EMPRESA, " + " " + Constantes.OWNER_TABELA + "PRODT_PNEL PRODUTO, " + Constantes.OWNER_TABELA
        + "CANAL_DGTAL_PNEL CANAL "

        + " WHERE CONFIG.CEMPR_PNEL = EMPRESA.CEMPR_PNEL  AND CONFIG.CPRODT_PNEL = PRODUTO.CPRODT_PNEL "
        + " AND CANAL.CCANAL_DGTAL_PNEL = CONFIG.CCANAL_DGTAL_PNEL  "

        + "AND CONFIG.CEMPR_PNEL = :codigoEmpresa " + "AND CONFIG.CPRODT_PNEL = :codigoProduto "
        + "AND CONFIG.CCANAL_DGTAL_PNEL = :codigoCanal " + "AND CONFIG.AVGCIA_FNAL IS NULL";

    public static final String INSERT_CONFIGURACAO_INTERVALO = "INSERT INTO " + Constantes.OWNER_TABELA
        + "CONFG_INTVL (CEMPR_PNEL,NUSUAR,QMNUTO_INTVL_NORML,QMNUTO_INTVL_ERRO,AINCL,"
        + "CPRODT_PNEL,CCANAL_DGTAL_PNEL,AVGCIA_INIC)"
        + "                        VALUES (:codigoEmpresa, :numeroUsuarioInterno, "
        + ":quantidadeMinutoIntervaloNormal, :quantidadeMinutoIntervaloErro, "
        + "                                SYSTIMESTAMP, :codigoProduto, " + ":codigoCanal, :dataVigenciaInicio    )";

    public static final String SELECT_VALIDAR_CONFIGURACAO_INTERVALO = "SELECT COUNT(NUSUAR) FROM "
        + Constantes.OWNER_TABELA
        + "CONFG_INTVL " + WHERE_CEMPR_PNEL_CODIGO_EMPRESA + AND_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL + " AND AVGCIA_FNAL IS NULL";

    public static final String UPDATE_DATA_FIM_VIGENCIA = "UPDATE OVSM.CONFG_INTVL "
        + "SET AVGCIA_FNAL = :dataFimVigencia " + WHERE_CEMPR_PNEL_CODIGO_EMPRESA + AND_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL + "AND AVGCIA_FNAL IS NULL ";

    public static final String SELECT_PARM_EVENTO = "SELECT QTRANS_ONLINE,QTRANS_OFLIN,QMIN_EVNTO_MRADO,"
        + " QMAX_EVNTO_MRADO,QMIN_EVNTO_ALTA,QMAX_EVNTO_ALTA,QMIN_EVNTO_VOLUM_MRADO, "
        + " QMAX_EVNTO_VOLUM_MRADO,QMIN_EVNTO_VOLUM_ALTA,QMAX_EVNTO_VOLUM_ALTA,"
        + " QLIM_EVNTO_VOLUM_BEM_BAIXO,QMETA_EVNTO_VOLUM, "
        + " QLIM_EVNTO_FUNCL_BEM_BAIXO,QMETA_EVNTO_FUNCL,QLIM_EVNTO_IPACT_BEM_BAIXO, "
        + " QMETA_EVNTO_IPACT,QLIM_SEGDA_EVNTO_BEM_BAIXO,QSEGDA_EXCUC_EVNTO "

        + Constantes.FROM + Constantes.OWNER_TABELA + PARM_EVNTO

        + WHERE_CEMPR_PNEL_CODIGO_EMPRESA
        + AND_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL
        + AND_DFIM_VGCIA_IS_NULL;

    public static final String SELECT_VERIFICA_PARM_EVENTO = "SELECT COUNT(CCANAL_DGTAL_PNEL) " + Constantes.FROM
        + Constantes.OWNER_TABELA + PARM_EVNTO
        + WHERE_CEMPR_PNEL_CODIGO_EMPRESA
        + AND_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL
        + AND_DFIM_VGCIA_IS_NULL;

    public static final String UPDATE_DATA_FIM_PARM_EVENTO = "UPDATE " + Constantes.OWNER_TABELA + PARM_EVNTO
        + "SET DFIM_VGCIA = SYSTIMESTAMP, "
        + " DULT_ALT_REG = SYSTIMESTAMP "
        + WHERE_CEMPR_PNEL_CODIGO_EMPRESA
        + AND_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_CCANAL_DGTAL_PNEL_CODIGO_CANAL
        + AND_DFIM_VGCIA_IS_NULL;

    public static final String INSERT_PARAM_EVENTO = "INSERT INTO " + Constantes.OWNER_TABELA + PARM_EVNTO
        + " (CEMPR_PNEL, CPRODT_PNEL, CCANAL_DGTAL_PNEL, DVERIF_APLIC, DPROCS_APLIC, QTRANS_ONLINE, QTRANS_OFLIN, "
        + "QMIN_EVNTO_MRADO, QMAX_EVNTO_MRADO, QMIN_EVNTO_ALTA, QMAX_EVNTO_ALTA, QMIN_EVNTO_VOLUM_MRADO, "
        + "QMAX_EVNTO_VOLUM_MRADO, QMIN_EVNTO_VOLUM_ALTA, QMAX_EVNTO_VOLUM_ALTA, QLIM_EVNTO_VOLUM_BEM_BAIXO, "
        + "QMETA_EVNTO_VOLUM, QLIM_EVNTO_FUNCL_BEM_BAIXO, QMETA_EVNTO_FUNCL, QLIM_EVNTO_IPACT_BEM_BAIXO, "
        + "QMETA_EVNTO_IPACT, QLIM_SEGDA_EVNTO_BEM_BAIXO, QSEGDA_EXCUC_EVNTO, DINIC_VGCIA, DINCL_REG) "

        + "VALUES(:codigoEmpresa, :codigoProduto, :codigoCanal, SYSTIMESTAMP, SYSTIMESTAMP, "
        + ":quantidadeTransacaoOnline, :quantidadeTransacaoOffiline, "
        + ":quantidadeMinimaEventoModerado, :quantidadeMaximaEventoModerado, :quantidadeMinimaEventoAlto, "
        + ":quantidadeMaximaEventoAlto, :quantidadeMinimaEventoVolumeModerado, "
        + ":quantidadeMaximaEventoVolumeModerado, :quantidadeMinimaEventoVolumeAlta, "
        + ":quantidadeMaximaEventoVolumeAlta, :quantidadeLimiteEventoVolumeBemBaixo, "
        + ":quantidadeMetricaEventoVolume, :quantidadeLimiteEventoFuncionalidadeBemBaixo, "
        + ":quantidadeMetricaEventoFuncionalidade, :quantidadeLimiteEventoImpactoBemBaixo, "
        + ":quantidadeMetricaEventoImpacto, :quantidadeLimiteSegundosEventoBemBaixo, "
        + ":quantidadeSegudosExecucaoEvento, SYSTIMESTAMP, SYSTIMESTAMP)";
    
    @Autowired
    public ConfiguracaoIntervaloProcessamentoDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public ConfiguracaoIntervaloProcessamentoResponse obterConfiguracaoIntervaloProcessamento(BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal) throws SQLException {
        try {
            MapSqlParameterSource params = adicionarParametros(codigoEmpresa, codigoProduto, codigoCanal);
            return jdbcTemplate.queryForObject(
                SELECT_CONFIGURACAO_INTERVALO, params, new ListaConfiguracaoIntervaloProcessamentoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(RESULTADO_NAO_ENCONTRADO, 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public void inserirConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento) throws SQLException {
        try {
            MapSqlParameterSource params = adicionarParametros(configuracaoIntervaloProcessamento.getCodigoEmpresa(),
                configuracaoIntervaloProcessamento.getCodigoProduto(),
                configuracaoIntervaloProcessamento.getCodigoCanal());

            params.addValue("numeroUsuarioInterno",
                configuracaoIntervaloProcessamento.getNumeroInternoConfiguracaoIntervalo());
            params.addValue("quantidadeMinutoIntervaloNormal",
                configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloNormal());
            params.addValue("quantidadeMinutoIntervaloErro",
                configuracaoIntervaloProcessamento.getQuantidadeMinutoIntervaloErro());
            params.addValue("dataVigenciaInicio", LocalDateTime.now());

            jdbcTemplate.update(INSERT_CONFIGURACAO_INTERVALO, params);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public Boolean verificarConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento) throws SQLException {

        try {
            MapSqlParameterSource params = adicionarParametros(configuracaoIntervaloProcessamento.getCodigoEmpresa(),
                configuracaoIntervaloProcessamento.getCodigoProduto(),
                configuracaoIntervaloProcessamento.getCodigoCanal());

            return jdbcTemplate.queryForObject(SELECT_VALIDAR_CONFIGURACAO_INTERVALO, params, Integer.class) == 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarDataFimVigencia(ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento)
        throws SQLException {

        try {
            MapSqlParameterSource params = adicionarParametros(configuracaoIntervaloProcessamento.getCodigoEmpresa(),
                configuracaoIntervaloProcessamento.getCodigoProduto(),
                configuracaoIntervaloProcessamento.getCodigoCanal());
            params.addValue("dataFimVigencia",
                obterParametroFimVigencia(configuracaoIntervaloProcessamento.getDataVigenciaInicio()));

            jdbcTemplate.update(UPDATE_DATA_FIM_VIGENCIA, params);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Obter parametro fim de vigencia encima da nova vigencia - 1 dia.
     * 
     * @param inicioVigencia Date
     * @return Date
     */
    private static Date obterParametroFimVigencia(Date inicioVigencia) {

        String dataIniString = Utils.javaDateFormatoBrasil(inicioVigencia);
        String[] dataIniStringArray = dataIniString.split("/");

        LocalDate localIni = LocalDate.of(Integer.parseInt(dataIniStringArray[Constantes.INT_2]),
            Integer.parseInt(dataIniStringArray[Constantes.INT_1]),
            Integer.parseInt(dataIniStringArray[Constantes.INT_0]) - 1);

        return Date.from(localIni.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    /**
     * {@inheritDoc}
     */
    public ParametroEvento obterParametroEvento(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException {
        try {
            MapSqlParameterSource params = adicionarParametros(codigoEmpresa, codigoProduto, codigoCanal);

            return jdbcTemplate.queryForObject(SELECT_PARM_EVENTO, params, new ParametroEventoRowMapper());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(RESULTADO_NAO_ENCONTRADO, 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Boolean verificarParametroEventoExiste(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException {
        try {
            MapSqlParameterSource params = adicionarParametros(codigoEmpresa, codigoProduto, codigoCanal);

            return jdbcTemplate.queryForObject(SELECT_VERIFICA_PARM_EVENTO, params, Integer.class) > 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarDataFimVigenciaParametroEvento(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException {
        try {
            MapSqlParameterSource params = adicionarParametros(codigoEmpresa, codigoProduto, codigoCanal);

            jdbcTemplate.update(UPDATE_DATA_FIM_PARM_EVENTO, params);
        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(Constantes.ERRO_DE_VIOLACAO_DE_INTEGRIDADE);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Adicionar parametros map
     * 
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal BigDecimal
     * @return MapSqlParameterSource
     */
    private static MapSqlParameterSource adicionarParametros(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue(CODIGO_CANAL, codigoCanal);
        params.addValue(CODIGO_PRODUTO, codigoProduto);
        params.addValue(CODIGO_EMPRESA, codigoEmpresa);

        return params;
    }

    /**
     * {@inheritDoc}
     */
    public void inserirParametroEvento(ParametroEventoRequest parametroEvento) throws SQLException {
        try {
            MapSqlParameterSource params = montarParametroInserirEvento(parametroEvento);

            jdbcTemplate.update(INSERT_PARAM_EVENTO, params);
        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(Constantes.ERRO_DE_VIOLACAO_DE_INTEGRIDADE);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Parametro para montar query de request 
     * parm evento
     * 
     * @param parametroEvento ParametroEventoRequest
     * @return MapSqlParameterSource
     */
    private static MapSqlParameterSource montarParametroInserirEvento(ParametroEventoRequest parametroEvento) {
        MapSqlParameterSource params = adicionarParametros(
            parametroEvento.getCodigoEmpresa(), parametroEvento.getCodigoProduto(), parametroEvento.getCodigoCanal());
        params.addValue("quantidadeTransacaoOnline",
            parametroEvento.getParametroEvento().getQuantidadeTransacaoOnline());
        params.addValue("quantidadeTransacaoOffiline",
            parametroEvento.getParametroEvento().getQuantidadeTransacaoOffline());
        params.addValue("quantidadeMinimaEventoModerado",
            parametroEvento.getParametroEvento().getQuantidadeMinimaEventoModerado());
        params.addValue("quantidadeMaximaEventoModerado",
            parametroEvento.getParametroEvento().getQuantidadeMaximaEventoModerado());
        params.addValue("quantidadeMinimaEventoAlto",
            parametroEvento.getParametroEvento().getQuantidadeMinimaEventoAlto());
        params.addValue("quantidadeMaximaEventoAlto",
            parametroEvento.getParametroEvento().getQuantidadeMaximaEventoAlto());
        params.addValue("quantidadeMinimaEventoVolumeModerado",
            parametroEvento.getParametroEvento().getQuantidadeMinimaEventoVolumeModerado());
        params.addValue("quantidadeMaximaEventoVolumeModerado",
            parametroEvento.getParametroEvento().getQuantidadeMaximaEventoVolumeModerado());
        params.addValue("quantidadeMinimaEventoVolumeAlta",
            parametroEvento.getParametroEvento().getQuantidadeMinimaEventoVolumeAlto());
        params.addValue("quantidadeMaximaEventoVolumeAlta",
            parametroEvento.getParametroEvento().getQuantidadeMaximaEventoVolumeAlto());
        params.addValue("quantidadeLimiteEventoVolumeBemBaixo",
            parametroEvento.getParametroEvento().getQuantidadeLimiteEventoVolumeBemBaixo());
        params.addValue("quantidadeMetricaEventoVolume",
            parametroEvento.getParametroEvento().getQuantidadeMetricaEventoVolume());
        params.addValue("quantidadeLimiteEventoFuncionalidadeBemBaixo",
            parametroEvento.getParametroEvento().getQuantidadeLimiteEventoFuncionalidadeBemBaixo());
        params.addValue("quantidadeMetricaEventoFuncionalidade",
            parametroEvento.getParametroEvento().getQuantidadeMetricaEventoFuncionalidade());
        params.addValue("quantidadeLimiteEventoImpactoBemBaixo",
            parametroEvento.getParametroEvento().getQuantidadeLimiteEventoImpactoBemBaixo());
        params.addValue("quantidadeMetricaEventoImpacto",
            parametroEvento.getParametroEvento().getQuantidadeMetricaEventoImpacto());
        params.addValue("quantidadeLimiteSegundosEventoBemBaixo",
            parametroEvento.getParametroEvento().getQuantidadeLimiteSegundoEventoBemBaixo());
        params.addValue("quantidadeSegudosExecucaoEvento",
            parametroEvento.getParametroEvento().getQuantidadeSegundoExecucaoEvento());

        return params;

    }

}
