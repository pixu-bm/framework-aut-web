package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.util.Collections;
import java.util.List;

/**
 * Classe para empresa combo
 * 
 * @author Wipro
 */
public class EmpresaCombo extends ResponseMensagem {

    private List<Empresa> empresaCombos;

    public EmpresaCombo() {
        super();
    }

    public List<Empresa> getEmpresaCombos() {
        return Collections.unmodifiableList(empresaCombos);
    }

    public void setEmpresaCombos(List<Empresa> empresaCombos) {
        this.empresaCombos = 
            Collections.unmodifiableList(empresaCombos);
    }

}
