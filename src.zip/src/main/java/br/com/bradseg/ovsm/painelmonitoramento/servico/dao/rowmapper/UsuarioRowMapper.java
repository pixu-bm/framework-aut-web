package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Mapeia uma extração de dados da base de usuarios
 *
 * @author Wipro
 */
public class UsuarioRowMapper implements RowMapper<Usuario> {

    public Usuario mapRow(ResultSet rs, int rowNum) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setNumeroInternoUsuario(new BigDecimal(rowNum));
        usuario.setLogin(rs.getString("CUSUAR"));
        usuario.setEmail(rs.getString("REMAIL_CORP"));
        usuario.setNome(rs.getString("IUSUAR"));
        usuario.setNumeroInternoUsuario(rs.getBigDecimal("NUSUAR"));

        return usuario;
    }

}
