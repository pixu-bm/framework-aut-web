package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Volumetria tempo real mapa objetos extração de base de dados.
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealRowMapper implements RowMapper<List<VolumetriaTempoReal>> {

    @Override
    public List<VolumetriaTempoReal> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<VolumetriaTempoReal> lista = new ArrayList<>();

        do {
            VolumetriaTempoReal volumetriaTempoReal = new VolumetriaTempoReal();

            volumetriaTempoReal.setHoraOcorrencia(rs.getString("HORA_OCORRENCIA"));
            volumetriaTempoReal.setTransacaoEvento(rs.getBigDecimal("SOMA_COM_EVENTO"));
            volumetriaTempoReal.setTransacaoSemEvento(rs.getBigDecimal("SOMA_SEM_EVENTO"));
            volumetriaTempoReal.setMediaHistoricaTransacao(rs.getBigDecimal("MEDIA_HISTORICA"));
            volumetriaTempoReal.setVolumetriaAtualTransacao(rs.getBigDecimal("SOMA_VOLUMETRIA_ATUAL"));

            lista.add(volumetriaTempoReal);
        } while (rs.next());

        return lista;
    }

}
