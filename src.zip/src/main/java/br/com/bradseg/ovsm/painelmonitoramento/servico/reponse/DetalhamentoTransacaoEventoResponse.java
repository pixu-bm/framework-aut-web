package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;

/**
 * Classe que implementa volumetria de tempo real tabela trafego objeto
 * 
 * @author Wipro
 */
public class DetalhamentoTransacaoEventoResponse extends ResponseMensagem {
    
    private NumeroTransacoes numeroTransacao;
    private List<EventoPorCanal> eventoPorCanal;
    private TipoEvento tipoEvento;

    public DetalhamentoTransacaoEventoResponse() {
        super();
    }

    public NumeroTransacoes getNumeroTransacao() {
        return numeroTransacao;
    }

    public void setNumeroTransacao(NumeroTransacoes numeroTransacao) {
        this.numeroTransacao = numeroTransacao;
    }

    public List<EventoPorCanal> getEventoPorCanal() {
        return Collections.unmodifiableList(eventoPorCanal);
    }

    public void setEventoPorCanal(List<EventoPorCanal> eventoPorCanal) {
        this.eventoPorCanal = Collections.unmodifiableList(eventoPorCanal);
    }

    public TipoEvento getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(TipoEvento tipoEvento) {
        this.tipoEvento = tipoEvento;
    }
}
