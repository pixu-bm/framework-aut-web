package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiPrevidenciaDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Component
public class ConsultaApiPrevidencia {
    
    private static final Log LOGGER = LogFactory.getLog(ConsultaApiPrevidencia.class);

    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "PREVIDENCIA";
    public static final int INTERVALO_PREV = 15;
    private static final int MAXIMO_CARACTERS = 100;

    
    @Autowired
    private ConsultaApiPrevidenciaDao consultaApiPrevidenciaDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING"};

    private boolean status;

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;
    
    private String obterDados = "/V2/v1/previdenciacorp/individual/obterDadosPais?codPais=0";
    private String[] metodosApi = {obterDados};
    
    public ConsultaApiPrevidencia(
        ConsultaApiPrevidenciaDao consultaApiPrevidenciaDao) {
        this.consultaApiPrevidenciaDao = consultaApiPrevidenciaDao;
    }
    
    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerPrev = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerPrev);
            
            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualPrevidencia = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterPrevidencia = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualPrevidencia.format(formatterPrevidencia);
            LocalDateTime dataHoraPrevidencia = LocalDateTime.parse(agoraFormatado, formatterPrevidencia);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiPrevidenciaDao.obterultimoregistroinserido();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterPrevidencia);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraPrevidencia, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + obterDados);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                connection.setInstanceFollowRedirects(false);
                connection.addRequestProperty("Authorization", authorization);

                
                LinkedList<TabelaTemp> listaPrevidenciaTemp = new LinkedList<>();

                validarConexaoPrevidenciaTemp(dataHoraPrevidencia, connection, canal,
                    enderecoApi + obterDados,
                    listaPrevidenciaTemp, enderecoApi + obterDados);

                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCancal = (HttpURLConnection) urlapi.openConnection();
                    connectionCancal.setRequestMethod("GET");
                    connectionCancal.setRequestProperty("Content-Type", "application/json");
                    connectionCancal.setDoOutput(true);
                    connectionCancal.setInstanceFollowRedirects(false);
                    connectionCancal.addRequestProperty("Authorization", authorization);

                 
                    validarConexaoPrevidenciaTempApi(dataHoraPrevidencia, connectionCancal,
                        canal, null, listaPrevidenciaTemp);

                }

                if (minutos >= INTERVALO_PREV) {

                    consultaApiPrevidenciaDao.inserirConsultaApiPrevidencia(listaPrevidenciaTemp);

                    consultaApiPrevidenciaDao.validarDuplicadosPrevidencia(listaPrevidenciaTemp);

                    consultaApiPrevidenciaDao.liberarProcessamentoPrevidencia(listaPrevidenciaTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public void validarConexaoPrevidenciaTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaPrevidenciaTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            // Consulta Realizada com erro
            status = true;

            listaPrevidenciaTemp
                .addLast(obterPrevidenciaNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {
            // Consulta Realizada com sucesso
            status = false;

            listaPrevidenciaTemp.addLast(obterPrevidenciaOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    public void validarConexaoPrevidenciaTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaPrevidenciaTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            status = true;

            listaPrevidenciaTemp.addLast(obterPrevidenciaNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            status = false;

            listaPrevidenciaTemp.addLast(obterPrevidenciaOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public TabelaTemp obterPrevidenciaNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        status = true;
        TabelaTemp previdenciaTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        previdenciaTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        previdenciaTemp.setCindRegProcs("J");
        // Codigo de retorno
        previdenciaTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        previdenciaTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        previdenciaTemp.setRenderUrlOrign(enderecoApi);
        previdenciaTemp.setRservcOrign(null);
        previdenciaTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > MAXIMO_CARACTERS) {
            previdenciaTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            previdenciaTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > MAXIMO_CARACTERS) {
            previdenciaTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            previdenciaTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            previdenciaTemp.setIapiOrign(enderecoApi);
            previdenciaTemp.setIetapaOfert(enderecoApi);
        }

        previdenciaTemp.setIcanalOrign(canal);
        previdenciaTemp.setIemprOrign("BVP");
        previdenciaTemp.setIprodtOrign(PRODUTO);
        previdenciaTemp.setIsprodOrign(null);

        previdenciaTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        previdenciaTemp.setIsitEvnto("NOK");
        previdenciaTemp.setDinicErro(dataHoraAtual);
        previdenciaTemp.setDfimErro(null);
        previdenciaTemp.setDinclReg(dataHoraAtual);
        previdenciaTemp.setDaltReg(null);

        return previdenciaTemp;
    }

    public static TabelaTemp obterPrevidenciaOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp previdenciaTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        previdenciaTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        previdenciaTempOk.setCindRegProcs("J");
        // Codigo de retorno
        previdenciaTempOk.setCerroOrign("200");
        previdenciaTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        previdenciaTempOk.setRenderUrlOrign(enderecoApi);
        previdenciaTempOk.setRservcOrign(null);
        previdenciaTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > MAXIMO_CARACTERS) {
            previdenciaTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            previdenciaTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > MAXIMO_CARACTERS) {
            previdenciaTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            previdenciaTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            previdenciaTempOk.setIapiOrign(enderecoApi);
            previdenciaTempOk.setIetapaOfert(enderecoApi);
        }

        previdenciaTempOk.setIcanalOrign(canal);
        previdenciaTempOk.setIemprOrign("BVP");
        previdenciaTempOk.setIprodtOrign(PRODUTO);
        previdenciaTempOk.setIsprodOrign(null);

        previdenciaTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        previdenciaTempOk.setIsitEvnto("OK");
        previdenciaTempOk.setDinicErro(dataHoraAtual);
        previdenciaTempOk.setDfimErro(null);
        previdenciaTempOk.setDinclReg(dataHoraAtual);
        previdenciaTempOk.setDaltReg(null);

        return previdenciaTempOk;
    }

    // Metodo responsavel por buscar o tempo parametrizado em milisegundos 900000
    public int buscaTempoParametrizado() {

        // Necessario implementar consulta na tabela de config de tempos para buscar os parametros
        // status = true erro identificado
        if (status) {
            return TEMPO_PARAMETRIZADO_SUCESSO;
        }

        return TEMPO_PARAMETRIZADO_ERRO;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
