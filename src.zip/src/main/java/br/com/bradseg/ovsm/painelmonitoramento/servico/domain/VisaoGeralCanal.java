package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * Visao geral canal
 * 
 * @author Wipro
 */
public class VisaoGeralCanal {

    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private Integer eventoGrave;
    private Integer eventoModerado;
    private Integer numeroImpacto;
    private Integer eventoDisponibilidade;
    private Integer eventoFuncional;
    private Integer eventoVolumetria;
    private List<RelacaoProdutoCanal> listaRelacaoProdutoCanal;

    public VisaoGeralCanal() {
        super();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public Integer getEventoGrave() {
        return eventoGrave;
    }

    public void setEventoGrave(Integer eventoGrave) {
        this.eventoGrave = eventoGrave;
    }

    public Integer getEventoModerado() {
        return eventoModerado;
    }

    public void setEventoModerado(Integer eventoModerado) {
        this.eventoModerado = eventoModerado;
    }

    public Integer getNumeroImpacto() {
        return numeroImpacto;
    }

    public void setNumeroImpacto(Integer numeroImpacto) {
        this.numeroImpacto = numeroImpacto;
    }

    public Integer getEventoDisponibilidade() {
        return eventoDisponibilidade;
    }

    public void setEventoDisponibilidade(Integer eventoDisponibilidade) {
        this.eventoDisponibilidade = eventoDisponibilidade;
    }

    public Integer getEventoFuncional() {
        return eventoFuncional;
    }

    public void setEventoFuncional(Integer eventoFuncional) {
        this.eventoFuncional = eventoFuncional;
    }

    public Integer getEventoVolumetria() {
        return eventoVolumetria;
    }

    public void setEventoVolumetria(Integer eventoVolumetria) {
        this.eventoVolumetria = eventoVolumetria;
    }

    public List<RelacaoProdutoCanal> getListaRelacaoProdutoCanal() {
        return Collections.unmodifiableList(listaRelacaoProdutoCanal);
    }

    public void setListaRelacaoProdutoCanal(List<RelacaoProdutoCanal> listaRelacaoProdutoCanal) {
        this.listaRelacaoProdutoCanal = Collections.unmodifiableList(listaRelacaoProdutoCanal);
    }
}
