package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

/**
 * Classe responsável para o login request de serviço rest
 * @author Wipro
 */
public class LoginRequest {


    private String login;

    public LoginRequest() {
        super();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

}
