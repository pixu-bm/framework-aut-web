package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Evento response.
 * 
 * @author Wipro
 */
public class GraficoDetalheEventoResponse extends ResponseMensagem {

    private List<GraficoDetalheEvento> graficoDetalheEvento;

    public GraficoDetalheEventoResponse() {
        super();
    }

    public List<GraficoDetalheEvento> getGraficoDetalheEvento() {
        return Collections.unmodifiableList(graficoDetalheEvento);
    }

    public void setGraficoDetalheEvento(List<GraficoDetalheEvento> graficoDetalheEvento) {
        this.graficoDetalheEvento = Collections.unmodifiableList(graficoDetalheEvento);
    }

}
