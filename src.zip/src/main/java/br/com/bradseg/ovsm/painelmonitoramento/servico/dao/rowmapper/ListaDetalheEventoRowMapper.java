package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista registro evento row mapper
 *
 * @author Wipro
 */
public class ListaDetalheEventoRowMapper implements RowMapper<List<RegistroEvento>> {

    @Override
    public List<RegistroEvento> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<RegistroEvento> lista = new ArrayList<>();

        do {
            RegistroEvento registroEvento = new RegistroEvento();
            registroEvento.setDescricaoProduto(rs.getString("IPRODT"));
            registroEvento.setCodigo(rs.getBigDecimal("CERRO_CNXAO_PNEL"));
            registroEvento.setDescricaoTipo(rs.getString("ITPO_EVNTO_PNEL"));
            registroEvento.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
            registroEvento.setRecorrencia(rs.getInt("QRCRRC_ERRO_EVNTO"));
            registroEvento.setDescricaoGravidade(rs.getString("ITPO_EVNTO_PNEL"));
            registroEvento.setNumeroTransacao(rs.getBigDecimal("QTRANS_EXECT_INSUC"));

            BigDecimal eventoDetalhe = rs.getBigDecimal("QEVNTO_NORML_FUNCL");

            if (eventoDetalhe != null && !eventoDetalhe.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_FUNCL"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_FUNCL")));
            }

            eventoDetalhe = rs.getBigDecimal("QEVNTO_NORML_DISPN");

            if (eventoDetalhe != null && !eventoDetalhe.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_DISPN"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_DISPN")));
            }

            eventoDetalhe = rs.getBigDecimal("QEVNTO_NORML_CNXAO");

            if (eventoDetalhe != null && !eventoDetalhe.equals(new BigDecimal(0))) {
                registroEvento.setCodigoGravidade(rs.getBigDecimal("CSIT_VOLUM"));
                registroEvento.setDataInicioEvento(Utils.javaDateFormatoBrasil(rs.getDate("DINIC_ERRO_VOLUM")));
            }

            registroEvento.setDuracao(Utils.formatoHoraMinutoSegundo(rs.getInt("QSEGDA_EVNTO")));
            registroEvento.setCodigoProduto(rs.getString("CPRODT_PNEL"));
            registroEvento.setCodigoCanal(rs.getString("CCANAL_DGTAL_PNEL"));
            registroEvento.setCodigoEmpresa(rs.getString("CEMPR_PNEL"));
            registroEvento.setMsgQtd(rs.getString("MSGS"));
            registroEvento.setDataProcessamento(rs.getString("DPROCS_APLIC"));
            String detalhe = rs.getString("ETAPA");
            if (detalhe != null) {
                registroEvento.setStatus(rs.getString("OSIT_ABERT_EVNTO"));
                registroEvento.setMainframe(rs.getString("MAINFRAME"));
                registroEvento.setQtdEventoUltimo30(rs.getString("QTD_30_DIAS"));
                registroEvento.setUrl(rs.getString("URL"));
                registroEvento.setEtapaEvento(rs.getString("ETAPA"));
                registroEvento.setApi(rs.getString("API"));
                registroEvento.setWebService(rs.getString("WEB_SERVICE"));
            }

            lista.add(registroEvento);

        } while (rs.next());

        return lista;
    }

}
