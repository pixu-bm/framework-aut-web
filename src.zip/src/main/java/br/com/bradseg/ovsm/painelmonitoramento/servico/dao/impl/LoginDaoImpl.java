package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.UsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe responsável por implementar busca base de dados informações relacionadas a login
 *
 * @author Wipro
 */
@Repository
public class LoginDaoImpl implements LoginDao {

    private static final Logger LOGGER = LogManager.getLogger(LoginDaoImpl.class);

    private static final int INT_3 = 3;
    public static final String USUAR = "USUAR ";
    public static final String WHERE_CUSUAR = " WHERE CUSUAR = ?  ";
    public static final String ERROR = "Error: ";
    public static final String CONSULTA_SEM_RESULTADO = "Consulta sem resultado";
    public static final String ERRO_INTERNO = "Erro interno.";
    private static final String ERRO_DADOS = "Erro de integridade dos dados.";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private static final String SELECT_LOGIN_COMPLETO = " SELECT COUNT(CUSUAR) FROM " + Constantes.OWNER_TABELA + USUAR
        + WHERE_CUSUAR;

    private static final String SELECT_LOGIN_USUARIO = " SELECT  CTPO_PRFIL FROM " + Constantes.OWNER_TABELA + USUAR
        + " WHERE CUSUAR = ? AND CSTTUS_CAD = 'APROV' ";

    private static final String SELECT_LOGIN_APROVADOR = " SELECT  COUNT(CTPO_PRFIL) FROM " + Constantes.OWNER_TABELA
        + USUAR
        + " WHERE CUSUAR = ? AND CSTTUS_CAD = 'APROV' AND CTPO_PRFIL = 'MSTER' OR CTPO_PRFIL = 'ADM' ";

    private static final String SELECT_INFORMACAO_USUARIO = " SELECT CUSUAR,NUSUAR,IUSUAR,CTPO_USUAR,"
        + "CSTTUS_CAD,AULT_STTUS_CAD, "
        + " CUSUAR_APROV_ACSSO,NFONE, "
        + " RENDER,AINCL,AULT_ATULZ,CTPO_PRFIL,CEMPR, "
        + " CDEPTO,REMAIL_CORP,QVIDEO_APRES "
        + " FROM " + Constantes.OWNER_TABELA + USUAR
        + " WHERE CUSUAR = ? ";

    private static final String INSERT_INTO = "INSERT INTO ";

    private static final String INSERIR_USUARIO_APROVACAO = INSERT_INTO + Constantes.OWNER_TABELA
        + "USUAR (NUSUAR, CUSUAR ,IUSUAR,CTPO_USUAR,CSTTUS_CAD,AULT_STTUS_CAD,CUSUAR_APROV_ACSSO,"
        + "NFONE ,RENDER ,CEMPR,"
        + "CDEPTO,REMAIL_CORP,QVIDEO_APRES,AINCL ) "
        + " VALUES   (?,?,?,'FNC','AGARD',SYSTIMESTAMP,' ',?,?,?,?,?,0,SYSTIMESTAMP) ";

    private static final String INSERIR_EMPRESA_USUARIO = INSERT_INTO + Constantes.OWNER_TABELA
        + "EMPR_USUAR (CEMPR, IEMPR)"
        + " VALUES   (?,?) ";

    private static final String INSERIR_DEPARTAMENTO_USUARIO = INSERT_INTO + Constantes.OWNER_TABELA
        + "DEPTO (CDEPTO, IDEPTO, AINCL, AULT_ATULZ, CEMPR)"
        + " VALUES   (?,?,SYSTIMESTAMP,SYSTIMESTAMP,?) ";

    private static final String SELECT_EMPRESA_USUARIO = " SELECT CEMPR , IEMPR FROM  "
        + Constantes.OWNER_TABELA
        + "EMPR_USUAR ";

    private static final String SELECT_DEPARTAMENTO_USUARIO = " SELECT CDEPTO , IDEPTO FROM "
        + Constantes.OWNER_TABELA
        + "DEPTO "
        + " WHERE CEMPR = ? ";

    private static final String SELECT_VALIDAR_EMPRESA_USUARIO = " SELECT COUNT(CEMPR) FROM  "
        + Constantes.OWNER_TABELA
        + "EMPR_USUAR "
        + " WHERE CEMPR = ? ";

    private static final String SELECT_VALIDAR_DEPARTAMENTO_USUARIO = " SELECT COUNT(CDEPTO) FROM  "
        + Constantes.OWNER_TABELA
        + "DEPTO "
        + " WHERE CDEPTO = ? ";

    private static final String SELECT_MAX_USUARIO = "SELECT MAX(NUSUAR) FROM " + Constantes.OWNER_TABELA + "USUAR";

    private static final String SELECT_LISTAR_USUARIO_MSTER_ADM = " SELECT CUSUAR , IUSUAR "
        + " FROM OVSM.USUAR "
        + " WHERE CSTTUS_CAD = 'APROV' "
        + " AND CTPO_PRFIL IN ('MSTER', 'ADM') ";

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public LoginDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public Boolean validarLogin(Usuario usuario) {
        Object[] params = new Object[] {
            usuario.getLogin().toUpperCase(),
        };

        return jdbcTemplate.queryForObject(SELECT_LOGIN_COMPLETO, Integer.class, params) == 0;
    }

    /**
     * Verificar se aquele usuario é existente na base de dados
     *
     * @param usuario Usuario
     * @return Boolean
     */
    public String obterTipoUsuario(Usuario usuario) {

        try {
            Object[] params = new Object[] {
                usuario.getLogin().toUpperCase()

            };

            return jdbcTemplate.queryForObject(SELECT_LOGIN_USUARIO, String.class, params);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException("Login inexistente na base de dados" +
                " ou usuário não aprovado ao acesso.", 1);
        }

    }

    /**
     * {@inheritDoc}
     */
    public Usuario obterInformacaoUsuario(Usuario usuario) throws SQLException {
        try {
            Object[] params = new Object[] {
                usuario.getLogin().toUpperCase()
            };

            return jdbcTemplate.queryForObject(SELECT_INFORMACAO_USUARIO, new UsuarioRowMapper(), params);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(CONSULTA_SEM_RESULTADO, 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public void inserirUsuarioAprovacao(Usuario usuario) throws SQLException {
        try {

            BigDecimal ultimoId = obterUltimoIdUsuario();
            ultimoId = new BigDecimal(ultimoId.intValue() + 1);
            usuario.setNumeroInternoUsuario(ultimoId);

            jdbcTemplate.update(INSERIR_USUARIO_APROVACAO, usuario.getNumeroInternoUsuario(),
                usuario.getLogin().toUpperCase(),
                usuario.getNome(),
                usuario.getTelefone(),
                usuario.getEndereco(),
                usuario.getNomeEmpresa().toUpperCase().substring(0, INT_3),
                usuario.getNomeDepartamento().toUpperCase().substring(0, INT_3),
                usuario.getEmail());

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    public void inserirEmpresaUsuario(Usuario usuario) throws SQLException {
        try {

            if (Boolean.FALSE
                .equals(validarEmpresaUsuario(usuario.getNomeEmpresa().toUpperCase().substring(0, INT_3)))) {

                jdbcTemplate.update(INSERIR_EMPRESA_USUARIO,
                    usuario.getNomeEmpresa().toUpperCase().substring(0, INT_3),
                    usuario.getNomeEmpresa().toUpperCase());
            }

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    public void inserirDepartamentoUsuario(Usuario usuario) throws SQLException {
        try {
            if (Boolean.FALSE
                .equals(validarDepartamentoUsuario(usuario.getNomeDepartamento().toUpperCase().substring(0, INT_3)))) {

                jdbcTemplate.update(INSERIR_DEPARTAMENTO_USUARIO,
                    usuario.getNomeDepartamento().toUpperCase().substring(0, INT_3),
                    usuario.getNomeDepartamento().toUpperCase(),
                    usuario.getNomeEmpresa().toUpperCase().substring(0, INT_3));
            }

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public List<EmpresaUsuario> listarEmpresaUsuario() throws SQLException {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_EMPRESA_USUARIO);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(CONSULTA_SEM_RESULTADO, 1);
            }

            List<EmpresaUsuario> listaEmpresaUsuario = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);

                EmpresaUsuario empresa = new EmpresaUsuario();
                empresa.setCodigoEmpresa((String) mapa.get("CEMPR"));
                empresa.setDescricaoEmpresa((String) mapa.get("IEMPR"));

                listaEmpresaUsuario.add(empresa);

            }

            return listaEmpresaUsuario;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<DepartamentoUsuario> listarDepartamentoUsuario(String codigoEmpresa) throws SQLException {

        try {
            Object[] params = new Object[] {
                codigoEmpresa.toUpperCase()
            };

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_DEPARTAMENTO_USUARIO, params);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Sem departamento para codigo empresa", 1);
            }

            List<DepartamentoUsuario> listaDepartamentoUsuario = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);

                DepartamentoUsuario departamentoUsuario = new DepartamentoUsuario();
                departamentoUsuario.setCodigoDepartamento((String) mapa.get("CDEPTO"));
                departamentoUsuario.setDescricaoDepartamento((String) mapa.get("IDEPTO"));

                listaDepartamentoUsuario.add(departamentoUsuario);

            }

            return listaDepartamentoUsuario;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Boolean validarEmpresaUsuario(String codigoEmpresa) throws SQLException {
        try {
            Object[] params = new Object[] {
                codigoEmpresa.toUpperCase()
            };

            StringBuilder sql = new StringBuilder(SELECT_VALIDAR_EMPRESA_USUARIO);

            return jdbcTemplate.queryForObject(sql.toString(), Integer.class, params) > 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Boolean validarDepartamentoUsuario(String codigoDepartamento) throws SQLException {
        try {
            Object[] params = new Object[] {
                codigoDepartamento.toUpperCase().substring(0, INT_3)
            };

            StringBuilder sql = new StringBuilder(SELECT_VALIDAR_DEPARTAMENTO_USUARIO);

            return jdbcTemplate.queryForObject(sql.toString(), Integer.class, params) > 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Boolean validarLoginAprovador(Usuario usuario) {
        try {
            Object[] params = new Object[] {
                usuario.getLoginAprovador()
            };

            StringBuilder sql = new StringBuilder(SELECT_LOGIN_APROVADOR);

            return jdbcTemplate.queryForObject(sql.toString(), Integer.class, params) > 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * Obtem o ultimo id de usuario
     *
     * @return BigDecimal
     * @throws SQLException
     */
    private BigDecimal obterUltimoIdUsuario() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_USUARIO, BigDecimal.class);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<Usuario> obterInformacaoUsuariosMasterAdm() throws SQLException {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_LISTAR_USUARIO_MSTER_ADM);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(CONSULTA_SEM_RESULTADO, 1);
            }

            List<Usuario> listaUsuario = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);

                Usuario usuario = new Usuario();
                usuario.setLogin((String) mapa.get("CUSUAR"));
                usuario.setNome((String) mapa.get("IUSUAR"));

                listaUsuario.add(usuario);
            }

            return listaUsuario;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
