package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiCaptalizacaoDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Repository
public class ConsultaApiCaptalizacaoDaoImpl implements ConsultaApiCaptalizacaoDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiCaptalizacaoDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";

    private static final String INSERIR_CONSULTA_CAP = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_CAPTZ(CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String VALIDAR_REGISTROS_DUPLICADOS = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_CAPTZ A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_CAPTZ B "
        + "WHERE A.RTRANS_ORIGN = B.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = B.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(B.IAPI_ORIGN, NULL, '1')"
        + "AND B.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String LIBERAR_PROCESSAMENTO = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_CAPTZ "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' ";

    private static final String SELECT_MAX_REGISTRO = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_CAPTZ "
        + "WHERE IPRODT_ORIGN = 'CAPITALIZACAO' ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaApiCaptalizacaoDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void inserirConsultaApi(List<TabelaTemp> listaCapitalizacaoTemp) throws SQLException {

        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaCapitalizacaoTemp.size());

            for (TabelaTemp capTemp : listaCapitalizacaoTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", capTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", capTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", capTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", capTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", capTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", capTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", capTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", capTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", capTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", capTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", capTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", capTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", capTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", capTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", capTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", capTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", capTemp.getDinicErro())
                        .addValue("DFIM_ERRO", capTemp.getDfimErro())
                        .addValue("DINCL_REG", capTemp.getDinclReg())
                        .addValue("DALT_REG", capTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_CAP,
                batchValues.toArray(new Map[listaCapitalizacaoTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void validarDuplicados(Collection<?> listaCapitalizacaoTemp) {

        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaCapitalizacaoTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS,
                batchValues.toArray(new Map[listaCapitalizacaoTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void liberarProcessamento(Collection<?> listaCapitalizacaoTemp) {

        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaCapitalizacaoTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO,
                batchValues.toArray(new Map[listaCapitalizacaoTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional
    public String obterultimoregistroinserido() {

        try {

            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }
}
