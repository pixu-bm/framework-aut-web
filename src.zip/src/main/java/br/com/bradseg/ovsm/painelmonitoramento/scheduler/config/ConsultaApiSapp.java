package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiSappDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

@Component
public class ConsultaApiSapp {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiSapp.class);

    private static final int MAXIMO_CARACTERS = INT_100;
    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "SAPP";
    public static final int INTERVALO_VIAGEM = 15;

    @Autowired
    private ConsultaApiSappDao consultaApiSappDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "SHOPPING SEGUROS", "ATM"};

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;


    private String validaProposta = "/V2/VPRS-RecuperaQtdModProd/service/ModuloWebService";

    private String[] metodosApi = {validaProposta};

    public ConsultaApiSapp(
      ConsultaApiSappDao consultaApiSappDao) {
        this.consultaApiSappDao = consultaApiSappDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerSapp = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerSapp);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualSapp = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterSapp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualSapp.format(formatterSapp);
            LocalDateTime dataHoraAtualSapp = LocalDateTime.parse(agoraFormatado, formatterSapp);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiSappDao.obterultimoregistroinseridoSapp();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterSapp);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualSapp, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + validaProposta);
                HttpURLConnection connectionSapp = (HttpURLConnection) url.openConnection();
                connectionSapp.setRequestMethod("POST");
                connectionSapp.setRequestProperty("Content-Type", "application/json");
                connectionSapp.setDoOutput(true);
                connectionSapp.setInstanceFollowRedirects(false);
                connectionSapp.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{}";

                try (OutputStream os = connectionSapp.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaSappTemp = new LinkedList<>();

                validarConexaoSappTemp(dataHoraAtualSapp, connectionSapp, canal,
                    enderecoApi + validaProposta,
                    listaSappTemp, enderecoApi + validaProposta);

                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanalSapp = (HttpURLConnection) urlapi.openConnection();
                    connectionCanalSapp.setRequestMethod("POST");
                    connectionCanalSapp.setRequestProperty("Content-Type", "application/json");
                    connectionCanalSapp.setDoOutput(true);
                    connectionCanalSapp.setInstanceFollowRedirects(false);
                    connectionCanalSapp.addRequestProperty("Authorization", authorization);

                    try (OutputStream os = connectionCanalSapp.getOutputStream()) {
                      byte[] inputCanal = jsonRequest.getBytes(StandardCharsets.UTF_8);
                        os.write(inputCanal, 0, inputCanal.length);
                    }

                    validarConexaoSappTempApi(dataHoraAtualSapp, connectionCanalSapp,
                        canal, null, listaSappTemp);
                }

                if (minutos >= INTERVALO_VIAGEM) {

                    consultaApiSappDao.inserirConsultaApiSapp(listaSappTemp);

                    consultaApiSappDao.validarDuplicadosSapp(listaSappTemp);

                    consultaApiSappDao.liberarProcessamentoSapp(listaSappTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoSappTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaSappTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaSappTemp
                .addLast(obterSappNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {

            listaSappTemp.addLast(obterSappOk(canal, enderecoApi, metodosApi, dataHoraAtual));
        }
    }

    private void validarConexaoSappTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaSappTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaSappTemp.addLast(obterSappNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            listaSappTemp.addLast(obterSappOk(canal, null, metodosApi, dataHoraAtual));
        }
    }

    public TabelaTemp obterSappNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        TabelaTemp sappTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        sappTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        sappTemp.setCindRegProcs("J");
        // Codigo de retorno
        sappTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        sappTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        sappTemp.setRenderUrlOrign(enderecoApi);
        sappTemp.setRservcOrign(null);
        sappTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            sappTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            sappTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            sappTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            sappTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            sappTemp.setIapiOrign(enderecoApi);
            sappTemp.setIetapaOfert(enderecoApi);
        }

        sappTemp.setIcanalOrign(canal);
        sappTemp.setIemprOrign("BVP");
        sappTemp.setIprodtOrign(PRODUTO);
        sappTemp.setIsprodOrign(null);

        sappTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        sappTemp.setIsitEvnto("NOK");
        sappTemp.setDinicErro(dataHoraAtual);
        sappTemp.setDfimErro(null);
        sappTemp.setDinclReg(dataHoraAtual);
        sappTemp.setDaltReg(null);

        return sappTemp;
    }

    public TabelaTemp obterSappOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp sappTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        sappTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        sappTempOk.setCindRegProcs("J");
        // Codigo de retorno
        sappTempOk.setCerroOrign("200");
        sappTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        sappTempOk.setRenderUrlOrign(enderecoApi);
        sappTempOk.setRservcOrign(null);
        sappTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            sappTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            sappTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            sappTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            sappTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            sappTempOk.setIapiOrign(enderecoApi);
            sappTempOk.setIetapaOfert(enderecoApi);
        }

        sappTempOk.setIcanalOrign(canal);
        sappTempOk.setIemprOrign("BVP");
        sappTempOk.setIprodtOrign(PRODUTO);
        sappTempOk.setIsprodOrign(null);

        sappTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        sappTempOk.setIsitEvnto("OK");
        sappTempOk.setDinicErro(dataHoraAtual);
        sappTempOk.setDfimErro(null);
        sappTempOk.setDinclReg(dataHoraAtual);
        sappTempOk.setDaltReg(null);

        return sappTempOk;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
