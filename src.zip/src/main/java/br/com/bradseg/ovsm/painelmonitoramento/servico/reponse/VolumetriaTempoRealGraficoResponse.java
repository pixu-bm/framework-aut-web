package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;

/**
 * Classe que implementa volumetria de tempo real grafico trafego objeto
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealGraficoResponse extends ResponseMensagem {

    private List<VolumetriaTempoReal> volumetriaTempoReal;
    private VolumetriaTempoRealVolumetriaMaxima volumetriaTempoRealVolumetriaMaxima;

    public VolumetriaTempoRealGraficoResponse() {
        super();
    }

    public List<VolumetriaTempoReal> getVolumetriaTempoReal() {
        return Collections.unmodifiableList(volumetriaTempoReal);
    }

    public void setVolumetriaTempoReal(List<VolumetriaTempoReal> volumetriaTempoReal) {
        this.volumetriaTempoReal = 
            Collections.unmodifiableList(volumetriaTempoReal);
    }

    public VolumetriaTempoRealVolumetriaMaxima getVolumetriaTempoRealVolumetriaMaxima() {
        return volumetriaTempoRealVolumetriaMaxima;
    }

    public void setVolumetriaTempoRealVolumetriaMaxima(
        VolumetriaTempoRealVolumetriaMaxima volumetriaTempoRealVolumetriaMaxima) {
        this.volumetriaTempoRealVolumetriaMaxima = volumetriaTempoRealVolumetriaMaxima;
    }

}
