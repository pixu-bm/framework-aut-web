package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Volumetria tempo real mapa objetos extração de base de dados.
 *
 * @author Wipro
 */
public class RelacionadosDetalheEventoRowMapper implements RowMapper<List<RelaciondosDetalheEvento>> {

    @Override
    public List<RelaciondosDetalheEvento> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<RelaciondosDetalheEvento> lista = new ArrayList<>();

        do {
            RelaciondosDetalheEvento relacionados = new RelaciondosDetalheEvento();

            relacionados.setProduto(rs.getString("PRODUTO"));
            relacionados.setCanal(rs.getString("CANAL"));
            relacionados.setTipo(rs.getString("TIPO"));
            relacionados.setDuracao(Utils.converteHoraMinutoSegundoBig(rs.getString("DURACAO")));
            relacionados.setQtd(rs.getBigDecimal("QTD"));
            relacionados.setCod(rs.getBigDecimal("CODIGO"));
            relacionados.setLinha(rs.getBigDecimal("RNUM"));

            lista.add(relacionados);
        } while (rs.next());

        return lista;
    }

}
