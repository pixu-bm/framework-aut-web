package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EmpresaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Repository
public class EmpresaDaoImpl implements EmpresaDao {

    private static final Logger LOGGER = LogManager.getLogger(EmpresaDaoImpl.class);

    private static final String SELECT_EMPRESA = "SELECT CEMPR_PNEL, IEMPR_PNEL FROM "
        + Constantes.OWNER_TABELA + "EMPR_PNEL";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public EmpresaDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Empresa> listarEmpresa() {
        try {
            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_EMPRESA, new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado não pode ser vazio", 1);
            }

            List<Empresa> listaEmpresa = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Empresa empresa = new Empresa();
                empresa.setCodigo((BigDecimal) mapa.get("CEMPR_PNEL"));
                empresa.setDescricao((String) mapa.get("IEMPR_PNEL"));

                listaEmpresa.add(empresa);
            }

            return listaEmpresa;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }
}
