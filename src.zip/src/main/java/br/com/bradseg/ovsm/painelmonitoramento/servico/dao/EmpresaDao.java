package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;

public interface EmpresaDao {

    /**
     * Listar Empresa
     * 
     * @return
     */
    List<Empresa> listarEmpresa();
}
