package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;

public interface ConsultaHistoricaDao {

    List<ConsultaHistorica> obterHistorico(List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, Integer freqMin, Integer freqMax, String duracaoMin, String duracaoMax,
        Integer transacaoMin,
        Integer transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException;

}
