package br.com.bradseg.ovsm.painelmonitoramento.servico.exception;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
@RestController
public class ServiceExcecao extends ResponseEntityExceptionHandler {

    /**
     * Construtor primário.
     * 
     * @param code
     *            String - Código do tipo de erro
     * @param e
     *            Throwable - Tipo de exceção geral não checada
     */
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ResponseMensagem> handleNotFoundException(ResponseStatusException ex, WebRequest request) {
        String[] mensagem = ex.getReason().split(";");
        ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
        mensagemIllegalArgumentException.setCodigoRetorno(Integer.parseInt(mensagem[1]));
        mensagemIllegalArgumentException.setMensagem(mensagem[0]);
        return new ResponseEntity<>(mensagemIllegalArgumentException, ex.getStatus());
    }
}
