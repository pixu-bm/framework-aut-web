package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

public class Produto {

    private BigDecimal codigo;
    private String descricao;

    public Produto() {
        super();
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getCodigo() {
        return codigo;
    }

    public void setCodigo(BigDecimal codigo) {
        this.codigo = codigo;
    }
}
