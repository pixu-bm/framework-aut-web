package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;

/**
 * Classe para representar os valores utilizados na devolução de informações ao
 * usuário.
 * 
 * @author Wipro
 */
public class CentralAcessoUsuarioResponse {

    private String login;
    private String nome;
    private String nomeEmpresa;
    private String departamento;
    private String dataSolicitacao;
    private String perfil;
    private String status;

    public CentralAcessoUsuarioResponse() {
        super();
    }

    public CentralAcessoUsuarioResponse(Usuario usuario) {
        this.login = usuario.getLogin();
        this.nome = usuario.getNome();
        this.nomeEmpresa = usuario.getNomeEmpresa();
        this.dataSolicitacao = usuario.getDataSolicitacaoFmt();
        this.perfil = usuario.getPerfil();
        this.status = usuario.getStatus();
        this.departamento = usuario.getNomeDepartamento();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeEmpresa() {
        return nomeEmpresa;
    }

    public void setNomeEmpresa(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getDataSolicitacao() {
        return dataSolicitacao;
    }

    public void setDataSolicitacao(String dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
