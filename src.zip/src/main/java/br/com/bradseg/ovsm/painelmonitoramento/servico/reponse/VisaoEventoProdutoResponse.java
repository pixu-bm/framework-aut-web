package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;

/**
 * Visao evento produto response.
 * 
 * @author Wipro
 */
public class VisaoEventoProdutoResponse extends ResponseMensagem {

    private List<VisaoEventoProduto> visaoEventoProduto;

    public VisaoEventoProdutoResponse() {
        super();
    }

    public List<VisaoEventoProduto> getVisaoEventoProduto() {
        return Collections.unmodifiableList(visaoEventoProduto);
    }

    public void setVisaoEventoProduto(List<VisaoEventoProduto> visaoEventoProduto) {
        this.visaoEventoProduto = 
            Collections.unmodifiableList(visaoEventoProduto);
    }

}
