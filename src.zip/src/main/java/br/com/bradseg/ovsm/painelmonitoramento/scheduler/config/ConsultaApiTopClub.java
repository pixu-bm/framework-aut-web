package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiTopClubDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

@Component
public class ConsultaApiTopClub {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiTopClub.class);


    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    private static final int MAXIMO_CARACTERS = INT_100;
    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "VIDA";
    public static final int INTERVALO_TOPCLUB = 15;


    @Autowired
    private ConsultaApiTopClubDao consultaApiTopClubDao;

    private String[] canais = {"MOBILE BANKING", "NEXT"};

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;


    private String sucursais = "/V2/be-ovsm/vendas-mas/api/v1/vendas/comum/sucursais";

    private String[] metodosApi = {sucursais};

    public ConsultaApiTopClub(
        ConsultaApiTopClubDao consultaApiTopClubDao) {
        this.consultaApiTopClubDao = consultaApiTopClubDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerTopClub = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
              tokendatapowerTopClub);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualTopClub = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterTopClub = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualTopClub.format(formatterTopClub);
            LocalDateTime dataHoraAtualTopClub = LocalDateTime.parse(agoraFormatado, formatterTopClub);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiTopClubDao.obterultimoregistroinseridoTopClub();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterTopClub);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualTopClub, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + sucursais);
                HttpURLConnection connectionTopClub = (HttpURLConnection) url.openConnection();
                connectionTopClub.setRequestMethod("GET");
                connectionTopClub.setRequestProperty("Content-Type", "application/json");
                connectionTopClub.setDoOutput(true);
                connectionTopClub.setInstanceFollowRedirects(false);
                connectionTopClub.addRequestProperty("Authorization", authorization);

                LinkedList<TabelaTemp> listaTopClubTemp = new LinkedList<>();

                validarConexaoTopClubTemp(dataHoraAtualTopClub, connectionTopClub, canal,
                    enderecoApi + sucursais,
                    listaTopClubTemp, enderecoApi + sucursais);

                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanalTopClub = (HttpURLConnection) urlapi.openConnection();
                    connectionCanalTopClub.setRequestMethod("GET");
                    connectionCanalTopClub.setRequestProperty("Content-Type", "application/json");
                    connectionCanalTopClub.setDoOutput(true);
                    connectionCanalTopClub.setInstanceFollowRedirects(false);
                    connectionCanalTopClub.addRequestProperty("Authorization", authorization);

                    validarConexaoTopClubTempApi(dataHoraAtualTopClub, connectionCanalTopClub,
                        canal, null, listaTopClubTemp);

                }

                if (minutos >= INTERVALO_TOPCLUB) {

                    consultaApiTopClubDao.inserirConsultaApiTopClub(listaTopClubTemp);

                    consultaApiTopClubDao.validarDuplicadosTopClub(listaTopClubTemp);

                    consultaApiTopClubDao.liberarProcessamentoTopClub(listaTopClubTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoTopClubTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaTopClubTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaTopClubTemp
                .addLast(obterViagemNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {

            listaTopClubTemp.addLast(obterViagemOk(canal, enderecoApi, metodosApi, dataHoraAtual));
        }
    }

    private void validarConexaoTopClubTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaTopClubTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaTopClubTemp.addLast(obterViagemNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            listaTopClubTemp.addLast(obterViagemOk(canal, null, metodosApi, dataHoraAtual));
        }
    }

    public TabelaTemp obterViagemNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        TabelaTemp topClubTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        topClubTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        topClubTemp.setCindRegProcs("J");
        // Codigo de retorno
        topClubTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        topClubTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        topClubTemp.setRenderUrlOrign(enderecoApi);
        topClubTemp.setRservcOrign(null);
        topClubTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            topClubTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            topClubTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            topClubTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            topClubTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            topClubTemp.setIapiOrign(enderecoApi);
            topClubTemp.setIetapaOfert(enderecoApi);
        }

        topClubTemp.setIcanalOrign(canal);
        topClubTemp.setIemprOrign("BVP");
        topClubTemp.setIprodtOrign(PRODUTO);
        topClubTemp.setIsprodOrign(null);

        topClubTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        topClubTemp.setIsitEvnto("NOK");
        topClubTemp.setDinicErro(dataHoraAtual);
        topClubTemp.setDfimErro(null);
        topClubTemp.setDinclReg(dataHoraAtual);
        topClubTemp.setDaltReg(null);

        return topClubTemp;
    }

    public TabelaTemp obterViagemOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp topClubTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        topClubTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        topClubTempOk.setCindRegProcs("J");
        // Codigo de retorno
        topClubTempOk.setCerroOrign("200");
        topClubTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        topClubTempOk.setRenderUrlOrign(enderecoApi);
        topClubTempOk.setRservcOrign(null);
        topClubTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            topClubTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            topClubTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            topClubTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            topClubTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            topClubTempOk.setIapiOrign(enderecoApi);
            topClubTempOk.setIetapaOfert(enderecoApi);
        }

        topClubTempOk.setIcanalOrign(canal);
        topClubTempOk.setIemprOrign("BVP");
        topClubTempOk.setIprodtOrign(PRODUTO);
        topClubTempOk.setIsprodOrign(null);

        topClubTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        topClubTempOk.setIsitEvnto("OK");
        topClubTempOk.setDinicErro(dataHoraAtual);
        topClubTempOk.setDfimErro(null);
        topClubTempOk.setDinclReg(dataHoraAtual);
        topClubTempOk.setDaltReg(null);

        return topClubTempOk;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
