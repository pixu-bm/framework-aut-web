/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ComboRankingEventosResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.DetalhamentoTransacaoEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.IndicadoresNegocioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VolumetriaTempoRealGraficoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VolumetriaVisaoNegocioTabelaResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.IndicadorNegocioService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/service/indicadores")
public class IndicadorNegocioController {

    private static final Logger LOGGER = LogManager.getLogger(IndicadorNegocioController.class);

    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final String INLINE_FILENAME_INDICADOR_XLSX = "inline;filename=\"indicadorNegocio.xlsx\"";
    public static final String INLINE_FILENAME_INDICADOR_PDF = "inline;filename=\"indicadorNegocio.pdf\"";
    public static final String INLINE_FILENAME_INDICADOR_CSV = "inline;filename=\"indicadorNegocio.csv\"";
    public static final String MSG_NENHUM_DADO_ENCONTRADO = "Não foram encontrados dados para a pesquisa";

    @Autowired
    private IndicadorNegocioService indicadorNegocioService;

    /**
     * Retonar a visão geral de eventos para posicionamento do painel atual.
     *
     * @param periodoVisaoEvento Integer
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVolumetriaTempoRealGraficoIndicador")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVolumetriaTempoRealGrafico(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodo") Integer periodo,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "dataInicio", required = false) String dataInicio,
        @RequestParam(name = "dataFim", required = false) String dataFim) {

        try {
            indicadorNegocioService.validarParametro(periodo);
            VolumetriaTempoRealGraficoResponse response = new VolumetriaTempoRealGraficoResponse();

            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setVolumetriaTempoRealVolumetriaMaxima(indicadorNegocioService
                .obterVolumetriaTempoRealVolumetriaMaxima(periodo,
                    listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim));
            response.setVolumetriaTempoReal(indicadorNegocioService
                .obterVolumetriaTempoRealFaixaTempo(periodo,
                    listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim));

            return ResponseEntity.ok(response);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQLExcGrafico = new ResponseMensagem();
            mensagemSQLExcGrafico.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLExcGrafico.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLExcGrafico.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentExceptionGrafico = new ResponseMensagem();
            mensagemIllegalArgumentExceptionGrafico.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentExceptionGrafico.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentExceptionGrafico.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        }
    }

    @GetMapping("/obterVisaoNegocios")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoNegocios(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodoVisaoEvento") Integer periodoVisaoEvento,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "dataInicio") String dataInicio,
        @RequestParam(value = "dataFim") String dataFim) {
        try {

            indicadorNegocioService.validarParametro(periodoVisaoEvento);
            indicadorNegocioService.validarParametrosDatas(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            VolumetriaVisaoNegocioTabelaResponse response = new VolumetriaVisaoNegocioTabelaResponse();
            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setListaVolumetriaVisaoNegocio(indicadorNegocioService
                .obterVolumetriaVisaoNegocio(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, dataInicioDate, dataFimDate));

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemVisaoEvento = new ResponseMensagem();
            mensagemVisaoEvento.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemVisaoEvento.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemVisaoEvento.getMensagem() + ";" + CODIGO_RETORNO_1);

        } catch (AcessoADadosException eAcesso) {
            ResponseMensagem retornoEAcessoVisao = new ResponseMensagem();
            retornoEAcessoVisao.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoEAcessoVisao.setMensagem(eAcesso.getMessage());
            LOGGER.error(eAcesso);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoEAcessoVisao.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2, eAcesso);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemVisaoEventoEmpty = new ResponseMensagem();
            mensagemVisaoEventoEmpty.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemVisaoEventoEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemVisaoEventoEmpty.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                e);
        }
    }

    @GetMapping("/obterIndicadoresNegocio")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterIndicadoresNegocio(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(name = "listaCodigoProduto",
                required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "dataInicio", required = false) String dataInicio,
        @RequestParam(value = "dataFim", required = false) String dataFim) throws SQLException {
        try {

            // definir qual será o retorno
            IndicadoresNegocioResponse response = new IndicadoresNegocioResponse();
            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setIndicadoresNegocio(indicadorNegocioService
                .obterIndicadoresNegocio(listaCodigoProduto, listaCodigoCanal,
                    dataInicio, dataFim));

            return ResponseEntity.ok(response);
        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmpty = new ResponseMensagem();
            mensagemEmpty.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmpty.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                e);
        } catch (AcessoADadosException eAcesso) {
            ResponseMensagem retornoEAcesso = new ResponseMensagem();
            retornoEAcesso.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoEAcesso.setMensagem(eAcesso.getMessage());
            LOGGER.error(eAcesso);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoEAcesso.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2, eAcesso);

        }
    }

    @GetMapping("/obterRankingEventos")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterRankingEventos(
        @Parameter(description = "Codigo Pesquisa: "
            + "1 = Por Duracao, 2 = Impacto, 3 = Recorrencia") @RequestParam(
                name = "codigoPesquisa") Integer codigoPesquisa,
        @RequestParam(value = "dataInicio") String dataInicio,
        @RequestParam(value = "dataFim") String dataFim) {
        try {

            indicadorNegocioService.validarParametroRanking(codigoPesquisa);
            indicadorNegocioService.validarParametrosDatas(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            ComboRankingEventosResponse comboRankingEventosResponse = new ComboRankingEventosResponse();
            comboRankingEventosResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            comboRankingEventosResponse.setMensagem(SUCESSO);
            comboRankingEventosResponse
                .setListaComboRankingEventos(indicadorNegocioService.obterRankingEventos(codigoPesquisa,
                    dataInicioDate, dataFimDate));

            return ResponseEntity.ok(comboRankingEventosResponse);
        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemRank = new ResponseMensagem();
            mensagemRank.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemRank.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemRank.getMensagem() + ";" + CODIGO_RETORNO_1);

        } catch (AcessoADadosException eAcesso) {
            ResponseMensagem retornoEAcessoRank = new ResponseMensagem();
            retornoEAcessoRank.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoEAcessoRank.setMensagem(eAcesso.getMessage());
            LOGGER.error(eAcesso);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoEAcessoRank.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2, eAcesso);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemRank = new ResponseMensagem();
            mensagemRank.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemRank.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemRank.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                e);
        }
    }

    @GetMapping("/obterDetalhamentoTransacaoEvento")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterDetalhamentoTransacaoEvento(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodo") Integer periodo,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "dataInicio", required = false) String dataInicio,
        @RequestParam(name = "dataFim", required = false) String dataFim) {

        try {
            indicadorNegocioService.validarParametro(periodo);
            DetalhamentoTransacaoEventoResponse response = new DetalhamentoTransacaoEventoResponse();

            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setNumeroTransacao(indicadorNegocioService.obterNumeroTransacao(periodo,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim));
            response.setEventoPorCanal(indicadorNegocioService.obterEventoPorCanal(periodo,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim));
            response.setTipoEvento(indicadorNegocioService.obterTipoEvento(periodo,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim));

            return ResponseEntity.ok(response);

        } catch (SQLException e) {
            ResponseMensagem mensagemDetalhe = new ResponseMensagem();
            mensagemDetalhe.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemDetalhe.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemDetalhe.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentExceptionDetalhe = new ResponseMensagem();
            mensagemIllegalArgumentExceptionDetalhe.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentExceptionDetalhe.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentExceptionDetalhe.getMensagem() + ";" + CODIGO_RETORNO_1, e);
        }
    }

    @GetMapping("/indicadorNegocioExcelCsv")
    @Operation(summary = "Obtem Excel ou Csv.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno"),
        @ApiResponse(responseCode = "404", description = "Nenhum registro encontrado")})
    public ResponseEntity<StreamingResponseBody> obterExcelCsv(
        @Parameter(description = "Periodo, "
            + "1 = dia, 2 = semana, 3 = mes") @RequestParam(
                name = "periodo", required = true) Integer periodo,
        @Parameter(description = "Tipo de relatório, "
            + "1 = Monitor + Visão de Negócios, 2 = Indicadores de Negócio, 3 = Ranking de Negócio") @RequestParam(
                name = "tipoRelatorio") Integer tipoRelatorio,
        @Parameter(description = "Tipo arquivo, "
            + "1 = Excel, 2 = CSv", required = true) @RequestParam(
                name = "tipoArquivo") Integer tipoArquivo,
        @Parameter(description = "Código da Pesquisa, necessário para o relatório Ranking de Negócio, "
            + "99 = quando não relatório de ranking, 1 = Por Duracao, 2 = Impacto, 3 = Recorrencia") @RequestParam(
                name = "codigoPesquisa") Integer codigoPesquisa,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "dataInicio") String dataInicio,
        @RequestParam(name = "dataFim") String dataFim,
        @RequestParam(name = "login", required = true) String login) {

        try {
            Workbook wb = indicadorNegocioService
                .gerarExcelCsv(periodo, tipoRelatorio, codigoPesquisa, listaCodigoProduto,
                    listaCodigoCanal, dataInicio, dataFim, login);
            if (tipoArquivo == 1) {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_INDICADOR_XLSX)
                    .body(wb::write);
            } else {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_INDICADOR_CSV)
                    .body(wb::write);
            }

        } catch (SQLException e) {
            ResponseMensagem msg = new ResponseMensagem();
            msg.setCodigoRetorno(CODIGO_RETORNO_2);
            msg.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                msg.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem msgIllegalArgumentException = new ResponseMensagem();
            msgIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            msgIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                msgIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem msgEmptyResultDataAccessException = new ResponseMensagem();
            msgEmptyResultDataAccessException.setCodigoRetorno(CODIGO_RETORNO_1);
            msgEmptyResultDataAccessException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, MSG_NENHUM_DADO_ENCONTRADO);
        }
    }

    @GetMapping("/indicadorNegocioPdf")
    @Operation(summary = "Obtem Pdf.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno"),
        @ApiResponse(responseCode = "404", description = "Nenhum registro encontrado")})
    public ResponseEntity<InputStreamResource> obterPdf(
        @Parameter(description = "Periodo, "
            + "1 = dia, 2 = semana, 3 = mes") @RequestParam(
                name = "periodo", required = true) Integer periodo,
        @Parameter(description = "Tipo de relatório, "
            + "1 = Monitor + Visão de Negócios, 2 = Indicadores de Negócio, 3 = Ranking de Negócio") @RequestParam(
                name = "tipoRelatorio") Integer tipoRelatorio,
        @Parameter(description = "Código da Pesquisa, necessário para o relatório Ranking de Negócio, "
            + "0 = quando não relatório de ranking, 1 = Por Duracao, 2 = Impacto, 3 = Recorrencia") @RequestParam(
                name = "codigoPesquisa") Integer codigoPesquisa,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "dataInicio") String dataInicio,
        @RequestParam(name = "dataFim") String dataFim,
        @RequestParam(name = "login", required = true) String login) {

        try {
            ByteArrayInputStream doc = indicadorNegocioService
                .exportarPdf(periodo, tipoRelatorio, codigoPesquisa, listaCodigoProduto,
                    listaCodigoCanal, dataInicio, dataFim, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_INDICADOR_PDF)
                .body(new InputStreamResource(doc));

        } catch (SQLException eobterPdf) {
            ResponseMensagem msgobterPdf = new ResponseMensagem();
            msgobterPdf.setCodigoRetorno(CODIGO_RETORNO_2);
            msgobterPdf.setMensagem(eobterPdf.getMessage());
            LOGGER.error(eobterPdf);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                msgobterPdf.getMensagem() + ";" + CODIGO_RETORNO_2, eobterPdf);

        } catch (IllegalArgumentException eobterPdf) {
            ResponseMensagem msgIllegalArgumentExceptionobterPdf = new ResponseMensagem();
            msgIllegalArgumentExceptionobterPdf.setCodigoRetorno(CODIGO_RETORNO_1);
            msgIllegalArgumentExceptionobterPdf.setMensagem(eobterPdf.getMessage());
            LOGGER.error(eobterPdf);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                msgIllegalArgumentExceptionobterPdf.getMensagem() + ";" + CODIGO_RETORNO_1, eobterPdf);

        } catch (EmptyResultDataAccessException eobterPdf) {
            ResponseMensagem msgEmptyResultDataAccessExceptionobterPdf = new ResponseMensagem();
            msgEmptyResultDataAccessExceptionobterPdf.setCodigoRetorno(CODIGO_RETORNO_1);
            msgEmptyResultDataAccessExceptionobterPdf.setMensagem(eobterPdf.getMessage());
            LOGGER.error(eobterPdf);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, MSG_NENHUM_DADO_ENCONTRADO);
        }
    }
}
