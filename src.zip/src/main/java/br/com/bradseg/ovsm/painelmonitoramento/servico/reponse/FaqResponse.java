package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

/**
 * Evento response.
 * 
 * @author Wipro
 */
public class FaqResponse extends ResponseMensagem {

    private List<Faq> listaFaq = new ArrayList<>();

    public FaqResponse() {
        super();
    }

    public List<Faq> getListaFaq() {
        return Collections.unmodifiableList(listaFaq);
    }

    public void setListaFaq(List<Faq> listaFaq) {
        this.listaFaq = Collections.unmodifiableList(listaFaq);
    }

}
