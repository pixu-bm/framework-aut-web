/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Configuração intervalo processamento classe
 * 
 * @author Wipro
 */
public class ConfiguracaoIntervaloProcessamento {

    private BigDecimal numeroInternoConfiguracaoIntervalo;
    private String login;
    private BigDecimal codigoEmpresa;
    private Date dataVigenciaFinal;
    private Integer quantidadeMinutoIntervaloNormal;
    private Integer quantidadeMinutoIntervaloErro;
    private BigDecimal codigoProduto;
    private Date dataVigenciaInicio;
    private BigDecimal codigoCanal;

    /**
     * Construtor
     */
    public ConfiguracaoIntervaloProcessamento() {
        super();
    }

    /**
     * Construtor configuracaoIntervaloProcessamentoRequest
     * 
     * @param configuracaoIntervaloProcessamentoRequest ConfiguracaoIntervaloProcessamentoRequest
     */
    public ConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest) {
        super();
        this.login = configuracaoIntervaloProcessamentoRequest.getLogin();
        this.codigoEmpresa = configuracaoIntervaloProcessamentoRequest.getCodigoEmpresa();
        this.codigoProduto = configuracaoIntervaloProcessamentoRequest.getCodigoProduto();
        this.codigoCanal = configuracaoIntervaloProcessamentoRequest.getCodigoCanal();
        this.quantidadeMinutoIntervaloErro = configuracaoIntervaloProcessamentoRequest
            .getQuantidadeMinutoIntervaloErro();
        this.quantidadeMinutoIntervaloNormal = configuracaoIntervaloProcessamentoRequest
            .getQuantidadeMinutoIntervaloNormal();
        this.dataVigenciaInicio = Utils
            .strDateFmtBrasilToJavaDate(configuracaoIntervaloProcessamentoRequest.getDataVigenciaInicio());

    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public Integer getQuantidadeMinutoIntervaloNormal() {
        return quantidadeMinutoIntervaloNormal;
    }

    public void setQuantidadeMinutoIntervaloNormal(Integer quantidadeMinutoIntervaloNormal) {
        this.quantidadeMinutoIntervaloNormal = quantidadeMinutoIntervaloNormal;
    }

    public Integer getQuantidadeMinutoIntervaloErro() {
        return quantidadeMinutoIntervaloErro;
    }

    public void setQuantidadeMinutoIntervaloErro(Integer quantidadeMinutoIntervaloErro) {
        this.quantidadeMinutoIntervaloErro = quantidadeMinutoIntervaloErro;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Date getDataVigenciaInicio() {

        if (dataVigenciaInicio != null) {
            return (Date) dataVigenciaInicio.clone();
        }

        return null;
    }

    public void setDataVigenciaInicio(Date dataVigenciaInicio) {
        this.dataVigenciaInicio = (Date) dataVigenciaInicio.clone();
    }

    public Date getDataVigenciaFinal() {
        if (dataVigenciaFinal != null) {
            return (Date) dataVigenciaFinal.clone();
        }

        return null;
    }

    public void setDataVigenciaFinal(Date dataVigenciaFinal) {
        this.dataVigenciaFinal = (Date) dataVigenciaFinal.clone();
    }

    public BigDecimal getNumeroInternoConfiguracaoIntervalo() {
        return numeroInternoConfiguracaoIntervalo;
    }

    public void setNumeroInternoConfiguracaoIntervalo(BigDecimal numeroInternoConfiguracaoIntervalo) {
        this.numeroInternoConfiguracaoIntervalo = numeroInternoConfiguracaoIntervalo;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }
}
