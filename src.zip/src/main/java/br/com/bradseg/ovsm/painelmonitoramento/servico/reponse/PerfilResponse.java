package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

/**
 * Classe expor consumo perfil Response
 * @author Wipro
 *
 */
public class PerfilResponse extends ResponseMensagem {

    private String perfil;

    public PerfilResponse() {
        super();
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }
}
