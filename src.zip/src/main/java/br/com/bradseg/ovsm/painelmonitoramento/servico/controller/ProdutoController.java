/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.CanalCombo;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ProdutoCombo;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ProdutoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * Classe responsável por expor serviços rest de produto
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/produto")
public class ProdutoController {

    private static final Logger LOGGER = LogManager.getLogger(ProdutoController.class);

    public static final String SUCESSO = "Sucesso";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final String ERRO = "erro: ";
    @Autowired
    private ProdutoService produtoService;

    public ProdutoController() {
        super();
    }

    /**
     * Obtem todos os produtos para pesquisa e criação de combo box nos paineis OV.
     *
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/")
    @Operation(summary = "Obtem todos os produtos para pesquisa e criação de combo box nos paineis OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterProduto() {
        try {
            List<Produto> produtos = produtoService.obterProduto();
            ProdutoCombo produtoCombo = new ProdutoCombo();
            produtoCombo.setCodigoRetorno(CODIGO_RETORNO_0);
            produtoCombo.setMensagem(SUCESSO);
            produtoCombo.setProdutosCombo(produtos);

            return ResponseEntity.ok(produtoCombo);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemArgumentException = new ResponseMensagem();
            mensagemArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        }
    }

    /**
     * Obtem todos os canais para pesquista atráves do produto e criação de combo
     * box nos paineis OV
     *
     * @param descricaoProduto String
     * @returnResponseEntity<ResponseMensagem>
     */
    @GetMapping("/canais")
    @Operation(summary = "Obtem todos os canais para pesquista "
        + "atráves do produto  e criação de combo box nos paineis OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterCanal(
        @RequestParam(name = "descricaoProduto") String descricaoProduto) {

        try {
            produtoService.obterCanaisProduto(descricaoProduto);
            CanalCombo canalCombo = new CanalCombo();
            canalCombo.setCodigoRetorno(CODIGO_RETORNO_0);
            canalCombo.setMensagem(SUCESSO);

            return ResponseEntity.ok(canalCombo);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegal = new ResponseMensagem();
            mensagemIllegal.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegal.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegal.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (ResponseStatusException e) {
            ResponseMensagem mensagemErro = new ResponseMensagem();
            mensagemErro.setMensagem(e.getMessage());
            mensagemErro.setCodigoRetorno(CODIGO_RETORNO_99);
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErro.getMensagem() + ";" + CODIGO_RETORNO_99, e);
        }

    }
}
