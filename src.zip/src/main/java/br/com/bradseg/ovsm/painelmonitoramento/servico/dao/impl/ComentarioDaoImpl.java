package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ComentarioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

/**
 * Classe responsável por implementar busca base de dados para inserção na
 * tabela Comentario
 *
 * @author Wipro
 */
@Repository
public class ComentarioDaoImpl implements ComentarioDao {

    private static final Logger LOGGER = LogManager
      .getLogger(ComentarioDaoImpl.class);

    public static final String COD_EMPRESA = "codigoEmpresa";

    public static final String COD_PRODUTO = "codigoProduto";

    public static final String COD_CANAL = "codigoCanal";

    public static final String DATA_PROCS = "dataProcs";

    public static final String COD_ERRO_CONEXAO_PAINEL = "codigoErroConexaoPainel";

    public static final String DATA_VERIF = "dataVerificacao";

    public static final String MSG_COMENTARIO = "comentario";

    public static final String LOGIN = "login";

    public static final String DATA_INCLUSAO = "dataInclusao";

    public static final String DATA_ALTERACAO = "dataAlteracao";

    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private NamedParameterJdbcTemplate jdbcTemplate;
    private DateFormat df;

    public static final String PATTERN = "yyyy-MM-dd HH:mm:ss";

    public static final String SELECT_FROM_PNEL_MNTTO_CNXAO = " SELECT COUNT(CEMPR_PNEL) "
      + "FROM OVSM.PNEL_MNTTO_CNXAO " + "WHERE CEMPR_PNEL = :codigoEmpresa "
      + "AND CPRODT_PNEL = :codigoProduto "
      + "AND CCANAL_DGTAL_PNEL = :codigoCanal "
      + "AND DPROCS_APLIC = :dataProcs "
      + "AND CERRO_CNXAO_PNEL = :codigoErroConexaoPainel";

    public static final String INSERT_PNEL_MSGEM_EVNTO = " INSERT INTO OVSM.PNEL_MSGEM_EVNTO "
      + "(CEMPR_PNEL, CPRODT_PNEL, CCANAL_DGTAL_PNEL, DVERIF_APLIC, DPROCS_APLIC, "
      + "CERRO_CNXAO_PNEL, RMSGEM_EVNTO, IUSUAR_INCL_MSGEM_APLIC, DINCL_REG) "
      + "VALUES (:codigoEmpresa, :codigoProduto, :codigoCanal, :dataVerificacao, "
      + ":dataProcs, :codigoErroConexaoPainel, :comentario, :login, :dataInclusao)";

    public static final String UPDATE_PNEL_MSGEM_EVNTO = " UPDATE OVSM.PNEL_MSGEM_EVNTO "
      + "SET RMSGEM_EVNTO = :comentario , DULT_ALT_REG = :dataAlteracao "
      + "WHERE CEMPR_PNEL = :codigoEmpresa AND CPRODT_PNEL = :codigoProduto "
      + "AND CCANAL_DGTAL_PNEL = :codigoCanal  "
      + "AND DPROCS_APLIC = TO_DATE(:dataProcs ,'yyyy-mm-dd HH24:MI:ss') "
      + "AND CERRO_CNXAO_PNEL = :codigoErroConexaoPainel AND IUSUAR_INCL_MSGEM_APLIC = :login "
      + "AND DINCL_REG = TO_DATE(:dataInclusao ,'yyyy-mm-dd HH24:MI:ss') ";


    public static final String DELETE_PNEL_MSGEM_EVNTO = " DELETE OVSM.PNEL_MSGEM_EVNTO "
      + "WHERE CEMPR_PNEL = :codigoEmpresa AND CPRODT_PNEL = :codigoProduto "
      + "AND CCANAL_DGTAL_PNEL = :codigoCanal "
      + "AND DPROCS_APLIC = TO_DATE(:dataProcs ,'yyyy-mm-dd HH24:MI:ss') "
      + "AND CERRO_CNXAO_PNEL = :codigoErroConexaoPainel AND IUSUAR_INCL_MSGEM_APLIC = :login "
      + "AND DINCL_REG = TO_DATE(:dataInclusao ,'yyyy-mm-dd HH24:MI:ss') ";

    public static final String SELECT_COMENTARIO = " SELECT OVSM.PNEL_MSGEM_EVNTO.CEMPR_PNEL, "
      + "OVSM.PNEL_MSGEM_EVNTO.CPRODT_PNEL, OVSM.PNEL_MSGEM_EVNTO.CCANAL_DGTAL_PNEL, "
      + "OVSM.PNEL_MSGEM_EVNTO.DVERIF_APLIC, OVSM.PNEL_MSGEM_EVNTO.DPROCS_APLIC, "
      + "OVSM.PNEL_MSGEM_EVNTO.RMSGEM_EVNTO, OVSM.PNEL_MSGEM_EVNTO.IUSUAR_INCL_MSGEM_APLIC, "
      + "OVSM.PNEL_MSGEM_EVNTO.CERRO_CNXAO_PNEL, "
      + "OVSM.PNEL_MSGEM_EVNTO.DINCL_REG, OVSM.USUAR.IUSUAR, OVSM.USUAR.CTPO_PRFIL FROM OVSM.PNEL_MSGEM_EVNTO "
      + "INNER JOIN OVSM.USUAR ON OVSM.PNEL_MSGEM_EVNTO.IUSUAR_INCL_MSGEM_APLIC = OVSM.USUAR.CUSUAR "
      + "WHERE OVSM.PNEL_MSGEM_EVNTO.CEMPR_PNEL = :codigoEmpresa "
      + "AND OVSM.PNEL_MSGEM_EVNTO.CPRODT_PNEL = :codigoProduto "
      + "AND OVSM.PNEL_MSGEM_EVNTO.CCANAL_DGTAL_PNEL= :codigoCanal "
      + "AND OVSM.PNEL_MSGEM_EVNTO.DPROCS_APLIC= :dataProcs "
      + "AND OVSM.PNEL_MSGEM_EVNTO.CERRO_CNXAO_PNEL= :codigoErroConexaoPainel ";

    public ComentarioDaoImpl() {
        super();
    }

    @Autowired
    public ComentarioDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.df = new SimpleDateFormat(PATTERN);
    }

    public Boolean obterDadosPainelMonitoramento(Comentario comentario)
      throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(COD_EMPRESA, comentario.getCodigoEmpresa());
            params.addValue(COD_PRODUTO, comentario.getCodigoProduto());
            params.addValue(COD_CANAL, comentario.getCodigoCanal());
            params.addValue(DATA_PROCS, comentario.getDataProcs());
            params.addValue(COD_ERRO_CONEXAO_PAINEL,
              comentario.getCodigoErroConexaoPainel());

            return jdbcTemplate.queryForObject(SELECT_FROM_PNEL_MNTTO_CNXAO,
              params, Integer.class) > 0;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public void inserirComentario(Comentario comentario) throws SQLException {
        LocalDateTime dataAtual = LocalDateTime
          .now(ZoneId.of("America/Sao_Paulo"));
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(COD_EMPRESA, comentario.getCodigoEmpresa());
            params.addValue(COD_PRODUTO, comentario.getCodigoProduto());
            params.addValue(COD_CANAL, comentario.getCodigoCanal());
            params.addValue(DATA_VERIF, dataAtual);
            params.addValue(DATA_PROCS, comentario.getDataProcs());
            params.addValue(COD_ERRO_CONEXAO_PAINEL,
              comentario.getCodigoErroConexaoPainel());
            params.addValue(MSG_COMENTARIO, comentario.getComentario());
            params.addValue(LOGIN, comentario.getLogin().toUpperCase());
            params.addValue(DATA_INCLUSAO, dataAtual);

            jdbcTemplate.update(INSERT_PNEL_MSGEM_EVNTO, params);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public List<Comentario> obterComentario(String codigoEmpresa,

      String codigoProduto, String codigoCanal,
      Date dataProcs, String codigoErroConexaoPainel) {
        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(COD_EMPRESA, codigoEmpresa);
            params.addValue(COD_PRODUTO, codigoProduto);
            params.addValue(COD_CANAL, codigoCanal);
            params.addValue(DATA_PROCS, dataProcs);
            params.addValue(COD_ERRO_CONEXAO_PAINEL, codigoErroConexaoPainel);

            List<Map<String, Object>> lista = jdbcTemplate
              .queryForList(SELECT_COMENTARIO, params);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  "Comentario não encontrado", 1);
            }

            List<Comentario> listaComentario = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Comentario comentario = new Comentario();
                comentario
                  .setCodigoEmpresa((BigDecimal) mapa.get("CEMPR_PNEL"));
                comentario
                  .setCodigoProduto((BigDecimal) mapa.get("CPRODT_PNEL"));
                comentario
                  .setCodigoCanal((BigDecimal) mapa.get("CCANAL_DGTAL_PNEL"));
                comentario.setDataVerificacao((Date) mapa.get("DVERIF_APLIC"));
                comentario.setDataProcs((Date) mapa.get("DPROCS_APLIC"));
                comentario.setCodigoErroConexaoPainel(
                  (BigDecimal) mapa.get("CERRO_CNXAO_PNEL"));
                comentario.setComentario((String) mapa.get("RMSGEM_EVNTO"));
                comentario
                  .setLogin((String) mapa.get("IUSUAR_INCL_MSGEM_APLIC"));
                comentario.setNomeUsuario((String) mapa.get("IUSUAR"));
                comentario.setPerfilUsuario((String) mapa.get("CTPO_PRFIL"));
                comentario.setDataInclusao((Date) mapa.get("DINCL_REG"));
                listaComentario.add(comentario);
            }
            return listaComentario;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public void alterarComentario(Comentario comentario) throws SQLException {
        LocalDateTime dataAtual = LocalDateTime
          .now(ZoneId.of("America/Sao_Paulo"));

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(COD_EMPRESA, comentario.getCodigoEmpresa());
            params.addValue(COD_PRODUTO, comentario.getCodigoProduto());
            params.addValue(COD_CANAL, comentario.getCodigoCanal());
            params.addValue(DATA_PROCS, df.format(comentario.getDataProcs()));
            params.addValue(COD_ERRO_CONEXAO_PAINEL, comentario.getCodigoErroConexaoPainel());
            params.addValue(MSG_COMENTARIO, comentario.getComentario());
            params.addValue(LOGIN, comentario.getLogin().toUpperCase());
            params.addValue(DATA_INCLUSAO, df.format(comentario.getDataInclusao()));
            params.addValue(DATA_ALTERACAO, dataAtual);

            jdbcTemplate.update(UPDATE_PNEL_MSGEM_EVNTO, params);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public void excluirComentario(Comentario comentario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(COD_EMPRESA, comentario.getCodigoEmpresa());
            params.addValue(COD_PRODUTO, comentario.getCodigoProduto());
            params.addValue(COD_CANAL, comentario.getCodigoCanal());
            params.addValue(DATA_PROCS, df.format(comentario.getDataProcs()));
            params.addValue(COD_ERRO_CONEXAO_PAINEL,
              comentario.getCodigoErroConexaoPainel());
            params.addValue(LOGIN, comentario.getLogin().toUpperCase());
            params.addValue(DATA_INCLUSAO, df.format(comentario.getDataInclusao()));

            jdbcTemplate.update(DELETE_PNEL_MSGEM_EVNTO, params);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
