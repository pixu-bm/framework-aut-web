package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Configuration
@EnableScheduling
public class CaptalizacaoSchedulingConfig implements SchedulingConfigurer {

    @Autowired
    private ConsultaApiCaptalizacao consultaApiCaptalizacao;
    @Autowired
    private ConsultaApiSaude consultaApiSaude;
    @Autowired
    private ConsultaApiPrevidencia consultaApiPrevidencia;
    @Autowired
    private ConsultaApiResidencial consultaApiResidencial;

    @Autowired
    private ConsultaApiTopClub consultaApiTopClub;

    @Autowired
    private ConsultaApiViagem consultaApiViagem;

    @Autowired
    private ConsultaApiSapp consultaApiSapp;

    @Autowired
    private ConsultaApiAuto consultaApiAuto;

    private static final Logger LOGGER = LogManager.getLogger(CaptalizacaoSchedulingConfig.class);

    public CaptalizacaoSchedulingConfig() {
        super();
    }

    @Bean
    public Executor taskExecutor() {
        return Executors.newSingleThreadScheduledExecutor();
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.setScheduler(taskExecutor());
        taskRegistrar.addTriggerTask(() -> {
            try {
                chamadasApi();
            } catch (AcessoADadosException e) {
                LOGGER.error(e);
            }
        },
            (TriggerContext context) -> {
                Optional<Date> lastCompletionTime = Optional.ofNullable(context.lastCompletionTime());
                Instant nextExecutionTime = lastCompletionTime.orElseGet(Date::new).toInstant()
                    .plusMillis(consultaApiCaptalizacao.buscaTempoParametrizado());
                return Date.from(nextExecutionTime);
            });
    }

    public void chamadasApi() {
        consultaApiCaptalizacao.consultaApi();
        consultaApiSaude.consultaApi();
        consultaApiTopClub.consultaApi();
        consultaApiSapp.consultaApi();
        consultaApiPrevidencia.consultaApi();
        consultaApiResidencial.consultaApi();
        consultaApiViagem.consultaApi();
        consultaApiAuto.consultaApi();
    }

}
