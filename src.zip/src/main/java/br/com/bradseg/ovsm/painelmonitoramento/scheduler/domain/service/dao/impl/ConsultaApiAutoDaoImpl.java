package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiAutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Repository

public class ConsultaApiAutoDaoImpl implements ConsultaApiAutoDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiAutoDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";

    private static final String VALIDAR_REGISTROS_DUPLICADOS_AUTO = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_SAUDE C "
        + "WHERE A.RTRANS_ORIGN = C.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = C.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(C.IAPI_ORIGN, NULL, '1')"
        + "AND C.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String INSERIR_CONSULTA_AUTO = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE (CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String LIBERAR_PROCESSAMENTO_AUTO = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' "
        + "AND IPRODT_ORIGN = 'AUTO' ";

    private static final String SELECT_MAX_REGISTRO_AUTO = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE "
        + "WHERE IPRODT_ORIGN = 'AUTO' ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaApiAutoDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public String obterultimoregistroinseridoAuto() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO_AUTO, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void liberarProcessamentoAuto(Collection<?> listaSaudeTemp) {

        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaSaudeTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO_AUTO,
                batchValues.toArray(new Map[listaSaudeTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void validarDuplicadosAuto(Collection<?> listaSaudeTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaSaudeTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS_AUTO,
                batchValues.toArray(new Map[listaSaudeTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }

    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void inserirConsultaApiAuto(List<TabelaTemp> listaAutoTemp) throws SQLException {
        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaAutoTemp.size());

            for (TabelaTemp autoTemp : listaAutoTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", autoTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", autoTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", autoTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", autoTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", autoTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", autoTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", autoTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", autoTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", autoTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", autoTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", autoTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", autoTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", autoTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", autoTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", autoTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", autoTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", autoTemp.getDinicErro())
                        .addValue("DFIM_ERRO", autoTemp.getDfimErro())
                        .addValue("DINCL_REG", autoTemp.getDinclReg())
                        .addValue("DALT_REG", autoTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_AUTO,
                batchValues.toArray(new Map[listaAutoTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);
        }

    }

}
