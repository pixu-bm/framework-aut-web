package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiViagemDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Repository
public class ConsultaApiViagemDaoImpl implements ConsultaApiViagemDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiViagemDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";

    private static final String VALIDAR_REGISTROS_DUPLICADOS_VIAGEM = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_SAUDE C "
        + "WHERE A.RTRANS_ORIGN = C.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = C.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(C.IAPI_ORIGN, NULL, '1')"
        + "AND C.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String INSERIR_CONSULTA_VIAGEM = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP (CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String LIBERAR_PROCESSAMENTO_VIAGEM = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' ";

    private static final String SELECT_MAX_REGISTRO_VIAGEM = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "WHERE IPRODT_ORIGN = 'VIAGEM' ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaApiViagemDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public String obterultimoregistroinseridoViagem() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO_VIAGEM, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void liberarProcessamentoViagem(Collection<?> listaSaudeTemp) {

        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaSaudeTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO_VIAGEM,
                batchValues.toArray(new Map[listaSaudeTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void validarDuplicadosViagem(Collection<?> listaSaudeTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaSaudeTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS_VIAGEM,
                batchValues.toArray(new Map[listaSaudeTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }

    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void inserirConsultaApiViagem(List<TabelaTemp> listaVaigemTemp) throws SQLException {
        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaVaigemTemp.size());

            for (TabelaTemp viagemTemp : listaVaigemTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", viagemTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", viagemTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", viagemTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", viagemTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", viagemTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", viagemTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", viagemTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", viagemTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", viagemTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", viagemTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", viagemTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", viagemTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", viagemTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", viagemTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", viagemTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", viagemTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", viagemTemp.getDinicErro())
                        .addValue("DFIM_ERRO", viagemTemp.getDfimErro())
                        .addValue("DINCL_REG", viagemTemp.getDinclReg())
                        .addValue("DALT_REG", viagemTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_VIAGEM,
                batchValues.toArray(new Map[listaVaigemTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);
        }

    }

}
