package br.com.bradseg.ovsm.painelmonitoramento.servico.service.export;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.PlanilhaUtils;

/**
 * Classe central de eventos service para exportação de arquivos.
 *
 * @author Wipro
 */
@Service
public class ConsultaHistoricaServiceExport {

    public static final int MARGIN_LEFT_30 = 30;
    public static final int INTEGER_9 = 9;
    private static final int INTEGER_6 = 6;
    private static final int INTEGER_5 = 5;
    public static final int INTEGER_4 = 4;
    public static final int INTEGER_3 = 3;
    public static final int INTEGER_2 = 2;
    public static final int INTEGER_1 = 1;
    public static final int INTEGER_0 = 0;
    private static final float FLOAT03 = 0.3F;
    private static final int INTEGER_7 = 7;
    private static final int INTEGER_8 = 8;
    private static final int INTEGER_10 = 10;
    private static final int INTEGER_11 = 11;
    public static final int MARGIN_RIGHT_30 = 30;
    public static final int MARGIN_TOP_20 = 20;
    public static final int MARGIN_BOTTOM_20 = 20;
    public static final int INTEGER_70 = 70;
    private static final String PRODUTO = "Produto";
    private static final String CANAL = "Canal";
    private static final String GRAVIDADE = "Gravidade";
    private static final String RECORRENCIA = "Recorrencia";
    private static final String CODIGO_EVENTO = "Código Evento";
    private static final String TRANSACOES_IMPAC = "Transações Impactadas";
    private static final String DURACAO_DISPON = "Duração Disponibilidade";
    private static final String DURACAO_FUNCL = "Duração Funcionalidade";
    private static final String TIPO_EVENTO = "Tipo";
    private static final String DURACAO_VOLUM = "Duração Volumetria";
    private static final String DATA = "Data";
    public static final String MSG_NENHUM_DADO_ENCONTRADO = "Não foram encontrados dados para a pesquisa";

    private LoginDao loginDao;

    private ProdutoDao produtoDao;

    private CanalDao canalDao;

    private static final Log LOGGER = LogFactory
        .getLog(ConsultaHistoricaServiceExport.class);

    @Autowired
    public ConsultaHistoricaServiceExport(LoginDao loginDao, ProdutoDao produtoDao, CanalDao canalDao) {
        this.loginDao = loginDao;
        this.produtoDao = produtoDao;
        this.canalDao = canalDao;
    }

    public ByteArrayInputStream gerarPdf(List<ConsultaHistorica> listaConsultaHistorica, String login,
        String dataInicio, String dataFim, List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal) {
        Document documento = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        Integer graves = INTEGER_0;
        Integer moderado = INTEGER_0;

        if (listaConsultaHistorica != null) {
            for (int i = INTEGER_0; i < listaConsultaHistorica.size(); i++) {
                if ("EVENTO GRAVE".equalsIgnoreCase(listaConsultaHistorica.get(i).getGravidade())) {
                    graves++;
                }

                if ("EVENTO MODERADO".equalsIgnoreCase(listaConsultaHistorica.get(i).getGravidade())) {
                    moderado++;
                }
            }
        }

        try {

            documento.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documento, out);

            documento.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INTEGER_9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INTEGER_9, BaseColor.BLACK);

            Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal, graves, moderado};
            documento = montarCabecalhoConsultaHistoricaPDF(documento, objectArray, font1, font2);
            documento.add(Chunk.NEWLINE);
            documento = montarListaConsultaHistoricoPDF(documento, listaConsultaHistorica, font1, font2);
            documento.close();

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    private Document montarCabecalhoConsultaHistoricaPDF(Document documento, Object[] objectArray, Font font1,
        Font font2) {

        Usuario usuarioConsulta = new Usuario();
        String loginConsulta = (String) objectArray[INTEGER_0];
        Integer gravesConsulta = (Integer) objectArray[INTEGER_5];
        Integer moderadosConsulta = (Integer) objectArray[INTEGER_6];
        Integer totalConsulta = gravesConsulta + moderadosConsulta;

        usuarioConsulta.setLogin(loginConsulta.toUpperCase());

        try {
            usuarioConsulta = loginDao.obterInformacaoUsuario(usuarioConsulta);

            PdfPTable tabCabConsulta = new PdfPTable(INTEGER_4);
            tabCabConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabCabConsulta.setWidthPercentage(INTEGER_70);
            Map<Integer, String> linhaVazioConsulta = new HashMap<>();

            Map<Integer, String> linha1Consulta = new HashMap<>();
            linha1Consulta.put(INTEGER_1, "Usuário");
            linha1Consulta.put(INTEGER_2, usuarioConsulta.getNome());
            linha1Consulta.put(INTEGER_3, "Versão de Central");
            linha1Consulta.put(INTEGER_4, "1.0");
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha1Consulta, tabCabConsulta, font1, font2, INTEGER_1,
                INTEGER_0);

            Map<Integer, String> linha6 = new HashMap<>();
            linha6.put(INTEGER_1, "Data e hora Exp");
            linha6.put(INTEGER_2, toDate());
            linha6.put(INTEGER_3, "");
            linha6.put(INTEGER_4, "");
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha6, tabCabConsulta, font1, font2, INTEGER_1,
                INTEGER_0);

            // Add linha vazia
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linhaVazioConsulta, tabCabConsulta, font1, font2,
                INTEGER_3, INTEGER_0);

            Map<Integer, String> linha2 = new HashMap<>();
            linha2.put(INTEGER_1, "Filtros aplicados");
            linha2.put(INTEGER_2, "");
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha2, tabCabConsulta, font1, font2, INTEGER_2,
                INTEGER_0);

            Map<Integer, String> linha3 = new HashMap<>();
            linha3.put(INTEGER_1, CANAL);
            if (objectArray[INTEGER_4] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INTEGER_4];
                String canais = obterTextoCanal(lista);
                linha3.put(INTEGER_2, canais);
            } else {
                String valueEmpty = " ";
                linha3.put(INTEGER_2, valueEmpty);
            }
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha3, tabCabConsulta, font1, font2, INTEGER_2,
                INTEGER_0);

            Map<Integer, String> linha4 = new HashMap<>();
            linha4.put(INTEGER_1, PRODUTO);
            if (objectArray[INTEGER_3] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INTEGER_3];
                String produtos = obterTextoProdutos(lista);
                linha4.put(INTEGER_2, produtos);
            } else {
                String valueEmpty = " ";
                linha4.put(INTEGER_2, valueEmpty);
            }
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha4, tabCabConsulta, font1, font2, INTEGER_2,
                INTEGER_0);

            Map<Integer, String> linha5 = new HashMap<>();
            linha5.put(INTEGER_1, "Periodo");
            linha5.put(INTEGER_2, "de " + objectArray[INTEGER_1] + " até " + objectArray[INTEGER_2]);

            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha5, tabCabConsulta, font1, font2, INTEGER_2,
                INTEGER_0);

            // Add linha vazia
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linhaVazioConsulta, tabCabConsulta, font1, font2,
                INTEGER_3, INTEGER_0);

            Map<Integer, String> linha7 = new HashMap<>();
            linha7.put(INTEGER_1, "Resumos");
            linha7.put(INTEGER_2, "");
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha7, tabCabConsulta, font1, font2, INTEGER_2,
                INTEGER_0);

            Map<Integer, String> linha8 = new HashMap<>();
            linha8.put(INTEGER_1, "Qtd de Eventos");
            linha8.put(INTEGER_2, totalConsulta.toString());
            linha8.put(INTEGER_3, null);
            linha8.put(INTEGER_4, null);
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha8, tabCabConsulta, font1, font2, INTEGER_1,
                INTEGER_0);

            Map<Integer, String> linha9 = new HashMap<>();
            linha9.put(INTEGER_1, "Eventos Graves");
            linha9.put(INTEGER_2, gravesConsulta.toString());
            linha9.put(INTEGER_3, null);
            linha9.put(INTEGER_4, null);
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha9, tabCabConsulta, font1, font2, INTEGER_1,
                INTEGER_0);

            Map<Integer, String> linha10 = new HashMap<>();
            linha10.put(INTEGER_1, "Eventos Moderados");
            linha10.put(INTEGER_2, moderadosConsulta.toString());
            linha10.put(INTEGER_3, null);
            linha10.put(INTEGER_4, null);
            tabCabConsulta = addCabecalhoConsultaHistoricaPDF(linha10, tabCabConsulta, font1, font2, INTEGER_1,
                INTEGER_0);

            documento.add(tabCabConsulta);

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static PdfPTable addCabecalhoConsultaHistoricaPDF(Map<Integer, String> linha, PdfPTable tabCab, Font font1,
        Font font2, Integer tipoConsulta, Integer borda) {

        if (tipoConsulta == INTEGER_1) {
            for (Map.Entry<Integer, String> pairConsulta : linha.entrySet()) {
                PdfPCell colConsulta = new PdfPCell();
                auxilioCabecalhoTipo1(colConsulta, pairConsulta, font1, font2, borda);
                tabCab.addCell(colConsulta);
            }
        } else if (tipoConsulta == INTEGER_2) {
            for (Map.Entry<Integer, String> pairConsulta : linha.entrySet()) {
                PdfPCell colConsulta = new PdfPCell();
                auxilioCabecalhoTipo2(colConsulta, pairConsulta, font1, font2, borda);                
                tabCab.addCell(colConsulta);
            }
        } else {
            PdfPCell colConsulta = new PdfPCell();
            colConsulta.setBackgroundColor(BaseColor.WHITE);
            colConsulta.setPhrase(new Phrase(" ", font1));
            colConsulta.setBorderWidth(borda);
            colConsulta.setBorderColor(BaseColor.LIGHT_GRAY);
            colConsulta.setColspan(INTEGER_4);
        }
        return tabCab;
    }
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoTipo2(PdfPCell colConsulta, Entry<Integer, String> pairConsulta, Font font1,
        Font font2, Integer borda) {

        if (pairConsulta.getKey() == INTEGER_2) {
            if (!"".equalsIgnoreCase(pairConsulta.getValue())) {
                colConsulta.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                colConsulta.setBackgroundColor(BaseColor.WHITE);
            }
            colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            colConsulta.setPhrase(new Phrase(pairConsulta.getValue(), font1));
            colConsulta.setBorderWidth(borda);
            colConsulta.setBorderColor(BaseColor.LIGHT_GRAY);
            colConsulta.setColspan(INTEGER_3);
        } else {
            colConsulta.setBackgroundColor(BaseColor.WHITE);
            colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            colConsulta.setPhrase(new Phrase(pairConsulta.getValue(), font2));
            colConsulta.setBorderWidth(borda);
            colConsulta.setBorderColor(BaseColor.LIGHT_GRAY);
        }
        
    }
    
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoTipo1(PdfPCell colConsulta, Entry<Integer, String> pairConsulta, Font font1,
        Font font2, Integer borda) {
        
        if (pairConsulta.getKey() % INTEGER_2 == INTEGER_0) {
            if (pairConsulta.getValue() != null && !"".equalsIgnoreCase(pairConsulta.getValue())) {
                colConsulta.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                colConsulta.setBackgroundColor(BaseColor.WHITE);
            }
            colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            colConsulta.setPhrase(new Phrase(pairConsulta.getValue(), font1));
            colConsulta.setBorderWidth(borda);
            colConsulta.setBorderColor(BaseColor.LIGHT_GRAY);
        } else {
            colConsulta.setBackgroundColor(BaseColor.WHITE);
            if (pairConsulta.getKey() == INTEGER_3) {
                colConsulta.setHorizontalAlignment(Element.ALIGN_RIGHT);
            } else {
                colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            colConsulta.setPhrase(new Phrase(pairConsulta.getValue(), font2));
            colConsulta.setBorderWidth(borda);
            colConsulta.setBorderColor(BaseColor.LIGHT_GRAY);
        }

    }

    private static Document montarListaConsultaHistoricoPDF(Document documento,
        List<ConsultaHistorica> listaConsultaHistorica,
        Font font1, Font font2) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INTEGER_11);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);

            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, CODIGO_EVENTO);
            cabecalhoConsulta.put(INTEGER_2, GRAVIDADE);
            cabecalhoConsulta.put(INTEGER_3, PRODUTO);
            cabecalhoConsulta.put(INTEGER_4, CANAL);
            cabecalhoConsulta.put(INTEGER_5, TIPO_EVENTO);
            cabecalhoConsulta.put(INTEGER_6, TRANSACOES_IMPAC);
            cabecalhoConsulta.put(INTEGER_7, DURACAO_DISPON);
            cabecalhoConsulta.put(INTEGER_8, DURACAO_FUNCL);
            cabecalhoConsulta.put(INTEGER_9, DURACAO_VOLUM);
            cabecalhoConsulta.put(INTEGER_10, DATA);
            cabecalhoConsulta.put(INTEGER_11, RECORRENCIA);

            PdfPTable tabBodyItens = new PdfPTable(INTEGER_11);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);

            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT03);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (listaConsultaHistorica != null) {
                for (int i = INTEGER_0; i < listaConsultaHistorica.size(); i++) {
                    tabBodyItens = addLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getCodigoEvento().toString(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getGravidade(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getProduto(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getCanal(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getTipoEvento(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getTransacoesImpactadas().toString(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoDispFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoFuncFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoVoluFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getData(), tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getRecorrencia().toString(),
                        tabBodyItens,
                        font1);
                }
            }

            documento.add(tabBodyConsulta);

            if (listaConsultaHistorica != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static PdfPTable addLinhaConsultaHistoricaPDF(String item, PdfPTable tabBodyConsulta, Font font1) {
        PdfPCell colConsulta = new PdfPCell();
        colConsulta.setBackgroundColor(BaseColor.WHITE);
        colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
        if (item != null) {
            colConsulta.setPhrase(new Phrase(item, font1));
        } else {
            colConsulta.setPhrase(new Phrase("", font1));
        }
        colConsulta.setBorderWidth(FLOAT03);
        colConsulta.setBorderColor(BaseColor.BLACK);
        tabBodyConsulta.addCell(colConsulta);
        return tabBodyConsulta;
    }

    public Workbook gerarExcel(List<ConsultaHistorica> lista) {
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Historico");
        int countSheet = INTEGER_0;

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INTEGER_0;

        String[] valoresCabecalho = {CODIGO_EVENTO, GRAVIDADE, PRODUTO,
            CANAL, TIPO_EVENTO, TRANSACOES_IMPAC, DURACAO_DISPON, DURACAO_FUNCL,
            DURACAO_VOLUM, DATA, RECORRENCIA};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = 0; i < lista.size(); i++) {
            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getCodigoEvento().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getGravidade());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getTipoEvento());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getTransacoesImpactadas().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoDispFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoFuncFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoVoluFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getData());

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getRecorrencia().toString());

        }

        for (int i = 0; i < valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    private static void montarCelula(Row row, int count,
        Sheet sheet, CellStyle styleInicial, String value) {

        Cell celula = row.createCell(count);
        celula.setCellValue(value);
        celula.setCellStyle(styleInicial);
    }

    private static String toDate() {
        DateFormat dateFormatConsulta = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date dateConsulta = Date.from(Instant.now());
        return dateFormatConsulta.format(dateConsulta);
    }

    private String obterTextoProdutos(List<BigDecimal> listaProdutoConsulta) {
        StringBuilder textoConsulta = new StringBuilder("");
        List<Produto> produtosBaseConsulta = produtoDao.listarProduto();

        for (int i = INTEGER_0; i < listaProdutoConsulta.size(); i++) {
            for (int j = INTEGER_0; j < produtosBaseConsulta.size(); j++) {
                if (listaProdutoConsulta.get(i)
                    .equals(produtosBaseConsulta.get(j).getCodigo())) {
                    textoConsulta.append(produtosBaseConsulta.get(j).getDescricao())
                        .append(";");

                }
            }
        }

        return textoConsulta.toString();
    }

    private String obterTextoCanal(List<BigDecimal> listaCanalConsulta) {
        StringBuilder textoConsulta = new StringBuilder("");
        List<Canal> canalBaseConsulta = canalDao.listarCanal();

        for (int i = INTEGER_0; i < listaCanalConsulta.size(); i++) {
            for (int j = INTEGER_0; j < canalBaseConsulta.size(); j++) {
                if (listaCanalConsulta.get(i).equals(canalBaseConsulta.get(j).getCodigo())) {
                    textoConsulta.append(canalBaseConsulta.get(j).getDescricao()).append(";");
                }
            }
        }

        return textoConsulta.toString();
    }
}
