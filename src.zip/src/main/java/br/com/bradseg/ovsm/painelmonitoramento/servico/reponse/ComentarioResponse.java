package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

public class ComentarioResponse extends ResponseMensagem {

    private List<Comentario> listaComentario;

    public ComentarioResponse() {
        super();
    }

    public List<Comentario> getListaComentario() {
        return Collections.unmodifiableList(listaComentario);
    }

    public void setListaComentario(List<Comentario> listaComentario) {
        this.listaComentario = Collections.unmodifiableList(listaComentario);
    }

}
