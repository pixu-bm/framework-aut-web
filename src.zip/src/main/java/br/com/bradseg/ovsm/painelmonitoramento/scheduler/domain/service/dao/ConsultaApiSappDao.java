package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface ConsultaApiSappDao {
    
    String obterultimoregistroinseridoSapp();

    void liberarProcessamentoSapp(Collection<?> listaSaudeTemp);
    
    void validarDuplicadosSapp(Collection<?> listaSaudeTemp);
    
    void inserirConsultaApiSapp(List<TabelaTemp> listaSaudeTemp) throws SQLException;
}
