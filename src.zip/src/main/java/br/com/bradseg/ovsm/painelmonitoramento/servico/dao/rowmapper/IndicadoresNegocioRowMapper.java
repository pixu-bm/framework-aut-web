package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;

/**
 * Volumetria tempo real volumetria maxima mapa objetos extração de base de
 * dados.
 * 
 * @author Wipro
 */
public class IndicadoresNegocioRowMapper implements RowMapper<IndicadoresNegocio> {
    
    private static final int INT_3600 = 3600;
    private static final int INT_60 = 60;
    private static final int INT_10 = 10;
    
    public IndicadoresNegocio mapRow(ResultSet rs, int rowNum) throws SQLException {

        IndicadoresNegocio indicadoresNegocio 
        = new IndicadoresNegocio();
        indicadoresNegocio.setTotalTransacoes(rowNum);
        indicadoresNegocio.setTotalTransacoes(rs.getInt("SOMA_TRANSACOES"));
        indicadoresNegocio.setQtdEventos(rs.getInt("SOMA_EVENTOS"));
        indicadoresNegocio.setTempoTotalEventos(formatoHoraMinutoSegundo(rs.getLong("SOMA_TEMPO_EVENTOS")));
        indicadoresNegocio.setTransacoesImpactadas(rs.getInt("TRANSACOES_IMPACTADAS"));
        indicadoresNegocio.setFrequenciaEventos(rs.getInt("FREQUENCIA_EVENTOS"));
        indicadoresNegocio.setTempoMedioEventos(formatoHoraMinutoSegundo(rs.getLong("MEDIA_TEMPO_EVENTOS")));

        return indicadoresNegocio;
    }
    
    private static String formatoHoraMinutoSegundo(Long segundos) {

        Long horas = (segundos / INT_3600);

        Long minutos = ((segundos - (horas * INT_60 * INT_60)) / INT_60);

        Long segundosLocal = segundos - (horas * INT_60 * INT_60) - (minutos * INT_60);

        String strHoras = "";
        String srtMinutos = "";
        String srtSegundos = "";

        if (horas < INT_10) {
            strHoras = "0" + horas;
        } else {
            strHoras = horas.toString();
        }

        if (minutos < INT_10) {
            srtMinutos = "0" + minutos;
        } else {
            srtMinutos = minutos.toString();
        }

        if (segundosLocal < INT_10) {
            srtSegundos = "0" + segundosLocal;
        } else {
            srtSegundos = segundosLocal.toString();
        }

        return strHoras + ":" + srtMinutos + ":" + srtSegundos;
    }
}
