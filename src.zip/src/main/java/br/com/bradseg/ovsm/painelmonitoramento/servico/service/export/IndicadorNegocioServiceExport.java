package br.com.bradseg.ovsm.painelmonitoramento.servico.service.export;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.PlanilhaUtils;

/**
 * Classe central de eventos service para exportação de arquivos.
 *
 * @author Wipro
 */
@Service
public class IndicadorNegocioServiceExport {

    public static final int MARGIN_LEFT_30 = 30;
    public static final int MARGIN_RIGHT_30 = 30;
    public static final int MARGIN_TOP_20 = 20;
    public static final int MARGIN_BOTTOM_20 = 20;
    public static final int INT9 = 9;
    private static final int INT6 = 6;
    private static final int INT5 = 5;
    public static final int INT4 = 4;
    public static final int INT3 = 3;
    public static final int INT2 = 2;
    public static final int INT1 = 1;
    public static final int INT0 = 0;
    private static final float FLOAT_03 = 0.3F;
    private static final int INT7 = 7;
    private static final int INT8 = 8;
    private static final int INT10 = 10;
    private static final int INT11 = 11;
    private static final int INT12 = 12;
    private static final int INT13 = 13;
    public static final int INT70 = 70;
    private static final String PRODUTO = "Produto";
    private static final String CANAL = "Canal";
    private static final String RECORRENCIA = "Recorrencia";
    private static final String DIA = "Dia";
    private static final String SEMANA = "Semana";
    private static final String MES = "Mês";
    public static final String MSG_NENHUM_DADO_ENCONTRADO = "Não foram encontrados dados para a pesquisa";
    private static final String PERIODO = "Período";
    private static final String QTD_VOLUMETRIA_ATUAL = "Qtd. Volumetria Atual";
    private static final String QTD_VOLUMETRIA_MEDIA = "Qtd. Volumetria Média Histórica";
    private static final String QTD_TRANS_SEVENTOS = "Qtd. Transações sem Eventos";
    private static final String QTD_TRANS_EVENTOS = "Qtd. Transações com Eventos";
    private static final String TOTAL_TRANSACOES = "Número Total de Transações";
    private static final String TRANSACOES_IMPACTADAS = "Número Total de Transações";
    private static final String QTD_EVENTOS = "Quantidade de Eventos";
    private static final String FREQ_EVENTOS = "Frequencia de Eventos";
    private static final String TT_EVENTOS = "Tempo Total de Eventos";
    private static final String PCT_TTRANSACOES = "Porcentagem total de Transações";
    private static final String PCT_QTD_EVENTOS = "Porcentagem de Quantidade de Eventos";
    private static final String PCT_TTRANSACOES_IMPAC = "Porcentagem total de Transações Impactadas";
    private static final String TM_EVENTOS = "Tempo Médio de Eventos";
    private static final String PCT_FREQ_EVENT = "Porcentagem Frequencia Eventos";
    private static final String PCT_TM_EVNT = "Porcentagem Tempo Médio de Eventos";
    private static final String TOP_15 = "Top 15";
    private static final String PARAMETRO = "Parâmetro";

    private LoginDao loginDao;

    private ProdutoDao produtoDao;

    private CanalDao canalDao;

    private static final Log LOGGER = LogFactory
        .getLog(IndicadorNegocioServiceExport.class);
    private static final float INT_100 = 100;

    @Autowired
    public IndicadorNegocioServiceExport(LoginDao loginDao, ProdutoDao produtoDao, CanalDao canalDao) {
        this.loginDao = loginDao;
        this.produtoDao = produtoDao;
        this.canalDao = canalDao;
    }

    private Document montarCabecalhoPDF(Document documento, Object[] objectArray, Font font1,
        Font font2) {

        Usuario usuarioIndNeg = new Usuario();
        Integer gravesIndNeg = 0;
        Integer moderadosIndNeg = 0;
        Integer totalIndNeg = 0;
        String loginIndNeg = (String) objectArray[INT0];
        if (objectArray.length != INT5) {
            gravesIndNeg = (Integer) objectArray[INT5];
            moderadosIndNeg = (Integer) objectArray[INT6];
            totalIndNeg = gravesIndNeg + moderadosIndNeg;
        }

        usuarioIndNeg.setLogin(loginIndNeg.toUpperCase());

        try {
            usuarioIndNeg = loginDao.obterInformacaoUsuario(usuarioIndNeg);

            PdfPTable tabCabIndNeg = new PdfPTable(INT4);
            tabCabIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabCabIndNeg.setWidthPercentage(INT70);
            Map<Integer, String> linhaVazioIndNeg = new HashMap<>();
            String valueEmptyIndNeg = " ";

            Map<Integer, String> linha1IndNeg = new HashMap<>();
            linha1IndNeg.put(INT1, "Usuário");
            linha1IndNeg.put(INT2, usuarioIndNeg.getNome());
            linha1IndNeg.put(INT3, "Versão de Central");
            linha1IndNeg.put(INT4, "1.0");
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha1IndNeg, tabCabIndNeg, font1, font2, INT1, INT0);

            Map<Integer, String> linha6IndNeg = new HashMap<>();
            linha6IndNeg.put(INT1, "Data e hora Exp");
            linha6IndNeg.put(INT2, toDate());
            linha6IndNeg.put(INT3, "");
            linha6IndNeg.put(INT4, "");
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha6IndNeg, tabCabIndNeg, font1, font2, INT1, INT0);

            // Add linha vazia
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linhaVazioIndNeg, tabCabIndNeg, font1, font2, INT3, INT0);

            Map<Integer, String> linha2IndNeg = new HashMap<>();
            linha2IndNeg.put(INT1, "Filtros aplicados");
            linha2IndNeg.put(INT2, "");
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha2IndNeg, tabCabIndNeg, font1, font2, INT2, INT0);

            Map<Integer, String> linha3IndNeg = new HashMap<>();
            linha3IndNeg.put(INT1, CANAL);
            if (objectArray[INT4] != null) {
                List<BigDecimal> listaIndNeg = (List<BigDecimal>) objectArray[INT4];
                String canaisIndNeg = obterTextoCanal(listaIndNeg);
                linha3IndNeg.put(INT2, canaisIndNeg);
            } else {
                linha3IndNeg.put(INT2, valueEmptyIndNeg);
            }
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha3IndNeg, tabCabIndNeg, font1, font2, INT2, INT0);

            Map<Integer, String> linha4IndNeg = new HashMap<>();
            linha4IndNeg.put(INT1, PRODUTO);
            if (objectArray[INT3] != null) {
                List<BigDecimal> listaIndNeg = (List<BigDecimal>) objectArray[INT3];
                String produtosIndNeg = obterTextoProdutos(listaIndNeg);
                linha4IndNeg.put(INT2, produtosIndNeg);
            } else {
                linha4IndNeg.put(INT2, valueEmptyIndNeg);
            }
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha4IndNeg, tabCabIndNeg, font1, font2, INT2, INT0);

            Map<Integer, String> linha5IndNeg = new HashMap<>();
            linha5IndNeg.put(INT1, "Periodo");
            linha5IndNeg.put(INT2, "de " + objectArray[INT1] + " até " + objectArray[INT2]);

            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha5IndNeg, tabCabIndNeg, font1, font2, INT2, INT0);

            // Add linha vazia
            tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linhaVazioIndNeg, tabCabIndNeg, font1, font2, INT3, INT0);

            if (objectArray.length != INT5) {
                Map<Integer, String> linha7IndNeg = new HashMap<>();
                linha7IndNeg.put(INT1, "Resumos");
                linha7IndNeg.put(INT2, "");
                tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha7IndNeg, tabCabIndNeg, font1, font2, INT2, INT0);

                Map<Integer, String> linha8IndNeg = new HashMap<>();
                linha8IndNeg.put(INT1, "Qtd de Eventos");
                linha8IndNeg.put(INT2, totalIndNeg.toString());
                linha8IndNeg.put(INT3, null);
                linha8IndNeg.put(INT4, null);
                tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha8IndNeg, tabCabIndNeg, font1, font2, INT1, INT0);

                Map<Integer, String> linha9IndNeg = new HashMap<>();
                linha9IndNeg.put(INT1, "Eventos Graves");
                linha9IndNeg.put(INT2, gravesIndNeg.toString());
                linha9IndNeg.put(INT3, null);
                linha9IndNeg.put(INT4, null);
                tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha9IndNeg, tabCabIndNeg, font1, font2, INT1, INT0);

                Map<Integer, String> linha10IndNeg = new HashMap<>();
                linha10IndNeg.put(INT1, "Eventos Moderados");
                linha10IndNeg.put(INT2, moderadosIndNeg.toString());
                linha10IndNeg.put(INT3, null);
                linha10IndNeg.put(INT4, null);
                tabCabIndNeg = addCabecalhoConsultaHistoricaPDF(linha10IndNeg, tabCabIndNeg, font1, font2, INT1, INT0);

            }

            tabCabIndNeg.setSpacingAfter(INT10);

            documento.add(tabCabIndNeg);

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static PdfPTable addCabecalhoConsultaHistoricaPDF(Map<Integer, String> linha, PdfPTable tabCab, Font font1,
        Font font2, Integer tipoIndNeg, Integer borda) {

        if (tipoIndNeg == INT1) {
            for (Map.Entry<Integer, String> pairIndNeg : linha.entrySet()) {
                PdfPCell colIndNeg = new PdfPCell();
                auxilioCabecalhoTipo1(colIndNeg, pairIndNeg, font1, font2, borda);
                tabCab.addCell(colIndNeg);
            }
        } else if (tipoIndNeg == INT2) {
            for (Map.Entry<Integer, String> pairIndNeg : linha.entrySet()) {
                PdfPCell colIndNeg = new PdfPCell();
                auxilioCabecalhoTipo2(colIndNeg, pairIndNeg, font1, font2, borda);
                tabCab.addCell(colIndNeg);
            }
        } else {
            PdfPCell colIndNeg = new PdfPCell();
            colIndNeg.setBackgroundColor(BaseColor.WHITE);
            colIndNeg.setPhrase(new Phrase(" ", font1));
            colIndNeg.setBorderWidth(borda);
            colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
            colIndNeg.setColspan(INT4);
        }
        return tabCab;
    }
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoTipo1(PdfPCell colIndNeg, Entry<Integer, String> pairIndNeg, Font font1,
        Font font2, Integer borda) {
        
        if (pairIndNeg.getKey() % INT2 == INT0) {
            if (pairIndNeg.getValue() != null && !"".equalsIgnoreCase(pairIndNeg.getValue())) {
                colIndNeg.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                colIndNeg.setBackgroundColor(BaseColor.WHITE);
            }
            colIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
            colIndNeg.setPhrase(new Phrase(pairIndNeg.getValue(), font1));
            colIndNeg.setBorderWidth(borda);
            colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
        } else {
            colIndNeg.setBackgroundColor(BaseColor.WHITE);
            if (pairIndNeg.getKey() == INT3) {
                colIndNeg.setHorizontalAlignment(Element.ALIGN_RIGHT);
            } else {
                colIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            colIndNeg.setPhrase(new Phrase(pairIndNeg.getValue(), font2));
            colIndNeg.setBorderWidth(borda);
            colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
        }

    }
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoTipo2(PdfPCell colIndNeg, Entry<Integer, String> pairIndNeg, Font font1,
        Font font2, Integer borda) {

        if (pairIndNeg.getKey() == INT2) {
            if (!"".equalsIgnoreCase(pairIndNeg.getValue())) {
                colIndNeg.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                colIndNeg.setBackgroundColor(BaseColor.WHITE);
            }
            colIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
            colIndNeg.setPhrase(new Phrase(pairIndNeg.getValue(), font1));
            colIndNeg.setBorderWidth(borda);
            colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
            colIndNeg.setColspan(INT3);
        } else {
            colIndNeg.setBackgroundColor(BaseColor.WHITE);
            colIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
            colIndNeg.setPhrase(new Phrase(pairIndNeg.getValue(), font2));
            colIndNeg.setBorderWidth(borda);
            colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
        }
        
    }

    private static PdfPTable addLinhaVazia(PdfPTable tab, int colunas, Font font1) {

        PdfPCell colIndNeg = new PdfPCell();
        colIndNeg.setBackgroundColor(BaseColor.WHITE);
        colIndNeg.setPhrase(new Phrase(" ", font1));
        colIndNeg.setBorderColor(BaseColor.LIGHT_GRAY);
        colIndNeg.setColspan(colunas);
        tab.addCell(colIndNeg);

        return tab;
    }

    private static PdfPTable addLinhaPDF(String item, PdfPTable tabBodyConsulta, Font font1) {
        PdfPCell colConsultaIndNeg = new PdfPCell();
        colConsultaIndNeg.setBackgroundColor(BaseColor.WHITE);
        colConsultaIndNeg.setHorizontalAlignment(Element.ALIGN_LEFT);
        if (item != null) {
            colConsultaIndNeg.setPhrase(new Phrase(item, font1));
        } else {
            colConsultaIndNeg.setPhrase(new Phrase("", font1));
        }
        colConsultaIndNeg.setBorderWidth(FLOAT_03);
        colConsultaIndNeg.setBorderColor(BaseColor.BLACK);
        tabBodyConsulta.addCell(colConsultaIndNeg);
        return tabBodyConsulta;
    }

    private static void montarCelula(Row row, int count,
        Sheet sheet, CellStyle styleInicial, String value) {

        Cell celulaIndNeg = row.createCell(count);
        celulaIndNeg.setCellValue(value);
        celulaIndNeg.setCellStyle(styleInicial);    
    }

    private static String toDate() {
        DateFormat dateFormatIndNeg = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date dateIndNeg = Date.from(Instant.now());
        return dateFormatIndNeg.format(dateIndNeg);
    }

    private String obterTextoProdutos(List<BigDecimal> listaProdutoIndNeg) {
        StringBuilder textoIndNeg = new StringBuilder("");
        List<Produto> produtosBaseIndNeg = produtoDao.listarProduto();

        for (int i = INT0; i < listaProdutoIndNeg.size(); i++) {
            for (int j = INT0; j < produtosBaseIndNeg.size(); j++) {
                if (listaProdutoIndNeg.get(i)
                    .equals(produtosBaseIndNeg.get(j).getCodigo())) {
                    textoIndNeg.append(produtosBaseIndNeg.get(j).getDescricao())
                        .append(";");

                }
            }
        }

        return textoIndNeg.toString();
    }

    private String obterTextoCanal(List<BigDecimal> listaCanalIndNeg) {
        StringBuilder textoIndNeg = new StringBuilder("");
        List<Canal> canalBaseIndNeg = canalDao.listarCanal();

        for (int i = INT0; i < listaCanalIndNeg.size(); i++) {
            for (int j = INT0; j < canalBaseIndNeg.size(); j++) {
                if (listaCanalIndNeg.get(i).equals(canalBaseIndNeg.get(j).getCodigo())) {
                    textoIndNeg.append(canalBaseIndNeg.get(j).getDescricao()).append(";");
                }
            }
        }

        return textoIndNeg.toString();
    }

    public Workbook excelCsvMonitorVisao(VolumetriaTempoRealVolumetriaMaxima volumetriaTempoRealVolumetriaMaxima,
        List<VolumetriaTempoReal> listaVolumetriaTempoReal, Integer periodo, Object[] objectArray) {

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Monitor + Visão Negocio");

        geraCabecalhoExcel(wb, sheet, objectArray);

        int countSheet = INT8;

        String periodoTempo = "";

        if (periodo == 1) {
            periodoTempo = DIA;
        } else if (periodo == INT2) {
            periodoTempo = SEMANA;
        } else {
            periodoTempo = MES;
        }

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT0;

        String[] valoresCabecalho = {PRODUTO, CANAL, PERIODO,
            QTD_TRANS_EVENTOS, QTD_TRANS_SEVENTOS};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = 0; i < listaVolumetriaTempoReal.size(); i++) {
            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                listaVolumetriaTempoReal.get(i).getDescProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaVolumetriaTempoReal.get(i).getDescCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                periodoTempo);
            count++;

            montarCelula(
                row, count, sheet, style,
                listaVolumetriaTempoReal.get(i).getTransacaoEvento().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaVolumetriaTempoReal.get(i).getTransacaoSemEvento().toString());
        }

        countSheet++;
        countSheet++;
        row = sheet.createRow(countSheet);
        String[] valoresCabecalhoParteEstatica = {QTD_VOLUMETRIA_ATUAL, QTD_VOLUMETRIA_MEDIA};

        for (int i = 0; i < valoresCabecalhoParteEstatica.length; i++) {
            montarCelula(
                row, i, sheet, styleCabecalho, valoresCabecalhoParteEstatica[i]);
        }

        count = 0;
        countSheet++;
        row = sheet.createRow(countSheet);
        if (volumetriaTempoRealVolumetriaMaxima.getVolumetriaAtualTransacao() != null) {
            montarCelula(
                row, count, sheet, style,
                volumetriaTempoRealVolumetriaMaxima.getVolumetriaAtualTransacao().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "");
        }
        count++;

        if (volumetriaTempoRealVolumetriaMaxima.getMediaHistoricaTransacao() != null) {
            montarCelula(
                row, count, sheet, style,
                volumetriaTempoRealVolumetriaMaxima.getMediaHistoricaTransacao().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "");
        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    public Workbook excelCsvIndicador(List<IndicadoresNegocio> list, Object[] objectArray) {
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Indicador Negócio");

        geraCabecalhoExcel(wb, sheet, objectArray);

        int countSheet = INT8;
        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT0;

        String[] valoresCabecalho = {PRODUTO, CANAL, TOTAL_TRANSACOES, TRANSACOES_IMPACTADAS, PCT_TTRANSACOES,
            PCT_TTRANSACOES_IMPAC, QTD_EVENTOS, FREQ_EVENTOS, TT_EVENTOS, TM_EVENTOS, PCT_QTD_EVENTOS, PCT_FREQ_EVENT,
            PCT_TM_EVNT};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        count = 0;
        countSheet++;
        row = sheet.createRow(countSheet);

        for (int i = 0; i < list.size(); i++) {
            montarCelula(
                row, count, sheet, style,
                list.get(i).getProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getTotalTransacoes() + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getTransacoesImpactadas() + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getPorcentagemtotalTransacoes());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getPorcentagemtransacoesImpactadas());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getQtdEventos() + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getFrequenciaEventos() + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getTempoTotalEventos());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getTempoMedioEventos());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getPorcentagemqtdEventos());
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getFrequenciaEventos() + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                list.get(i).getTempoMedioEventos());

            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);
        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    public Workbook excelCsvRanking(List<ComboRankingEventos> listaComboRankingEventos, Integer periodo,
        Integer codigoPesquisa, Object[] objectArray) {
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Ranking");

        geraCabecalhoExcel(wb, sheet, objectArray);

        int countSheet = INT8;
        String periodoTempo = "";
        String param = "";

        if (periodo == 1) {
            periodoTempo = DIA;
        } else if (periodo == INT2) {
            periodoTempo = SEMANA;
        } else {
            periodoTempo = MES;
        }

        if (codigoPesquisa == 1) {
            param = "Maior Duração";
        } else if (codigoPesquisa == INT2) {
            param = "Maior Impacto";
        } else {
            param = "Maior Recorrência";
        }

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT0;

        String[] valoresCabecalho = {TOP_15, PRODUTO, CANAL, PERIODO,
            PARAMETRO, RECORRENCIA};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = 0; i < listaComboRankingEventos.size(); i++) {
            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                (i + 1) + "");
            count++;

            montarCelula(
                row, count, sheet, style,
                listaComboRankingEventos.get(i).getDescricaoProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaComboRankingEventos.get(i).getDescricaoCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                periodoTempo);
            count++;

            montarCelula(
                row, count, sheet, style,
                param);
            count++;

            if (listaComboRankingEventos.get(i).getRecorrencia() != null) {
                montarCelula(
                    row, count, sheet, style,
                    listaComboRankingEventos.get(i).getRecorrencia().toString());
            } else {
                montarCelula(
                    row, count, sheet, style,
                    "");
            }
        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        return wb;
    }

    private void geraCabecalhoExcel(Workbook wbIndNeg, Sheet sheet, Object[] objectArray) {
        Usuario usuarioIndNeg = new Usuario();
        String loginIndNeg = (String) objectArray[INT0];
        usuarioIndNeg.setLogin(loginIndNeg.toUpperCase());

        try {
            usuarioIndNeg = loginDao.obterInformacaoUsuario(usuarioIndNeg);

            CellStyle styleCabecalhoIndNeg = PlanilhaUtils.createStyleCabecalho(wbIndNeg);

            CellStyle styleIndNeg = PlanilhaUtils.createStyleBordaTotal(wbIndNeg);

            String valueEmptyIndNeg = " ";

            int countSheetIndNeg = INT0;
            Row rowIndNeg = sheet.createRow(countSheetIndNeg);
            int countIndNeg = INT0;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, "Usuário");
            countIndNeg++;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleIndNeg,
                usuarioIndNeg.getNome());
            countIndNeg = countIndNeg + INT2;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, "Versão de Central");
            countIndNeg++;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleIndNeg,
                "1.0");

            countIndNeg = INT0;
            countSheetIndNeg++;
            rowIndNeg = sheet.createRow(countSheetIndNeg);

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, "Data e hora Exp");
            countIndNeg++;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleIndNeg,
                toDate());

            countIndNeg = INT0;
            countSheetIndNeg = countSheetIndNeg + INT2;
            rowIndNeg = sheet.createRow(countSheetIndNeg);

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, "Filtros aplicados");
            countSheetIndNeg++;
            rowIndNeg = sheet.createRow(countSheetIndNeg);

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, CANAL);
            countIndNeg++;

            if (objectArray[INT4] != null) {
                List<BigDecimal> listaIndNeg = (List<BigDecimal>) objectArray[INT4];
                String canaisIndNeg = obterTextoCanal(listaIndNeg);
                montarCelula(
                    rowIndNeg, countIndNeg, sheet, styleIndNeg,
                    canaisIndNeg);
            } else {
                montarCelula(
                    rowIndNeg, countIndNeg, sheet, styleIndNeg,
                    valueEmptyIndNeg);
            }

            countIndNeg = INT0;
            countSheetIndNeg++;
            rowIndNeg = sheet.createRow(countSheetIndNeg);

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, PRODUTO);
            countIndNeg++;

            if (objectArray[INT4] != null) {
                List<BigDecimal> listaIndNeg = (List<BigDecimal>) objectArray[INT3];
                String produtosIndNeg = obterTextoProdutos(listaIndNeg);
                montarCelula(
                    rowIndNeg, countIndNeg, sheet, styleIndNeg,
                    produtosIndNeg);
            } else {
                montarCelula(
                    rowIndNeg, countIndNeg, sheet, styleIndNeg,
                    valueEmptyIndNeg);
            }

            countIndNeg = INT0;
            countSheetIndNeg++;
            rowIndNeg = sheet.createRow(countSheetIndNeg);

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleCabecalhoIndNeg, "Periodo");
            countIndNeg++;

            montarCelula(
                rowIndNeg, countIndNeg, sheet, styleIndNeg,
                "de " + objectArray[INT1] + " até " + objectArray[INT2]);
        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public ByteArrayInputStream pdfMonitorVisao(
        VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima,
        List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo, Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim,
        String login) {

        Document documentoIndNeg = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream outIndNeg = new ByteArrayOutputStream();

        try {

            String textoPeriodo = "";

            if (periodo == 1) {
                textoPeriodo = DIA;
            } else if (periodo == INT2) {
                textoPeriodo = SEMANA;
            } else {
                textoPeriodo = MES;
            }

            documentoIndNeg.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documentoIndNeg, outIndNeg);

            documentoIndNeg.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT9, BaseColor.BLACK);

            Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal};
            documentoIndNeg = montarCabecalhoPDF(documentoIndNeg, objectArray, font1, font2);

            documentoIndNeg = montarListaMonitorPDF(documentoIndNeg, obterVolumetriaTempoRealFaixaTempo, font1, font2,
                textoPeriodo);
            documentoIndNeg = montarTabelaMonitorPDF(documentoIndNeg, obterVolumetriaTempoRealVolumetriaMaxima, font1,
                font2);
            documentoIndNeg.close();

        } catch (AcessoADadosException eIndNeg) {
            LOGGER.error(Constantes.ERROR, eIndNeg);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException eIndNeg) {
            LOGGER.error(eIndNeg);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        } catch (DocumentException eIndNeg) {
            LOGGER.error(Constantes.ERROR, eIndNeg);
        }
        return new ByteArrayInputStream(outIndNeg.toByteArray());
    }

    private static Document montarTabelaMonitorPDF(Document documento,
        VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima, Font font1, Font font2) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INT2);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);

            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, QTD_VOLUMETRIA_ATUAL);
            cabecalhoConsulta.put(INT2, QTD_VOLUMETRIA_MEDIA);

            PdfPTable tabBodyItens = new PdfPTable(INT2);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);

            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_03);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (obterVolumetriaTempoRealVolumetriaMaxima != null) {

                tabBodyItens = addLinhaPDF(
                    obterVolumetriaTempoRealVolumetriaMaxima.getVolumetriaAtualTransacao().toString(),
                    tabBodyItens, font1);
                tabBodyItens = addLinhaPDF(
                    obterVolumetriaTempoRealVolumetriaMaxima.getMediaHistoricaTransacao().toString(),
                    tabBodyItens,
                    font1);
                tabBodyItens = addLinhaVazia(tabBodyItens, INT5, font1);
            }
            documento.add(tabBodyConsulta);
            if (obterVolumetriaTempoRealVolumetriaMaxima != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static Document montarListaMonitorPDF(Document documento,
        List<VolumetriaTempoReal> lista, Font font1, Font font2, String periodo) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INT5);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);

            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, PRODUTO);
            cabecalhoConsulta.put(INT2, CANAL);
            cabecalhoConsulta.put(INT3, PERIODO);
            cabecalhoConsulta.put(INT4, QTD_TRANS_EVENTOS);
            cabecalhoConsulta.put(INT5, QTD_TRANS_SEVENTOS);

            PdfPTable tabBodyItens = new PdfPTable(INT5);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);

            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_03);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (lista != null) {
                for (int i = INT0; i < lista.size(); i++) {
                    tabBodyItens = addLinhaPDF(
                        lista.get(i).getDescProduto(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaPDF(lista.get(i).getDescCanal(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(periodo,
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(lista.get(i).getTransacaoEvento().toString(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(lista.get(i).getTransacaoSemEvento().toString(),
                        tabBodyItens, font1);
                }
            }

            tabBodyItens.setSpacingAfter(INT10);

            documento.add(tabBodyConsulta);

            if (lista != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    public ByteArrayInputStream pdfIndicador(List<IndicadoresNegocio> obterIndicadoresNegocio,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim,
        String login) {

        Document documentoIndNeg = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream outIndNeg = new ByteArrayOutputStream();

        try {
            documentoIndNeg.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documentoIndNeg, outIndNeg);

            documentoIndNeg.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT9, BaseColor.BLACK);

            Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal};
            documentoIndNeg = montarCabecalhoPDF(documentoIndNeg, objectArray, font1, font2);

            documentoIndNeg = montarListaIndicadorPDF(documentoIndNeg, obterIndicadoresNegocio, font1, font2);
            documentoIndNeg.close();

        } catch (AcessoADadosException eIndNegIndicador) {
            LOGGER.error(Constantes.ERROR, eIndNegIndicador);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException eIndNegIndicador) {
            LOGGER.error(eIndNegIndicador);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        } catch (DocumentException eIndNegIndicador) {
            LOGGER.error(Constantes.ERROR, eIndNegIndicador);
        }
        return new ByteArrayInputStream(outIndNeg.toByteArray());
    }

    private static Document montarListaIndicadorPDF(Document documento, List<IndicadoresNegocio> obterIndicadoresNegocio,
        Font font1,
        Font font2) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INT13);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyConsulta.setWidthPercentage(INT_100);
            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, PRODUTO);
            cabecalhoConsulta.put(INT2, CANAL);
            cabecalhoConsulta.put(INT3, TOTAL_TRANSACOES);
            cabecalhoConsulta.put(INT4, TRANSACOES_IMPACTADAS);
            cabecalhoConsulta.put(INT5, PCT_TTRANSACOES);
            cabecalhoConsulta.put(INT6, PCT_TTRANSACOES_IMPAC);
            cabecalhoConsulta.put(INT7, QTD_EVENTOS);
            cabecalhoConsulta.put(INT8, FREQ_EVENTOS);
            cabecalhoConsulta.put(INT9, TT_EVENTOS);
            cabecalhoConsulta.put(INT10, TM_EVENTOS);
            cabecalhoConsulta.put(INT11, PCT_QTD_EVENTOS);
            cabecalhoConsulta.put(INT12, PCT_FREQ_EVENT);
            cabecalhoConsulta.put(INT13, PCT_TM_EVNT);

            PdfPTable tabBodyItens = new PdfPTable(INT13);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyItens.setWidthPercentage(INT_100);

            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_03);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (obterIndicadoresNegocio != null) {
                for (int i = INT0; i < obterIndicadoresNegocio.size(); i++) {
                    tabBodyItens = addLinhaPDF(
                        obterIndicadoresNegocio.get(i).getProduto(),
                        tabBodyItens, font1);

                    tabBodyItens = addLinhaPDF(
                        obterIndicadoresNegocio.get(i).getCanal(),
                        tabBodyItens, font1);

                    tabBodyItens = addLinhaPDF(
                        obterIndicadoresNegocio.get(i).getTotalTransacoes() + "",
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getTransacoesImpactadas() + "",
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getPorcentagemtotalTransacoes(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getPorcentagemtransacoesImpactadas(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getQtdEventos() + "",
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getFrequenciaEventos() + "",
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getTempoTotalEventos() + "",
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(obterIndicadoresNegocio.get(i).getTempoMedioEventos() + "",
                        tabBodyItens,
                        font1);
                    
                    auxilioMontagemLista(obterIndicadoresNegocio.get(i), tabBodyItens, font1);
                    
                }
            }

            documento.add(tabBodyConsulta);

            if (obterIndicadoresNegocio != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }    
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioMontagemLista(IndicadoresNegocio indicadoresNegocio, PdfPTable tabBodyItens,
        Font font1) {


        if (indicadoresNegocio.getPorcentagemqtdEventos() != null) {
            tabBodyItens = addLinhaPDF(indicadoresNegocio.getPorcentagemqtdEventos() + "",
                tabBodyItens,
                font1);
        } else {
            tabBodyItens = addLinhaPDF("",
                tabBodyItens,
                font1);
        }

        if (indicadoresNegocio.getPorcentagemqtdEventos() != null) {
            tabBodyItens = addLinhaPDF(indicadoresNegocio.getPorcentagemqtdEventos() + "",
                tabBodyItens,
                font1);
        } else {
            tabBodyItens = addLinhaPDF("",
                tabBodyItens,
                font1);
        }

        if (indicadoresNegocio.getPorcentagemtempoMedioEventos() != null) {
            tabBodyItens = addLinhaPDF(
                indicadoresNegocio.getPorcentagemtempoMedioEventos() + "",
                tabBodyItens,
                font1);
        } else {
            tabBodyItens = addLinhaPDF("",
                tabBodyItens,
                font1);
        }
    }

    public ByteArrayInputStream pdfRanking(List<ComboRankingEventos> obterRankingEventos, Integer periodo,
        Integer codigoPesquisa, List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim, String login) {
        Document documentoIndNeg = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream outIndNeg = new ByteArrayOutputStream();

        try {
            String textoPeriodo = "";
            String parametro = "";

            if (periodo == 1) {
                textoPeriodo = DIA;
            } else if (periodo == INT2) {
                textoPeriodo = SEMANA;
            } else {
                textoPeriodo = MES;
            }

            if (codigoPesquisa == 1) {
                parametro = "Maior Duração";
            } else if (codigoPesquisa == INT2) {
                parametro = "Maior Impacto";
            } else {
                parametro = "Maior Recorrência";
            }

            documentoIndNeg.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documentoIndNeg, outIndNeg);

            documentoIndNeg.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT9, BaseColor.BLACK);

            Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal};
            documentoIndNeg = montarCabecalhoPDF(documentoIndNeg, objectArray, font1, font2);
            documentoIndNeg.add(Chunk.NEWLINE);
            documentoIndNeg = montarListaRankingPDF(documentoIndNeg, obterRankingEventos, font1, font2, textoPeriodo,
                parametro);
            documentoIndNeg.close();

        } catch (AcessoADadosException eIndNegRanking) {
            LOGGER.error(Constantes.ERROR, eIndNegRanking);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException eIndNegRanking) {
            LOGGER.error(eIndNegRanking);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        } catch (DocumentException eIndNegRanking) {
            LOGGER.error(Constantes.ERROR, eIndNegRanking);
        }
        return new ByteArrayInputStream(outIndNeg.toByteArray());
    }

    private static Document montarListaRankingPDF(Document documento, List<ComboRankingEventos> listaRankingEventos,
        Font font1, Font font2, String periodo, String param) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INT6);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);

            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, TOP_15);
            cabecalhoConsulta.put(INT2, PRODUTO);
            cabecalhoConsulta.put(INT3, CANAL);
            cabecalhoConsulta.put(INT4, PERIODO);
            cabecalhoConsulta.put(INT5, PARAMETRO);
            cabecalhoConsulta.put(INT6, RECORRENCIA);

            PdfPTable tabBodyItens = new PdfPTable(INT6);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);

            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_03);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (listaRankingEventos != null) {
                for (int i = INT0; i < listaRankingEventos.size(); i++) {
                    tabBodyItens = addLinhaPDF(
                        (i + 1) + "",
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaPDF(listaRankingEventos.get(i).getDescricaoProduto(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(listaRankingEventos.get(i).getDescricaoCanal(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(periodo,
                        tabBodyItens,
                        font1);
                    tabBodyItens = addLinhaPDF(param,
                        tabBodyItens,
                        font1);
                    if (listaRankingEventos.get(i).getRecorrencia() != null) {
                        tabBodyItens = addLinhaPDF(listaRankingEventos.get(i).getRecorrencia().toString(),
                            tabBodyItens, font1);
                    } else {
                        tabBodyItens = addLinhaPDF("",
                            tabBodyItens, font1);
                    }
                }
            }

            documento.add(tabBodyConsulta);

            if (listaRankingEventos != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }
}
