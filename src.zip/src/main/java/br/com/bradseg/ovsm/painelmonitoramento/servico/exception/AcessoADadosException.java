package br.com.bradseg.ovsm.painelmonitoramento.servico.exception;

public class AcessoADadosException extends RuntimeException {

    public AcessoADadosException(String message) {
        super(message);
    }

    public AcessoADadosException(Throwable t) {
        super(t);
    }

}
