package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

public class PainelMonitoramentoAtualResponse extends ResponseMensagem{
    
    private PainelMonitoramentoAtual painel;
    
    public PainelMonitoramentoAtualResponse() {
        super();
    }

    public PainelMonitoramentoAtual getPainel() {
        return painel;
    }

    public void setPainel(PainelMonitoramentoAtual painel) {
        this.painel = painel;
    }
    
    
}
