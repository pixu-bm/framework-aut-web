package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConfiguracaoIntervaloProcessamentoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConfiguracaoIntervaloProcessamentoService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.sql.SQLException;

/**
 * Configuração de intervalo processamento service.
 * 
 * @author Wipro
 */
@Service
public class ConfiguracaoIntervaloProcessamentoServiceImpl
    implements ConfiguracaoIntervaloProcessamentoService {

    private ConfiguracaoIntervaloProcessamentoDao configuracaoIntervaloProcessamentoDao;

    private LoginDao loginDao;

    private static final Log LOGGER = LogFactory
        .getLog(ConfiguracaoIntervaloProcessamentoServiceImpl.class);

    @Autowired
    public ConfiguracaoIntervaloProcessamentoServiceImpl(
        ConfiguracaoIntervaloProcessamentoDao configuracaoIntervaloProcessamentoDao,
        LoginDao loginDao) {
        this.configuracaoIntervaloProcessamentoDao = configuracaoIntervaloProcessamentoDao;
        this.loginDao = loginDao;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public ConfiguracaoIntervaloProcessamentoResponse obterConfiguracaoIntervaloProcessamento(
        BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal) throws SQLException {
        try {

            return configuracaoIntervaloProcessamentoDao
                .obterConfiguracaoIntervaloProcessamento(codigoEmpresa,
                    codigoProduto, codigoCanal);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void validarParametroConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest) {

        Assert.notNull(configuracaoIntervaloProcessamentoRequest,
            "É obrigatório enviar parametros de configuração intervalo de processamento.");
        Assert.notNull(configuracaoIntervaloProcessamentoRequest.getLogin(),
            "É obrigatório preencher o login");
        Assert.notNull(
            configuracaoIntervaloProcessamentoRequest.getCodigoEmpresa(),
            "É obrigatório preencher código de empresa");
        Assert.notNull(
            configuracaoIntervaloProcessamentoRequest.getCodigoProduto(),
            "É obrigatório preencher código de produto");
        Assert.notNull(
            configuracaoIntervaloProcessamentoRequest.getDataVigenciaInicio(),
            "É obrigatório preencher data inicio de vigencia");
        Assert.notNull(
            Utils.strDateFmtBrasilToJavaDate(
                configuracaoIntervaloProcessamentoRequest
                    .getDataVigenciaInicio()),
            "Formato de data tem que ser dd/MM/yyyy");

    }

    /**
     * {@inheritDoc}
     */
    public void inserirConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento)
        throws SQLException {
        try {
            Usuario usuario = new Usuario();
            usuario.setLogin(configuracaoIntervaloProcessamento.getLogin());
            usuario = loginDao.obterInformacaoUsuario(usuario);

            configuracaoIntervaloProcessamento
                .setNumeroInternoConfiguracaoIntervalo(
                    usuario.getNumeroInternoUsuario());

            if (Boolean.TRUE.equals(configuracaoIntervaloProcessamentoDao
                .verificarConfiguracaoIntervaloProcessamento(
                    configuracaoIntervaloProcessamento))) {
                configuracaoIntervaloProcessamentoDao
                    .inserirConfiguracaoIntervaloProcessamento(
                        configuracaoIntervaloProcessamento);
            } else {
                configuracaoIntervaloProcessamentoDao.atualizarDataFimVigencia(
                    configuracaoIntervaloProcessamento);
                configuracaoIntervaloProcessamentoDao
                    .inserirConfiguracaoIntervaloProcessamento(
                        configuracaoIntervaloProcessamento);
            }
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new EmptyResultDataAccessException("Login não existente.", 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public ParametroEvento obterParametroEvento(BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException {
        try {
            return configuracaoIntervaloProcessamentoDao.obterParametroEvento(
                codigoEmpresa, codigoProduto,
                codigoCanal);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarParametroEvento(ParametroEventoRequest parametroEvento)
        throws SQLException {
        try {

            if (Boolean.TRUE.equals(configuracaoIntervaloProcessamentoDao
                .verificarParametroEventoExiste(
                    parametroEvento.getCodigoEmpresa(),
                    parametroEvento.getCodigoProduto(),
                    parametroEvento.getCodigoCanal()))) {

                configuracaoIntervaloProcessamentoDao
                    .atualizarDataFimVigenciaParametroEvento(
                        parametroEvento.getCodigoEmpresa(),
                        parametroEvento.getCodigoProduto(),
                        parametroEvento.getCodigoCanal());
                configuracaoIntervaloProcessamentoDao
                    .inserirParametroEvento(parametroEvento);
            } else {
                configuracaoIntervaloProcessamentoDao
                    .inserirParametroEvento(parametroEvento);
            }

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new DataIntegrityViolationException(
                Constantes.ERRO_DE_VIOLACAO_DE_INTEGRIDADE);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public void validarParametroEvento(ParametroEventoRequest parametroEvento) {
        Assert.notNull(parametroEvento,
            "É obrigatório preencher parametro evento.");
        Assert.notNull(parametroEvento.getCodigoEmpresa(),
            "É obrigatório preencher o codigo empresa.");
        Assert.notNull(parametroEvento.getCodigoProduto(),
            "É obrigatório preencher o codigo produto.");
        Assert.notNull(parametroEvento.getCodigoCanal(),
            "É obrigatório preencher o codigo canal.");
        Assert.notNull(
            parametroEvento.getParametroEvento().getQuantidadeTransacaoOnline(),
            "É obrigatório preencher quantidade transação online.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeTransacaoOffline(),
            "É obrigatório preencher quantidade transação offline.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMinimaEventoModerado(),
            "É obrigatório preencher quantidade minima evento moderado.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMaximaEventoModerado(),
            "É obrigatório preencher quantidade maxima evento moderado.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMinimaEventoAlto(),
            "É obrigatório preencher quantidade minima evento alto.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMaximaEventoAlto(),
            "É obrigatório preencher quantidade maxima evento alto.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMinimaEventoVolumeModerado(),
            "É obrigatório preencher quantidade minima evento volume moderado.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMaximaEventoVolumeModerado(),
            "É obrigatório preencher quantidade maxima evento volume moderado.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMinimaEventoVolumeAlto(),
            "É obrigatório preencher quantidade minima evento volume alto.");
        
        validarComplementoParametroEvento(parametroEvento);
    }
    
    private static void validarComplementoParametroEvento(ParametroEventoRequest parametroEvento) {
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMaximaEventoVolumeAlto(),
            "É obrigatório preencher quantidade maxima evento volume alto.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeLimiteEventoVolumeBemBaixo(),
            "É obrigatório preencher quantidade limite evento volume bem baixo.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMetricaEventoVolume(),
            "É obrigatório preencher quantidade metrica evento volume.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeLimiteEventoFuncionalidadeBemBaixo(),
            "É obrigatório preencher quantidade limite evento funcionalidade bem baixo.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMetricaEventoFuncionalidade(),
            "É obrigatório preencher quantidade metrica evento funcionalidade.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeLimiteEventoImpactoBemBaixo(),
            "É obrigatório preencher quantidade limite evento impacto bem baixo.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeMetricaEventoImpacto(),
            "É obrigatório preencher quantidade metrica evento impacto bem baixo.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeLimiteSegundoEventoBemBaixo(),
            "É obrigatório preencher quantidade limite em segundos evento bem baixo.");
        Assert.notNull(
            parametroEvento.getParametroEvento()
                .getQuantidadeSegundoExecucaoEvento(),
            "É obrigatório preencher quantidade em segundos execução evento.");
    }

}
