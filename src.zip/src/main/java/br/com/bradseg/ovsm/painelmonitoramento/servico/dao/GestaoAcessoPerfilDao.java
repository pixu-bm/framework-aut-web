package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * Gestao acesso perfil interface
 *
 * @author Wipro
 */
public interface GestaoAcessoPerfilDao {

    /**
     * Listar todos os perfis de usuario do sistema
     *
     * @return List<PerfilUsuario>
     * @throws SQLException
     */
    List<PerfilUsuario> listarPerfilUsuario() throws SQLException;

    /**
     * Listar usuario para gestao de acesso.
     *
     * @param usuario Usuario
     * @return List<Usuario>
     * @throws SQLException
     */
    List<Usuario> listarUsuario(Usuario usuario) throws SQLException;

    /**
     * Atualizar usuário status perfil para gestão de acesso.
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    void atualizarStatusPerfilUsuario(Usuario usuario) throws SQLException;

    /**
     * Obter listar funcionalidade perfil
     *
     * @param perfil String
     * @return List<Funcionalidade>
     * @throws SQLException
     */
    List<Funcionalidade> obterListaFuncionalidadePerfil(String perfil) throws SQLException;

    /**
     * Obter listar funcionalidade cadastradas
     *
     * @param perfil String
     * @return List<Funcionalidade>
     * @throws SQLException
     */
    List<Funcionalidade> obterListaFuncionalidade() throws SQLException;

    /**
     * Obtem numero usuario cancelado ou rejeitado
     *
     * @param numeroUsuario BigDecimal
     * @return BigDecimal
     * @throws SQLException
     */
    BigDecimal obterNumeroUsuarioCanceladoRejeitado(BigDecimal numeroUsuario) throws SQLException;

    /**
     * Obtem numero de usuario
     *
     * @param usuario Usuario
     * @return BigDecimal
     * @throws SQLException
     */
    BigDecimal obterNumeroUsuario(Usuario usuario) throws SQLException;

    /**
     * Inserir usuario cancelado
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    void inserirUsuarioCancelado(Usuario usuario) throws SQLException;

    /**
     * Atualizar usuario cancelado
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    void atualizarUsuarioCancelado(Usuario usuario) throws SQLException;

    /**
     * Remover perfil funcionalidade
     *
     * @param usuario
     * @throws SQLException
     */
    void removerPerfilFuncionalidade(Usuario usuario) throws SQLException;

    /**
     * Insrir funcionalidade para perfil sistema OVSM
     *
     * @param usuario
     * @throws SQLException
     */
    void inserirPerfilFuncionalidade(Usuario usuario) throws SQLException;
}
