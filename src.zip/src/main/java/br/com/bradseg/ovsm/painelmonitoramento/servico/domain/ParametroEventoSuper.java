package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

public class ParametroEventoSuper {

    private Integer quantidadeMetricaEventoVolume;
    private Integer quantidadeLimiteEventoFuncionalidadeBemBaixo;
    private Integer quantidadeMetricaEventoFuncionalidade;
    private Integer quantidadeLimiteEventoImpactoBemBaixo;
    private Integer quantidadeMetricaEventoImpacto;
    private Integer quantidadeLimiteSegundoEventoBemBaixo;
    private Integer quantidadeSegundoExecucaoEvento;

    public ParametroEventoSuper() {
        super();
    }

    public Integer getQuantidadeMetricaEventoVolume() {
        return quantidadeMetricaEventoVolume;
    }

    public void setQuantidadeMetricaEventoVolume(Integer quantidadeMetricaEventoVolume) {
        this.quantidadeMetricaEventoVolume = quantidadeMetricaEventoVolume;
    }

    public Integer getQuantidadeLimiteEventoFuncionalidadeBemBaixo() {
        return quantidadeLimiteEventoFuncionalidadeBemBaixo;
    }

    public void setQuantidadeLimiteEventoFuncionalidadeBemBaixo(Integer quantidadeLimiteEventoFuncionalidadeBemBaixo) {
        this.quantidadeLimiteEventoFuncionalidadeBemBaixo = quantidadeLimiteEventoFuncionalidadeBemBaixo;
    }

    public Integer getQuantidadeMetricaEventoFuncionalidade() {
        return quantidadeMetricaEventoFuncionalidade;
    }

    public void setQuantidadeMetricaEventoFuncionalidade(Integer quantidadeMetricaEventoFuncionalidade) {
        this.quantidadeMetricaEventoFuncionalidade = quantidadeMetricaEventoFuncionalidade;
    }

    public Integer getQuantidadeLimiteEventoImpactoBemBaixo() {
        return quantidadeLimiteEventoImpactoBemBaixo;
    }

    public void setQuantidadeLimiteEventoImpactoBemBaixo(Integer quantidadeLimiteEventoImpactoBemBaixo) {
        this.quantidadeLimiteEventoImpactoBemBaixo = quantidadeLimiteEventoImpactoBemBaixo;
    }

    public Integer getQuantidadeMetricaEventoImpacto() {
        return quantidadeMetricaEventoImpacto;
    }

    public void setQuantidadeMetricaEventoImpacto(Integer quantidadeMetricaEventoImpacto) {
        this.quantidadeMetricaEventoImpacto = quantidadeMetricaEventoImpacto;
    }

    public Integer getQuantidadeLimiteSegundoEventoBemBaixo() {
        return quantidadeLimiteSegundoEventoBemBaixo;
    }

    public void setQuantidadeLimiteSegundoEventoBemBaixo(Integer quantidadeLimiteSegundoEventoBemBaixo) {
        this.quantidadeLimiteSegundoEventoBemBaixo = quantidadeLimiteSegundoEventoBemBaixo;
    }

    public Integer getQuantidadeSegundoExecucaoEvento() {
        return quantidadeSegundoExecucaoEvento;
    }

    public void setQuantidadeSegundoExecucaoEvento(Integer quantidadeSegundoExecucaoEvento) {
        this.quantidadeSegundoExecucaoEvento = quantidadeSegundoExecucaoEvento;
    }
}
