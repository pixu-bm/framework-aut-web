package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Visao evento produto row mapper
 * 
 * @author Wipro
 */
public class VisaoGeralProdutoRowMapper implements RowMapper<VisaoGeralProduto> {

    public VisaoGeralProduto mapRow(ResultSet rs, int rowNum) throws SQLException {

        VisaoGeralProduto visao = new VisaoGeralProduto();

        visao.setCodigoProduto(rs.getBigDecimal("CPRODT_PNEL"));
        visao.setDescricaoProduto(rs.getString("IPRODT"));
        visao.setEventoGrave(rs.getInt("SOMA_EVENTO_GRAVE"));
        visao.setEventoModerado(rs.getInt("SOMA_EVENTO_MODERADO"));
        visao.setEventoVolumetria(rowNum);
        visao.setEventoVolumetria(rs.getInt("SOMA_EVENTO_VOLUMETRIA"));
        visao.setEventoDisponibilidade(rs.getInt("SOMA_EVENTO_DISP"));
        visao.setEventoFuncional(rs.getInt("SOMA_EVENTO_FUNC"));
        visao.setNumeroImpacto(rs.getInt("SOMA_TRANSACAO"));

        return visao;
    }
}
