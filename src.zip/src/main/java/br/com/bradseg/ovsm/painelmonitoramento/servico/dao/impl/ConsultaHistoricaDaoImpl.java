package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConsultaHistoricaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ConsultaHistoricaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

@Repository
public class ConsultaHistoricaDaoImpl implements ConsultaHistoricaDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaHistoricaDaoImpl.class);
    private static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final int HORA = 3600;
    private static final int MIN_SEC = 60;
    private static final String AND_CCANAL_DGTAL_PNEL_IN = " AND T.CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_TQTRANS_EXECT_INSUC = " AND T.QTRANS_EXECT_INSUC ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO_IN = " AND T.CPRODT_PNEL IN ( ";
    private static final String QUERY_PRINCIPAL = "SELECT "
        + " T.CTPO_EVNTO_PNEL AS COD_EVENTO, "
        + " T2.ISIT_EVNTO_PNEL AS GRAVIDADE, "
        + " T4.IPRODT AS PRODUTO, "
        + " T5.ICANAL_DGTAL_PNEL AS CANAL, "
        + " T6.ITPO_EVNTO_PNEL AS TIPO_EVENTO, "
        + " T.QTRANS_EXECT_INSUC AS TRANSACOES_IMPACTADAS, "
        + " (T.DFIM_ERRO_FUNCL - T.DINIC_ERRO_FUNCL) * 24 * 60 * 60 AS DIFF_FUNCL, "
        + " (T.DFIM_ERRO_DISPN - T.DINIC_ERRO_DISPN) * 24 * 60 * 60 AS DIFF_DISPN, "
        + " (T.DFIM_ERRO_VOLUM - T.DINIC_ERRO_VOLUM) * 24 * 60 * 60 AS DIFF_VOLUM, "
        + " T.DPROCS_APLIC AS DATA_REG "
        + " FROM " + Constantes.OWNER_TABELA + "PNEL_MNTTO_CNXAO T "
        + Constantes.JOIN + Constantes.OWNER_TABELA + "SIT_EVNTO_PNEL T2 "
        + "   ON T.CSIT_DISPN = T2.CSIT_EVNTO_PNEL "
        + "   AND T.CSIT_FUNCL = T2.CSIT_EVNTO_PNEL "
        + "   AND T.CSIT_VOLUM = T2.CSIT_EVNTO_PNEL "
        + Constantes.JOIN + Constantes.OWNER_TABELA + "RCRRC_EVNTO T3 "
        + "   ON T.CEMPR_PNEL = T3.CEMPR_PNEL "
        + "   AND T.CPRODT_PNEL = T3.CPRODT_PNEL "
        + "   AND T.CCANAL_DGTAL_PNEL = T3.CCANAL_DGTAL_PNEL "
        + Constantes.JOIN + Constantes.OWNER_TABELA + "PRODT_PNEL T4 "
        + "   ON T.CPRODT_PNEL = T4.CPRODT_PNEL "
        + Constantes.JOIN + Constantes.OWNER_TABELA + "CANAL_DGTAL_PNEL T5 "
        + "   ON T.CCANAL_DGTAL_PNEL = T5.CCANAL_DGTAL_PNEL "
        + Constantes.JOIN + Constantes.OWNER_TABELA + "TPO_EVNTO_PNEL T6 "
        + "   ON T.CTPO_EVNTO_PNEL = T6.CTPO_EVNTO_PNEL ";
    private static final String SELECT_RECORRENCIA = "SELECT "
        + " T.CTPO_EVNTO_PNEL AS COD_EVENTO, "
        + " SUM(T3.QRCRRC_ERRO_EVNTO) AS RECORRENCIA "
        + " FROM OVSM.PNEL_MNTTO_CNXAO T "
        + " JOIN OVSM.RCRRC_EVNTO T3 "
        + "    ON T.CEMPR_PNEL = T3.CEMPR_PNEL "
        + "    AND T.CPRODT_PNEL = T3.CPRODT_PNEL "
        + "    AND T.CCANAL_DGTAL_PNEL = T3.CCANAL_DGTAL_PNEL "
        + " WHERE DPROCS_APLIC >= SYSTIMESTAMP - 30 "
        + "    AND DPROCS_APLIC <= SYSTIMESTAMP "
        + " GROUP BY T.CTPO_EVNTO_PNEL ";
    
    private static final int INT_2 = 2;

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaHistoricaDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<ConsultaHistorica> obterHistorico(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento, Integer freqMin, Integer freqMax,
        String duracaoMin, String duracaoMax, Integer transacaoMin, Integer transacaoMax, String nomeServico,
        String dataInicio, String dataFim) throws SQLException {
        try {

            StringBuilder sql = new StringBuilder(QUERY_PRINCIPAL);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (Utils.strDateFmtBrasilToJavaDate(dataInicio) != null) {
                sql.append("WHERE T.DPROCS_APLIC >= :dataInicio  ");
                params.addValue("dataInicio", Utils.strDateFmtBrasilToJavaDate(dataInicio));
            }

            if (Utils.strDateFmtBrasilToJavaDate(dataFim) != null) {
                sql.append("AND T.DPROCS_APLIC <= :dataFim  ");
                params.addValue("dataFim", Utils.strDateFmtBrasilToJavaDate(dataFim));
            }

            sql.append(filtroListas(listaCodigoProduto, AND_CPRODT_PNEL_CODIGO_PRODUTO_IN));

            sql.append(filtroListas(listaCodigoCanal, AND_CCANAL_DGTAL_PNEL_IN));

            sql.append(filtroListaTipoEvento(listTipoEvento));

            if (checkStrings(duracaoMin)) {
                sql.append(" AND (T.DFIM_ERRO_FUNCL - T.DINIC_ERRO_FUNCL) * 24 * 60 * 60 >= :duracaoMin "
                    + " OR (T.DFIM_ERRO_DISPN - T.DINIC_ERRO_DISPN) * 24 * 60 * 60 >= :duracaoMin "
                    + " OR (T.DFIM_ERRO_VOLUM - T.DINIC_ERRO_VOLUM) * 24 * 60 * 60 >= :duracaoMin ");
                params.addValue("duracaoMin", converteParaSegundos(duracaoMin));
            }

            if (checkStrings(duracaoMax)) {
                sql.append(" AND (T.DFIM_ERRO_FUNCL - T.DINIC_ERRO_FUNCL) * 24 * 60 * 60 <= :duracaoMax "
                    + " OR (T.DFIM_ERRO_DISPN - T.DINIC_ERRO_DISPN) * 24 * 60 * 60 <= :duracaoMax "
                    + " OR (T.DFIM_ERRO_VOLUM - T.DINIC_ERRO_VOLUM) * 24 * 60 * 60 <= :duracaoMax ");
                params.addValue("duracaoMax", converteParaSegundos(duracaoMax));
            }

            if (transacaoMin != null) {
                sql.append(AND_TQTRANS_EXECT_INSUC + " >= :transacaoMin");
                params.addValue("transacaoMin", transacaoMin);
            }

            if (transacaoMax != null) {
                sql.append(AND_TQTRANS_EXECT_INSUC + " <= :transacaoMax");
                params.addValue("transacaoMax", transacaoMax);
            }

            if (checkStrings(nomeServico)) {
                sql.append("AND T.IAPI_ORIGE = :api");
                params.addValue("api", nomeServico);
            }

            return obterFrequencia(freqMin, freqMax,
                jdbcTemplate.queryForObject(sql.toString(),
                    params, new ConsultaHistoricaRowMapper()));

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException("Nenhum dado encontrado", 0);
        }
    }

    private static boolean checkStrings(String str) {
        if (str != null && !"".equalsIgnoreCase(str)) {
            return true;
        } else {
            return false;
        }
    }

    private static String filtroListaTipoEvento(List<BigDecimal> lista) {
        if (lista != null && !lista.isEmpty()) {

            StringBuilder texto = new StringBuilder();
            texto.append(lista.get(0).toString());
            for (int i = 0; i < lista.size(); i++) {
                if (lista.get(i).intValue() == 1) {
                    texto.append(" AND (T.QEVNTO_GRAVE_FUNCL > 0 "
                        + "    OR T.QEVNTO_MRADO_FUNCL > 0) ");
                } else if (lista.get(i).intValue() == INT_2) {
                    texto.append(" AND (T.QEVNTO_GRAVE_VOLUM > 0 "
                        + " OR T.QEVNTO_MRADO_VOLUM > 0) ");
                } else {
                    texto.append(" AND (T.QEVNTO_GRAVE_DISPN > 0 "
                        + " OR T.QEVNTO_MRADO_DISPN > 0) ");
                }
            }
            return texto.toString();
        }
        return "";
    }

    private static String filtroListas(List<BigDecimal> lista, String queryString) {
        if (lista != null && !lista.isEmpty()) {

            StringBuilder textoProduto = new StringBuilder();
            textoProduto.append(lista.get(0).toString());
            for (int i = 0; i < lista.size(); i++) {

                textoProduto.append(",");
                textoProduto.append(lista.get(i).toString());
            }
            return queryString + textoProduto.toString() + " )";
        }
        return "";
    }

    private static double converteParaSegundos(String duracao) {
        double resultado = 0.0;
        String[] array = duracao.split(":");
        for (int i = 0; i < array.length; i++) {
            if (i == 0) {
                resultado += Double.parseDouble(array[0]) * HORA;
            } else if (i == 1) {
                resultado += Double.parseDouble(array[1]) * MIN_SEC;
            } else {
                resultado += Double.parseDouble(array[INT_2]) * MIN_SEC;
            }
        }
        return resultado;
    }

    private List<ConsultaHistorica> obterFrequencia(Integer freqMin, Integer freqMax, List<ConsultaHistorica> lista) {

        StringBuilder sql = new StringBuilder(SELECT_RECORRENCIA);
        MapSqlParameterSource params = new MapSqlParameterSource();

        List<Map<String, Object>> listaResult = jdbcTemplate.queryForList(sql.toString(), params);

        for (ConsultaHistorica element : lista) {
            for (int j = 0; j < listaResult.size(); j++) {
                Map<String, Object> mapa = listaResult.get(j);
                if (element.getCodigoEvento().equals((BigDecimal) mapa.get("COD_EVENTO"))) {
                    element.setRecorrencia((BigDecimal) mapa.get("RECORRENCIA"));
                }
            }
        }

        if (freqMin != null) {
            return filtroFrequencia(lista, freqMin, freqMax);
        }

        return lista;
    }

    private List<ConsultaHistorica> filtroFrequencia(List<ConsultaHistorica> lista, Integer freqMin, Integer freqMax) {

        List<ConsultaHistorica> listaFreqMin = new ArrayList<>();

        for (ConsultaHistorica element : lista) {
            if (element.getCodigoEvento().intValue() >= freqMin) {
                listaFreqMin.add(element);
            }
        }

        if (freqMax != null) {
            return filtroFrequenciMax(lista, freqMax);
        } else {
            return listaFreqMin;
        }
    }

    private static List<ConsultaHistorica> filtroFrequenciMax(List<ConsultaHistorica> lista, Integer freqMax) {

        List<ConsultaHistorica> listaFinal = new ArrayList<>();

        for (ConsultaHistorica element : lista) {
            if (element.getCodigoEvento().intValue() <= freqMax) {
                listaFinal.add(element);
            }
        }

        return listaFinal;

    }

}
