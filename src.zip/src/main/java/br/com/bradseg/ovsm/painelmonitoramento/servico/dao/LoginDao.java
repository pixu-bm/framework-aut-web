package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;

import java.sql.SQLException;
import java.util.List;

/**
 * Interface para acesso base de dados para tabela de Usuarios
 *
 * @author Wipro
 */
public interface LoginDao {

    /**
     * Valida se login existe na Base.
     *
     * @param usuario
     */
    Boolean validarLogin(Usuario usuario);

    /**
     * Verificar se aquele usuario é existente na base de dados
     *
     * @param usuario Usuario
     * @return Boolean
     */
    String obterTipoUsuario(Usuario usuario);

    /**
     * Carregar todas as informações pertinentes de usuario
     *
     * @param usuario Usuario
     * @return Usuario
     */
    Usuario obterInformacaoUsuario(Usuario usuario) throws SQLException;
    
    /**
     * Obter informação usuarios master adm
     *
     * @return Usuario
     */
    List<Usuario> obterInformacaoUsuariosMasterAdm() throws SQLException;

    /**
     * Inserir usuario com pendencia de aprovação para solicitação de acesso.
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    void inserirUsuarioAprovacao(Usuario usuario) throws SQLException;

    /**
     * Lista de empresa usuário cadastradas para acesso de usuario
     *
     * @return List<EmpresaUsuario>
     * @throws SQLException
     */
    List<EmpresaUsuario> listarEmpresaUsuario() throws SQLException;

    /**
     * Listar departamento usuário associado a uma empresa
     *
     * @param codigoEmpresa String
     * @return List<DepartamentoUsuario>
     * @throws SQLException
     */
    List<DepartamentoUsuario> listarDepartamentoUsuario(String codigoEmpresa) throws SQLException;

    /**
     * Validar se empresa do usuário existe na base de dados.
     *
     * @param codigoEmpresa String
     * @return Boolean
     * @throws SQLException
     */
    Boolean validarEmpresaUsuario(String codigoEmpresa) throws SQLException;

    /**
     * Valida se usuario pode aprovar requisições de solicitação de acesso.
     *
     * @param usuario Usuario
     * @return Boolean
     * @throws SQLException
     */
    Boolean validarLoginAprovador(Usuario usuario) throws SQLException;

    void inserirEmpresaUsuario(Usuario usuario) throws SQLException;

    void inserirDepartamentoUsuario(Usuario usuario) throws SQLException;

    Boolean validarDepartamentoUsuario(String codigoDepartamento) throws SQLException;
}
