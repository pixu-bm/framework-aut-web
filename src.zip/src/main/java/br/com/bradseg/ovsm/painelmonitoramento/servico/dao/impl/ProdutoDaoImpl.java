package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ProdutoDaoImpl Classe implementador acesso a base de dados.
 *
 * @author Wipro
 */
@Repository
public class ProdutoDaoImpl implements ProdutoDao {

    private static final Logger LOGGER = LogManager.getLogger(ProdutoDaoImpl.class);

    private NamedParameterJdbcTemplate jdbcTemplate;

    private static final String SELECT_PRODUTO = "SELECT CPRODT_PNEL , IPRODT FROM " + Constantes.OWNER_TABELA
        + "PRODT_PNEL";

    @Autowired
    public ProdutoDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public List<Produto> listarProduto() {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_PRODUTO, new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado não pode ser vazio", 1);
            }

            List<Produto> listaProduto = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Produto produto = new Produto();
                produto.setCodigo((BigDecimal) mapa.get("CPRODT_PNEL"));
                produto.setDescricao((String) mapa.get("IPRODT"));

                listaProduto.add(produto);
            }

            return listaProduto;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

}
