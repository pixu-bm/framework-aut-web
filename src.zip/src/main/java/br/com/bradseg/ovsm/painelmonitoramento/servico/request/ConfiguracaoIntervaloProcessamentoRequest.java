package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

import java.math.BigDecimal;

/**
 * Configuração de intervalo de processamento de requisição.
 * @author Wipro
 */
public class ConfiguracaoIntervaloProcessamentoRequest {

    private String login;
    private BigDecimal codigoEmpresa;
    private BigDecimal codigoCanal;
    private Integer quantidadeMinutoIntervaloNormal;
    private Integer quantidadeMinutoIntervaloErro;
    private BigDecimal codigoProduto;
    private String dataVigenciaInicio;

    public ConfiguracaoIntervaloProcessamentoRequest() {
        super();
    }

    public String getLogin() {
        return login;
    }

    public void setQuantidadeMinutoIntervaloErro(Integer quantidadeMinutoIntervaloErro) {
        this.quantidadeMinutoIntervaloErro = quantidadeMinutoIntervaloErro;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public Integer getQuantidadeMinutoIntervaloErro() {
        return quantidadeMinutoIntervaloErro;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public void setQuantidadeMinutoIntervaloNormal(Integer quantidadeMinutoIntervaloNormal) {
        this.quantidadeMinutoIntervaloNormal = quantidadeMinutoIntervaloNormal;
    }

    public Integer getQuantidadeMinutoIntervaloNormal() {
        return quantidadeMinutoIntervaloNormal;
    }

    public String getDataVigenciaInicio() {
        return dataVigenciaInicio;
    }

    public void setDataVigenciaInicio(String dataVigenciaInicio) {
        this.dataVigenciaInicio = dataVigenciaInicio;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }
}
