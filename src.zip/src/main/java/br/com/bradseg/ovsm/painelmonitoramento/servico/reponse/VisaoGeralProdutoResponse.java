package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;

/**
 * Visao geral de produto response
 * 
 * @author Wipro
 */
public class VisaoGeralProdutoResponse extends ResponseMensagem {

    private VisaoGeralProduto visaoGeralProduto;

    public VisaoGeralProdutoResponse() {
        super();
    }

    public VisaoGeralProduto getVisaoGeralProduto() {
        return visaoGeralProduto;
    }

    public void setVisaoGeralProduto(VisaoGeralProduto visaoGeralProduto) {
        this.visaoGeralProduto = visaoGeralProduto;
    }

}
