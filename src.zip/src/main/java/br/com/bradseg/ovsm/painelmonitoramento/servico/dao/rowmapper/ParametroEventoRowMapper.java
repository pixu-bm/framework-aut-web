package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ParametroEventoRowMapper implements RowMapper<ParametroEvento> {

    public ParametroEvento mapRow(ResultSet rs, int rowNum) throws SQLException {

        ParametroEvento parametroEvento = new ParametroEvento();
        parametroEvento.setQuantidadeTransacaoOnline(rowNum);
        parametroEvento.setQuantidadeTransacaoOnline(rs.getInt("QTRANS_ONLINE"));
        parametroEvento.setQuantidadeTransacaoOffline(rs.getInt("QTRANS_OFLIN"));
        parametroEvento.setQuantidadeMinimaEventoModerado(rs.getInt("QMIN_EVNTO_MRADO"));
        parametroEvento.setQuantidadeMaximaEventoModerado(rs.getInt("QMAX_EVNTO_MRADO"));
        parametroEvento.setQuantidadeMinimaEventoAlto(rs.getInt("QMIN_EVNTO_ALTA"));
        parametroEvento.setQuantidadeMaximaEventoAlto(rs.getInt("QMAX_EVNTO_ALTA"));
        parametroEvento.setQuantidadeMinimaEventoVolumeModerado(rs.getInt("QMIN_EVNTO_VOLUM_MRADO"));
        parametroEvento.setQuantidadeMaximaEventoVolumeModerado(rs.getInt("QMAX_EVNTO_VOLUM_MRADO"));
        parametroEvento.setQuantidadeMinimaEventoVolumeAlto(rs.getInt("QMIN_EVNTO_VOLUM_ALTA"));
        parametroEvento.setQuantidadeMaximaEventoVolumeAlto(rs.getInt("QMAX_EVNTO_VOLUM_ALTA"));
        parametroEvento.setQuantidadeLimiteEventoVolumeBemBaixo(rs.getInt("QLIM_EVNTO_VOLUM_BEM_BAIXO"));
        parametroEvento.setQuantidadeMetricaEventoVolume(rs.getInt("QMETA_EVNTO_VOLUM"));
        parametroEvento.setQuantidadeLimiteEventoFuncionalidadeBemBaixo(rs.getInt("QLIM_EVNTO_FUNCL_BEM_BAIXO"));
        parametroEvento.setQuantidadeMetricaEventoFuncionalidade(rs.getInt("QMETA_EVNTO_FUNCL"));
        parametroEvento.setQuantidadeLimiteEventoImpactoBemBaixo(rs.getInt("QLIM_EVNTO_IPACT_BEM_BAIXO"));
        parametroEvento.setQuantidadeMetricaEventoImpacto(rs.getInt("QMETA_EVNTO_IPACT"));
        parametroEvento.setQuantidadeSegundoExecucaoEvento(rs.getInt("QSEGDA_EXCUC_EVNTO"));
        parametroEvento.setQuantidadeLimiteSegundoEventoBemBaixo(rs.getInt("QLIM_SEGDA_EVNTO_BEM_BAIXO"));

        return parametroEvento;
    }

}
