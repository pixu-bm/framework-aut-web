package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Visao geral produto
 *
 * @author Wipro
 */
public class VisaoDetalhadaProdutoCanal {

    private String produto;
    private String canal;
    private BigDecimal eventoAberto;
    private BigDecimal eventoFechado;
    private BigDecimal eventoGrave;
    private BigDecimal eventoModerado;
    private BigDecimal numeroImpacto;
    private BigDecimal eventoDisponibilidade;
    private BigDecimal eventoFuncional;
    private BigDecimal eventoVolumetria;
    private BigDecimal total;
    private String periodo;

    public VisaoDetalhadaProdutoCanal() {
        super();
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public BigDecimal getEventoAberto() {
        return eventoAberto;
    }

    public void setEventoAberto(BigDecimal eventoAberto) {
        this.eventoAberto = eventoAberto;
    }

    public BigDecimal getEventoFechado() {
        return eventoFechado;
    }

    public void setEventoFechado(BigDecimal eventoFechado) {
        this.eventoFechado = eventoFechado;
    }

    public BigDecimal getEventoGrave() {
        return eventoGrave;
    }

    public void setEventoGrave(BigDecimal eventoGrave) {
        this.eventoGrave = eventoGrave;
    }

    public BigDecimal getEventoModerado() {
        return eventoModerado;
    }

    public void setEventoModerado(BigDecimal eventoModerado) {
        this.eventoModerado = eventoModerado;
    }

    public BigDecimal getNumeroImpacto() {
        return numeroImpacto;
    }

    public void setNumeroImpacto(BigDecimal numeroImpacto) {
        this.numeroImpacto = numeroImpacto;
    }

    public BigDecimal getEventoDisponibilidade() {
        return eventoDisponibilidade;
    }

    public void setEventoDisponibilidade(BigDecimal eventoDisponibilidade) {
        this.eventoDisponibilidade = eventoDisponibilidade;
    }

    public BigDecimal getEventoFuncional() {
        return eventoFuncional;
    }

    public void setEventoFuncional(BigDecimal eventoFuncional) {
        this.eventoFuncional = eventoFuncional;
    }

    public BigDecimal getEventoVolumetria() {
        return eventoVolumetria;
    }

    public void setEventoVolumetria(BigDecimal eventoVolumetria) {
        this.eventoVolumetria = eventoVolumetria;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

}
