package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

/**
 * Classe que implementa volumetria de tempo real tabela trafego objeto
 * 
 * @author Wipro
 */
public class VolumetriaVisaoNegocioTabelaResponse extends ResponseMensagem {

    private List<VolumetriaVisaoNegocio> listaVolumetriaVisaoNegocio;

    public VolumetriaVisaoNegocioTabelaResponse() {
        super();
    }

    public List<VolumetriaVisaoNegocio> getListaVolumetriaVisaoNegocio() {
        return Collections.unmodifiableList(listaVolumetriaVisaoNegocio);
    }

    public void setListaVolumetriaVisaoNegocio(
        List<VolumetriaVisaoNegocio> listaVolumetriaVisaoNegocio) {
        this.listaVolumetriaVisaoNegocio = 
            Collections.unmodifiableList(listaVolumetriaVisaoNegocio);
    }
}
