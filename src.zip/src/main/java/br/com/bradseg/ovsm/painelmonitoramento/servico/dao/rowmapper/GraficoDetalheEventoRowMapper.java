package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Volumetria tempo real mapa objetos extração de base de dados.
 * 
 * @author Wipro
 */
public class GraficoDetalheEventoRowMapper implements RowMapper<List<GraficoDetalheEvento>> {

    @Override
    public List<GraficoDetalheEvento> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<GraficoDetalheEvento> lista = new ArrayList<>();

        do {
            GraficoDetalheEvento grafico = new GraficoDetalheEvento();

            grafico.setHoraOcorrencia(rs.getString("HORA_OCORRENCIA"));
            grafico.setTransacaoEvento(rs.getBigDecimal("SOMA_COM_EVENTO"));
            grafico.setTransacaoSemEvento(rs.getBigDecimal("SOMA_SEM_EVENTO"));
            grafico.setMediaHistoricaTransacao(rs.getBigDecimal("MEDIA_HISTORICA"));
            grafico.setVolumetriaAtualTransacao(rs.getBigDecimal("SOMA_VOLUMETRIA_ATUAL"));
            grafico.setCodigoEmpresa(rs.getBigDecimal("CEMPR_PNEL"));
            grafico.setCodigoProduto(rs.getBigDecimal("CPRODT_PNEL"));
            grafico.setCodigoCanal(rs.getBigDecimal("CCANAL_DGTAL_PNEL"));
            
            lista.add(grafico);
        } while (rs.next());

        return lista;
    }

}
