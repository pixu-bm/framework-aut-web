package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Date;

public class Faq {

    private BigDecimal codSeq;
    private String codData;
    private String pergunta;
    private String resposta;
    private BigDecimal prioridade;
    private String imagem;
    private Date dataCriacao;

    public Faq() {
        super();
    }

    public BigDecimal getCod() {
        return codSeq;
    }

    public void setCod(BigDecimal codSeq) {
        this.codSeq = codSeq;
    }

    public String getData() {
        return codData;
    }

    public void setData(String codData) {
        this.codData = codData;
    }

    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public BigDecimal getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(BigDecimal prioridade) {
        this.prioridade = prioridade;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public Date getDataCriacao() {
        return (Date) dataCriacao.clone();
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = (Date) dataCriacao.clone();
    }
}
