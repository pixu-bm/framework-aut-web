package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

/**
 * Classe que implementa volumetria de tempo real tabela trafego objeto
 * 
 * @author Wipro
 */
public class IndicadoresNegocioResponse extends ResponseMensagem {

    private IndicadoresNegocio indicadoresNegocio;

    public IndicadoresNegocioResponse() {
        super();
    }

    public IndicadoresNegocio getIndicadoresNegocio() {
        return indicadoresNegocio;
    }

    public void setIndicadoresNegocio(IndicadoresNegocio indicadoresNegocio) {
        this.indicadoresNegocio = indicadoresNegocio;
    }
}
