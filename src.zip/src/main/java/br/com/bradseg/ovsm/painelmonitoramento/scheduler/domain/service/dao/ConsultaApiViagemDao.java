package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface ConsultaApiViagemDao {
    
    String obterultimoregistroinseridoViagem();
    
    void liberarProcessamentoViagem(Collection<?> listaSaudeTemp);
    
    void validarDuplicadosViagem(Collection<?> listaSaudeTemp);
    
    void inserirConsultaApiViagem(List<TabelaTemp> listaSaudeTemp) throws SQLException;
}
