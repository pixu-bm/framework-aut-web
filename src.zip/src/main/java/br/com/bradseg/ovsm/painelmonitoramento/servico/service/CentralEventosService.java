package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;

/**
 * Interface central eventos service
 *
 * @author Wipro
 *
 */
public interface CentralEventosService {

    /**
     * Obter visão evento em aberto.
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return VisaoEvento
     */
    VisaoEvento obterVisaoEventoAberto(Date dataInicio, Date dataFim);

    /**
     * Validar parametros de visao de evento aberto
     *
     * @param dataInicio String
     * @param dataFim    String
     */
    void validarParametrosVisaoEventoAberto(String dataInicio, String dataFim);

    /**
     * Obter visão evento por produtos
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoProduto>
     */
    List<VisaoEventoProduto> obterVisaoEventoProduto(Date dataInicio, Date dataFim);

    /**
     * Obter visão evento por canal
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoCanal>
     */
    List<VisaoEventoCanal> obterVisaoEventoCanal(Date dataInicio, Date dataFim);

    /**
     * Obter lista de registros de evento
     *
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @param statusEvento       Integer
     * @param dataInicio         Date
     * @param dataFim            Date
     * @param codigoTipoEvento   BigDecimal
     * @return List<RegistroEvento>
     */
    List<RegistroEvento> obterRegistroEvento(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, Integer statusEvento, Date dataInicio, Date dataFim,
        BigDecimal codigoTipoEvento);

    /**
     * Obter lista de registros de evento detalhe
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @param periodoTempo      Integer
     * @param statusEvento      Integer
     * @return List<StatusDetalheEvento>
     */
    List<StatusDetalheEvento> obterStatusDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento);

    /**
     * Obter grafico de registros de evento detalhe
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @return List<GraficoDetalheEvento>
     */
    List<GraficoDetalheEvento> obterGraficoDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento);

    /**
     * Obter lista de registros de evento elacionados
     *
     * @param codigoErro Integer
     * @param limite     Integer
     * @param linha      Integer
     * @return List<RelaciondosDetalheEvento>
     */
    List<RelaciondosDetalheEvento> obterDetalheEventoRelacionados(Integer codigoErro, Integer limite,
        Integer linha);

    /**
     * Obter o total de registros de evento elacionados
     *
     * @param codigoErro Integer
     * @return Integer
     */
    Integer obterTotalEventoRelacionados(Integer codigoErro);

    /**
     * Obter visao evento dentalhe
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @return VisaoGeralProduto
     */
    VisaoGeralProduto obterVisaoEventoProdutoDetalhe(Integer periodoVisaoEvento, BigDecimal codigoProduto);

    /**
     * Obter visao evento dentalhe canal
     *
     * @param periodoVisaoEvento Integer
     * @param codigoCanal        BigDecimal
     * @return VisaoGeralCanal
     */
    VisaoGeralCanal obterVisaoEventoCanalDetalhe(Integer periodoVisaoEvento, BigDecimal codigoCanal);

    /**
     * Obter registro evento excel
     *
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @param statusEvento       Integer
     * @param dataInicio         Date
     * @param dataFim            Date
     * @param codigoTipoEvento   BigDecimal
     * @return Workbook
     */
    Workbook obterRegistroEventoExcel(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, Integer statusEvento,
        Date dataInicio, Date dataFim,
        BigDecimal codigoTipoEvento, String login);

    /**
     * Obter registro evento pdf
     *
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @param statusEvento       Integer
     * @param dataInicio         Date
     * @param dataFim            Date
     * @param codigoTipoEvento   BigDecimal
     * @return Workbook
     */
    ByteArrayInputStream obterRegistroEventoPDF(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, Integer statusEvento,
        Date dataInicio, Date dataFim,
        BigDecimal codigoTipoEvento, String login);

    /**
     * Obter registro evento por produto ou canal pdf
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoCanal        BigDecimal
     * @param login              String
     * @return Workbook
     */
    ByteArrayInputStream obterVisaoEventoProdutoCanalDetalhePDF(Integer periodoVisaoEvento,
        List<BigDecimal> codigoProduto,
        List<BigDecimal> codigoCanal, String login);

    /**
     * Obter lista eventos por produto / canal
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoCanal        BigDecimal
     * @return List<VisaoDetalhadaProdutoCanal>
     */
    List<VisaoDetalhadaProdutoCanal> obterListaEventoProdutoCanalDetalhe(Integer periodoVisaoEvento,
        BigDecimal codigoProduto, BigDecimal codigoCanal);

    /**
     * Obter registro evento detalhado pdf
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @param periodoTempo      Integer
     * @param statusEvento      Integer
     * @param login             String
     * @return Workbook
     */
    ByteArrayInputStream obterVisaoEventoDetalhadoPDF(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento,
        String login);

    Workbook obterVisaoEventoProdutoCanalDetalheExcelCsv(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String login);

    Workbook obterVisaoEventoDetalhadoExcelCsv(Integer codigoErro, BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento, String login);

}
