package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Evento response.
 * 
 * @author Wipro
 */
public class RelacionadoDetalheEventoResponse extends ResponseMensagem {

    private List<RelaciondosDetalheEvento> listaDetalheEventoRelacionados;
    private Integer totalItensRelacionados;

    public RelacionadoDetalheEventoResponse() {
        super();
    }

    public Integer getTotalItensRelacionados() {
        return totalItensRelacionados;
    }

    public void setTotalItensRelacionados(Integer totalItensRelacionados) {
        this.totalItensRelacionados = totalItensRelacionados;
    }

    public List<RelaciondosDetalheEvento> getListaDetalheEventoRelacionados() {
        return Collections.unmodifiableList(listaDetalheEventoRelacionados);
    }

    public void setListaDetalheEventoRelacionados(List<RelaciondosDetalheEvento> listaDetalheEventoRelacionados) {
        this.listaDetalheEventoRelacionados = Collections.unmodifiableList(listaDetalheEventoRelacionados);
    }



}
