package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EventoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * CentralEventosDaoImpl Classe implementador acesso a base de dados.
 *
 * @author Wipro
 */
@Repository
public class EventoDaoImpl implements EventoDao {

    private static final Logger LOGGER = LogManager.getLogger(EventoDaoImpl.class);

    public static final String ERROR = "Error: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private static final String SELECT_EVENTOS = "SELECT CTPO_EVNTO_PNEL, ITPO_EVNTO_PNEL FROM "
        + Constantes.OWNER_TABELA + "TPO_EVNTO_PNEL ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public EventoDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public List<Evento> obterListaEvento() {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_EVENTOS, new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(Constantes.RESULTADO_NAO_ENCONTRADO, 1);
            }

            List<Evento> listaEvento = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Evento evento = new Evento();
                evento.setCodigo((BigDecimal) mapa.get("CTPO_EVNTO_PNEL"));
                evento.setDescricao((String) mapa.get("ITPO_EVNTO_PNEL"));

                listaEvento.add(evento);
            }

            return listaEvento;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
