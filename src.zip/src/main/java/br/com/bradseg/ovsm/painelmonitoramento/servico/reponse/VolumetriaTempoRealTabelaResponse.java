package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;

/**
 * Classe que implementa volumetria de tempo real tabela trafego objeto
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealTabelaResponse extends ResponseMensagem {

    private List<VolumetriaTempoRealTransacaoEvento> listaVolumetriaTempoRealTransacaoEvento;

    public VolumetriaTempoRealTabelaResponse() {
        super();
    }

    public List<VolumetriaTempoRealTransacaoEvento> getListaVolumetriaTempoRealTransacaoEvento() {
        return Collections.unmodifiableList(listaVolumetriaTempoRealTransacaoEvento);
    }

    public void setListaVolumetriaTempoRealTransacaoEvento(
        List<VolumetriaTempoRealTransacaoEvento> listaVolumetriaTempoRealTransacaoEvento) {
        this.listaVolumetriaTempoRealTransacaoEvento = 
            Collections.unmodifiableList(listaVolumetriaTempoRealTransacaoEvento);
    }
}
