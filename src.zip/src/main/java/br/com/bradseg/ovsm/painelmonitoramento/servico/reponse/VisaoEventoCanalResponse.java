package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;

/**
 * Visao evento canal response
 * 
 * @author Wipro
 */
public class VisaoEventoCanalResponse extends ResponseMensagem {

    private List<VisaoEventoCanal> listaVisaoEventoCanal;

    public VisaoEventoCanalResponse() {
        super();
    }

    public List<VisaoEventoCanal> getListaVisaoEventoCanal() {
        return Collections.unmodifiableList(listaVisaoEventoCanal);
    }

    public void setListaVisaoEventoCanal(List<VisaoEventoCanal> listaVisaoEventoCanal) {
        this.listaVisaoEventoCanal = 
            Collections.unmodifiableList(listaVisaoEventoCanal);
    }

}
