package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.EventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EventoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * Classe central evento rest controller
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/evento")
public class EventoController {

    private static final Logger LOGGER = LogManager.getLogger(EventoController.class);

    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_3 = 3;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";

    @Autowired
    private EventoService eventoService;

    public EventoController() {
        super();
    }

    /**
     * Obtem informações de visao de evento aberto para painel de central de eventos
     *
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/")
    @Operation(summary = "Obtem lista de eventos para criação de combo.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterListaEvento() {

        try {

            List<Evento> mapa = eventoService.obterListaEvento();

            EventoResponse response = new EventoResponse();
            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setListaEvento(mapa);

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem msg = new ResponseMensagem();
            msg.setCodigoRetorno(CODIGO_RETORNO_3);
            msg.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, msg.getMensagem() + ";" + CODIGO_RETORNO_3, e);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoSqlAcesso = new ResponseMensagem();
            retornoSqlAcesso.setCodigoRetorno(CODIGO_RETORNO_2);
            retornoSqlAcesso.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlAcesso.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }

    }
}
