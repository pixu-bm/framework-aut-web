package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

import java.math.BigDecimal;

public class FaqRequest {

    private BigDecimal codSeq;
    private String codData;
    private String pergunta;
    private String resposta;
    private Float prioridade;
    private String imagem;
    private String login;

    public FaqRequest() {
        super();
    }

    public BigDecimal getCodSeq() {
        return codSeq;
    }

    public void setCodSeq(BigDecimal codSeq) {
        this.codSeq = codSeq;
    }

    public String getCodData() {
        return codData;
    }

    public void setCodData(String codData) {
        this.codData = codData;
    }

    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public Float getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(Float prioridade) {
        this.prioridade = prioridade;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}
