package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe row mapper para extrair lista visao evento canal
 * 
 * @author Wipro
 */
public class ListaVisaoEventoCanalRowMapper implements RowMapper<List<VisaoEventoCanal>> {

    @Override
    public List<VisaoEventoCanal> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<VisaoEventoCanal> listaVisaoEventoCanal = new ArrayList<>();
        int count = 0;

        do {
            VisaoEventoCanal visaoEventoCanal = new VisaoEventoCanal();
            visaoEventoCanal.setCodigoCanal(rs.getBigDecimal("CCANAL_DGTAL_PNEL"));
            visaoEventoCanal.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
            visaoEventoCanal.setQuantidadeOcorrencia(rs.getInt("QNT_TOTAL"));
            listaVisaoEventoCanal.add(visaoEventoCanal);
            count++;
        } while (rs.next());

        for (int i = 0; i < listaVisaoEventoCanal.size(); i++) {
            listaVisaoEventoCanal.get(i).setPorcentagemOcorrencia(
                Utils.calcularPorcentagem(listaVisaoEventoCanal.get(i).getQuantidadeOcorrencia(), count));
        }

        return listaVisaoEventoCanal;
    }

}
