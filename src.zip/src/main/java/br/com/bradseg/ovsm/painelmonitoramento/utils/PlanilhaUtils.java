package br.com.bradseg.ovsm.painelmonitoramento.utils;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;

public class PlanilhaUtils {


    private PlanilhaUtils() {
        throw new IllegalStateException("Classe não pode ser instanciada.");
    }

    public static CellStyle createStyleBordaCima(Workbook wb) {
        CellStyle styleInicial = wb.createCellStyle();
        styleInicial.setBorderBottom(BorderStyle.THIN);
        styleInicial.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleInicial.setBorderLeft(BorderStyle.THIN);
        styleInicial.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        styleInicial.setBorderRight(BorderStyle.THIN);
        styleInicial.setRightBorderColor(IndexedColors.WHITE.getIndex());
        styleInicial.setBorderTop(BorderStyle.THIN);
        styleInicial.setTopBorderColor(IndexedColors.BLACK.getIndex());
        return styleInicial;
    }

    public static CellStyle createStyleBordaTopo(Workbook wb) {
        CellStyle styleTopo = wb.createCellStyle();
        styleTopo.setBorderBottom(BorderStyle.THIN);
        styleTopo.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleTopo.setBorderLeft(BorderStyle.THIN);
        styleTopo.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleTopo.setBorderRight(BorderStyle.THIN);
        styleTopo.setRightBorderColor(IndexedColors.WHITE.getIndex());
        styleTopo.setBorderTop(BorderStyle.THIN);
        styleTopo.setTopBorderColor(IndexedColors.BLACK.getIndex());
        return styleTopo;
    }

    public static CellStyle createStyleBordaTopoDireita(Workbook wb) {
        CellStyle styleTopoDireita = wb.createCellStyle();
        styleTopoDireita.setBorderBottom(BorderStyle.THIN);
        styleTopoDireita.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleTopoDireita.setBorderLeft(BorderStyle.THIN);
        styleTopoDireita.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleTopoDireita.setBorderRight(BorderStyle.THIN);
        styleTopoDireita.setRightBorderColor(IndexedColors.BLACK.getIndex());
        styleTopoDireita.setBorderTop(BorderStyle.THIN);
        styleTopoDireita.setTopBorderColor(IndexedColors.BLACK.getIndex());
        return styleTopoDireita;
    }

    public static CellStyle createStyleBordaTopoDireitaCinza(Workbook wb) {
        CellStyle styleTopoDireitaCinza = wb.createCellStyle();
        styleTopoDireitaCinza.setBorderBottom(BorderStyle.THIN);
        styleTopoDireitaCinza.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleTopoDireitaCinza.setBorderLeft(BorderStyle.THIN);
        styleTopoDireitaCinza.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleTopoDireitaCinza.setBorderRight(BorderStyle.THIN);
        styleTopoDireitaCinza.setRightBorderColor(IndexedColors.BLACK.getIndex());
        styleTopoDireitaCinza.setBorderTop(BorderStyle.THIN);
        styleTopoDireitaCinza.setTopBorderColor(IndexedColors.BLACK.getIndex());
        styleTopoDireitaCinza.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styleTopoDireitaCinza.setFillForegroundColor(
            HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());

        return styleTopoDireitaCinza;
    }

    public static CellStyle createStyleBordaEsquerda(Workbook wb) {
        CellStyle styleEsquerda = wb.createCellStyle();
        styleEsquerda.setBorderBottom(BorderStyle.THIN);
        styleEsquerda.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleEsquerda.setBorderLeft(BorderStyle.THIN);
        styleEsquerda.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        styleEsquerda.setBorderRight(BorderStyle.THIN);
        styleEsquerda.setRightBorderColor(IndexedColors.WHITE.getIndex());
        styleEsquerda.setBorderTop(BorderStyle.THIN);
        styleEsquerda.setTopBorderColor(IndexedColors.WHITE.getIndex());

        return styleEsquerda;
    }

    public static CellStyle createStyleBordaDireita(Workbook wb) {
        CellStyle styleDireita = wb.createCellStyle();
        styleDireita.setBorderBottom(BorderStyle.THIN);
        styleDireita.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        styleDireita.setBorderLeft(BorderStyle.THIN);
        styleDireita.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleDireita.setBorderRight(BorderStyle.THIN);
        styleDireita.setRightBorderColor(IndexedColors.BLACK.getIndex());
        styleDireita.setBorderTop(BorderStyle.THIN);
        styleDireita.setTopBorderColor(IndexedColors.WHITE.getIndex());

        return styleDireita;
    }

    public static CellStyle createStyleBordaBaixo(Workbook wb) {
        CellStyle styleBaixo = wb.createCellStyle();
        styleBaixo.setBorderBottom(BorderStyle.THIN);
        styleBaixo.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        styleBaixo.setBorderLeft(BorderStyle.THIN);
        styleBaixo.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleBaixo.setBorderRight(BorderStyle.THIN);
        styleBaixo.setRightBorderColor(IndexedColors.WHITE.getIndex());
        styleBaixo.setBorderTop(BorderStyle.THIN);
        styleBaixo.setTopBorderColor(IndexedColors.WHITE.getIndex());

        return styleBaixo;
    }

    public static CellStyle createStyleBordaBaixoDireita(Workbook wb) {
        CellStyle styleBaixoDireita = wb.createCellStyle();
        styleBaixoDireita.setBorderBottom(BorderStyle.THIN);
        styleBaixoDireita.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        styleBaixoDireita.setBorderLeft(BorderStyle.THIN);
        styleBaixoDireita.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        styleBaixoDireita.setBorderRight(BorderStyle.THIN);
        styleBaixoDireita.setRightBorderColor(IndexedColors.BLACK.getIndex());
        styleBaixoDireita.setBorderTop(BorderStyle.THIN);
        styleBaixoDireita.setTopBorderColor(IndexedColors.WHITE.getIndex());

        return styleBaixoDireita;
    }

    public static CellStyle createStyleCinza(Workbook wb) {
        CellStyle styleCinza = wb.createCellStyle();
        styleCinza.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styleCinza.setFillForegroundColor(
            HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());

        return styleCinza;
    }

    public static CellStyle createStyleBranco(Workbook wb) {
        CellStyle styleBranco = wb.createCellStyle();
        styleBranco.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styleBranco.setFillForegroundColor(
            HSSFColor.HSSFColorPredefined.WHITE.getIndex());

        return styleBranco;
    }

    public static CellStyle createStyleBordaTotal(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());

        return style;
    }

    public static CellStyle createStyleCabecalho(Workbook wb) {
        CellStyle styleCabecalho = wb.createCellStyle();

        styleCabecalho.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styleCabecalho.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());
        styleCabecalho.setBorderBottom(BorderStyle.THIN);
        styleCabecalho.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        styleCabecalho.setBorderLeft(BorderStyle.THIN);
        styleCabecalho.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        styleCabecalho.setBorderRight(BorderStyle.THIN);
        styleCabecalho.setRightBorderColor(IndexedColors.BLACK.getIndex());
        styleCabecalho.setBorderTop(BorderStyle.THIN);
        styleCabecalho.setTopBorderColor(IndexedColors.BLACK.getIndex());

        return styleCabecalho;
    }
}
