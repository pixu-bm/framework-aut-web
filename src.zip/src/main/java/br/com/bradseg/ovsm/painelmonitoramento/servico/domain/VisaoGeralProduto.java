package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * Visao geral produto
 * @author Wipro
 */
public class VisaoGeralProduto {

    private BigDecimal codigoProduto;
    private String descricaoProduto;
    private Integer eventoGrave;
    private Integer eventoModerado;
    private Integer numeroImpacto;
    private Integer eventoDisponibilidade;
    private Integer eventoFuncional;
    private Integer eventoVolumetria;
    private List<RelacaoCanalProduto> listaRelacaoCanalProduto;

    public VisaoGeralProduto() {
        super();
    }

    public void setListaRelacaoCanalProduto(List<RelacaoCanalProduto> listaRelacaoCanalProduto) {
        this.listaRelacaoCanalProduto = Collections.unmodifiableList(listaRelacaoCanalProduto);
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public List<RelacaoCanalProduto> getListaRelacaoCanalProduto() {
        return Collections.unmodifiableList(listaRelacaoCanalProduto);
    }

    public Integer getEventoGrave() {
        return eventoGrave;
    }

    public Integer getEventoModerado() {
        return eventoModerado;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setEventoDisponibilidade(Integer eventoDisponibilidade) {
        this.eventoDisponibilidade = eventoDisponibilidade;
    }

    public Integer getEventoDisponibilidade() {
        return eventoDisponibilidade;
    }

    public void setEventoFuncional(Integer eventoFuncional) {
        this.eventoFuncional = eventoFuncional;
    }

    public void setNumeroImpacto(Integer numeroImpacto) {
        this.numeroImpacto = numeroImpacto;
    }

    public void setEventoModerado(Integer eventoModerado) {
        this.eventoModerado = eventoModerado;
    }

    public void setEventoVolumetria(Integer eventoVolumetria) {
        this.eventoVolumetria = eventoVolumetria;
    }

    public Integer getNumeroImpacto() {
        return numeroImpacto;
    }

    public Integer getEventoVolumetria() {
        return eventoVolumetria;
    }

    public void setEventoGrave(Integer eventoGrave) {
        this.eventoGrave = eventoGrave;
    }

    public Integer getEventoFuncional() {
        return eventoFuncional;
    }

}
