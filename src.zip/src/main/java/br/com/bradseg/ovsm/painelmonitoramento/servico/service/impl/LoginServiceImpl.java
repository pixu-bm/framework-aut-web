package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.LoginRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmailService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.LoginService;

/**
 * Camada de serviço para obter informações de login
 * @author Wipro
 */
@Service
public class LoginServiceImpl implements LoginService {

    private LoginDao loginDao;
    private EmailService emailService;
    private static final Logger LOGGER = LogManager
        .getLogger(LoginServiceImpl.class);
    public static final String ERRO = "erro: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final int INT_3 = 3;

    @Autowired
    public LoginServiceImpl(LoginDao loginDao, EmailService emailService) {
        this.loginDao = loginDao;
        this.emailService = emailService;
    }

    /**
     * {@inheritDoc}
     * @throws SQLException 
     */
    public String logar(Usuario usuario) throws SQLException {
        try {

            return loginDao.obterTipoUsuario(usuario);

        } catch (IllegalArgumentException e) {
            LOGGER.error(ERRO, e);
            throw new IllegalArgumentException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 0);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void validarLogin(LoginRequest login) {
        Assert.notNull(login, "É obrigatório colocar dados do usuário");
        Assert.notNull(login.getLogin(),
            "Parametro login é obrigatório o preenchimento");

    }

    /**
     * {@inheritDoc}
     */
    public void validarSolicitacaoAcesso(
        SolicitacaoAcessoRequest solicitarAcesso) {
        Assert.notNull(solicitarAcesso,
            "É obrigatório colocar dados do usuário");
        Assert.notNull(solicitarAcesso.getNome(),
            "É obrigatório preenchimento do nome");
        Assert.notNull(solicitarAcesso.getLogin(),
            "Parametro login é obrigatório o preenchimento");
        Assert.notNull(solicitarAcesso.getEmail(),
            "Paramêtro email é obrigatório o preenchimento");
        Assert.notNull(solicitarAcesso.getTelefone(),
            "Telefone é obrigatório o preenchimento");
        Assert.notNull(solicitarAcesso.getEndereco(),
            "Endereço é obrigatório o preenchimento");

        // Assert.notNull(solicitarAcesso.getCodigoEmpresa(),
        // "Código empresa é obrigatório o preenchimento");
        //
        // Assert.notNull(solicitarAcesso.getCodigoDepartamento(),
        // "Código departamento é obrigatório o preenchimento");

        Assert.isTrue(INT_3 < solicitarAcesso.getNomeEmpresa().length(),
            "Nome da Empresa é obrigatório o preenchimento e deve conter no mínimo 3 caracteres");

        Assert.isTrue(INT_3 < solicitarAcesso.getNomeDepartamento().length(),
            "Nome do departamento é obrigatório o preenchimento  e deve conter no mínimo 3 caracteres");

    }

    /**
     * {@inheritDoc}
     */
    public void inserirUsuarioAprovacao(Usuario usuario) throws SQLException {
        try {
            if (Boolean.FALSE.equals(loginDao.validarLogin(usuario))) {
                throw new IllegalArgumentException(
                    "Login já existente na base.");
            }

            String codigoEmpresa = usuario.getNomeDepartamento().toUpperCase().substring(0, INT_3);
            String codigoDepartamento = usuario.getNomeDepartamento().toUpperCase().substring(0, INT_3);

            if (Boolean.FALSE.equals(loginDao.validarEmpresaUsuario(codigoEmpresa))) {
                loginDao.inserirEmpresaUsuario(usuario);
            }

            if (Boolean.FALSE.equals(loginDao.validarDepartamentoUsuario(codigoDepartamento))) {
                loginDao.inserirDepartamentoUsuario(usuario);
            }

            loginDao.inserirUsuarioAprovacao(usuario);
            enviarEmailConfirmacaoCadastro(usuario);
            enviarEmailNotificacaoUsuarioAprovador(usuario);

        } catch (IllegalArgumentException e) {
            LOGGER.error(ERRO, e);
            throw new IllegalArgumentException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            loginDao.inserirUsuarioAprovacao(usuario);
        } catch (DataIntegrityViolationException e) {
            LOGGER.error(ERRO, e);
            throw new DataIntegrityViolationException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    private void enviarEmailNotificacaoUsuarioAprovador(Usuario usuario) throws SQLException {
        List<Usuario> listaUsuarioAprovador = loginDao.obterInformacaoUsuariosMasterAdm();

        for (Usuario usuarioAprovador : listaUsuarioAprovador) {

            StringBuilder textoSolicitacao = new StringBuilder();
            textoSolicitacao.append("Olá,");
            textoSolicitacao.append("(" + usuarioAprovador.getLogin() + " - " + usuarioAprovador.getNome() + ")");

            textoSolicitacao.append(
                "Um novo usuário pediu solicitação de acesso. "
                    + "Login: " + usuario.getLogin() + "</br>"
                    + " Nome: " + usuario.getNome() + "</br>"

                    + "Este é um e-mail automático. Em caso de dúvidas, entre em contato através do "
                    + "<b>SuporteCM@bradescoseguros.com.br</b>");

            emailService.enviarEmail(usuario.getEmail(), textoSolicitacao.toString(),
                "[OVSM] - Novo usuário pediu solicitação de acesso.");
        }
    }

    /**
     * Atualizar 
     * @param usuario
     * @throws SQLException
     */
    private void enviarEmailConfirmacaoCadastro(Usuario usuario) throws SQLException {
        Usuario usuarioCompletoAprov = loginDao.obterInformacaoUsuario(usuario);
        StringBuilder textoSolicitacao = new StringBuilder();
        textoSolicitacao.append("Olá,");
        textoSolicitacao.append("(" + usuarioCompletoAprov.getLogin() + " - " + usuarioCompletoAprov.getNome() + ")");

        textoSolicitacao.append(
            "Seu cadastro foi confirmado no sistema Painel de Monitoramento - OV Digital, "
                + "aguarde a aprovação para liberação seu acesso."
                + "Este é um e-mail automático. Em caso de dúvidas, entre em contato através do "
                + "<b>SuporteCM@bradescoseguros.com.br</b>");

        emailService.enviarEmail(usuario.getEmail(), textoSolicitacao.toString(),
            "[OVSM] - Confirmação de cadastro Painel Monitoramento.");
    }

    /**
     * {@inheritDoc}
     */
    public List<EmpresaUsuario> listarEmpresaUsuario() throws SQLException {
        try {

            return loginDao.listarEmpresaUsuario();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<DepartamentoUsuario> listarDepartamentoUsuarioEmpresa(
        String codigoEmpresa) throws SQLException {
        try {

            if (Boolean.FALSE.equals(
                loginDao.validarEmpresaUsuario(codigoEmpresa))) {
                throw new EmptyResultDataAccessException(
                    "Codigo empresa não consta na base de dados", 1);
            }

            return loginDao.listarDepartamentoUsuario(codigoEmpresa);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERRO, e);
            throw new EmptyResultDataAccessException(e.getMessage(),
                e.getExpectedSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERRO, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void validarParametroEmpresaUsuario(String codigoEmpresa) {
        Assert.notNull(codigoEmpresa,
            "É obrigatório preencher o codigo de empresa.");
        Assert.isTrue(!"".equals(codigoEmpresa.trim()),
            "Codigo empresa não pode ser preenchido vazio");
    }

}
