package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

import java.sql.SQLException;
import java.util.List;

public interface ConsultaApiCaptalizacaoDao {

    void inserirConsultaApi(List<TabelaTemp> listaCapitalizacaoTemp) throws SQLException;
}
