package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Lista de departamento de usuario response
 * @author Wipro
 */
public class ListaDepartamentoUsuarioResponse extends ResponseMensagem {

    private List<DepartamentoUsuario> listaDepartamentoUsuario;

    public ListaDepartamentoUsuarioResponse() {
        super();
    }

    public List<DepartamentoUsuario> getListaDepartamentoUsuario() {
        return Collections.unmodifiableList(listaDepartamentoUsuario);
    }

    public void setListaDepartamentoUsuario(List<DepartamentoUsuario> listaDepartamentoUsuario) {
        this.listaDepartamentoUsuario = 
            Collections.unmodifiableList(listaDepartamentoUsuario);
    }

}
