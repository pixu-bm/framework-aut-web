package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;

public class ComboRankingEventosResponse extends ResponseMensagem{
    private List<ComboRankingEventos> listaComboRankingEventos;

    public ComboRankingEventosResponse() {
        super();
    }

    public List<ComboRankingEventos> getListaComboRankingEventos() {
        return Collections.unmodifiableList(listaComboRankingEventos);
    }

    public void setListaComboRankingEventos(List<ComboRankingEventos> listaComboRankingEventos) {
        this.listaComboRankingEventos = Collections.unmodifiableList(listaComboRankingEventos);
    }

}
