/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Classe que implementa a empresa de monitoramento atual e seus valores para
 * trafego de objetos.
 *
 * @author Wipro
 */
public class EmpresaPainelMonitoramentoAtual {

    private BigDecimal codigoEmpresa;
    private String descricaoEmpresa;
    private Date dataInclusaoRegistro;
    private Date dataAlteracaoRegistro;
    private List<ProdutoPainelMonitoramentoAtual> listaProduto;

    public EmpresaPainelMonitoramentoAtual() {
        super();
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getDescricaoEmpresa() {
        return descricaoEmpresa;
    }

    public void setDescricaoEmpresa(String descricaoEmpresa) {
        this.descricaoEmpresa = descricaoEmpresa;
    }

    public Date getDataInclusaoRegistro() {
        if (dataInclusaoRegistro != null) {
            return (Date) dataInclusaoRegistro.clone();
        }
        return null;
    }

    public void setDataInclusaoRegistro(Date dataInclusaoRegistro) {
        this.dataInclusaoRegistro = (Date) dataInclusaoRegistro.clone();
    }

    public Date getDataAlteracaoRegistro() {
        if (dataAlteracaoRegistro != null) {
            return (Date) dataAlteracaoRegistro.clone();
        }
        return null;
    }

    public void setDataAlteracaoRegistro(Date dataAlteracaoRegistro) {
        this.dataAlteracaoRegistro = (Date) dataAlteracaoRegistro.clone();
    }

    public List<ProdutoPainelMonitoramentoAtual> getListaProduto() {
        if(listaProduto == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(listaProduto);
    }

    public void setListaProduto(
      List<ProdutoPainelMonitoramentoAtual> listaProduto) {
        this.listaProduto = Collections.unmodifiableList(listaProduto);
    }

}
