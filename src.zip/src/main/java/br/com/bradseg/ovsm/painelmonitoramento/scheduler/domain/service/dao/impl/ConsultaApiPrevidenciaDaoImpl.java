package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiPrevidenciaDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Repository
public class ConsultaApiPrevidenciaDaoImpl implements ConsultaApiPrevidenciaDao {
    
    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiPrevidenciaDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";
    
    private static final String VALIDAR_REGISTROS_DUPLICADOS_PREV = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_BVP C "
        + "WHERE A.RTRANS_ORIGN = C.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = C.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(C.IAPI_ORIGN, NULL, '1')"
        + "AND C.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String INSERIR_CONSULTA_PREV = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP (CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String LIBERAR_PROCESSAMENTO_PREV = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' ";

    private static final String SELECT_MAX_REGISTRO_PREV = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "WHERE IPRODT_ORIGN = 'PREVIDENCIA' ";
    
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaApiPrevidenciaDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    public String obterultimoregistroinserido() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO_PREV, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }

    
    public void liberarProcessamentoPrevidencia(Collection<?> listaPrevidenciaTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaPrevidenciaTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO_PREV,
                batchValues.toArray(new Map[listaPrevidenciaTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
        
    }

    
    public void validarDuplicadosPrevidencia(Collection<?> listaPrevidenciaTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaPrevidenciaTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS_PREV,
                batchValues.toArray(new Map[listaPrevidenciaTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
        
    }

    
    public void inserirConsultaApiPrevidencia(List<TabelaTemp> listaPrevidenciaTemp) throws SQLException {
        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaPrevidenciaTemp.size());

            for (TabelaTemp prevTemp : listaPrevidenciaTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", prevTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", prevTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", prevTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", prevTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", prevTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", prevTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", prevTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", prevTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", prevTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", prevTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", prevTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", prevTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", prevTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", prevTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", prevTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", prevTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", prevTemp.getDinicErro())
                        .addValue("DFIM_ERRO", prevTemp.getDfimErro())
                        .addValue("DINCL_REG", prevTemp.getDinclReg())
                        .addValue("DALT_REG", prevTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_PREV,
                batchValues.toArray(new Map[listaPrevidenciaTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);
        }
        
    }

}
