package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;

import java.math.BigDecimal;

/**
 * Parametro evento request
 * 
 * @author Wipro
 */
public class ParametroEventoRequest {

    private BigDecimal codigoEmpresa;
    private BigDecimal codigoProduto;
    private BigDecimal codigoCanal;
    private ParametroEvento parametroEvento;

    public ParametroEventoRequest() {
        super();
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public ParametroEvento getParametroEvento() {
        return parametroEvento;
    }

    public void setParametroEvento(ParametroEvento parametroEvento) {
        this.parametroEvento = parametroEvento;
    }
}
