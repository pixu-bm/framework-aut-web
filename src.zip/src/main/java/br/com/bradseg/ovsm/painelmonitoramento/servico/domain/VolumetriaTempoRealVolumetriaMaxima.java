package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Classe responsável por armamazendar informações de volumetria maxima para
 * grafico de tenpo real
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealVolumetriaMaxima {

    private BigDecimal volumetriaAtualTransacao;
    private BigDecimal mediaHistoricaTransacao;
    private BigDecimal transacaoEvento;
    private BigDecimal transacaoSemEvento;

    public VolumetriaTempoRealVolumetriaMaxima() {
        super();
    }

    public BigDecimal getVolumetriaAtualTransacao() {
        return volumetriaAtualTransacao;
    }

    public void setVolumetriaAtualTransacao(BigDecimal volumetriaAtualTransacao) {
        this.volumetriaAtualTransacao = volumetriaAtualTransacao;
    }

    public BigDecimal getMediaHistoricaTransacao() {
        return mediaHistoricaTransacao;
    }

    public void setMediaHistoricaTransacao(BigDecimal mediaHistoricaTransacao) {
        this.mediaHistoricaTransacao = mediaHistoricaTransacao;
    }

    public BigDecimal getTransacaoEvento() {
        return transacaoEvento;
    }

    public void setTransacaoEvento(BigDecimal transacaoEvento) {
        this.transacaoEvento = transacaoEvento;
    }

    public BigDecimal getTransacaoSemEvento() {
        return transacaoSemEvento;
    }

    public void setTransacaoSemEvento(BigDecimal transacaoSemEvento) {
        this.transacaoSemEvento = transacaoSemEvento;
    }

}
