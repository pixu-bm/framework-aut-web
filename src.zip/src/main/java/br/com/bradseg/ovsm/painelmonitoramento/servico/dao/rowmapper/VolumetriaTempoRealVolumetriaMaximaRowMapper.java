package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Volumetria tempo real volumetria maxima mapa objetos extração de base de
 * dados.
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealVolumetriaMaximaRowMapper implements RowMapper<VolumetriaTempoRealVolumetriaMaxima> {

    public VolumetriaTempoRealVolumetriaMaxima mapRow(ResultSet rs, int rowNum) throws SQLException {

        VolumetriaTempoRealVolumetriaMaxima volumetriaTempoRealVolumetriaMaxima 
        = new VolumetriaTempoRealVolumetriaMaxima();
        volumetriaTempoRealVolumetriaMaxima.setVolumetriaAtualTransacao(new BigDecimal(rowNum));
        volumetriaTempoRealVolumetriaMaxima.setVolumetriaAtualTransacao(rs.getBigDecimal("SOMA_VOLUMETRIA_ATUAL"));
        volumetriaTempoRealVolumetriaMaxima.setMediaHistoricaTransacao(rs.getBigDecimal("MEDIA_VOLUMETRIA_HISTORICA"));
        volumetriaTempoRealVolumetriaMaxima.setTransacaoEvento(rs.getBigDecimal("SOMA_COM_EVENTO"));
        volumetriaTempoRealVolumetriaMaxima.setTransacaoSemEvento(rs.getBigDecimal("SOMA_SEM_EVENTO"));

        return volumetriaTempoRealVolumetriaMaxima;
    }
}
