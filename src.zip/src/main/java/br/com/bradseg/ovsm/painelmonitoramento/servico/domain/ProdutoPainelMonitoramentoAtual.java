/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Classe de produto
 * 
 * @author Wipro
 */
public class ProdutoPainelMonitoramentoAtual {

    private BigDecimal codigoProduto;
    private String descricaoProduto;
    private Date dataInclusaoRegistro;
    private Date dataAlteracaoRegistro;
    private List<CanalPainelMonitoramentoAtual> listaCanal;

    public ProdutoPainelMonitoramentoAtual() {
        super();
    }

    public ProdutoPainelMonitoramentoAtual(BigDecimal codigoProduto, List<BigDecimal> listaCodigoCanal) {
        super();
        if (codigoProduto != null) {
            this.codigoProduto = codigoProduto;
        }

        if (listaCodigoCanal != null) {
            this.listaCanal = new ArrayList<>();
            for (int i = 0; i < listaCodigoCanal.size(); i++) {
                CanalPainelMonitoramentoAtual canal = new CanalPainelMonitoramentoAtual();
                canal.setCodigoCanal(listaCodigoCanal.get(i));
                this.listaCanal.add(canal);
            }
        }
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public Date getDataAlteracaoRegistro() {
        if (dataAlteracaoRegistro != null) {
            return (Date) dataAlteracaoRegistro.clone();
        }
        return null;
    }

    public void setDataAlteracaoRegistro(Date dataAlteracaoRegistro) {
        this.dataAlteracaoRegistro = (Date) dataAlteracaoRegistro.clone();
    }

    public Date getDataInclusaoRegistro() {
        if (dataInclusaoRegistro != null) {
            return (Date) dataInclusaoRegistro.clone();
        }
        return null;
    }

    public void setDataInclusaoRegistro(Date dataInclusaoRegistro) {
        this.dataInclusaoRegistro = (Date) dataInclusaoRegistro.clone();
    }

    public List<CanalPainelMonitoramentoAtual> getListaCanal() {
        if (listaCanal != null) {
            return new ArrayList<>(listaCanal);
        }
        return Collections.emptyList();
    }

    public void setListaCanal(List<CanalPainelMonitoramentoAtual> listaCanal) {
        this.listaCanal = new ArrayList<>(listaCanal);
    }

}
