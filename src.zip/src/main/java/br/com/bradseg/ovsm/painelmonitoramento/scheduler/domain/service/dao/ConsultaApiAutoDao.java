package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface ConsultaApiAutoDao {
    
    String obterultimoregistroinseridoAuto();
    
    void liberarProcessamentoAuto(Collection<?> listaAutoTemp);
    
    void validarDuplicadosAuto(Collection<?> listaAutoTemp);
    
    void inserirConsultaApiAuto(List<TabelaTemp> listaAutoTemp) throws SQLException;
}
