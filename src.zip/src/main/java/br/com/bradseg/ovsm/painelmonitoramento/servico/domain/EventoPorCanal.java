package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Classe para implementação dos indicadores
 * 
 * @author Wipro
 */
public class EventoPorCanal {

    private Canal canal;
    private int quantidadeEventoCanal;
    private Double porcentagem;
    
    public EventoPorCanal() {
        super();
    }

    public Canal getCanal() {
        return canal;
    }

    public void setCanal(Canal canal) {
        this.canal = canal;
    }

    public int getQuantidadeEventoCanal() {
        return quantidadeEventoCanal;
    }

    public void setQuantidadeEventoCanal(int quantidadeEventoCanal) {
        this.quantidadeEventoCanal = quantidadeEventoCanal;
    }

    public Double getPorcentagem() {
        return porcentagem;
    }

    public void setPorcentagem(Double porcentagem) {
        this.porcentagem = porcentagem;
    }
}
