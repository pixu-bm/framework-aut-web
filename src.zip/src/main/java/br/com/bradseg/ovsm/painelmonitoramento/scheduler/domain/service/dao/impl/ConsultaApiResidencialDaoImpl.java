package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiResidencialDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Repository
public class ConsultaApiResidencialDaoImpl implements ConsultaApiResidencialDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiResidencialDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";

    private static final String VALIDAR_REGISTROS_DUPLICADOS_RESI = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_BARE C "
        + "WHERE A.RTRANS_ORIGN = C.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = C.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(C.IAPI_ORIGN, NULL, '1')"
        + "AND C.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String INSERIR_CONSULTA_RESI = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE (CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String LIBERAR_PROCESSAMENTO_RESI = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' ";

    private static final String SELECT_MAX_REGISTRO_RESI = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BARE "
        + "WHERE IPRODT_ORIGN = 'RESIDENCIAL' ";
    
    private NamedParameterJdbcTemplate jdbcTemplate;
    
    @Autowired
    public ConsultaApiResidencialDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public String obterultimoregistroinserido() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO_RESI, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }

    public void liberarProcessamentoResidencial(Collection<?> listaResidencialTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaResidencialTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO_RESI,
                batchValues.toArray(new Map[listaResidencialTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }

    }

    public void validarDuplicadosResidencial(Collection<?> listaResidencialTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaResidencialTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS_RESI,
                batchValues.toArray(new Map[listaResidencialTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }

    }

    public void inserirConsultaApiResidencial(List<TabelaTemp> listaResidencialTemp) throws SQLException {
        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaResidencialTemp.size());

            for (TabelaTemp resiTemp : listaResidencialTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", resiTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", resiTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", resiTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", resiTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", resiTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", resiTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", resiTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", resiTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", resiTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", resiTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", resiTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", resiTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", resiTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", resiTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", resiTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", resiTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", resiTemp.getDinicErro())
                        .addValue("DFIM_ERRO", resiTemp.getDfimErro())
                        .addValue("DINCL_REG", resiTemp.getDinclReg())
                        .addValue("DALT_REG", resiTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_RESI,
                batchValues.toArray(new Map[listaResidencialTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);
        }

    }

}
