package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista visão evento produto row mapper
 *
 * @author Wipro
 */
public class ListaVisaoEventoProdutoRowMapper implements RowMapper<List<VisaoEventoProduto>> {

    @Override
    public List<VisaoEventoProduto> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<VisaoEventoProduto> listaVisaoEventoProduto = new ArrayList<>();
        int count = 0;
        do {
            VisaoEventoProduto visaoEventoProduto = new VisaoEventoProduto();
            visaoEventoProduto.setCodigoProduto(rs.getBigDecimal("CPRODT_PNEL"));
            visaoEventoProduto.setDescricaoProduto(rs.getString("IPRODT"));
            visaoEventoProduto.setQuantidadeOcorrencia(rs.getInt("QNT_TOTAL"));
            listaVisaoEventoProduto.add(visaoEventoProduto);
            count++;
        } while (rs.next());

        for (int i = 0; i < listaVisaoEventoProduto.size(); i++) {
            listaVisaoEventoProduto.get(i).setPorcentagemOcorrencia(
                Utils.calcularPorcentagem(listaVisaoEventoProduto.get(i).getQuantidadeOcorrencia(), count));
        }

        return listaVisaoEventoProduto;
    }
}
