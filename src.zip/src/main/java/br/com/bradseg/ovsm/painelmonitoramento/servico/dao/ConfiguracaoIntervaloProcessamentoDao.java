package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;

import java.math.BigDecimal;
import java.sql.SQLException;

/**
 * Configuração intervalo processamento
 * 
 * @author Wipro
 */
public interface ConfiguracaoIntervaloProcessamentoDao {

    /**
     * Listar todos configuracao intervalo processamento
     * 
     * @return List<ConfiguracaoProcessamentoIntervalo>
     * @throws SQLException
     */
    ConfiguracaoIntervaloProcessamentoResponse obterConfiguracaoIntervaloProcessamento(BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal) throws SQLException;

    /**
     * Inserir configuração de intervalo de processamento
     * 
     * @param configuracaoIntervaloProcessamento ConfiguracaoIntervaloProcessamento
     * @throws SQLException
     */
    void inserirConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento) throws SQLException;

    /**
     * Verificar configuração de intervalo processamento já existe na base de dados.
     * 
     * @param configuracaoIntervaloProcessamento ConfiguracaoIntervaloProcessamento
     * @return Boolean
     * @throws SQLException
     */
    Boolean verificarConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento) throws SQLException;

    /**
     * Atualizar data fim de vigencia do registro atual que sera suplantado por um
     * novo registro
     * 
     * @param configuracaoIntervaloProcessamento ConfiguracaoIntervaloProcessamento
     * @throws SQLException
     */
    void atualizarDataFimVigencia(ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento)
        throws SQLException;

    /**
     * Obter parametro Evento
     * 
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal   BigDecimal
     * @return ParametroEvento
     * @throws SQLException
     */
    ParametroEvento obterParametroEvento(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException;

    /**
     * Verifica se parametro evento existe na base.
     * 
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal   BigDecimal
     * @return ParametroEvento
     * @throws Boolean
     */
    Boolean verificarParametroEventoExiste(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException;

    /**
     * Atualiza data fim vigencia parametro evento
     * 
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal   BigDecimal
     * @throws SQLException
     */
    void atualizarDataFimVigenciaParametroEvento(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException;

    /**
     * Inserir parametro evento.
     * 
     * @param parametroEvento ParametroEventoRequest
     * @throws SQLException
     */
    void inserirParametroEvento(ParametroEventoRequest parametroEvento) throws SQLException;
}
