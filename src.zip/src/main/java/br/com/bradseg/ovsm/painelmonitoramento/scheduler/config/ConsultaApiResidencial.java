package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiResidencialDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Component
public class ConsultaApiResidencial {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiResidencial.class);

    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    private static final int MAXIMO_CARACTERS = INT_100;

    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "RESIDENCIAL";
    public static final int INTERVALO_SAUDE = 15;

    @Autowired
    private ConsultaApiResidencialDao consultaApiResidencialDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "SHOPPING SEGUROS", "NEXT"};

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;

    private String contratacao = "/V2/AFND-Webservices-Json/modulocontratacao";

    private String[] metodosApi = {contratacao};

    public ConsultaApiResidencial(
        ConsultaApiResidencialDao consultaApiResidencialDao) {
        this.consultaApiResidencialDao = consultaApiResidencialDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerResi = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerResi);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualResidencial = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterResidencial = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualResidencial.format(formatterResidencial);
            LocalDateTime dataHoraAtualResidencial = LocalDateTime.parse(agoraFormatado, formatterResidencial);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiResidencialDao.obterultimoregistroinserido();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterResidencial);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualResidencial, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + contratacao);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                connection.setInstanceFollowRedirects(false);
                connection.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{"
                    + " \"soapenv:Body\":{"
                    + "        \"web:atualizarSistemaProdutoInfoCbon\": {}"
                    + "}"
                    + "}";

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaResiTemp = new LinkedList<>();

                validarConexaoResidencialTemp(dataHoraAtualResidencial, connection, canal,
                    enderecoApi + contratacao,
                    listaResiTemp, enderecoApi + contratacao);

                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanal = (HttpURLConnection) urlapi.openConnection();
                    connectionCanal.setRequestMethod("POST");
                    connectionCanal.setRequestProperty("Content-Type", "application/json");
                    connectionCanal.setDoOutput(true);
                    connectionCanal.setInstanceFollowRedirects(false);
                    connectionCanal.addRequestProperty("Authorization", authorization);

                    try (OutputStream os = connectionCanal.getOutputStream()) {
                        byte[] inputCanal = jsonRequest.getBytes(StandardCharsets.UTF_8);
                        os.write(inputCanal, 0, inputCanal.length);
                    }

                    validarConexaoCapitalizacaoTempApi(dataHoraAtualResidencial, connectionCanal,
                        canal, null, listaResiTemp);

                }

                if (minutos >= INTERVALO_SAUDE) {

                    consultaApiResidencialDao.inserirConsultaApiResidencial(listaResiTemp);

                    consultaApiResidencialDao.validarDuplicadosResidencial(listaResiTemp);

                    consultaApiResidencialDao.liberarProcessamentoResidencial(listaResiTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoResidencialTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaResidencialTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaResidencialTemp
                .addLast(obterResidencialNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {

            listaResidencialTemp.addLast(obterResidencialOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    private void validarConexaoCapitalizacaoTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaResidencialTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {

            listaResidencialTemp.addLast(obterResidencialNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {

            listaResidencialTemp.addLast(obterResidencialOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public TabelaTemp obterResidencialNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {

        TabelaTemp resiTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        resiTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        resiTemp.setCindRegProcs("J");
        // Codigo de retorno
        resiTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        resiTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        resiTemp.setRenderUrlOrign(enderecoApi);
        resiTemp.setRservcOrign(null);
        resiTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            resiTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            resiTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            resiTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            resiTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            resiTemp.setIapiOrign(enderecoApi);
            resiTemp.setIetapaOfert(enderecoApi);
        }

        resiTemp.setIcanalOrign(canal);
        resiTemp.setIemprOrign("BARE");
        resiTemp.setIprodtOrign(PRODUTO);
        resiTemp.setIsprodOrign(null);

        resiTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        resiTemp.setIsitEvnto("NOK");
        resiTemp.setDinicErro(dataHoraAtual);
        resiTemp.setDfimErro(null);
        resiTemp.setDinclReg(dataHoraAtual);
        resiTemp.setDaltReg(null);

        return resiTemp;
    }

    public static TabelaTemp obterResidencialOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp resiTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        resiTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        resiTempOk.setCindRegProcs("J");
        // Codigo de retorno
        resiTempOk.setCerroOrign("200");
        resiTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        resiTempOk.setRenderUrlOrign(enderecoApi);
        resiTempOk.setRservcOrign(null);
        resiTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            resiTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            resiTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            resiTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            resiTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            resiTempOk.setIapiOrign(enderecoApi);
            resiTempOk.setIetapaOfert(enderecoApi);
        }

        resiTempOk.setIcanalOrign(canal);
        resiTempOk.setIemprOrign("BARE");
        resiTempOk.setIprodtOrign(PRODUTO);
        resiTempOk.setIsprodOrign(null);

        resiTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        resiTempOk.setIsitEvnto("OK");
        resiTempOk.setDinicErro(dataHoraAtual);
        resiTempOk.setDfimErro(null);
        resiTempOk.setDinclReg(dataHoraAtual);
        resiTempOk.setDaltReg(null);

        return resiTempOk;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
