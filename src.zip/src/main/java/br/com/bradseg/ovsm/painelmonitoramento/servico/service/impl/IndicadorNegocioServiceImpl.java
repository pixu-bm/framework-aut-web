package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.IndicadorNegocioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.IndicadorNegocioService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.IndicadorNegocioServiceExport;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

@Service
public class IndicadorNegocioServiceImpl implements IndicadorNegocioService {

    private static final Log LOGGER = LogFactory
        .getLog(IndicadorNegocioServiceImpl.class);
    public static final String ERROR = "Error: ";
    public static final int INT = 0;
    public static final int INT1 = 4;
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final String NENHUM_DADO_VOLUMETRIA = "Nenhum dado de volumetria foi encontrado";
    private static final String ACIMA_MEDIA = "% acima da média";
    private static final String ABAIXO_MEDIA = "% abaixo da média";
    private static final int HORA = 3600;
    private static final int MIN_SEC = 60;
    private static final int INT_2 = 2;
    private static final int INT_100 = 100;
    private static final int INT_99 = 99;
    private IndicadorNegocioDao indicadorDao;
    private IndicadorNegocioServiceExport export;

    @Autowired
    public IndicadorNegocioServiceImpl(IndicadorNegocioDao indicadorDao,
        IndicadorNegocioServiceExport export) {
        this.indicadorDao = indicadorDao;
        this.export = export;
    }

    /**
     * Valida os parametros enviados para pesquisa de visão de evento.
     * 
     * @param periodoVisaoEvento Integer
     */
    public void validarParametro(Integer periodo) {
        Assert.notNull(periodo,
            "Parametro periodoVisaoEvento não deve ser nulo.");
        Assert.isTrue(periodo > INT,
            "Parametro periodoVisaoEvento não pode ser 0(Zero)");
        Assert.isTrue(periodo < INT1,
            "Parametro periodoVisaoEvento diferente dos número validos");
    }

    public void validarParametroRanking(Integer codigoPesquisa) {
        Assert.notNull(codigoPesquisa,
            "Parametro codigoPesquisa não deve ser nulo.");
        Assert.isTrue(codigoPesquisa > INT,
            "Parametro codigoPesquisa não pode ser 0(Zero)");
        Assert.isTrue(codigoPesquisa < INT1,
            "Parametro codigoPesquisa diferente dos número validos");
    }

    public void validarParametrosDatas(String dataInicio,
        String dataFim) {
        Assert.notNull(dataInicio, "dataInicio não pode ser nulo.");
        Assert.notNull(dataFim, "dataFim não pode ser nulo.");
        Assert.notNull(Utils.strDateFmtBrasilToJavaDate(dataInicio),
            "Formato de dataInicio errado.");
        Assert.notNull(Utils.strDateFmtBrasilToJavaDate(dataFim),
            "Formato de dataFim errado.");
    }

    /**
     * {@inheritDoc}
     */
    public VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim)
        throws SQLException {
        try {
            return indicadorDao
                .obterVolumetriaTempoRealVolumetriaMaxima(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim)
        throws SQLException {
        try {
            List<VolumetriaTempoReal> listaVolumetriaTempoReal = indicadorDao
                .obterVolumetriaTempoRealFaixaTempo(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal,
                    dataInicio, dataFim);

            if (listaVolumetriaTempoReal.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    NENHUM_DADO_VOLUMETRIA, 1);
            }

            return listaVolumetriaTempoReal;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoRelatorio(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim)
        throws SQLException {
        try {
            List<VolumetriaTempoReal> listaVolumetriaTempoReal = indicadorDao
                .obterVolumetriaTempoRealFaixaTempoRelatorio(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal,
                    dataInicio, dataFim);

            if (listaVolumetriaTempoReal.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    NENHUM_DADO_VOLUMETRIA, 1);
            }

            return listaVolumetriaTempoReal;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    public List<VolumetriaVisaoNegocio> obterVolumetriaVisaoNegocio(Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, Date dataInicio, Date dataFim) {
        try {
            List<VolumetriaVisaoNegocio> listaVolumetriaVisaoNegocio = indicadorDao
                .obterVolumetriaVisaoNegocio(periodo, listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim);

            if (listaVolumetriaVisaoNegocio.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    NENHUM_DADO_VOLUMETRIA, 1);
            }
            return listaVolumetriaVisaoNegocio;

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    @Override
    public IndicadoresNegocio obterIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        return comparacaoIndicadorNegocio(listaCodigoProduto, listaCodigoCanal,
            dataInicio, dataFim);
    }

    private IndicadoresNegocio comparacaoIndicadorNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        IndicadoresNegocio dados;
        IndicadoresNegocio dadosComparacao;
        try {
            dados = indicadorDao.obterIndicadoresNegocio(listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim);
            dadosComparacao = indicadorDao.obterIndicadoresNegocioComparacao(listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim);
            return comparacao(dados, dadosComparacao);
        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private List<IndicadoresNegocio> comparacaoIndicadorNegocioRelatorio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        List<IndicadoresNegocio> dadosList = new ArrayList<>();
        List<IndicadoresNegocio> dadosComparacaoList = new ArrayList<>();
        try {

            dadosList = indicadorDao.relatorioIndicadoresNegocio(listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim);
            dadosComparacaoList = indicadorDao.relatorioIndicadoresNegocioComparacao(listaCodigoProduto,
                listaCodigoCanal,
                dataInicio, dataFim);
            if (dadosComparacaoList == null) {
                return dadosList;
            } else {
                return comparacaoLista(dadosList, dadosComparacaoList);
            }
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private List<IndicadoresNegocio> comparacaoLista(List<IndicadoresNegocio> dadosList,
        List<IndicadoresNegocio> dadosComparacaoList) {

        List<IndicadoresNegocio> lista = new ArrayList<>();

        for (int i = 0; i < dadosList.size(); i++) {
            lista.add(comparacao(dadosList.get(i), dadosComparacaoList.get(i)));
        }

        return lista;
    }

    private IndicadoresNegocio comparacao(IndicadoresNegocio dados, IndicadoresNegocio dadosComparacao) {

        IndicadoresNegocio dadosPorcentagem = dados;

        if (dadosPorcentagem.getTotalTransacoes() > dadosComparacao.getTotalTransacoes()) {
            double valorAtual = dados.getTotalTransacoes();
            double valorComparacao = dadosComparacao.getTotalTransacoes();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemtotalTransacoes(fim + ACIMA_MEDIA);
        } else {
            double valorAtual = dados.getTotalTransacoes();
            double valorComparacao = dadosComparacao.getTotalTransacoes();
            double resultado = (valorComparacao * INT_100) / valorAtual;
            String fim = String.format("%.2f", resultado);
            dados.setPorcentagemtotalTransacoes(fim + ABAIXO_MEDIA);
        }

        if (dadosPorcentagem.getQtdEventos() > dadosComparacao.getQtdEventos()) {
            double valorAtual = dados.getQtdEventos();
            double valorComparacao = dadosComparacao.getQtdEventos();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemqtdEventos(fim + ACIMA_MEDIA);
        } else {
            double valorAtual = dados.getQtdEventos();
            double valorComparacao = dadosComparacao.getQtdEventos();
            double resultado = (valorComparacao * INT_100) / valorAtual;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemqtdEventos(fim + ABAIXO_MEDIA);
        }

        if (dadosPorcentagem.getTransacoesImpactadas() > dadosComparacao.getTransacoesImpactadas()) {
            double valorAtual = dados.getTransacoesImpactadas();
            double valorComparacao = dadosComparacao.getTransacoesImpactadas();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemtransacoesImpactadas(fim + ACIMA_MEDIA);
        } else {
            double valorAtual = dados.getTransacoesImpactadas();
            double valorComparacao = dadosComparacao.getTransacoesImpactadas();
            double resultado = (valorComparacao * INT_100) / valorAtual;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemtransacoesImpactadas(fim + ABAIXO_MEDIA);
        }

        if (dadosPorcentagem.getFrequenciaEventos() > dadosComparacao.getFrequenciaEventos()) {
            double valorAtual = dados.getFrequenciaEventos();
            double valorComparacao = dadosComparacao.getFrequenciaEventos();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemfrequenciaEventos(fim + ACIMA_MEDIA);
        } else {
            double valorAtual = dados.getFrequenciaEventos();
            double valorComparacao = dadosComparacao.getFrequenciaEventos();
            double resultado = (valorComparacao * INT_100) / valorAtual;
            String fim = String.format("%.2f", resultado);
            dadosPorcentagem.setPorcentagemfrequenciaEventos(fim + ABAIXO_MEDIA);
        }

        // Analise Tempo
        analiseTempo(dadosPorcentagem, dadosComparacao);

        return dadosPorcentagem;
    }

    private static void analiseTempo(IndicadoresNegocio dadosPorcentagem, IndicadoresNegocio dadosComparacao) {
        int valorAtual = converteHoraParaSegundos(dadosPorcentagem.getTempoTotalEventos());
        int valorComparacao = converteHoraParaSegundos(dadosComparacao.getTempoTotalEventos());

        dadosPorcentagem.setPorcentagemtempoTotalEventos("NaN");

        if (valorAtual > valorComparacao) {
            if (valorAtual != 0) {
                double resultado = (double) (valorComparacao * INT_100) / valorAtual;
                String fim = String.format("%.2f", resultado);
                dadosPorcentagem.setPorcentagemtempoTotalEventos(fim + ACIMA_MEDIA);
            }
        } else {
            if (valorComparacao != 0) {
                double resultado = (double) (valorAtual * INT_100) / valorComparacao;
                String fim = String.format("%.2f", resultado);
                dadosPorcentagem.setPorcentagemtempoTotalEventos(fim + ABAIXO_MEDIA);
            }
        }

        valorAtual = converteHoraParaSegundos(dadosPorcentagem.getTempoMedioEventos());
        valorComparacao = converteHoraParaSegundos(dadosComparacao.getTempoMedioEventos());

        dadosPorcentagem.setPorcentagemtempoMedioEventos("NaN");

        if (valorAtual > valorComparacao) {
            if (valorAtual != 0) {
                double resultado = (double) (valorComparacao * INT_100) / valorAtual;
                String fim = String.format("%.2f", resultado);
                dadosPorcentagem.setPorcentagemtempoMedioEventos(fim + ACIMA_MEDIA);
            }
        } else {
            if (valorComparacao != 0) {
                double resultado = (double) (valorAtual * INT_100) / valorComparacao;
                String fim = String.format("%.2f", resultado);
                dadosPorcentagem.setPorcentagemtempoMedioEventos(fim + ABAIXO_MEDIA);
            }
        }
    }

    private static int converteHoraParaSegundos(String string) {
        int horas = 0;
        int minutos = 0;
        int segundos = 0;
        if (!"00:00:00".equalsIgnoreCase(string)) {
            String[] array = string.split(":");
            for (int i = 0; i < array.length; i++) {
                if (i == 0) {
                    horas = Integer.parseInt(array[0]) * HORA;
                }
                if (i == 1) {
                    minutos = Integer.parseInt(array[1]) * MIN_SEC;
                }
                if (i == INT_2) {
                    segundos = Integer.parseInt(array[INT_2]) * MIN_SEC;
                }
            }
        }

        return horas + minutos + segundos;
    }

    @Override
    public List<ComboRankingEventos> obterRankingEventos(Integer codigoPesquisa,
        Date dataInicio, Date dataFim) {

        try {
            return indicadorDao.obterRankingEventos(codigoPesquisa, dataInicio, dataFim);
        } catch (SQLException e) {
            LOGGER.error(ERROR, e);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(),
                e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
        return Collections.emptyList();
    }

    @Override
    public List<ComboRankingEventos> relatorioRankingEventos(Integer codigoPesquisa,
        Date dataInicio, Date dataFim) {

        try {

            return indicadorDao.relatorioRankingEventos(codigoPesquisa, dataInicio, dataFim);
        } catch (SQLException eRelatorio) {
            LOGGER.error(ERROR, eRelatorio);
        } catch (EmptyResultDataAccessException eRelatorio) {
            LOGGER.error(ERROR, eRelatorio);
            throw new EmptyResultDataAccessException(eRelatorio.getMessage(),
                eRelatorio.getActualSize());
        } catch (AcessoADadosException eRelatorio) {
            LOGGER.error(ERROR, eRelatorio);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
        return Collections.emptyList();
    }

    @Override
    public NumeroTransacoes obterNumeroTransacao(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException {

        return obterPorcentagemNumeroTransacoes(
            indicadorDao.obterNumeroTransacao(periodo, listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim));
    }

    @Override
    public List<EventoPorCanal> obterEventoPorCanal(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException {

        return obterPorcentagemEventosCanal(
            indicadorDao.obterListaEventoCanal(periodo, listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim));
    }

    @Override
    public TipoEvento obterTipoEvento(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException {

        return obterPorcentagemTipoEvento(indicadorDao.obterTipoEvento(periodo, listaCodigoProduto, listaCodigoCanal,
            dataInicio, dataFim));
    }

    private static int totalQuantidadeEventoCanal(List<EventoPorCanal> listaQuantidadeEventos) {
        int soma = 0;
        for (EventoPorCanal valor : listaQuantidadeEventos) {
            soma += valor.getQuantidadeEventoCanal();
        }
        return soma;
    }

    private static List<EventoPorCanal> obterPorcentagemEventosCanal(List<EventoPorCanal> listaEventoCanal) {
        int total = totalQuantidadeEventoCanal(listaEventoCanal);
        for (EventoPorCanal valor : listaEventoCanal) {
            if (total == 0) {
                valor.setPorcentagem((double) 0);
            } else {
                double valorAtual = valor.getQuantidadeEventoCanal();
                double valorComparacao = total;
                double resultado = (valorAtual * INT_100) / valorComparacao;
                BigDecimal resultadoBd = BigDecimal.valueOf(resultado);
                valor.setPorcentagem(resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
            }
        }

        return listaEventoCanal;
    }

    private static NumeroTransacoes obterPorcentagemNumeroTransacoes(NumeroTransacoes retorno) {

        if (retorno.getTotalTransacoes() == 0) {
            retorno.setPorcentagemTotalTransacoesComEvento((double) 0);
            retorno.setPorcentagemTotalTransacoesSemEvento((double) 0);
        } else {
            double valorAtual = retorno.getTotalTransacoesSemEvento();
            double valorComparacao = retorno.getTotalTransacoes();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            BigDecimal resultadoBd = BigDecimal.valueOf(resultado);
            retorno.setPorcentagemTotalTransacoesSemEvento(
                resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
            valorAtual = retorno.getTotalTransacoesComEvento();
            valorComparacao = retorno.getTotalTransacoes();
            resultado = (valorAtual * INT_100) / valorComparacao;
            resultadoBd = BigDecimal.valueOf(resultado);
            retorno.setPorcentagemTotalTransacoesComEvento(
                resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
        }

        return retorno;
    }

    private static TipoEvento obterPorcentagemTipoEvento(TipoEvento retorno) {
        retorno.setQuantidadeTotalTipoEvento(
            retorno.getQuantidadeTotalDisponibilidade() +
                retorno.getQuantidadeTotalFuncionalidade() +
                retorno.getQuantidadeTotalVolumetria());

        if (retorno.getQuantidadeTotalTipoEvento() == 0) {
            retorno.setPorcentagemDisponibilidade((double) 0);
            retorno.setPorcentagemFuncionalidade((double) 0);
            retorno.setPorcentagemVolumetria((double) 0);
        } else {
            double valorAtual = retorno.getQuantidadeTotalDisponibilidade();
            double valorComparacao = retorno.getQuantidadeTotalTipoEvento();
            double resultado = (valorAtual * INT_100) / valorComparacao;
            BigDecimal resultadoBd = BigDecimal.valueOf(resultado);
            retorno.setPorcentagemDisponibilidade(resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
            valorAtual = retorno.getQuantidadeTotalFuncionalidade();
            valorComparacao = retorno.getQuantidadeTotalTipoEvento();
            resultado = (valorAtual * INT_100) / valorComparacao;
            resultadoBd = BigDecimal.valueOf(resultado);
            retorno.setPorcentagemFuncionalidade(resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
            valorAtual = retorno.getQuantidadeTotalVolumetria();
            valorComparacao = retorno.getQuantidadeTotalTipoEvento();
            resultado = (valorAtual * INT_100) / valorComparacao;
            resultadoBd = BigDecimal.valueOf(resultado);
            retorno.setPorcentagemVolumetria(resultadoBd.setScale(INT_2, RoundingMode.HALF_EVEN).doubleValue());
        }

        return retorno;
    }

    @Override
    public Workbook gerarExcelCsv(Integer periodo, Integer tipoRelatorio, Integer codigoPesquisa,
        List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim, String login) throws SQLException {
        Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal};
        if (tipoRelatorio == 1) {
            return export.excelCsvMonitorVisao(obterVolumetriaTempoRealVolumetriaMaxima(periodo,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim),
                obterVolumetriaTempoRealFaixaTempoRelatorio(periodo,
                    listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim),
                periodo, objectArray);
        } else if (tipoRelatorio == INT_2) {
            return export.excelCsvIndicador(comparacaoIndicadorNegocioRelatorio(listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim), objectArray);
        } else {
            if (codigoPesquisa == INT_99) {
                throw new AcessoADadosException("Código Pesquisa não Informado");
            }
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);
            return export.excelCsvRanking(relatorioRankingEventos(codigoPesquisa,
                dataInicioDate, dataFimDate), periodo, codigoPesquisa, objectArray);
        }
    }

    @Override
    public ByteArrayInputStream exportarPdf(Integer periodo, Integer tipoRelatorio, Integer codigoPesquisa,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim,
        String login) throws SQLException {
        if (tipoRelatorio == 1) {
            return export.pdfMonitorVisao(obterVolumetriaTempoRealVolumetriaMaxima(periodo,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim),
                obterVolumetriaTempoRealFaixaTempo(periodo,
                    listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim),
                periodo, listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim, login);
        } else if (tipoRelatorio == INT_2) {
            return export.pdfIndicador(comparacaoIndicadorNegocioRelatorio(listaCodigoProduto, listaCodigoCanal,
                dataInicio, dataFim), listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim, login);
        } else {
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);
            return export.pdfRanking(relatorioRankingEventos(codigoPesquisa,
                dataInicioDate, dataFimDate), periodo, codigoPesquisa, listaCodigoProduto, listaCodigoCanal, dataInicio,
                dataFim, login);
        }
    }
}
