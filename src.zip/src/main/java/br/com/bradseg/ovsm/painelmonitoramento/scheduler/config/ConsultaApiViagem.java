package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiViagemDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

@Component
public class ConsultaApiViagem {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiViagem.class);


    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    private static final int MAXIMO_CARACTERS = INT_100;
    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "VIAGEM";
    public static final int INTERVALO_VIAGEM = 15;


    @Autowired
    private ConsultaApiViagemDao consultaApiViagemDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "SHOPPING SEGUROS"};

    private boolean status;

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;


    private String validaProposta = "/V2/VPRS-ValidadorPropostas/service/TransmissaoWebService";

    private String[] metodosApi = {validaProposta};

    public ConsultaApiViagem(
        ConsultaApiViagemDao consultaApiViagemDao) {
        this.consultaApiViagemDao = consultaApiViagemDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerViagem = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerViagem);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualViagem = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterViagem = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualViagem.format(formatterViagem);
            LocalDateTime dataHoraAtualViagem = LocalDateTime.parse(agoraFormatado, formatterViagem);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiViagemDao.obterultimoregistroinseridoViagem();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterViagem);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualViagem, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + validaProposta);
                HttpURLConnection connectionViagem = (HttpURLConnection) url.openConnection();
                connectionViagem.setRequestMethod("POST");
                connectionViagem.setRequestProperty("Content-Type", "application/json");
                connectionViagem.setDoOutput(true);
                connectionViagem.setInstanceFollowRedirects(false);
                connectionViagem.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{}";

                try (OutputStream os = connectionViagem.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaViagemTemp = new LinkedList<>();

                validarConexaoViagemTemp(dataHoraAtualViagem, connectionViagem, canal,
                    enderecoApi + validaProposta,
                    listaViagemTemp, enderecoApi + validaProposta);


                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanalViagem = (HttpURLConnection) urlapi.openConnection();
                    connectionCanalViagem.setRequestMethod("POST");
                    connectionCanalViagem.setRequestProperty("Content-Type", "application/json");
                    connectionCanalViagem.setDoOutput(true);
                    connectionCanalViagem.setInstanceFollowRedirects(false);
                    connectionCanalViagem.addRequestProperty("Authorization", authorization);

                    try (OutputStream os = connectionCanalViagem.getOutputStream()) {
                        byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                        os.write(input, 0, input.length);
                    }

                    validarConexaoViagemTempApi(dataHoraAtualViagem, connectionCanalViagem,
                        canal, null, listaViagemTemp);


                }

                if (minutos >= INTERVALO_VIAGEM) {

                    consultaApiViagemDao.inserirConsultaApiViagem(listaViagemTemp);

                    consultaApiViagemDao.validarDuplicadosViagem(listaViagemTemp);

                    consultaApiViagemDao.liberarProcessamentoViagem(listaViagemTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoViagemTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaViagemTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            // Consulta Realizada com erro
            status = true;

            listaViagemTemp
                .addLast(obterViagemNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {
            // Consulta Realizada com sucesso
            status = false;

            listaViagemTemp.addLast(obterViagemOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    private void validarConexaoViagemTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaViagemTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            status = true;

            listaViagemTemp.addLast(obterViagemNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            status = false;

            listaViagemTemp.addLast(obterViagemOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public TabelaTemp obterViagemNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        status = true;
        TabelaTemp viagemTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        viagemTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        viagemTemp.setCindRegProcs("J");
        // Codigo de retorno
        viagemTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        viagemTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        viagemTemp.setRenderUrlOrign(enderecoApi);
        viagemTemp.setRservcOrign(null);
        viagemTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            viagemTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            viagemTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            viagemTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            viagemTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            viagemTemp.setIapiOrign(enderecoApi);
            viagemTemp.setIetapaOfert(enderecoApi);
        }

        viagemTemp.setIcanalOrign(canal);
        viagemTemp.setIemprOrign("BVP");
        viagemTemp.setIprodtOrign(PRODUTO);
        viagemTemp.setIsprodOrign(null);

        viagemTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        viagemTemp.setIsitEvnto("NOK");
        viagemTemp.setDinicErro(dataHoraAtual);
        viagemTemp.setDfimErro(null);
        viagemTemp.setDinclReg(dataHoraAtual);
        viagemTemp.setDaltReg(null);

        return viagemTemp;
    }

    public TabelaTemp obterViagemOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp viagemTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        viagemTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        viagemTempOk.setCindRegProcs("J");
        // Codigo de retorno
        viagemTempOk.setCerroOrign("200");
        viagemTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        viagemTempOk.setRenderUrlOrign(enderecoApi);
        viagemTempOk.setRservcOrign(null);
        viagemTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            viagemTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            viagemTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            viagemTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            viagemTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            viagemTempOk.setIapiOrign(enderecoApi);
            viagemTempOk.setIetapaOfert(enderecoApi);
        }

        viagemTempOk.setIcanalOrign(canal);
        viagemTempOk.setIemprOrign("BVP");
        viagemTempOk.setIprodtOrign(PRODUTO);
        viagemTempOk.setIsprodOrign(null);

        viagemTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        viagemTempOk.setIsitEvnto("OK");
        viagemTempOk.setDinicErro(dataHoraAtual);
        viagemTempOk.setDfimErro(null);
        viagemTempOk.setDinclReg(dataHoraAtual);
        viagemTempOk.setDaltReg(null);

        return viagemTempOk;
    }

    // Metodo responsavel por buscar o tempo parametrizado em milisegundos 900000
    public int buscaTempoParametrizado() {

        // Necessario implementar consulta na tabela de config de tempos para buscar os parametros
        // status = true erro identificado
        if (status) {
            return TEMPO_PARAMETRIZADO_SUCESSO;
        }

        return TEMPO_PARAMETRIZADO_ERRO;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
