package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl.ConsultaApiCaptalizacaoDaoImpl;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

@Component
public class ConsultaApiCaptalizacao {

    public static final int RESPONSE_CODE_400 = 400;
    public static final int RESPONSE_CODE_200 = 200;
    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    public static final int CORRIGE_DADO = 850;
    public static final String PLATA_FORMA_ORIGN = "API";
    public static final int INTERVALO_CAP = 15;
    public static final int INTERVALO_DEFAULT = 16;


    @Autowired
    private ConsultaApiCaptalizacaoDaoImpl consultaApiCaptalizacaoDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "ATM"};

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;
    private String validarCpf = "/V2/TCAP-Aquisicao/validarCpf";
    private String consultarDadosBancarios = "/V2/TCAP-DadosBancarios/consultarDadosBancarios";
    private String listarPlanosCompativeis = "/V2/TCAP-Proposta/listarPlanosCompativeis";
    private String consultarPlano = "/V2/TCAP-Proposta/consultarPlano";
    private String consultarValoresPlano = "/V2/TCAP-Proposta/consultarValoresPlano";
    private String efetivarProposta = "/V2/TCAP-Proposta/efetivarProposta";
    private String verificarPendenciaAceiteDigital = "/V2/TCAP-Proposta/verificarPendenciaAceiteDigital";
    private String aceitarRecusarPropostas = "/V2/TCAP-Proposta/aceitarRecusarPropostas";
    private String[] metodosApi = {validarCpf, consultarDadosBancarios, listarPlanosCompativeis, consultarPlano,
        consultarValoresPlano, efetivarProposta, verificarPendenciaAceiteDigital, aceitarRecusarPropostas};

    private boolean status;
    private static final String PRODUTO = "CAPITALIZACAO";
    public static final String ERROR = "Error: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final Log LOGGER = LogFactory.getLog(ConsultaApiCaptalizacao.class);

    public ConsultaApiCaptalizacao(ConsultaApiCaptalizacaoDaoImpl consultaApiCaptalizacaoDao) {
        this.consultaApiCaptalizacaoDao = consultaApiCaptalizacaoDao;
    }

    public void consultaApi() {
        try {

            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapower = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapower);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtual = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtual.format(formatter);
            LocalDateTime dataHoraAtual = LocalDateTime.parse(agoraFormatado, formatter);

            dataultimoregistro = consultaApiCaptalizacaoDao.obterultimoregistroinserido();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatter);
            } else {
                datahoraregistro = LocalDateTime.now(ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtual, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + validarCpf);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                connection.setInstanceFollowRedirects(false);
                connection.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{ }";

                try (OutputStream osConect = connection.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    osConect.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaCapitalizacaoTemp = new LinkedList<>();

                validarConexaoCapitalizacaoTemp(dataHoraAtual, connection, canal, enderecoApi + validarCpf,
                    listaCapitalizacaoTemp, enderecoApi + validarCpf);


                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCancal = (HttpURLConnection) urlapi.openConnection();
                    connectionCancal.setRequestMethod("POST");
                    connectionCancal.setRequestProperty("Content-Type", "application/json");
                    connectionCancal.setDoOutput(true);
                    connectionCancal.setInstanceFollowRedirects(false);
                    connectionCancal.addRequestProperty("Authorization", authorization);

                    try(OutputStream os = connectionCancal.getOutputStream()) {
                        byte[] inputCancal = jsonRequest.getBytes(StandardCharsets.UTF_8);
                        os.write(inputCancal, 0, inputCancal.length);
                    }


                    validarConexaoCapitalizacaoTempApi(dataHoraAtual, connectionCancal, canal, null,
                        listaCapitalizacaoTemp);

                }

                if (minutos >= INTERVALO_CAP) {

                    consultaApiCaptalizacaoDao.inserirConsultaApi(listaCapitalizacaoTemp);

                    consultaApiCaptalizacaoDao.validarDuplicados(listaCapitalizacaoTemp);

                    consultaApiCaptalizacaoDao.liberarProcessamento(listaCapitalizacaoTemp);
                }
            }
        } catch (SQLException | IOException e) {
            LOGGER.error(ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    // Metodo responsavel por buscar o tempo parametrizado em milisegundos 900000
    public int buscaTempoParametrizado() {

        // Necessario implementar consulta na tabela de config de tempos para buscar os
        // parametros
        // status = true erro identificado
        if (status) {
            return TEMPO_PARAMETRIZADO_SUCESSO;
        }

        return TEMPO_PARAMETRIZADO_ERRO;
    }

    public TabelaTemp obterCapitalizacaoNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        status = true;
        TabelaTemp capitalizacaoTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        capitalizacaoTemp.setcorrigeDado(CORRIGE_DADO);
        capitalizacaoTemp.setCindRegProcs("J");
        // Codigo de retorno
        capitalizacaoTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        capitalizacaoTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        capitalizacaoTemp.setRenderUrlOrign(enderecoApi);
        capitalizacaoTemp.setRservcOrign(null);
        capitalizacaoTemp.setItransOrign("A001");
        capitalizacaoTemp.setRtransOrign(metodosApi);
        capitalizacaoTemp.setIapiOrign(enderecoApi);
        capitalizacaoTemp.setIcanalOrign(canal);
        capitalizacaoTemp.setIemprOrign("CAPI");
        capitalizacaoTemp.setIprodtOrign(PRODUTO);
        capitalizacaoTemp.setIsprodOrign(null);
        capitalizacaoTemp.setIetapaOfert(enderecoApi);
        capitalizacaoTemp.setIplatfOrign(PLATA_FORMA_ORIGN);
        capitalizacaoTemp.setIsitEvnto("NOK");
        capitalizacaoTemp.setDinicErro(dataHoraAtual);
        capitalizacaoTemp.setDfimErro(null);
        capitalizacaoTemp.setDinclReg(dataHoraAtual);
        capitalizacaoTemp.setDaltReg(null);

        return capitalizacaoTemp;
    }

    public static TabelaTemp obterCapitalizacaoOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp capTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        capTemp.setcorrigeDado(CORRIGE_DADO);
        capTemp.setCindRegProcs("J");
        // Codigo de retorno
        capTemp.setCerroOrign("200");
        capTemp.setRmsgemErroOrign("OK");
        // Endereco API consultada
        capTemp.setRenderUrlOrign(enderecoApi);
        capTemp.setRservcOrign(null);
        capTemp.setItransOrign("A001");
        capTemp.setRtransOrign(metodosApi);
        capTemp.setIapiOrign(enderecoApi);
        capTemp.setIcanalOrign(canal);
        capTemp.setIemprOrign("CAPI");
        capTemp.setIprodtOrign(PRODUTO);
        capTemp.setIsprodOrign(null);
        capTemp.setIetapaOfert(enderecoApi);
        capTemp.setIplatfOrign(PLATA_FORMA_ORIGN);
        capTemp.setIsitEvnto("OK");
        capTemp.setDinicErro(dataHoraAtual);
        capTemp.setDfimErro(null);
        capTemp.setDinclReg(dataHoraAtual);
        capTemp.setDaltReg(null);

        return capTemp;
    }

    public void validarConexaoCapitalizacaoTemp(LocalDateTime dataHoraAtual, HttpURLConnection connection,
        String canal, String enderecoApi, LinkedList<TabelaTemp> listaCapitalizacaoTemp, String metodosApi)
        throws IOException {

        if (connection.getResponseCode() != RESPONSE_CODE_400 && connection.getResponseCode() != RESPONSE_CODE_200) {
            // Consulta Realizada com erro
            status = true;

            listaCapitalizacaoTemp
                .addLast(obterCapitalizacaoNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {
            // Consulta Realizada com sucesso
            status = false;

            listaCapitalizacaoTemp.addLast(obterCapitalizacaoOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    public void validarConexaoCapitalizacaoTempApi(LocalDateTime dataHoraAtual, HttpURLConnection connection,
        String canal, String metodosApi, LinkedList<TabelaTemp> listaCapitalizacaoTemp) throws IOException {

        if (connection.getResponseCode() != RESPONSE_CODE_400 && connection.getResponseCode() != RESPONSE_CODE_200) {
            status = true;

            listaCapitalizacaoTemp.addLast(obterCapitalizacaoNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            status = false;

            listaCapitalizacaoTemp.addLast(obterCapitalizacaoOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
