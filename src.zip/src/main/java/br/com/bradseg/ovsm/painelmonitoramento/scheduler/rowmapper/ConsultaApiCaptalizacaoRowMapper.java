package br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ConsultaApiCaptalizacaoRowMapper implements RowMapper<String> {

    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
        return rs.getString("DINCL_REG");
    }

}
