package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Visao evento por produtos para preenchimento de cards.
 * 
 * @author Wipro
 */
public class VisaoEventoProduto {

    private Integer quantidadeOcorrencia;
    private BigDecimal codigoProduto;
    private String descricaoProduto;
    private Integer porcentagemOcorrencia;

    public VisaoEventoProduto() {
        super();
    }

    public Integer getQuantidadeOcorrencia() {
        return quantidadeOcorrencia;
    }

    public void setQuantidadeOcorrencia(Integer quantidadeOcorrencia) {
        this.quantidadeOcorrencia = quantidadeOcorrencia;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public Integer getPorcentagemOcorrencia() {
        return porcentagemOcorrencia;
    }

    public void setPorcentagemOcorrencia(Integer porcentagemOcorrencia) {
        this.porcentagemOcorrencia = porcentagemOcorrencia;
    }

}
