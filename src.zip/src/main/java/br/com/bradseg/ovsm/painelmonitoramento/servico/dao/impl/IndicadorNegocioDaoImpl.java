package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.IndicadorNegocioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.IndicadoresNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaEventoPorCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaIndicadoresNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.NumeroTransacoesRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.TipoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaTempoRealVolumetriaMaximaRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VolumetriaVisaoNegocioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

@Repository
public class IndicadorNegocioDaoImpl implements IndicadorNegocioDao {

    public static final String ERROR = "Error: ";
    private static final String NENHUM_DADO = "Nenhum dado encontrado";
    public static final String CCANAL_DGTAL_PNEL = "CCANAL_DGTAL_PNEL";
    public static final String DATA_INICIO = "dataInicio";
    public static final String DATA_FIM = "dataFim";
    private static final int INT_0 = 0;
    private static final int INT_1 = 1;
    private static final int INT_2 = 2;
    private static final int INT_3 = 3;
    private static final int INT_5 = 5;
    private static final int INT_6 = 6;
    private static final int INT_7 = 7;
    private static final double DOUBLE_24 = 24D;
    private static final int INT_30 = 30;
    private static final int INT_3600 = 3600;
    private static final String PERIODO = "periodo";
    private static final String PERIODO_DE = "periodoDe";
    private static final String PERIODO_ATE = "periodoAte";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final Logger LOGGER = LogManager.getLogger(IndicadorNegocioDaoImpl.class);
    private static final String SELECT = " SELECT ";
    private static final String FROM = " FROM ";
    private static final String FROM_OVSM_PNEL_MNTRD_HORA_T = " FROM OVSM.PNEL_MNTRD_HORA T ";
    private static final String FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN = FROM_OVSM_PNEL_MNTRD_HORA_T
        + " JOIN OVSM.PRODT_PNEL T4 ON "
        + "    T.CPRODT_PNEL = T4.CPRODT_PNEL "
        + " JOIN OVSM.CANAL_DGTAL_PNEL T5 ON "
        + "    T.CCANAL_DGTAL_PNEL = T5.CCANAL_DGTAL_PNEL ";
    private static final String AND_CCANAL_DGTAL_PNEL_IN = " AND CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO_IN = " AND CPRODT_PNEL IN ( ";
    private static final String AND_TCCANAL_DGTAL_PNEL_IN = " AND T.CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_TCPRODT_PNEL_CODIGO_PRODUTO_IN = " AND T.CPRODT_PNEL IN ( ";
    private static final String AND_PNEL_HORA_CPRODT_PNEL_IN = " AND PNEL_HORA.CPRODT_PNEL IN ( ";
    private static final String AND_PNEL_HORA_CCANAL_DGTAL_PNEL_IN = " AND PNEL_HORA.CCANAL_DGTAL_PNEL IN (";
    private static final String DPROCS_APLIC_BETWEEN = " DPROCS_APLIC BETWEEN TO_DATE(:periodoDe, ";
    private static final String AND_DPROCS_APLIC_BETWEEN_TO_DATE_1 = DPROCS_APLIC_BETWEEN
        + "'yyyy-mm-dd HH24:MI') AND TO_DATE(:periodoAte, 'yyyy-mm-dd HH24:MI') ";
    private static final String AND_DPROCS_APLIC_BETWEEN_TO_DATE_7 = DPROCS_APLIC_BETWEEN
        + "'yyyy-mm-dd') AND TO_DATE(:periodoAte, 'yyyy-mm-dd') ";
    private static final String AND_DPROCS_APLIC_BETWEEN_TO_DATE_30 = DPROCS_APLIC_BETWEEN
        + "'yyyy-mm-dd') AND TO_DATE(:periodoAte, 'yyyy-mm-dd') ";
    private static final String WHERE_T_DPROCS_APLIC_BETWEEN = " WHERE T.DPROCS_APLIC BETWEEN ";
    private static final String WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1 = WHERE_T_DPROCS_APLIC_BETWEEN
        + "TO_DATE(:periodoDe, 'yyyy-mm-dd HH24:MI') AND TO_DATE(:periodoAte, 'yyyy-mm-dd HH24:MI') ";
    private static final String WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7 = WHERE_T_DPROCS_APLIC_BETWEEN
        + "TO_DATE(:periodoDe, 'yyyy-mm-dd') AND TO_DATE(:periodoAte, 'yyyy-mm-dd') ";
    private static final String WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30 = WHERE_T_DPROCS_APLIC_BETWEEN
        + "TO_DATE(:periodoDe, 'yyyy-mm-dd') AND TO_DATE(:periodoAte, 'yyyy-mm-dd') ";
    private static final String COMPLEMENTO_HORA = " 00:00";

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_VOLUMETRIA_MAXIMA = "SELECT SUM"
        + " (QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC)" + " AS SOMA_VOLUMETRIA_ATUAL,"
        + " SUM(QTRANS_EXECT_SCESS) AS SOMA_SEM_EVENTO,"
        + " SUM(QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO, ROUND(SUM(QMED_TRANS_PARMD)) AS MEDIA_VOLUMETRIA_HISTORICA "
        + FROM + Constantes.OWNER_TABELA + "PNEL_MNTRD_HORA"
        + " WHERE ";

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO = SELECT
        + " SUM(T.QTRANS_EXECT_SCESS + T.QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
        + " SUM(T.QTRANS_EXECT_SCESS) AS SOMA_SEM_EVENTO, "
        + " SUM(T.QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO, "
        + " MEDIAN(T.QTRANS_EXECT_INSUC + T.QTRANS_EXECT_INSUC ) AS MEDIA_HISTORICA, ";

    private static final String TO_CHAR_DPROCS_APLIC_DIA = " TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd HH24:MI') "
        + " AS HORA_OCORRENCIA ";
    private static final String TO_CHAR_DPROCS_APLIC_SEMANA = " TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd') "
        + " AS HORA_OCORRENCIA ";
    private static final String TO_CHAR_DPROCS_APLIC_MES = " TO_CHAR(T.DPROCS_APLIC,'yyyy-mm') AS HORA_OCORRENCIA ";

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_RELATORIO = SELECT
        + " T4.IPRODT AS PRODUTO, "
        + " T5.ICANAL_DGTAL_PNEL AS CANAL, "
        + " SUM(T.QTRANS_EXECT_SCESS + T.QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
        + " SUM(T.QTRANS_EXECT_SCESS) AS SOMA_SEM_EVENTO, "
        + " SUM(T.QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO, "
        + " MEDIAN(T.QTRANS_EXECT_INSUC + T.QTRANS_EXECT_INSUC ) AS MEDIA_HISTORICA";

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_DIA = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO
        + TO_CHAR_DPROCS_APLIC_DIA
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1;

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO
        + TO_CHAR_DPROCS_APLIC_SEMANA
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7;

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO
        + TO_CHAR_DPROCS_APLIC_MES
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30;

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_DIA_RELATORIO = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_RELATORIO
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1;

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL_RELATORIO = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_RELATORIO
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7;

    private static final String SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES_RELATORIO = 
        SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_RELATORIO
        + FROM_OVSM_PNEL_MNTRD_HORA_T_JOIN
        + WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30;

    private static final String SELECT_VOLUMETRIA_VISAO_NEGOCIO = " SELECT PNEL_HORA.CCANAL_DGTAL_PNEL,"
        + " CANAL.ICANAL_DGTAL_PNEL, " + "  SUM(PNEL_HORA.QTRANS_EXECT_SCESS) AS VOLUME_TRANSACAO,"
        + " SUM(PNEL_HORA.QMED_TRANS_PARMD) AS HISTORICO,"
        + " SUM (PNEL_HORA.QTRANS_EXECT_SCESS + PNEL_HORA.QTRANS_EXECT_INSUC) AS VOLUMETRIA_MAXIMA,"
        + " SUM(PNEL_HORA.QEVNTO_NORML_DISPN) AS EVNTO_NORML_DISPN,"
        + " SUM(PNEL_HORA.QEVNTO_NORML_FUNCL) AS EVNTO_NORML_FUNC,"
        + " SUM(PNEL_HORA.QEVNTO_NORML_CNXAO) AS EVNTO_NORML_CNXAO,"
        + " SUM(PNEL_HORA.QEVNTO_MRADO_DISPN + PNEL_HORA.QEVNTO_MRADO_FUNCL + PNEL_HORA.QEVNTO_MRADO_CNXAO +"
        + " PNEL_HORA.QEVNTO_GRAVE_FUNCL + PNEL_HORA.QEVNTO_GRAVE_DISPN +"
        + " PNEL_HORA.QEVNTO_GRAVE_CNXAO) AS SOMA_TOTAL_EVENTO,"
        + " SUM(PNEL_HORA.QEVNTO_GRAVE_FUNCL + PNEL_HORA.QEVNTO_GRAVE_DISPN +"
        + " PNEL_HORA.QEVNTO_GRAVE_CNXAO) AS SOMA_EVENTO_GRAVE"
        + " FROM OVSM.PNEL_MNTRD_HORA PNEL_HORA, OVSM.CANAL_DGTAL_PNEL CANAL"
        + " WHERE PNEL_HORA.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL "
        + " AND DPROCS_APLIC BETWEEN :periodoDe AND :periodoAte "
        + " AND DPROCS_APLIC >= SYSTIMESTAMP - :periodo AND DPROCS_APLIC <= SYSTIMESTAMP"
        + " AND PNEL_HORA.CCANAL_DGTAL_PNEL <> -2";

    private static final String QUERY_GERAL = "SELECT SUM(T.QEVNTO_NORML_FUNCL +"
        + " T.QEVNTO_NORML_DISPN + T.QEVNTO_NORML_CNXAO) AS SOMA_EVENTOS, "
        + " SUM(T.QTRANS_EXECT_SCESS + T.QTRANS_EXECT_INSUC) AS SOMA_TRANSACOES, "
        + " SUM(T.QTRANS_EXECT_INSUC) AS TRANSACOES_IMPACTADAS, "
        + " SUM(T2.QSEGDA_EVNTO) AS SOMA_TEMPO_EVENTOS, "
        + " MEDIAN(T2.QSEGDA_EVNTO) AS MEDIA_TEMPO_EVENTOS, "
        + " MEDIAN(T2.QRCRRC_ERRO_EVNTO) AS FREQUENCIA_EVENTOS "
        + " FROM OVSM.PNEL_MNTTO_CNXAO T "
        + " JOIN OVSM.RCRRC_EVNTO T2 "
        + " ON T.CEMPR_PNEL = T2.CEMPR_PNEL AND "
        + " T.CPRODT_PNEL = T2.CPRODT_PNEL AND "
        + " T.CCANAL_DGTAL_PNEL = T2.CCANAL_DGTAL_PNEL AND "
        + " T.DVERIF_APLIC = T2.DVERIF_APLIC ";

    private static final String QUERY_GERAL_RELATORIO = SELECT
        + " T4.IPRODT AS PRODUTO, "
        + " T5.ICANAL_DGTAL_PNEL AS CANAL, "
        + " SUM(T.QEVNTO_NORML_FUNCL +"
        + " T.QEVNTO_NORML_DISPN + T.QEVNTO_NORML_CNXAO) AS SOMA_EVENTOS, "
        + " SUM(T.QTRANS_EXECT_SCESS + T.QTRANS_EXECT_INSUC) AS SOMA_TRANSACOES, "
        + " SUM(T.QTRANS_EXECT_INSUC) AS TRANSACOES_IMPACTADAS, "
        + " SUM(T2.QSEGDA_EVNTO) AS SOMA_TEMPO_EVENTOS, "
        + " MEDIAN(T2.QSEGDA_EVNTO) AS MEDIA_TEMPO_EVENTOS, "
        + " MEDIAN(T2.QRCRRC_ERRO_EVNTO) AS FREQUENCIA_EVENTOS "
        + " FROM OVSM.PNEL_MNTTO_CNXAO T "
        + " JOIN OVSM.RCRRC_EVNTO T2 "
        + " ON T.CEMPR_PNEL = T2.CEMPR_PNEL AND "
        + " T.CPRODT_PNEL = T2.CPRODT_PNEL AND "
        + " T.CCANAL_DGTAL_PNEL = T2.CCANAL_DGTAL_PNEL AND "
        + " T.DVERIF_APLIC = T2.DVERIF_APLIC "
        + " JOIN OVSM.PRODT_PNEL T4 ON "
        + "    T.CPRODT_PNEL = T4.CPRODT_PNEL "
        + " JOIN OVSM.CANAL_DGTAL_PNEL T5 ON "
        + "    T.CCANAL_DGTAL_PNEL = T5.CCANAL_DGTAL_PNEL ";

    private static final String WHERE_BETWEEN = WHERE_T_DPROCS_APLIC_BETWEEN
        + "TO_DATE(:dataInicio, 'yyyy-mm-dd') AND TO_DATE(:dataFim, 'yyyy-mm-dd') ";
    private static final String WHERE_BETWEEN_COMPARATIVA = WHERE_T_DPROCS_APLIC_BETWEEN
        + "TO_DATE(:dataInicio, 'yyyy-mm-dd')-30 AND TO_DATE(:dataInicio, 'yyyy-mm-dd') ";
    private static final String GROUPBY_RELATORIO_INDICADORES = " GROUP BY T4.IPRODT, T5.ICANAL_DGTAL_PNEL ";
    private static final String AND_CCANAL_DGTAL_PNEL_IN_INDICADORES = " AND T.CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_INDICADORES = " AND T.CPRODT_PNEL IN ( ";

    private static final String SELECT_PRODUTO_E_CANAL = " SELECT OVSM.PRODT_PNEL.IPRODT AS PRODUTO, "
        + "OVSM.CANAL_DGTAL_PNEL.ICANAL_DGTAL_PNEL AS CANAL ";

    private static final String FROM_TABLES_COLUMNS = " FROM OVSM.PRODT_PNEL, "
        + "OVSM.CANAL_DGTAL_PNEL, OVSM.RCRRC_EVNTO, OVSM.PNEL_MNTTO_CNXAO "
        + "WHERE OVSM.RCRRC_EVNTO.CPRODT_PNEL = OVSM.PRODT_PNEL.CPRODT_PNEL "
        + "AND OVSM.RCRRC_EVNTO.CCANAL_DGTAL_PNEL = OVSM.CANAL_DGTAL_PNEL.CCANAL_DGTAL_PNEL "
        + "AND OVSM.PNEL_MNTTO_CNXAO.CEMPR_PNEL = OVSM.RCRRC_EVNTO.CEMPR_PNEL "
        + "AND OVSM.PNEL_MNTTO_CNXAO.CPRODT_PNEL = OVSM.RCRRC_EVNTO.CPRODT_PNEL "
        + "AND OVSM.PNEL_MNTTO_CNXAO.CCANAL_DGTAL_PNEL = OVSM.RCRRC_EVNTO.CCANAL_DGTAL_PNEL "
        + "AND OVSM.PNEL_MNTTO_CNXAO.DVERIF_APLIC = OVSM.RCRRC_EVNTO.DVERIF_APLIC "
        + "AND OVSM.PNEL_MNTTO_CNXAO.CERRO_CNXAO_PNEL = OVSM.RCRRC_EVNTO.CERRO_CNXAO_PNEL "
        + "AND DPROCS_APLIC BETWEEN :dataInicio AND :dataFim ";

    private static final String LIMIT_15 = " OFFSET 0 ROWS FETCH FIRST 15 ROWS ONLY ";
    private static final String SUM_DURACAO = ", SUM (OVSM.RCRRC_EVNTO.QSEGDA_EVNTO) AS DURACAO ";
    private static final String SUM_IMPACTO = ", SUM (OVSM.RCRRC_EVNTO.QTRANS_EXECT_INSUC) AS IMPACTO ";
    private static final String SUM_RECORRENCIA = ", SUM (OVSM.RCRRC_EVNTO.QRCRRC_ERRO_EVNTO) AS RECORRENCIA ";

    private static final String GROUP_BY = " GROUP BY (OVSM.PRODT_PNEL.IPRODT, "
        + "OVSM.CANAL_DGTAL_PNEL.ICANAL_DGTAL_PNEL, ";
    private static final String ORDER_BY = "ORDER BY ";
    private static final String DESC = " DESC ";

    private static final String ORDER_BY_DURACAO = " DURACAO ";
    private static final String ORDER_BY_IMPACTO = " IMPACTO ";
    private static final String ORDER_BY_RECORRENCIA = " RECORRENCIA ";
    private static final String GROUP_BY_RECORRENCIA = " OVSM.RCRRC_EVNTO.QRCRRC_ERRO_EVNTO) ";
    private static final String GROUP_BY_IMPACTO = " OVSM.RCRRC_EVNTO.QTRANS_EXECT_INSUC) ";
    private static final String GROUP_BY_DURACAO = " OVSM.RCRRC_EVNTO.QSEGDA_EVNTO) ";

    private static final String AND_CCANAL_DGTAL_PNEL_IN_DETALHAMENTO = " AND T.CCANAL_DGTAL_PNEL IN ( ";
    private static final String AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_DETALHAMENTO = " AND T.CPRODT_PNEL IN ( ";
    private static final String QUERY_TRANSACOES = " SELECT SUM "
        + " (T.QTRANS_EXECT_SCESS + T.QTRANS_EXECT_INSUC) AS SOMA_TRANSACOES, "
        + " SUM(T.QTRANS_EXECT_SCESS) AS TRANSACOES_SCESS, "
        + " SUM(T.QTRANS_EXECT_INSUC) AS TRANSACOES_INSUC "
        + FROM_OVSM_PNEL_MNTRD_HORA_T;

    private static final String QUERY_EVENTO_CANAL = " SELECT T.CCANAL_DGTAL_PNEL AS CANAL, "
        + " T1.ICANAL_DGTAL_PNEL AS DESC_CANAL, "
        + " SUM(T.QEVNTO_NORML_FUNCL + T.QEVNTO_NORML_DISPN + T.QEVNTO_NORML_CNXAO) AS SOMAS_EVENTOS "
        + FROM_OVSM_PNEL_MNTRD_HORA_T
        + " JOIN OVSM.CANAL_DGTAL_PNEL T1 "
        + " ON T.CCANAL_DGTAL_PNEL = T1.CCANAL_DGTAL_PNEL ";

    private static final String GROUP_ORDER_EVENTO_CANAL = " GROUP BY T.CCANAL_DGTAL_PNEL, "
        + " T1.ICANAL_DGTAL_PNEL "
        + " ORDER BY T.CCANAL_DGTAL_PNEL ";

    private static final String GROUP_BY_PRODUTO_CANAL = " GROUP BY T4.IPRODT, T5.ICANAL_DGTAL_PNEL ";

    private static final String ORDER_BY_PRODUTO_CANAL = " ORDER BY T4.IPRODT, T5.ICANAL_DGTAL_PNEL ";

    private static final String QUERY_TIPO_EVENTO = SELECT
        + " SUM(T.QEVNTO_NORML_DISPN + T.QEVNTO_MRADO_DISPN + T.QEVNTO_GRAVE_DISPN) AS SOMA_DISPONIBILIDADE, "
        + " SUM(T.QEVNTO_NORML_FUNCL + T.QEVNTO_MRADO_FUNCL + T.QEVNTO_GRAVE_FUNCL) AS SOMA_FUNCIONALIDADE, "
        + " SUM(T.QEVNTO_NORML_CNXAO + T.QEVNTO_MRADO_CNXAO + T.QEVNTO_GRAVE_CNXAO) AS SOMA_VOLUMETRIA, "
        + " SUM(T.QEVNTO_NORML_DISPN + T.QEVNTO_MRADO_DISPN + T.QEVNTO_GRAVE_DISPN "
        + " + T.QEVNTO_NORML_FUNCL + T.QEVNTO_MRADO_FUNCL + T.QEVNTO_GRAVE_FUNCL "
        + " + T.QEVNTO_NORML_CNXAO + T.QEVNTO_MRADO_CNXAO + T.QEVNTO_GRAVE_CNXAO) AS SOMA_TOTAL "
        + FROM_OVSM_PNEL_MNTRD_HORA_T;

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public IndicadorNegocioDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {
        try {

            StringBuilder sql = new StringBuilder(SELECT_VOLUMETRIA_TEMPO_REAL_VOLUMETRIA_MAXIMA);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (periodoVisaoEvento == INT_1) {
                params.addValue(PERIODO, INT_1);
                if (checkDatas(dataInicio, dataFim)) {
                    sql.append(AND_DPROCS_APLIC_BETWEEN_TO_DATE_1);
                    params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                        + "-" + dataInicio.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                    params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                }
            } else if (periodoVisaoEvento == INT_2) {
                params.addValue(PERIODO, INT_7);
                if (checkDatas(dataInicio, dataFim)) {
                    sql.append(AND_DPROCS_APLIC_BETWEEN_TO_DATE_7);
                    params.addValue(PERIODO_DE,
                        dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                            + dataInicio.substring(INT_0, INT_2));
                    params.addValue(PERIODO_ATE,
                        dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                            + dataFim.substring(INT_0, INT_2));
                }
            } else {
                params.addValue(PERIODO, INT_30);
                if (checkDatas(dataInicio, dataFim)) {
                    sql.append(AND_DPROCS_APLIC_BETWEEN_TO_DATE_30);
                    params.addValue(PERIODO_DE,
                        dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                            + dataInicio.substring(INT_0, INT_2));
                    params.addValue(PERIODO_ATE,
                        dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                            + dataFim.substring(INT_0, INT_2));
                }
            }

            sql.append(filtroListas(listaCodigoProduto, AND_CPRODT_PNEL_CODIGO_PRODUTO_IN));
            sql.append(filtroListas(listaCodigoCanal, AND_CCANAL_DGTAL_PNEL_IN));

            return jdbcTemplate.queryForObject(sql.toString(), params,
                new VolumetriaTempoRealVolumetriaMaximaRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();

            Object[] objectParams = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixa(periodoVisaoEvento, objectParams, sql, sqlGroup,
                params, dataInicio, dataFim);

            List<VolumetriaTempoReal> listaindicadoresVolumetriaTempoReal = jdbcTemplate.queryForObject(
                sql.toString() + sqlGroup.toString(), params,
                new VolumetriaTempoRealRowMapper());

            List<VolumetriaTempoReal> listaAnteriorIndicadoresVolumetriaTempoReal = 
                obterVolumetriaTempoRealFaixaTempoAnterior(
                periodoVisaoEvento,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim);

            if (listaAnteriorIndicadoresVolumetriaTempoReal != null &&
                listaAnteriorIndicadoresVolumetriaTempoReal.isEmpty()) {
                for (int i = 0; i < listaindicadoresVolumetriaTempoReal.size(); i++) {
                    listaindicadoresVolumetriaTempoReal.get(i).setMediaHistoricaTransacao(BigDecimal.ZERO);
                }
            }

            return listaindicadoresVolumetriaTempoReal;

        } catch (EmptyResultDataAccessException eVolumetriaTempoReal) {
            LOGGER.error(eVolumetriaTempoReal);
            throw new AcessoADadosException("Nenhum resultado encontrado.");
        } catch (AcessoADadosException eVolumetriaTempoReal) {
            LOGGER.error(eVolumetriaTempoReal);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoRelatorio(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();

            Object[] objectParams = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixaRelatorio(periodoVisaoEvento, objectParams, sql, sqlGroup,
                params, dataInicio, dataFim);

            List<VolumetriaTempoReal> listaindicadoresRelatorio = jdbcTemplate.queryForObject(
                sql.toString() + sqlGroup.toString(), params,
                new VolumetriaTempoRealRowMapper());

            List<VolumetriaTempoReal> listaAnteriorIndicadoresRelatorio = 
                obterVolumetriaTempoRealFaixaTempoAnteriorRelatorio(
                periodoVisaoEvento,
                listaCodigoProduto, listaCodigoCanal, dataInicio, dataFim);

            if (listaAnteriorIndicadoresRelatorio != null && listaAnteriorIndicadoresRelatorio.isEmpty()) {
                for (int i = 0; i < listaindicadoresRelatorio.size(); i++) {
                    listaindicadoresRelatorio.get(i).setMediaHistoricaTransacao(BigDecimal.ZERO);
                }
            }

            return listaindicadoresRelatorio;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("Nenhum resultado encontrado.");
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private static void obterParametrosVolumetriaTempoRealFaixa(Integer periodoVisaoEvento, Object[] objectParams,
        StringBuilder sql, StringBuilder sqlGroup, MapSqlParameterSource params, String dataInicio, String dataFim) {

        List<BigDecimal> listaCodigoProdutoParametros = (List<BigDecimal>) objectParams[0];
        List<BigDecimal> listaCodigoCanalParametros = (List<BigDecimal>) objectParams[1];

        if (periodoVisaoEvento == INT_1) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_DIA);
            sqlGroup.append(" GROUP BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd HH24:MI')");
            sqlGroup.append(" ORDER BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd HH24:MI')");

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                + "-" + dataInicio.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                + dataFim.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
        } else if (periodoVisaoEvento == INT_2) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL);
            sqlGroup.append(" GROUP BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd') ");
            sqlGroup.append(" ORDER BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm-dd') ");

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                + dataInicio.substring(INT_0, INT_2));
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                + dataFim.substring(INT_0, INT_2));
        } else {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES);
            sqlGroup.append(" GROUP BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm') ");
            sqlGroup.append(" ORDER BY TO_CHAR(T.DPROCS_APLIC,'yyyy-mm') ");

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                + dataInicio.substring(INT_0, INT_2));
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                + dataFim.substring(INT_0, INT_2));
        }

        if (listaCodigoProdutoParametros != null && !listaCodigoProdutoParametros.isEmpty()) {

            StringBuilder textoCodigoProdutoParametros = new StringBuilder();
            textoCodigoProdutoParametros.append(listaCodigoProdutoParametros.get(0).toString());
            for (int i = 0; i < listaCodigoProdutoParametros.size(); i++) {

                textoCodigoProdutoParametros.append(",");
                textoCodigoProdutoParametros.append(listaCodigoProdutoParametros.get(i).toString());

            }

            sql.append(AND_TCPRODT_PNEL_CODIGO_PRODUTO_IN + textoCodigoProdutoParametros + " )");
        }

        if (listaCodigoCanalParametros != null && !listaCodigoCanalParametros.isEmpty()) {

            StringBuilder textoCodigoCanalParametros = new StringBuilder();
            textoCodigoCanalParametros.append(listaCodigoCanalParametros.get(0).toString());
            for (int i = 0; i < listaCodigoCanalParametros.size(); i++) {

                textoCodigoCanalParametros.append(",");
                textoCodigoCanalParametros.append(listaCodigoCanalParametros.get(i).toString());

            }

            sql.append(AND_TCCANAL_DGTAL_PNEL_IN + textoCodigoCanalParametros + " )");
        }
    }

    private static void obterParametrosVolumetriaTempoRealFaixaRelatorio(Integer periodoVisaoEvento,
        Object[] objectParams,
        StringBuilder sql, StringBuilder sqlGroup, MapSqlParameterSource params, String dataInicio, String dataFim) {

        List<BigDecimal> listaCodigoProdutoRelatorio = (List<BigDecimal>) objectParams[0];
        List<BigDecimal> listaCodigoCanalRelatorio = (List<BigDecimal>) objectParams[1];

        if (periodoVisaoEvento == INT_1) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_DIA_RELATORIO);
            sqlGroup.append(GROUP_BY_PRODUTO_CANAL);
            sqlGroup.append(ORDER_BY_PRODUTO_CANAL);

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                + "-" + dataInicio.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                + dataFim.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
        } else if (periodoVisaoEvento == INT_2) {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_SEMANAL_RELATORIO);
            sqlGroup.append(GROUP_BY_PRODUTO_CANAL);
            sqlGroup.append(ORDER_BY_PRODUTO_CANAL);

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                + dataInicio.substring(INT_0, INT_2));
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                + dataFim.substring(INT_0, INT_2));
        } else {
            sql.append(SELECT_VOLUMETRIA_TEMPO_REAL_FAIXA_TEMPO_PERIODO_MES_RELATORIO);
            sqlGroup.append(GROUP_BY_PRODUTO_CANAL);
            sqlGroup.append(ORDER_BY_PRODUTO_CANAL);

            params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5));
            params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5));
        }

        if (listaCodigoProdutoRelatorio != null && !listaCodigoProdutoRelatorio.isEmpty()) {

            StringBuilder textoCodigoProdutoRelatorio = new StringBuilder();
            textoCodigoProdutoRelatorio.append(listaCodigoProdutoRelatorio.get(0).toString());
            for (int i = 0; i < listaCodigoProdutoRelatorio.size(); i++) {

                textoCodigoProdutoRelatorio.append(",");
                textoCodigoProdutoRelatorio.append(listaCodigoProdutoRelatorio.get(i).toString());

            }

            sql.append(AND_TCPRODT_PNEL_CODIGO_PRODUTO_IN + textoCodigoProdutoRelatorio + " )");
        }

        if (listaCodigoCanalRelatorio != null && !listaCodigoCanalRelatorio.isEmpty()) {

            StringBuilder textoCodigoCanalRelatorio = new StringBuilder();
            textoCodigoCanalRelatorio.append(listaCodigoCanalRelatorio.get(0).toString());
            for (int i = 0; i < listaCodigoCanalRelatorio.size(); i++) {

                textoCodigoCanalRelatorio.append(",");
                textoCodigoCanalRelatorio.append(listaCodigoCanalRelatorio.get(i).toString());

            }

            sql.append(AND_TCCANAL_DGTAL_PNEL_IN + textoCodigoCanalRelatorio + " )");
        }
    }

    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoAnterior(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();

            Object[] objectParam = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixa(periodoVisaoEvento, objectParam, sql, sqlGroup, params,
                dataInicio, dataFim);

            return jdbcTemplate.queryForObject(sql.toString() + sqlGroup.toString(), params,
                new VolumetriaTempoRealRowMapper());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoAnteriorRelatorio(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        try {
            StringBuilder sql = new StringBuilder();
            MapSqlParameterSource params = new MapSqlParameterSource();

            StringBuilder sqlGroup = new StringBuilder();

            Object[] objectParam = {listaCodigoProduto, listaCodigoCanal};

            obterParametrosVolumetriaTempoRealFaixaRelatorio(periodoVisaoEvento, objectParam, sql, sqlGroup, params,
                dataInicio, dataFim);

            return jdbcTemplate.queryForObject(sql.toString() + sqlGroup.toString(), params,
                new VolumetriaTempoRealRowMapper());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<VolumetriaVisaoNegocio> obterVolumetriaVisaoNegocio(Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, Date dataInicio, Date dataFim) {
        try {

            StringBuilder sql = new StringBuilder(SELECT_VOLUMETRIA_VISAO_NEGOCIO);
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            if (dataInicio != null && dataFim != null) {
                parametros.addValue(PERIODO_DE, dataInicio);
                parametros.addValue(PERIODO_ATE, dataFim);
            }

            if (periodo == INT_1) {
                parametros.addValue(PERIODO, INT_1);
            } else if (periodo == INT_2) {
                parametros.addValue(PERIODO, INT_7);
            } else {
                parametros.addValue(PERIODO, INT_30);
            }

            sql.append(filtroListas(listaCodigoProduto, AND_PNEL_HORA_CPRODT_PNEL_IN));

            sql.append(filtroListas(listaCodigoCanal, AND_PNEL_HORA_CCANAL_DGTAL_PNEL_IN));

            sql.append(" GROUP BY PNEL_HORA.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL ");

            return jdbcTemplate.queryForObject(sql.toString(), parametros,
                new VolumetriaVisaoNegocioRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(NENHUM_DADO, INT_2);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    @Override
    public IndicadoresNegocio obterIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {
        try {

            StringBuilder sqlIndicadoresNegocio = new StringBuilder(QUERY_GERAL);
            MapSqlParameterSource paramsIndicadoresNegocio = new MapSqlParameterSource();

            if (checkDatas(dataInicio, dataFim)) {
                sqlIndicadoresNegocio.append(WHERE_BETWEEN);
                paramsIndicadoresNegocio.addValue(DATA_INICIO,
                    dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                        + "-" + dataInicio.substring(INT_0, INT_2));
                paramsIndicadoresNegocio.addValue(DATA_FIM,
                    dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2));
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProdutoIndNegocio = new StringBuilder();
                textoProdutoIndNegocio.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProdutoIndNegocio.append(",");
                    textoProdutoIndNegocio.append(listaCodigoProduto.get(i).toString());
                }

                sqlIndicadoresNegocio
                    .append(AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_INDICADORES + textoProdutoIndNegocio.toString() + " )");

            }

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder textoCanalIndNegocio = new StringBuilder();
                textoCanalIndNegocio.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    textoCanalIndNegocio.append(",");
                    textoCanalIndNegocio.append(listaCodigoCanal.get(i).toString());
                }

                sqlIndicadoresNegocio
                    .append(AND_CCANAL_DGTAL_PNEL_IN_INDICADORES + textoCanalIndNegocio.toString() + " )");

            }

            return jdbcTemplate.queryForObject(sqlIndicadoresNegocio.toString(), paramsIndicadoresNegocio,
                new IndicadoresNegocioRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public IndicadoresNegocio obterIndicadoresNegocioComparacao(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {
        try {

            StringBuilder sqlIndicadoresNegocioComp = new StringBuilder(QUERY_GERAL);
            MapSqlParameterSource paramsIndicadoresNegocioComp = new MapSqlParameterSource();

            if (checkDatas(dataInicio, dataFim)) {
                sqlIndicadoresNegocioComp.append(WHERE_BETWEEN_COMPARATIVA);
                paramsIndicadoresNegocioComp.addValue(DATA_INICIO,
                    dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                        + "-" + dataInicio.substring(INT_0, INT_2));
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProdutoIndicadoresNegocioComp = new StringBuilder();
                textoProdutoIndicadoresNegocioComp.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProdutoIndicadoresNegocioComp.append(",");
                    textoProdutoIndicadoresNegocioComp.append(listaCodigoProduto.get(i).toString());
                }

                sqlIndicadoresNegocioComp.append(AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_INDICADORES
                    + textoProdutoIndicadoresNegocioComp.toString() + " )");

            }

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder textoCanalIndicadoresNegocioComp = new StringBuilder();
                textoCanalIndicadoresNegocioComp.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    textoCanalIndicadoresNegocioComp.append(",");
                    textoCanalIndicadoresNegocioComp.append(listaCodigoCanal.get(i).toString());
                }

                sqlIndicadoresNegocioComp
                    .append(AND_CCANAL_DGTAL_PNEL_IN_INDICADORES + textoCanalIndicadoresNegocioComp.toString() + " )");

            }

            return jdbcTemplate.queryForObject(sqlIndicadoresNegocioComp.toString(), paramsIndicadoresNegocioComp,
                new IndicadoresNegocioRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<IndicadoresNegocio> relatorioIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {
        try {

            StringBuilder sqlIndNegocioRelatorio = new StringBuilder(QUERY_GERAL_RELATORIO);
            MapSqlParameterSource paramsIndNegocioRelatorio = new MapSqlParameterSource();

            if (checkDatas(dataInicio, dataFim)) {
                sqlIndNegocioRelatorio.append(WHERE_BETWEEN);
                paramsIndNegocioRelatorio.addValue(DATA_INICIO,
                    dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                        + "-" + dataInicio.substring(INT_0, INT_2));
                paramsIndNegocioRelatorio.addValue(DATA_FIM,
                    dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2));
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProdutoIndNegocioRelatorio = new StringBuilder();
                textoProdutoIndNegocioRelatorio.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProdutoIndNegocioRelatorio.append(",");
                    textoProdutoIndNegocioRelatorio.append(listaCodigoProduto.get(i).toString());
                }

                sqlIndNegocioRelatorio.append(
                    AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_INDICADORES + textoProdutoIndNegocioRelatorio.toString() + " )");

            }

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder textoCanalIndNegocioRelatorio = new StringBuilder();
                textoCanalIndNegocioRelatorio.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    textoCanalIndNegocioRelatorio.append(",");
                    textoCanalIndNegocioRelatorio.append(listaCodigoCanal.get(i).toString());
                }

                sqlIndNegocioRelatorio
                    .append(AND_CCANAL_DGTAL_PNEL_IN_INDICADORES + textoCanalIndNegocioRelatorio.toString() + " )");

            }

            sqlIndNegocioRelatorio.append(GROUPBY_RELATORIO_INDICADORES);

            return jdbcTemplate.queryForObject(sqlIndNegocioRelatorio.toString(), paramsIndNegocioRelatorio,
                new ListaIndicadoresNegocioRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<IndicadoresNegocio> relatorioIndicadoresNegocioComparacao(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {
        try {

            StringBuilder sqlRelIndNegComp = new StringBuilder(QUERY_GERAL_RELATORIO);
            MapSqlParameterSource paramsRelIndNegComp = new MapSqlParameterSource();

            if (checkDatas(dataInicio, dataFim)) {
                sqlRelIndNegComp.append(WHERE_BETWEEN_COMPARATIVA);
                paramsRelIndNegComp.addValue(DATA_INICIO,
                    dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5)
                        + "-" + dataInicio.substring(INT_0, INT_2));
                paramsRelIndNegComp.addValue(DATA_FIM,
                    dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2));
            }

            if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {

                StringBuilder textoProdutoRelIndNegComp = new StringBuilder();
                textoProdutoRelIndNegComp.append(listaCodigoProduto.get(0).toString());
                for (int i = 0; i < listaCodigoProduto.size(); i++) {

                    textoProdutoRelIndNegComp.append(",");
                    textoProdutoRelIndNegComp.append(listaCodigoProduto.get(i).toString());
                }

                sqlRelIndNegComp.append(
                    AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_INDICADORES + textoProdutoRelIndNegComp.toString() + " )");

            }

            if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {

                StringBuilder textoCanalRelIndNegComp = new StringBuilder();
                textoCanalRelIndNegComp.append(listaCodigoCanal.get(0).toString());
                for (int i = 0; i < listaCodigoCanal.size(); i++) {

                    textoCanalRelIndNegComp.append(",");
                    textoCanalRelIndNegComp.append(listaCodigoCanal.get(i).toString());
                }

                sqlRelIndNegComp
                    .append(AND_CCANAL_DGTAL_PNEL_IN_INDICADORES + textoCanalRelIndNegComp.toString() + " )");

            }

            sqlRelIndNegComp.append(GROUPBY_RELATORIO_INDICADORES);

            return jdbcTemplate.queryForObject(sqlRelIndNegComp.toString(), paramsRelIndNegComp,
                new ListaIndicadoresNegocioRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        }
    }

    @Override
    public List<ComboRankingEventos> obterRankingEventos(Integer codigoPesquisa,
        Date dataInicio, Date dataFim)
        throws SQLException {

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(DATA_INICIO, dataInicio);
            params.addValue(DATA_FIM, dataFim);

            List<Map<String, Object>> lista = jdbcTemplate
                .queryForList(SELECT_PRODUTO_E_CANAL + SUM_DURACAO
                    + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_DURACAO + ORDER_BY + ORDER_BY_DURACAO + DESC + LIMIT_15,
                    params);

            if (codigoPesquisa == INT_1) {
                lista = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_DURACAO
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_DURACAO + ORDER_BY + ORDER_BY_DURACAO + DESC
                        + LIMIT_15,
                        params);
            }

            if (codigoPesquisa == INT_2) {
                lista = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_IMPACTO
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_IMPACTO + ORDER_BY + ORDER_BY_IMPACTO + DESC
                        + LIMIT_15,
                        params);
            }

            if (codigoPesquisa == INT_3) {
                lista = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_RECORRENCIA
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_RECORRENCIA + ORDER_BY + ORDER_BY_RECORRENCIA + DESC
                        + LIMIT_15, params);
            }

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    "Dados não encontrados", 1);
            }

            List<ComboRankingEventos> listaComboRankingEventos = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                ComboRankingEventos comboRankingEventos = new ComboRankingEventos();
                comboRankingEventos.setDescricaoProduto((String) mapa.get("PRODUTO"));
                comboRankingEventos.setDescricaoCanal((String) mapa.get("CANAL"));
                comboRankingEventos.setDuracao((BigDecimal) mapa.get("DURACAO"));
                comboRankingEventos.setImpacto((BigDecimal) mapa.get("IMPACTO"));
                comboRankingEventos.setRecorrencia((BigDecimal) mapa.get("RECORRENCIA"));
                double horas = comboRankingEventos.getDuracao().intValue() / INT_3600;
                if(horas>DOUBLE_24) {
                    double dias = horas / DOUBLE_24;
                    BigDecimal bd = new BigDecimal(dias).setScale(0, RoundingMode.HALF_EVEN);
                    comboRankingEventos
                    .setDuracaoFmt(bd.toString() + " dias");
                }else {
                    comboRankingEventos
                    .setDuracaoFmt(Utils.formatoHoraMinutoSegundo(comboRankingEventos.getDuracao().intValue()));
                }
                listaComboRankingEventos.add(comboRankingEventos);               
            }

            return listaComboRankingEventos;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(NENHUM_DADO, INT_2);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<ComboRankingEventos> relatorioRankingEventos(Integer codigoPesquisaRelatorio,
        Date dataInicio, Date dataFim)
        throws SQLException {

        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(DATA_INICIO, dataInicio);
            params.addValue(DATA_FIM, dataFim);

            List<Map<String, Object>> listaRelatorio = new ArrayList<>();

            if (codigoPesquisaRelatorio == INT_1) {
                listaRelatorio = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_DURACAO + SUM_RECORRENCIA
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_DURACAO + ORDER_BY + ORDER_BY_DURACAO + DESC
                        + LIMIT_15,
                        params);
            }

            if (codigoPesquisaRelatorio == INT_2) {
                listaRelatorio = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_IMPACTO + SUM_RECORRENCIA
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_IMPACTO + ORDER_BY + ORDER_BY_IMPACTO + DESC
                        + LIMIT_15,
                        params);
            }

            if (codigoPesquisaRelatorio == INT_3) {
                listaRelatorio = jdbcTemplate
                    .queryForList(SELECT_PRODUTO_E_CANAL + SUM_RECORRENCIA
                        + FROM_TABLES_COLUMNS + GROUP_BY + GROUP_BY_RECORRENCIA + ORDER_BY + ORDER_BY_RECORRENCIA + DESC
                        + LIMIT_15, params);
            }

            if (listaRelatorio.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    "Dados não encontrados", 1);
            }

            List<ComboRankingEventos> listaComboRankingEventosRelatorio = new ArrayList<>();

            for (int i = 0; i < listaRelatorio.size(); i++) {
                Map<String, Object> mapa = listaRelatorio.get(i);
                ComboRankingEventos comboRankingEventosRelatorio = new ComboRankingEventos();
                comboRankingEventosRelatorio.setDescricaoProduto((String) mapa.get("PRODUTO"));
                comboRankingEventosRelatorio.setDescricaoCanal((String) mapa.get("CANAL"));
                comboRankingEventosRelatorio.setDuracao((BigDecimal) mapa.get("DURACAO"));
                comboRankingEventosRelatorio.setImpacto((BigDecimal) mapa.get("IMPACTO"));
                comboRankingEventosRelatorio.setRecorrencia((BigDecimal) mapa.get("RECORRENCIA"));
                listaComboRankingEventosRelatorio.add(comboRankingEventosRelatorio);
            }

            return listaComboRankingEventosRelatorio;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(NENHUM_DADO, INT_2);
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public NumeroTransacoes obterNumeroTransacao(Integer periodoNumeroTransacao,
        List<BigDecimal> listaCodigoProdutoNumeroTransacao, List<BigDecimal> listaCodigoCanalNumeroTransacao,
        String dataInicioNumeroTransacao, String dataFimNumeroTransacao) {
        try {

            StringBuilder sql = new StringBuilder(QUERY_TRANSACOES);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (periodoNumeroTransacao == INT_1) {
                if (checkDatas(dataInicioNumeroTransacao, dataFimNumeroTransacao)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1);
                    params.addValue(PERIODO_DE,
                        dataInicioNumeroTransacao.substring(INT_6) + "-"
                            + dataInicioNumeroTransacao.substring(INT_3, INT_5) + "-"
                            + dataInicioNumeroTransacao.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                    params.addValue(PERIODO_ATE,
                        dataFimNumeroTransacao.substring(INT_6) + "-" + dataFimNumeroTransacao.substring(INT_3, INT_5)
                            + "-"
                            + dataFimNumeroTransacao.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                }
            } else if (periodoNumeroTransacao == INT_2) {
                if (checkDatas(dataInicioNumeroTransacao, dataFimNumeroTransacao)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7);
                    params.addValue(PERIODO_DE,
                        dataInicioNumeroTransacao.substring(INT_6) + "-"
                            + dataInicioNumeroTransacao.substring(INT_3, INT_5) + "-"
                            + dataInicioNumeroTransacao.substring(INT_0, INT_2));
                    params.addValue(PERIODO_ATE,
                        dataFimNumeroTransacao.substring(INT_6) + "-" + dataFimNumeroTransacao.substring(INT_3, INT_5)
                            + "-"
                            + dataFimNumeroTransacao.substring(INT_0, INT_2));
                }
            } else {
                if (checkDatas(dataInicioNumeroTransacao, dataFimNumeroTransacao)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30);
                    params.addValue(PERIODO_DE, dataInicioNumeroTransacao.substring(INT_6) + "-"
                        + dataInicioNumeroTransacao.substring(INT_3, INT_5));
                    params.addValue(PERIODO_ATE,
                        dataFimNumeroTransacao.substring(INT_6) + "-" + dataFimNumeroTransacao.substring(INT_3, INT_5));
                }
            }

            sql.append(filtroListas(listaCodigoProdutoNumeroTransacao, AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_DETALHAMENTO));

            sql.append(filtroListas(listaCodigoCanalNumeroTransacao, AND_CCANAL_DGTAL_PNEL_IN_DETALHAMENTO));

            return jdbcTemplate.queryForObject(sql.toString(), params,
                new NumeroTransacoesRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<EventoPorCanal> obterListaEventoCanal(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) {

        StringBuilder sql = new StringBuilder(QUERY_EVENTO_CANAL);
        MapSqlParameterSource params = new MapSqlParameterSource();

        if (periodo == INT_1) {
            if (checkDatas(dataInicio, dataFim)) {
                sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1);
                params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                    + dataInicio.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                params.addValue(PERIODO_ATE,
                    dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2)
                        + COMPLEMENTO_HORA);
            }
        } else if (periodo == INT_2) {
            if (checkDatas(dataInicio, dataFim)) {
                sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7);
                params.addValue(PERIODO_DE,
                    dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5) + "-"
                        + dataInicio.substring(INT_0, INT_2));
                params.addValue(PERIODO_ATE,
                    dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5) + "-"
                        + dataFim.substring(INT_0, INT_2));
            }
        } else {
            if (checkDatas(dataInicio, dataFim)) {
                sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30);
                params.addValue(PERIODO_DE, dataInicio.substring(INT_6) + "-" + dataInicio.substring(INT_3, INT_5));
                params.addValue(PERIODO_ATE, dataFim.substring(INT_6) + "-" + dataFim.substring(INT_3, INT_5));
            }
        }

        sql.append(filtroListas(listaCodigoProduto, AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_DETALHAMENTO));

        sql.append(filtroListas(listaCodigoCanal, AND_CCANAL_DGTAL_PNEL_IN_DETALHAMENTO));

        sql.append(GROUP_ORDER_EVENTO_CANAL);

        return jdbcTemplate.queryForObject(sql.toString(), params,
            new ListaEventoPorCanalRowMapper());
    }

    @Override
    public TipoEvento obterTipoEvento(Integer periodoTipoEvento, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataIni, String dataFm) {
        try {

            StringBuilder sql = new StringBuilder(QUERY_TIPO_EVENTO);
            MapSqlParameterSource params = new MapSqlParameterSource();

            if (periodoTipoEvento == INT_1) {
                if (checkDatas(dataIni, dataFm)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_1);
                    params.addValue(PERIODO_DE, dataIni.substring(INT_6) + "-" + dataIni.substring(INT_3, INT_5) + "-"
                        + dataIni.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                    params.addValue(PERIODO_ATE, dataFm.substring(INT_6) + "-" + dataFm.substring(INT_3, INT_5) + "-"
                        + dataFm.substring(INT_0, INT_2) + COMPLEMENTO_HORA);
                }
            } else if (periodoTipoEvento == INT_2) {
                if (checkDatas(dataIni, dataFm)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_7);
                    params.addValue(PERIODO_DE,
                        dataIni.substring(INT_6) + "-" + dataIni.substring(INT_3, INT_5) + "-"
                            + dataIni.substring(INT_0, INT_2));
                    params.addValue(PERIODO_ATE,
                        dataFm.substring(INT_6) + "-" + dataFm.substring(INT_3, INT_5) + "-"
                            + dataFm.substring(INT_0, INT_2));
                }
            } else {
                if (checkDatas(dataIni, dataFm)) {
                    sql.append(WHERE_TDPROCS_APLIC_BETWEEN_TO_DATE_30);
                    params.addValue(PERIODO_DE, dataIni.substring(INT_6) + "-" + dataIni.substring(INT_3, INT_5));
                    params.addValue(PERIODO_ATE, dataFm.substring(INT_6) + "-" + dataFm.substring(INT_3, INT_5));
                }
            }

            sql.append(filtroListas(listaCodigoProduto, AND_CPRODT_PNEL_CODIGO_PRODUTO_IN_DETALHAMENTO));

            sql.append(filtroListas(listaCodigoCanal, AND_CCANAL_DGTAL_PNEL_IN_DETALHAMENTO));

            return jdbcTemplate.queryForObject(sql.toString(), params,
                new TipoEventoRowMapper());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private static boolean checkDatas(String dataInicio, String dataFim) {
        boolean retorno;
        if (dataInicio != null && !"".equalsIgnoreCase(dataInicio) &&
            dataFim != null && !"".equalsIgnoreCase(dataFim)) {
            retorno = true;
        } else {
            retorno = false;
        }
        return retorno;
    }

    private static String filtroListas(List<BigDecimal> lista, String queryString) {
        if (lista != null && !lista.isEmpty()) {

            StringBuilder textoProduto = new StringBuilder();
            textoProduto.append(lista.get(0).toString());
            for (int i = 0; i < lista.size(); i++) {

                textoProduto.append(",");
                textoProduto.append(lista.get(i).toString());
            }
            return queryString + textoProduto.toString() + " )";
        }
        return "";
    }
}
