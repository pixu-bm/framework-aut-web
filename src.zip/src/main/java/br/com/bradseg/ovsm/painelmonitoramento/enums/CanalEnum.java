package br.com.bradseg.ovsm.painelmonitoramento.enums;

/**
 * Canal Enum com os valores.
 * 
 * @author WIPRO
 */
public enum CanalEnum {

    INTERNET_BANKING(1, "INTERNET BANKING"), MOBILE_BANKING(2, "MOBILE BANKING"), ATM(3, "ATM"),
    SHOPPING(4, "SHOPPING"), NEXT(5, "NEXT"), MOVE(6, "MOVE"), MEI(7, "MEI"), NET_EMPRESA(8, "NET EMPRESA");

    private final Integer valor;
    private final String descricao;

    CanalEnum(Integer valor, String descricao) {
        this.valor = valor;
        this.descricao = descricao;
    }

    public Integer getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }

}
