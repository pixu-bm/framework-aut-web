package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ComentarioDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ComentarioService;

@Service
public class ComentarioServiceImpl implements ComentarioService {

    private LoginDao loginDao;

    private ComentarioDao comentarioDao;

    private static final Logger LOGGER = LogManager
        .getLogger(ComentarioServiceImpl.class);
    public static final String ERROR = "Error: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    public static final String REQUISICAO_INVALIDA = "É necessário uma requisição válida";
    private static final String USUARIO_INVALIDO = "Usuário inválido.";

    @Autowired
    public ComentarioServiceImpl(LoginDao loginDao,
        ComentarioDao comentarioDao) {
        this.loginDao = loginDao;
        this.comentarioDao = comentarioDao;
    }

    public void validarParametrosVisaoComentarios(String codigoEmpresa,
        String codigoProduto, String codigoCanal,
        Date dataProcs, String codigoErroConexaoPainel) {
        Assert.notNull(codigoEmpresa, "codigoEmpresa não pode ser nulo.");
        Assert.notNull(codigoProduto, "codigoProduto não pode ser nulo.");
        Assert.notNull(codigoCanal, "codigoCanal não pode ser nulo.");
        Assert.notNull(dataProcs, "dataProcs não pode ser nulo.");
        Assert.notNull(codigoErroConexaoPainel,
            "codigoErroConexaoPainel não pode ser nulo.");
    }

    public void validarComentarioRequest(ComentarioRequest comentarioRequest) {
        Assert.notNull(comentarioRequest, REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getCodigoEmpresa(),
            REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getCodigoProduto(),
            REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getCodigoCanal(), REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getDataProcs(), REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getCodigoErroConexaoPainel(),
            REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getComentario(), REQUISICAO_INVALIDA);
        Assert.notNull(comentarioRequest.getLogin(), REQUISICAO_INVALIDA);
    }

    public void inserirComentario(ComentarioRequest comentarioRequest)
        throws SQLException {

        Usuario usuario = new Usuario();
        usuario.setLogin(comentarioRequest.getLogin());

        Comentario comentario = new Comentario(comentarioRequest);

        if (Boolean.FALSE.equals(loginDao.validarLogin(usuario))) {

            if (Boolean.TRUE.equals(
                comentarioDao.obterDadosPainelMonitoramento(comentario))) {
                comentarioDao.inserirComentario(comentario);
            } else {
                throw new IllegalArgumentException("Dados não encontrados.");
            }

        } else {
            throw new IllegalArgumentException(USUARIO_INVALIDO);
        }

    }

    public List<Comentario> obterComentario(String codigoEmpresa,
        String codigoProduto, String codigoCanal,
        Date dataProcs, String codigoErroConexaoPainel) {
        try {
            return comentarioDao.obterComentario(codigoEmpresa, codigoProduto,
                codigoCanal, dataProcs,
                codigoErroConexaoPainel);
        } catch (SQLException e) {
            LOGGER.error(ERROR, e);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(),
                e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
        return Collections.emptyList();
    }

    public void alterarComentario(ComentarioRequest comentarioRequest)
        throws SQLException {

        Usuario usuario = new Usuario();
        usuario.setLogin(comentarioRequest.getLogin());

        Comentario comentario = new Comentario(comentarioRequest);

        if (Boolean.FALSE.equals(loginDao.validarLogin(usuario))) {
            comentarioDao.alterarComentario(comentario);
        } else {
            throw new IllegalArgumentException(USUARIO_INVALIDO);
        }

    }

    public void excluirComentario(ComentarioRequest comentarioRequest)
        throws SQLException {

        Usuario usuario = new Usuario();
        usuario.setLogin(comentarioRequest.getLogin());

        Comentario comentario = new Comentario(comentarioRequest);

        if (Boolean.FALSE.equals(loginDao.validarLogin(usuario))) {
            comentarioDao.excluirComentario(comentario);
        } else {
            throw new IllegalArgumentException(USUARIO_INVALIDO);
        }

    }

}
