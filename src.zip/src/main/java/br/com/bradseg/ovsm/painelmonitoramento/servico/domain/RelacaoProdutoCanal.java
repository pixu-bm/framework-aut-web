package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

public class RelacaoProdutoCanal {

    private BigDecimal codigoProduto;
    private String descricaoProduto;
    private Integer eventoGrave;
    private Integer eventoModerado;
    private Integer transacaoImpactada;

    public RelacaoProdutoCanal() {
        super();
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setEventoGrave(Integer eventoGrave) {
        this.eventoGrave = eventoGrave;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public Integer getEventoGrave() {
        return eventoGrave;
    }

    public Integer getEventoModerado() {
        return eventoModerado;
    }

    public Integer getTransacaoImpactada() {
        return transacaoImpactada;
    }

    public void setEventoModerado(Integer eventoModerado) {
        this.eventoModerado = eventoModerado;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public void setTransacaoImpactada(Integer transacaoImpactada) {
        this.transacaoImpactada = transacaoImpactada;
    }

}
