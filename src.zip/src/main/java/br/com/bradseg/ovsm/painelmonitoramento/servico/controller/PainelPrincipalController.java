/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VolumetriaTempoRealGraficoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VolumetriaTempoRealTabelaResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.PainelPrincipalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Camada de serviço rest para uso de painel monitoramento.
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/painelPrincipal")
public class PainelPrincipalController {

    private static final Logger LOGGER = LogManager.getLogger(PainelPrincipalController.class);

    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_3 = 3;

    
    @Autowired
    private PainelPrincipalService painelMonitoramentoService;

    public PainelPrincipalController() {
        super();
    }

    /**
     * Obtem painel de monitoramento com em sua posição atual de status.
     *
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/painelMonitoramento")
    @Operation(summary = "Obtem painel de monitoramento com em sua posição atual de status.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterPainelMonitoramento() {
        try {
            PainelMonitoramentoAtual painel = painelMonitoramentoService.obterPainelMonitoramento();
            
            painel.setCodigoRetorno(CODIGO_RETORNO_0);
            painel.setMensagem(SUCESSO);
           
            return ResponseEntity.ok(painel);

        } catch (SQLException e) {
            ResponseMensagem erroRetornobancoDeDados = new ResponseMensagem();
            erroRetornobancoDeDados.setCodigoRetorno(CODIGO_RETORNO_2);
            erroRetornobancoDeDados.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                erroRetornobancoDeDados.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }
    }

    /**
     * Retonar a visão geral de eventos para posicionamento do painel atual.
     *
     * @param periodoVisaoEvento Integer
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/visaoEvento")
    @Operation(summary = "Retonar a visão geral de eventos para posicionamento do painel atual.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEvento(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodoVisaoEvento") Integer periodoVisaoEvento) {

        try {
            VisaoEvento visaoEvento = painelMonitoramentoService.obterVisaoEvento(periodoVisaoEvento);

            visaoEvento.setCodigoRetorno(CODIGO_RETORNO_0);
            visaoEvento.setMensagem(SUCESSO);

            return ResponseEntity.ok(visaoEvento);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQLExc = new ResponseMensagem();
            mensagemSQLExc.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLExc.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLExc.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }
    }

    /**
     * Retonar a visão geral de eventos para posicionamento do painel atual.
     *
     * @param periodoVisaoEvento Integer
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVolumetriaTempoRealGrafico")
    @Operation(summary = "Obtem a volumetria em tempo real para construção de grafico de volumetria.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "404", description = "Nenhum dado encontrado para os parametros passados"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVolumetriaTempoRealGrafico(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodoVisaoEvento") Integer periodoVisaoEvento,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "listTipoEvento", required = false) List<BigDecimal> listTipoEvento) {

        try {
            painelMonitoramentoService.validarParametroEvento(periodoVisaoEvento);
            VolumetriaTempoRealGraficoResponse response = new VolumetriaTempoRealGraficoResponse();

            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setVolumetriaTempoRealVolumetriaMaxima(painelMonitoramentoService
                .obterVolumetriaTempoRealVolumetriaMaxima(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, listTipoEvento));
            response.setVolumetriaTempoReal(painelMonitoramentoService
                .obterVolumetriaTempoRealFaixaTempo(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, listTipoEvento));

            return ResponseEntity.ok(response);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQLExc = new ResponseMensagem();
            mensagemSQLExc.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLExc.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLExc.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (AcessoADadosException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_3, e);
        }
    }

    /**
     * Retonar a visão geral de eventos para posicionamento do painel atual.
     *
     * @param periodoVisaoEvento Integer
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVolumetriaTempoRealTabela")
    @Operation(summary = "Obtem a volumetria em tempo real para construção de grafico de volumetria.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "404", description = "Nenhum dado encontrado para os parametros passados"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVolumetriaTempoRealTabela(
        @Parameter(description = "Periodo de tempo determinado para visão evento, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(
                name = "periodoVisaoEvento") Integer periodoVisaoEvento,
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "listTipoEvento", required = false) List<BigDecimal> listTipoEvento) {

        try {
            painelMonitoramentoService.validarParametroEvento(periodoVisaoEvento);

            VolumetriaTempoRealTabelaResponse response = new VolumetriaTempoRealTabelaResponse();

            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setListaVolumetriaTempoRealTransacaoEvento(painelMonitoramentoService
                .obterVolumetriaTempoRealTransacaoEvento(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, listTipoEvento));

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagem.getMensagem() + ";" + CODIGO_RETORNO_1);

        } catch (SQLException except) {
            ResponseMensagem mensagemSQLExcept = new ResponseMensagem();
            mensagemSQLExcept.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLExcept.setMensagem(except.getMessage());
            LOGGER.error(except);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLExcept.getMensagem() + ";" + CODIGO_RETORNO_2);

        } catch (AcessoADadosException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_3, e);
        }
    }
}
