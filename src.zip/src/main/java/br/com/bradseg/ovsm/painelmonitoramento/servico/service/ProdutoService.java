package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;

import java.util.List;
import java.util.Map;

/**
 * Classe responsável por trazer valores referentes a produto e canais
 * @author Wipro
 */
public interface ProdutoService {

    /**
     * Obtem todos os produtos cadastrados
     * @return List<Produto>
     */
    List<Produto> obterProduto();

    /**
     * Obtem canais por produto
     * @param produto
     * @return
     */
    Map<String, String> obterCanaisProduto(String produto);
}
