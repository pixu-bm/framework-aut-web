/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Volumetria tempo real
 * 
 * @author Wipro
 */
public class VolumetriaTempoReal {

    private BigDecimal volumetriaAtualTransacao;
    private BigDecimal mediaHistoricaTransacao;
    private BigDecimal transacaoEvento;
    private BigDecimal transacaoSemEvento;
    private BigDecimal codigoProduto;
    private String descProduto;
    private BigDecimal codigoCanal;
    private String descCanal;
    private BigDecimal codigoEmpresa;
    private String horaOcorrencia;

    public VolumetriaTempoReal() {
        super();
    }

    public BigDecimal getVolumetriaAtualTransacao() {
        return volumetriaAtualTransacao;
    }

    public void setVolumetriaAtualTransacao(BigDecimal volumetriaAtualTransacao) {
        this.volumetriaAtualTransacao = volumetriaAtualTransacao;
    }

    public String getHoraOcorrencia() {
        return horaOcorrencia;
    }

    public BigDecimal getTransacaoEvento() {
        return transacaoEvento;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public void setTransacaoSemEvento(BigDecimal transacaoSemEvento) {
        this.transacaoSemEvento = transacaoSemEvento;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setTransacaoEvento(BigDecimal transacaoEvento) {
        this.transacaoEvento = transacaoEvento;
    }

    public void setHoraOcorrencia(String horaOcorrencia) {
        this.horaOcorrencia = horaOcorrencia;
    }

    public BigDecimal getTransacaoSemEvento() {
        return transacaoSemEvento;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public void setMediaHistoricaTransacao(BigDecimal mediaHistoricaTransacao) {
        this.mediaHistoricaTransacao = mediaHistoricaTransacao;
    }

    public BigDecimal getMediaHistoricaTransacao() {
        return mediaHistoricaTransacao;
    }

    public String getDescProduto() {
        return descProduto;
    }

    public void setDescProduto(String descProduto) {
        this.descProduto = descProduto;
    }

    public String getDescCanal() {
        return descCanal;
    }

    public void setDescCanal(String descCanal) {
        this.descCanal = descCanal;
    }

}
