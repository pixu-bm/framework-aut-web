package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;

public interface ComentarioService {
    void validarParametrosVisaoComentarios(String codigoEmpresa, String codigoProduto, String codigoCanal,
      Date dataProcs, String codigoErroConexaoPainel);

    void validarComentarioRequest(ComentarioRequest comentarioRequest);

    void inserirComentario(ComentarioRequest comentarioRequest) throws SQLException;

    void alterarComentario(ComentarioRequest comentarioRequest) throws SQLException;

    void excluirComentario(ComentarioRequest comentarioRequest) throws SQLException;

    List<Comentario> obterComentario(String codigoEmpresa, String codigoProduto, String codigoCanal, Date dataProcs,
      String codigoErroConexaoPainel);

}
