/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.CentralAcessoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.CentralAcessoUsuarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ListaFuncionalidadeResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ListaPerfilUsuarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.StatusResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.GestaoAcessoPerfilService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe de controle de serviços disponível para gestão de acesso do portal OV.
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/gestaoAcessoPerfil")
public class GestaoAcessoPerfilController {

    private static final Logger LOGGER = LogManager.getLogger(GestaoAcessoPerfilController.class);

    public static final String ERRO = "erro: ";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_3 = 3;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final String SUCESSO = "sucesso";

    @Autowired
    private GestaoAcessoPerfilService gestaoAcessoService;

    public GestaoAcessoPerfilController() {
        super();
    }

    /**
     * Serviço para listar todas as empresas em que usuário pode pertencer.
     *
     * @return ResponseEntity<ResponseMensagem>
     * @throws SQLException
     */
    @GetMapping(value = "/perfisUsuario")
    @Operation(summary = "Serviço para listar todas as empresas em que usuário pode pertencer.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterListaEmpresaUsuario() throws SQLException {
        try {

            List<PerfilUsuario> listaPerfilUsuarios = gestaoAcessoService.listarPerfilUsuario();

            ListaPerfilUsuarioResponse listaPerfilUsuarioResponse = new ListaPerfilUsuarioResponse();
            listaPerfilUsuarioResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            listaPerfilUsuarioResponse.setMensagem(SUCESSO);
            listaPerfilUsuarioResponse.setListaPerfilUsuario(listaPerfilUsuarios);

            return ResponseEntity.ok(listaPerfilUsuarioResponse);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmptyResultDataAccessException = new ResponseMensagem();
            mensagemEmptyResultDataAccessException.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagemEmptyResultDataAccessException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyResultDataAccessException.getMensagem() + ";" + CODIGO_RETORNO_3, e);

        } catch (SQLException e) {
            ResponseMensagem erroRespostaBancodedados = new ResponseMensagem();
            erroRespostaBancodedados.setCodigoRetorno(CODIGO_RETORNO_2);
            erroRespostaBancodedados.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                erroRespostaBancodedados.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }
    }

    /**
     * Obtem todos os status da situação do usuário para combo box nos paineis OV.
     *
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/statusUsuario")
    @Operation(summary = "Obtem todos os status da situação do usuário para combo box nos paineis OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterStatus() {
        try {
            List<Status> status = gestaoAcessoService.obterStatus();

            StatusResponse statusResponse = new StatusResponse();
            statusResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            statusResponse.setMensagem(SUCESSO);

            statusResponse.setStatus(status);

            return ResponseEntity.ok(statusResponse);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (ResponseStatusException e) {
            ResponseMensagem retornoException = new ResponseMensagem();
            retornoException.setCodigoRetorno(CODIGO_RETORNO_99);
            retornoException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoException.getMensagem() + ";" + CODIGO_RETORNO_99, e);
        }
    }

    /**
     * Obtem lista com informações de usuário para compor consulta em central de
     * acesso do painel OV. Usuário esses que já fizeram solicitações de acesso a
     * ferramenta.
     *
     * @param codigoEmpresa
     * @param codigoDepartamento
     * @param status
     * @param nome
     * @param tipoPerfil
     * @param dataSolicitação
     * @return
     */
    @GetMapping("/acessos")
    @Operation(summary = "Obtem lista com informações de usuário para compor consulta" +
        " em central de acesso do painel OV. "
        + "Usuário esses que já fizeram solicitações de acesso a ferramenta.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterListaUsuario(
        @RequestParam(value = "codigoEmpresa", required = false) String codigoEmpresa,
        @RequestParam(value = "codigoDepartamento", required = false) String codigoDepartamento,
        @RequestParam(value = "status", required = false) String status,
        @RequestParam(value = "nome", required = false) String nome,
        @RequestParam(value = "matricula", required = false) String matricula,
        @RequestParam(value = "tipoPerfil", required = false) String tipoPerfil,
        @RequestParam(value = "dataSolicitacao", required = false) String dataSolicitacao) {

        try {

            Usuario usuario = new Usuario(codigoEmpresa, codigoDepartamento, status, nome, matricula, tipoPerfil,
                dataSolicitacao);
            List<Usuario> listaUsuario = gestaoAcessoService.listarUsuario(usuario);
            List<CentralAcessoUsuarioResponse> listaUsuarioResponse = new ArrayList<>();

            for (Usuario usuarioBase : listaUsuario) {
                CentralAcessoUsuarioResponse central = new CentralAcessoUsuarioResponse(usuarioBase);
                listaUsuarioResponse.add(central);
            }

            CentralAcessoResponse response = new CentralAcessoResponse();
            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            response.setCentralAcessoUsuarioResponse(listaUsuarioResponse);

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem repostaEmpty = new ResponseMensagem();
            repostaEmpty.setCodigoRetorno(CODIGO_RETORNO_3);
            repostaEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                repostaEmpty.getMensagem() + ";" + CODIGO_RETORNO_3, e);

        } catch (SQLException e) {
            ResponseMensagem repostaBancoDeDados = new ResponseMensagem();
            repostaBancoDeDados.setCodigoRetorno(CODIGO_RETORNO_2);
            repostaBancoDeDados.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                repostaBancoDeDados.getMensagem() + ";" + CODIGO_RETORNO_2);

        }
    }

    /**
     * Atualiza o status de um usuario sobre solicitação de acesso no sistema em
     * central de acesso do painel OV. Usuário esses que já fizeram solicitações de
     * acesso a ferramenta.
     *
     * @param atualizarStatusUsuarioRequest AtualizarStatusPerfilUsuarioRequest
     * @return ResponseEntity<ResponseMensagem>
     */
    @PutMapping("/atualizarStatusUsuario")
    @Operation(summary = "Atualiza o status de um usuario sobre solicitação de acesso no sistema" +
        " em central de acesso do painel OV. "
        + "Usuário esses que já fizeram solicitações de acesso a ferramenta.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> atualizarStatusPerfilUsuario(
        @RequestBody AtualizarStatusPerfilUsuarioRequest atualizarStatusUsuarioRequest) {
        try {

            gestaoAcessoService.validarParametrosAtualizarStatusPerfilUsuario(atualizarStatusUsuarioRequest);
            Usuario usuario = new Usuario(atualizarStatusUsuarioRequest);

            gestaoAcessoService.atualizarStatusPerfilUsuario(usuario);

            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);

            return ResponseEntity.ok(mensagem);

        } catch (SQLException except) {
            ResponseMensagem retornoSqlExcecao = new ResponseMensagem();
            retornoSqlExcecao.setCodigoRetorno(CODIGO_RETORNO_2);
            retornoSqlExcecao.setMensagem(except.getMessage());
            LOGGER.error(except);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlExcecao.getMensagem() + ";" + CODIGO_RETORNO_2);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, mensagem.getMensagem() + ";" + CODIGO_RETORNO_3,
                e);

        }
    }

    /**
     * Obtem funcionalidades em alguns perfil
     *
     * @param perfil String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterFuncionalidadesPerfil")
    @Operation(summary = "Obtem funcionalidades que são atribuidas a cada perfil")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterFuncionalidadesPerfil(@RequestParam(value = "perfil") String perfil) {
        try {
            gestaoAcessoService.validarParametroPerfil(perfil);
            List<Funcionalidade> listaFuncionalidade = gestaoAcessoService.obterListaFuncionalidadePerfil(perfil);
            ListaFuncionalidadeResponse mensagem = new ListaFuncionalidadeResponse();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);
            mensagem.setListaFuncionalidade(listaFuncionalidade);

            return ResponseEntity.ok(mensagem);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem retornoEmptyResultDataAccessException = new ResponseMensagem();
            retornoEmptyResultDataAccessException.setCodigoRetorno(CODIGO_RETORNO_3);
            retornoEmptyResultDataAccessException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                retornoEmptyResultDataAccessException.getMensagem() + ";" + CODIGO_RETORNO_3);

        } catch (SQLException e) {
            ResponseMensagem retornoBancoSql = new ResponseMensagem();
            retornoBancoSql.setCodigoRetorno(CODIGO_RETORNO_2);
            retornoBancoSql.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoBancoSql.getMensagem() + ";" + CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem todos os tipos de funcionalidades que são cadastradas no sistema.
     *
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterFuncionalidades")
    @Operation(summary = "Obtem todos os tipos de funcionalidades que são cadastradas no sistema.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterFuncionalidades() {
        try {
            ListaFuncionalidadeResponse mensagem = new ListaFuncionalidadeResponse();
            List<Funcionalidade> listaFuncionalidade = gestaoAcessoService.obterListaFuncionalidade();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);
            mensagem.setListaFuncionalidade(listaFuncionalidade);

            return ResponseEntity.ok(mensagem);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem dataAccesserror = new ResponseMensagem();
            dataAccesserror.setCodigoRetorno(CODIGO_RETORNO_3);
            dataAccesserror.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                dataAccesserror.getMensagem() + ";" + CODIGO_RETORNO_3);

        } catch (SQLException e) {
            ResponseMensagem erroBancoDeDados = new ResponseMensagem();
            erroBancoDeDados.setCodigoRetorno(CODIGO_RETORNO_2);
            erroBancoDeDados.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                erroBancoDeDados.getMensagem() + ";" + CODIGO_RETORNO_2);

        } 
    }

    /**
     * Atualizar perfil funcionalidade
     *
     * @param atualizarPerfilFuncionalidadeRequest AtualizarPerfilFuncionalidadeRequest
     * @return ResponseEntity<ResponseMensagem>
     */
    @PutMapping("/atualizarPerfilFuncionalidade")
    @Operation(summary = "Atualiza e atribui funcionalidades aos perfis do sistema painel monitoramento OV")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> atualizarPerfilFuncionalidade(
        @RequestBody AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest) {

        try {
            gestaoAcessoService.validarParametroAtualizarPerfilFuncionalidade(atualizarPerfilFuncionalidadeRequest);
            Usuario usuario = new Usuario(atualizarPerfilFuncionalidadeRequest);
            gestaoAcessoService.atualizarPerfilFuncionalidade(usuario);

            ListaFuncionalidadeResponse mensagem = new ListaFuncionalidadeResponse();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);

            return ResponseEntity.ok(mensagem);

        } catch (IllegalArgumentException e) {
            ResponseMensagem retornoIllegal = new ResponseMensagem();
            retornoIllegal.setCodigoRetorno(CODIGO_RETORNO_3);
            retornoIllegal.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                retornoIllegal.getMensagem() + ";" + CODIGO_RETORNO_3);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem retornoResult = new ResponseMensagem();
            retornoResult.setCodigoRetorno(CODIGO_RETORNO_3);
            retornoResult.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                retornoResult.getMensagem() + ";" + CODIGO_RETORNO_3);

        } catch (DataIntegrityViolationException e) {
            ResponseMensagem erroViolation = new ResponseMensagem();
            erroViolation.setCodigoRetorno(CODIGO_RETORNO_3);
            erroViolation.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                erroViolation.getMensagem() + ";" + CODIGO_RETORNO_3);

        } catch (SQLException e) {
            ResponseMensagem erroRepostaBanco = new ResponseMensagem();
            erroRepostaBanco.setCodigoRetorno(CODIGO_RETORNO_2);
            erroRepostaBanco.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                erroRepostaBanco.getMensagem() + ";" + CODIGO_RETORNO_2);

        }
    }
}
