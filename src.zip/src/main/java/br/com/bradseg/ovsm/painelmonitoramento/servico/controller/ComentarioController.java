package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ComentarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ComentarioService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/service/comentario")
public class ComentarioController {

    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final String SUCESSO = "Sucesso.";

    @Autowired
    private ComentarioService comentarioService;

    public ComentarioController() {
        super();
    }

    @GetMapping("/")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterComentario(
        @RequestParam(value = "codigoEmpresa", required = true) String codigoEmpresa,
        @RequestParam(value = "codigoProduto", required = true) String codigoProduto,
        @RequestParam(value = "codigoCanal", required = true) String codigoCanal,
        @RequestParam("dataProcs") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date dataProcs,
        @RequestParam(value = "codigoErroConexaoPainel", required = true) String codigoErroConexaoPainel) {

        try {
            comentarioService.validarParametrosVisaoComentarios(codigoEmpresa, codigoProduto, codigoCanal, dataProcs,
                codigoErroConexaoPainel);

            ComentarioResponse comentarioResponse = new ComentarioResponse();
            comentarioResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            comentarioResponse.setMensagem(SUCESSO);
            comentarioResponse.setListaComentario(comentarioService.obterComentario(codigoEmpresa, codigoProduto,
                codigoCanal, dataProcs, codigoErroConexaoPainel));

            return ResponseEntity.ok(comentarioResponse);
        } catch (IllegalArgumentException e) {
            ResponseMensagem response = new ResponseMensagem();
            response.setCodigoRetorno(CODIGO_RETORNO_1);
            response.setMensagem(e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, response.getMensagem() + ";" + CODIGO_RETORNO_1,
                e);
        }

    }

    @PostMapping("/")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> adicionarComentario(@RequestBody ComentarioRequest comentarioRequest) {

        try {
            comentarioService.validarComentarioRequest(comentarioRequest);
            comentarioService.inserirComentario(comentarioRequest);

            ResponseMensagem responseAddComentario = new ResponseMensagem();
            responseAddComentario.setCodigoRetorno(CODIGO_RETORNO_0);
            responseAddComentario.setMensagem(SUCESSO);
            return ResponseEntity.ok(responseAddComentario);

        } catch (IllegalArgumentException | SQLException eAddComentario) {
            ResponseMensagem responseAddComentario = new ResponseMensagem();
            responseAddComentario.setCodigoRetorno(CODIGO_RETORNO_1);
            responseAddComentario.setMensagem(eAddComentario.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                responseAddComentario.getMensagem() + ";" + CODIGO_RETORNO_1,
                eAddComentario);
        }

    }

    @PostMapping("/update")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> alterarComentario(@RequestBody ComentarioRequest comentarioRequest) {

        try {
            comentarioService.validarComentarioRequest(comentarioRequest);
            comentarioService.alterarComentario(comentarioRequest);

            ResponseMensagem responseAltComentario = new ResponseMensagem();
            responseAltComentario.setCodigoRetorno(CODIGO_RETORNO_0);
            responseAltComentario.setMensagem(SUCESSO);
            return ResponseEntity.ok(responseAltComentario);

        } catch (IllegalArgumentException | SQLException eAltComentario) {
            ResponseMensagem responseAltComentario = new ResponseMensagem();
            responseAltComentario.setCodigoRetorno(CODIGO_RETORNO_1);
            responseAltComentario.setMensagem(eAltComentario.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                responseAltComentario.getMensagem() + ";" + CODIGO_RETORNO_1,
                eAltComentario);
        }

    }

    @PostMapping("/delete")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> excluirComentario(@RequestBody ComentarioRequest comentarioRequest) {

        try {
            comentarioService.validarComentarioRequest(comentarioRequest);
            comentarioService.excluirComentario(comentarioRequest);

            ResponseMensagem response = new ResponseMensagem();
            response.setCodigoRetorno(CODIGO_RETORNO_0);
            response.setMensagem(SUCESSO);
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | SQLException e) {
            ResponseMensagem response = new ResponseMensagem();
            response.setCodigoRetorno(CODIGO_RETORNO_1);
            response.setMensagem(e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, response.getMensagem() + ";" + CODIGO_RETORNO_1,
                e);
        }

    }

}
