package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.FaqResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.FaqRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.FaqService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Classe rest
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/faq")
public class FaqController {

    private static final Logger LOGGER = LogManager.getLogger(FaqController.class);

    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_0 = 0;
    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";
    @Autowired
    private FaqService faqService;

    public FaqController() {
        super();
    }

    @GetMapping("/carregar")
    @Operation(summary = "Carrega as perguntas e comentarios da aba FAQ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> carregar() {

        try {
            FaqResponse response = new FaqResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setListaFaq(
                faqService.carregar());

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException ecarregar) {
            ResponseMensagem mensagemcarregar = new ResponseMensagem();
            mensagemcarregar.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemcarregar.setMensagem(ecarregar.getMessage());
            LOGGER.error(ecarregar);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemcarregar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                ecarregar);

        } catch (AcessoADadosException ecarregar) {
            ResponseMensagem retornoSqlcarregar = new ResponseMensagem();
            retornoSqlcarregar.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlcarregar.setMensagem(ecarregar.getMessage());
            LOGGER.error(ecarregar);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlcarregar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    @GetMapping("/pesquisar")
    @Operation(summary = "Realizar pesquisa de uma pargunta a partir de um input de texto")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> pesquisar(
        @RequestParam(value = "pergunta", required = true) String pergunta) {

        try {
            FaqResponse response = new FaqResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setListaFaq(
                faqService.pesquisar(pergunta));

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException epesquisar) {
            ResponseMensagem mensagempesquisar = new ResponseMensagem();
            mensagempesquisar.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagempesquisar.setMensagem(epesquisar.getMessage());
            LOGGER.error(epesquisar);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagempesquisar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                epesquisar);

        } catch (AcessoADadosException epesquisar) {
            ResponseMensagem retornoSqlpesquisar = new ResponseMensagem();
            retornoSqlpesquisar.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlpesquisar.setMensagem(epesquisar.getMessage());
            LOGGER.error(epesquisar);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlpesquisar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    @PostMapping("/editar")
    @Operation(summary = "Edita uma pergunta")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "431", description = "Request Header Fields Too Large"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> editar(@RequestBody FaqRequest faqRequest) {

        try {

            faqService.editar(faqRequest.getCodSeq(), faqRequest.getPergunta(), faqRequest.getResposta(),
                faqRequest.getPrioridade(), faqRequest.getImagem(), faqRequest.getLogin());

            FaqResponse response = new FaqResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException eeditar) {
            ResponseMensagem mensagemeditar = new ResponseMensagem();
            mensagemeditar.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemeditar.setMensagem(eeditar.getMessage());
            LOGGER.error(eeditar);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemeditar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                eeditar);

        } catch (AcessoADadosException eeditar) {
            ResponseMensagem retornoSqleditar = new ResponseMensagem();
            retornoSqleditar.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqleditar.setMensagem(eeditar.getMessage());
            LOGGER.error(eeditar);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqleditar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    @PostMapping("/salvar")
    @Operation(summary = "Cria uma nova pergunta com seu comentario")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "431", description = "Request Header Fields Too Large"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> salvar(@RequestBody FaqRequest faqRequest) {

        try {

            faqService.salvar(faqRequest.getPergunta(), faqRequest.getResposta(),
                faqRequest.getPrioridade(), faqRequest.getImagem(), faqRequest.getLogin());

            FaqResponse response = new FaqResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException esalvar) {
            ResponseMensagem mensagemsalvar = new ResponseMensagem();
            mensagemsalvar.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemsalvar.setMensagem(esalvar.getMessage());
            LOGGER.error(esalvar);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemsalvar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                esalvar);

        } catch (AcessoADadosException esalvar) {
            ResponseMensagem retornoSqlsalvar = new ResponseMensagem();
            retornoSqlsalvar.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlsalvar.setMensagem(esalvar.getMessage());
            LOGGER.error(esalvar);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlsalvar.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    @PostMapping("/excluir")
    @Operation(summary = "Exclui uma pergunta a partir de sua chave")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "431", description = "Request Header Fields Too Large"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> excluir(@RequestBody FaqRequest faqRequest) {

        try {

            faqService.excluir(faqRequest.getCodSeq(), faqRequest.getCodData());

            FaqResponse response = new FaqResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException eexcluir) {
            ResponseMensagem mensagemexcluir = new ResponseMensagem();
            mensagemexcluir.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemexcluir.setMensagem(eexcluir.getMessage());
            LOGGER.error(eexcluir);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemexcluir.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                eexcluir);

        } catch (AcessoADadosException eexcluir) {
            ResponseMensagem retornoSqlexcluir = new ResponseMensagem();
            retornoSqlexcluir.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlexcluir.setMensagem(eexcluir.getMessage());
            LOGGER.error(eexcluir);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlexcluir.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }
}
