package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;

import java.util.List;

/**
 * Interface de serviço eventos
 * 
 * @author Wipro
 */
public interface EventoService {

    /**
     * Listar todos os tipos de evento.
     * 
     * @return Map<BigDecimal, String>
     */
    List<Evento> obterListaEvento();
}
