package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Classe para implementação dos indicadores
 * 
 * @author Wipro
 */
public class NumeroTransacoes {

    private int totalTransacoes;
    private int totalTransacoesSemEvento;
    private int totalTransacoesComEvento;
    private Double porcentagemTotalTransacoesSemEvento;
    private Double porcentagemTotalTransacoesComEvento;
    
    public NumeroTransacoes() {
        super();
    }

    public int getTotalTransacoes() {
        return totalTransacoes;
    }

    public void setTotalTransacoes(int totalTransacoes) {
        this.totalTransacoes = totalTransacoes;
    }

    public int getTotalTransacoesSemEvento() {
        return totalTransacoesSemEvento;
    }

    public void setTotalTransacoesSemEvento(int totalTransacoesSemEvento) {
        this.totalTransacoesSemEvento = totalTransacoesSemEvento;
    }

    public int getTotalTransacoesComEvento() {
        return totalTransacoesComEvento;
    }

    public void setTotalTransacoesComEvento(int totalTransacoesComEvento) {
        this.totalTransacoesComEvento = totalTransacoesComEvento;
    }

    public Double getPorcentagemTotalTransacoesSemEvento() {
        return porcentagemTotalTransacoesSemEvento;
    }

    public void setPorcentagemTotalTransacoesSemEvento(Double porcentagemTotalTransacoesSemEvento) {
        this.porcentagemTotalTransacoesSemEvento = porcentagemTotalTransacoesSemEvento;
    }

    public Double getPorcentagemTotalTransacoesComEvento() {
        return porcentagemTotalTransacoesComEvento;
    }

    public void setPorcentagemTotalTransacoesComEvento(Double porcentagemTotalTransacoesComEvento) {
        this.porcentagemTotalTransacoesComEvento = porcentagemTotalTransacoesComEvento;
    }
}
