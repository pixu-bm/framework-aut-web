package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;

/**
 * Volumetria tempo real volumetria maxima mapa objetos extração de base de
 * dados.
 * 
 * @author Wipro
 */
public class NumeroTransacoesRowMapper implements RowMapper<NumeroTransacoes> {

    public NumeroTransacoes mapRow(ResultSet rs, int rowNum) throws SQLException {

        NumeroTransacoes numeroTransacoes 
        = new NumeroTransacoes();
        numeroTransacoes.setTotalTransacoes(rowNum);
        numeroTransacoes.setTotalTransacoes(rs.getInt("SOMA_TRANSACOES"));
        numeroTransacoes.setTotalTransacoesSemEvento(rs.getInt("TRANSACOES_SCESS"));
        numeroTransacoes.setTotalTransacoesComEvento(rs.getInt("TRANSACOES_INSUC"));

        return numeroTransacoes;
    }
}
