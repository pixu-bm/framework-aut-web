package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista funcionario row mapper da tabela.
 *
 * @author Wipro
 */
public class ListaFuncionalidadeRowMapper implements ResultSetExtractor<List<Funcionalidade>> {

    @Override
    public List<Funcionalidade> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<Funcionalidade> listaFuncionalidade = new ArrayList<>();

        while (rs.next()) {
            Funcionalidade funcionalidade = new Funcionalidade();
            funcionalidade.setCodigoFuncionalidade(rs.getString("CFUNCL"));
            funcionalidade.setDescricaoFuncionalidade(rs.getString("RFUNCL"));

            listaFuncionalidade.add(funcionalidade);
        }

        return listaFuncionalidade;
    }

}
