/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * Classe rest implementa chamada swagger
 * @author Wipro
 */
@RestController
@RequestMapping("/")
public class SwaggerController {

    /**
     * Redireciona a pagina do swagger.
     * @return ModelAndView
     */
    @GetMapping
    public ModelAndView open() {
        return new ModelAndView("redirect:swagger-ui/index.html?configUrl=/ovsm-srv-monitoramento/" +
            "v3/api-docs/swagger-config#/", HttpStatus.OK);
    }
}
