/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import br.com.bradseg.ovsm.painelmonitoramento.enums.StatusEnum;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Classe responsável por informaçoes de usuário
 * 
 * @author Wipro
 *
 */
public class Usuario {

    private BigDecimal numeroInternoUsuario;
    private String login;
    private String email;
    private String nome;
    private String matricula;
    private String telefone;
    private String endereco;
    private String codigoEmpresa;
    private String nomeEmpresa;
    private String codigoDepartamento;
    private String nomeDepartamento;
    private Date dataSolicitacao;
    private String dataSolicitacaoFmt;
    private String status;
    private String perfil;
    private String motivoRecusa;
    private List<Funcionalidade> listaFuncionalidades;
    private String loginAprovador;

    public Usuario() {
        super();
    }

    public Usuario(SolicitacaoAcessoRequest solicitacaoAcesso) {
        super();
        login = solicitacaoAcesso.getLogin();
        email = solicitacaoAcesso.getEmail();
        nome = solicitacaoAcesso.getNome();
        matricula = solicitacaoAcesso.getMatricula();
        telefone = solicitacaoAcesso.getTelefone();
        endereco = solicitacaoAcesso.getEndereco();
        codigoEmpresa = solicitacaoAcesso.getCodigoEmpresa();

        codigoDepartamento = solicitacaoAcesso.getCodigoDepartamento();
    }

    /**
     * Construtor para listar usuarios
     * 
     * @param codigoEmpresa      String
     * @param codigoDepartamento String
     * @param status             String
     * @param nome               String
     * @param matricula          String
     * @param tipoPerfil         String
     * @param dataSolicitação    String
     */
    public Usuario(String codigoEmpresa, String codigoDepartamento,
        String status, String nome, String matricula,
        String perfil, String dataSolicitacao) {
        super();

        this.codigoEmpresa = codigoEmpresa;

        this.codigoDepartamento = codigoDepartamento;

        if (StatusEnum.ATIVO.getDescricao().equals(status)) {
            this.status = "APROV";
        }

        if (StatusEnum.CANCELADO.getDescricao().equals(status)) {
            this.status = "CANCEL";
        }

        if (StatusEnum.REJEITADO.getDescricao().equals(status)) {
            this.status = "NEGAD";
        }

        if (StatusEnum.PENDENTE.getDescricao().equals(status)) {
            this.status = "AGARD";
        }

        this.nome = nome;

        this.matricula = matricula;

        this.perfil = perfil;

        if (dataSolicitacao != null) {
            this.dataSolicitacaoFmt = dataSolicitacao;
            this.dataSolicitacao = Utils
                .strDateFmtBrasilToJavaDate(dataSolicitacao);
        }
    }

    /**
     * Construtor para atualizar status usuario request
     * 
     * @param atualizarStatusUsuarioRequest
     */
    public Usuario(
        AtualizarStatusPerfilUsuarioRequest atualizarStatusUsuarioRequest) {
        super();
        this.login = atualizarStatusUsuarioRequest.getLogin();

        if (StatusEnum.ATIVO.getDescricao()
            .equals(atualizarStatusUsuarioRequest.getStatus())) {
            this.status = "APROV";
        }

        if (StatusEnum.CANCELADO.getDescricao()
            .equals(atualizarStatusUsuarioRequest.getStatus())) {
            this.status = "CANCEL";
        }

        if (StatusEnum.REJEITADO.getDescricao()
            .equals(atualizarStatusUsuarioRequest.getStatus())) {
            this.status = "NEGAD";
        }

        if (StatusEnum.PENDENTE.getDescricao()
            .equals(atualizarStatusUsuarioRequest.getStatus())) {
            this.status = "AGARD";
        }

        this.perfil = atualizarStatusUsuarioRequest.getPerfil();

        if (atualizarStatusUsuarioRequest.getMotivoRecusa() != null) {
            this.motivoRecusa = atualizarStatusUsuarioRequest.getMotivoRecusa();
        }

        this.loginAprovador = atualizarStatusUsuarioRequest.getLoginAprovador();
    }

    public Usuario(
        AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest) {
        super();
        this.login = atualizarPerfilFuncionalidadeRequest.getLogin();
        this.listaFuncionalidades = atualizarPerfilFuncionalidadeRequest
            .getListaFuncionalidade();
        this.perfil = atualizarPerfilFuncionalidadeRequest.getPerfil();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome != null) {
            this.nome = nome;
        }
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        if (matricula != null) {
            this.matricula = matricula;
        }
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(String codigoEmpresa) {
        if (codigoEmpresa != null) {
            this.codigoEmpresa = codigoEmpresa;
        }
    }

    public String getNomeEmpresa() {
        return nomeEmpresa;
    }

    public void setNomeEmpresa(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }

    public String getCodigoDepartamento() {
        return codigoDepartamento;
    }

    public void setCodigoDepartamento(String codigoDepartamento) {
        if (codigoDepartamento != null) {
            this.codigoDepartamento = codigoDepartamento;
        }
    }

    public String getNomeDepartamento() {
        return nomeDepartamento;
    }

    public void setNomeDepartamento(String nomeDepartamento) {
        this.nomeDepartamento = nomeDepartamento;
    }

    public Date getDataSolicitacao() {
        if (dataSolicitacao != null) {
            return (Date) dataSolicitacao.clone();
        }

        return null;
    }

    public void setDataSolicitacao(Date dataSolicitacao) {
        this.dataSolicitacao = (Date) dataSolicitacao.clone();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        if (perfil != null) {
            this.perfil = perfil;
        }
    }

    public String getDataSolicitacaoFmt() {
        return dataSolicitacaoFmt;
    }

    public void setDataSolicitacaoFmt(String dataSolicitacaoFmt) {
        this.dataSolicitacaoFmt = dataSolicitacaoFmt;
    }

    public String getMotivoRecusa() {
        return motivoRecusa;
    }

    public void setMotivoRecusa(String motivoRecusa) {
        this.motivoRecusa = motivoRecusa;
    }

    public BigDecimal getNumeroInternoUsuario() {
        return numeroInternoUsuario;
    }

    public void setNumeroInternoUsuario(BigDecimal numeroInternoUsuario) {
        this.numeroInternoUsuario = numeroInternoUsuario;
    }

    public List<Funcionalidade> getListaFuncionalidades() {
        return Collections.unmodifiableList(listaFuncionalidades);
    }

    public void setListaFuncionalidades(
        List<Funcionalidade> listaFuncionalidades) {
        this.listaFuncionalidades = Collections.unmodifiableList(listaFuncionalidades);
    }

    public String getLoginAprovador() {
        return loginAprovador;
    }

    public void setLoginAprovador(String loginAprovador) {
        this.loginAprovador = loginAprovador;
    }

}
