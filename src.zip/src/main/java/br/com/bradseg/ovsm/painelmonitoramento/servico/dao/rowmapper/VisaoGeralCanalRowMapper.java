package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Visao geral canal row mapper
 * 
 * @author Wipto
 */
public class VisaoGeralCanalRowMapper implements RowMapper<VisaoGeralCanal> {

    public VisaoGeralCanal mapRow(ResultSet rs, int rowNum) throws SQLException {
        VisaoGeralCanal visao = new VisaoGeralCanal();
        visao.setCodigoCanal(rs.getBigDecimal("CCANAL_DGTAL_PNEL"));
        visao.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
        visao.setEventoGrave(rowNum);
        visao.setEventoGrave(rs.getInt("SOMA_EVENTO_GRAVE"));
        visao.setEventoModerado(rs.getInt("SOMA_EVENTO_MODERADO"));
        visao.setEventoVolumetria(rs.getInt("SOMA_EVENTO_VOLUMETRIA"));
        visao.setEventoDisponibilidade(rs.getInt("SOMA_EVENTO_DISP"));
        visao.setEventoFuncional(rs.getInt("SOMA_EVENTO_FUNC"));
        visao.setNumeroImpacto(rs.getInt("SOMA_TRANSACAO"));

        return visao;
    }

}
