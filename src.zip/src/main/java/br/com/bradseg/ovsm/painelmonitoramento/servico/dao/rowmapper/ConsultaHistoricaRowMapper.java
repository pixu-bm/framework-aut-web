package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

public class ConsultaHistoricaRowMapper implements RowMapper<List<ConsultaHistorica>> {

    @Override
    public List<ConsultaHistorica> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<ConsultaHistorica> lista = new ArrayList<>();

        do {
            ConsultaHistorica consulta = new ConsultaHistorica();
            consulta.setCodigoEvento(new BigDecimal(rs.getInt("COD_EVENTO")));
            consulta.setGravidade(rs.getString("GRAVIDADE"));
            consulta.setProduto(rs.getString("PRODUTO"));
            consulta.setCanal(rs.getString("CANAL"));
            consulta.setTipoEvento(rs.getString("TIPO_EVENTO"));
            consulta.setTransacoesImpactadas(rs.getBigDecimal("TRANSACOES_IMPACTADAS"));
            consulta.setDuracaoDisp(rs.getLong("DIFF_DISPN"));
            consulta.setDuracaoFunc(rs.getLong("DIFF_FUNCL"));
            consulta.setDuracaoVolu(rs.getLong("DIFF_VOLUM"));
            consulta.setData(Utils.javaDateFormatoBrasil(rs.getDate("DATA_REG")));
            lista.add(consulta);
        } while (rs.next());

        return lista;
    }

}
