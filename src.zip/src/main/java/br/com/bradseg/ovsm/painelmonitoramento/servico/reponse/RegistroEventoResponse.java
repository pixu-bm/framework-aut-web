package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Registro evento response.
 * 
 * @author Wipro
 */
public class RegistroEventoResponse extends ResponseMensagem {

    private List<RegistroEvento> listaRegistroEvento;

    public RegistroEventoResponse() {
        super();
    }

    public List<RegistroEvento> getListaRegistroEvento() {
        return Collections.unmodifiableList(listaRegistroEvento);
    }

    public void setListaRegistroEvento(List<RegistroEvento> listaRegistroEvento) {
        this.listaRegistroEvento = 
            Collections.unmodifiableList(listaRegistroEvento);
    }
}
