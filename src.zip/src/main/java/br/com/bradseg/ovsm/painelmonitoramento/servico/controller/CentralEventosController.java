package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.GraficoDetalheEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.RegistroEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.RelacionadoDetalheEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.StatusDetalheEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VisaoEventoCanalResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VisaoEventoProdutoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VisaoGeralCanalResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.VisaoGeralProdutoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CentralEventosService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Classe central evento rest controller
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/centralEventos")
public class CentralEventosController {

    private static final Logger LOGGER = LogManager.getLogger(CentralEventosController.class);
    public static final String INLINE_FILENAME_REGISTRO_EVENTO_XLSX = "inline;filename=\"registroEvento.xlsx\"";
    public static final String INLINE_FILENAME_REGISTRO_EVENTO_CSV = "inline;filename=\"registroEvento.csv\"";
    public static final String INLINE_FILENAME_REGISTRO_EVENTO_PDF = "inline;filename=\"registroEvento.pdf\"";

    @Autowired
    private CentralEventosService centralEventosService;

    /**
     * Construtor
     */
    public CentralEventosController() {
        super();
    }

    /**
     * Obtem informações de visao de evento aberto para painel de central de eventos
     *
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoGeral")
    @Operation(summary = "Obtem visão de evento aberto com soma geral de eventos"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEventoAberto(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            VisaoEvento visaoEventoResponse = centralEventosService.obterVisaoEventoAberto(
                dataInicioDate, dataFimDate);
            visaoEventoResponse.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            visaoEventoResponse.setMensagem(Constantes.SUCESSO);

            return ResponseEntity.ok(visaoEventoResponse);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagem.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                e);

        } catch (AcessoADadosException eAcesso) {
            ResponseMensagem retornoEAcesso = new ResponseMensagem();
            retornoEAcesso.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoEAcesso.setMensagem(eAcesso.getMessage());
            LOGGER.error(eAcesso);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoEAcesso.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2, eAcesso);

        }

    }

    /**
     * Obtem informações de visao de evento aberto por produto para painel de
     * central de eventos
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoProduto")
    @Operation(summary = "Obtem visão de evento aberto relacionada por produtos"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "404", description = "Não encontrado"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEventoAbertoProduto(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            VisaoEventoProdutoResponse response = new VisaoEventoProdutoResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setVisaoEventoProduto(
                centralEventosService.obterVisaoEventoProduto(dataInicioDate, dataFimDate));

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagem.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3,
                e);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoSql = new ResponseMensagem();
            retornoSql.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSql.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSql.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoCanal")
    @Operation(summary = "Obtem visão de evento aberto relacionada por canal"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEventoAbertoCanal(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            VisaoEventoCanalResponse response = new VisaoEventoCanalResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setListaVisaoEventoCanal(
                centralEventosService.obterVisaoEventoCanal(dataInicioDate, dataFimDate));

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem msgVazia = new ResponseMensagem();
            msgVazia.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            msgVazia.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                msgVazia.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3, e);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoSqlException = new ResponseMensagem();
            retornoSqlException.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlException.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de registro
     * de eventos
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterRegistroEvento")
    @Operation(summary = "Obtem visão de evento aberto relacionada por canal"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterRegistroEvento(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim,
        @RequestParam(value = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(value = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "codigoTipoEvento", required = false) BigDecimal codigoTipoEvento) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            RegistroEventoResponse response = new RegistroEventoResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setListaRegistroEvento(centralEventosService.obterRegistroEvento(listaCodigoProduto,
                listaCodigoCanal, statusEvento, dataInicioDate, dataFimDate, codigoTipoEvento));

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException exception) {
            ResponseMensagem mensagemVazio = new ResponseMensagem();
            mensagemVazio.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemVazio.setMensagem(exception.getMessage());
            LOGGER.error(exception);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemVazio.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoSql = new ResponseMensagem();
            retornoSql.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSql.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSql.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoProdutoDetalhe")
    @Operation(summary = "Obtem visão de evento por produto em detalhe em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEventoProdutoDetalhe(
        @Parameter(description = "Periodo de tempo determinado para visão evento produto detalhe, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(value = "peridoVisaoEvento",
                required = true) Integer periodoVisaoEvento,
        @RequestParam(value = "codigoProduto", required = true) BigDecimal codigoProduto) {

        try {
            VisaoGeralProdutoResponse response = new VisaoGeralProdutoResponse();
            response.setVisaoGeralProduto(
                centralEventosService.obterVisaoEventoProdutoDetalhe(periodoVisaoEvento,
                    codigoProduto));
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmptyResultDataAccessException = new ResponseMensagem();
            mensagemEmptyResultDataAccessException.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyResultDataAccessException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyResultDataAccessException.getMensagem() + ";"
                    + Constantes.CODIGO_RETORNO_3,
                e);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoAcessoADadosException = new ResponseMensagem();
            retornoAcessoADadosException.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoAcessoADadosException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoAcessoADadosException.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoCanalDetalhe")
    @Operation(summary = "Obtem visão de evento por canal em detalhe central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterVisaoEventoCanalDetalhe(
        @Parameter(description = "Periodo de tempo determinado para visão evento produto detalhe, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(value = "peridoVisaoEvento",
                required = true) Integer periodoVisaoEvento,
        @RequestParam(value = "codigoCanal", required = true) BigDecimal codigoCanal) {

        try {
            VisaoGeralCanalResponse response = new VisaoGeralCanalResponse();
            response.setVisaoGeralCanal(
                centralEventosService.obterVisaoEventoCanalDetalhe(periodoVisaoEvento,
                    codigoCanal));
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemResult = new ResponseMensagem();
            mensagemResult.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemResult.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemResult.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException ex) {
            ResponseMensagem retornoSqlAcessoADadosException = new ResponseMensagem();
            retornoSqlAcessoADadosException.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlAcessoADadosException.setMensagem(ex.getMessage());
            LOGGER.error(ex);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlAcessoADadosException.getMensagem() + ";"
                    + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de registro
     * de eventos exportar arquivo Excel
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @param periodoTempo      Integer
     * @param dataIncio         String
     * @param dataFim           String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterStatusDetalheEvento")
    @Operation(summary = "Obtem detalhe de evento selecionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterStatusDetalhesEvento(
        @RequestParam(value = "codigoErro", required = false) Integer codigoErro,
        @RequestParam(value = "codigoEmpresa", required = false) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto", required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal", required = true) BigDecimal codigoCanal,
        @RequestParam("dataProcessamento") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date dataProcessamento,
        @RequestParam(value = "periodoTempo", required = true) Integer periodoTempo,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento) {

        try {

            StatusDetalheEventoResponse response = new StatusDetalheEventoResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setListaStatusDetalheEvento(centralEventosService.obterStatusDetalheEvento(
                codigoErro, codigoEmpresa, codigoProduto, codigoCanal, dataProcessamento,
                periodoTempo,
                statusEvento));

            return ResponseEntity.ok(response);

        } catch (AcessoADadosException excep) {
            ResponseMensagem retornoAccep = new ResponseMensagem();
            retornoAccep.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoAccep.setMensagem(excep.getMessage());
            LOGGER.error(excep);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoAccep.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        } catch (EmptyResultDataAccessException exception) {
            ResponseMensagem mensagemEmpty = new ResponseMensagem();
            mensagemEmpty.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmpty.setMensagem(exception.getMessage());
            LOGGER.error(exception);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmpty.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        }

    }

    /**
     * Obtem informações de detalhe de eventos grafico
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @param periodoTempo      Integer
     * @param dataIncio         String
     * @param dataFim           String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterGraficoDetalheEvento")
    @Operation(summary = "Obtem grafico detalhe de evento selecionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterGraficoDetalheEvento(
        @RequestParam(value = "codigoErro", required = true) Integer codigoErro,
        @RequestParam(value = "codigoEmpresa", required = true) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto", required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal", required = true) BigDecimal codigoCanal,
        @RequestParam("dataProcessamento") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date dataProcessamento) {

        try {

            GraficoDetalheEventoResponse response = new GraficoDetalheEventoResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setGraficoDetalheEvento(centralEventosService.obterGraficoDetalheEvento(
                codigoErro, codigoEmpresa, codigoProduto, codigoCanal, dataProcessamento));

            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem msgEmpty = new ResponseMensagem();
            msgEmpty.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            msgEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                msgEmpty.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3, e);

        } catch (AcessoADadosException e) {
            ResponseMensagem returnSqlEx = new ResponseMensagem();
            returnSqlEx.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            returnSqlEx.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                returnSqlEx.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de detalhe de eventos relacionados
     *
     * @param codigoErro Integer
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterDetalheEventoRelacionados")
    @Operation(summary = "Obtem detalhe de evento relacionados")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterDetalheEventoRelacionados(
        @RequestParam(value = "codigoErro", required = true) Integer codigoErro,
        @RequestParam(value = "limite", required = true) Integer limite,
        @RequestParam(value = "linha", required = true) Integer linha) {

        try {

            RelacionadoDetalheEventoResponse response = new RelacionadoDetalheEventoResponse();
            response.setCodigoRetorno(Constantes.CODIGO_RETORNO_0);
            response.setMensagem(Constantes.SUCESSO);
            response.setTotalItensRelacionados(
                centralEventosService.obterTotalEventoRelacionados(codigoErro));
            response.setListaDetalheEventoRelacionados(
                centralEventosService.obterDetalheEventoRelacionados(codigoErro, limite,
                    linha));
            return ResponseEntity.ok(response);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmpty = new ResponseMensagem();
            mensagemEmpty.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmpty.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3, e);

        } catch (AcessoADadosException e) {
            ResponseMensagem retornoSqlEx = new ResponseMensagem();
            retornoSqlEx.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlEx.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlEx.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de registro
     * de eventos exportar arquivo Excel
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterRegistroEventoExcel")
    @Operation(summary = "Obtem visão de evento aberto relacionada por canal"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<StreamingResponseBody> obterRegistroEventoExcel(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim,
        @RequestParam(value = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(value = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "codigoTipoEvento", required = false) BigDecimal codigoTipoEvento,
        @RequestParam(value = "login", required = true) String login) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            Workbook wb = centralEventosService.obterRegistroEventoExcel(
                listaCodigoProduto, listaCodigoCanal, statusEvento, dataInicioDate, dataFimDate,
                codigoTipoEvento,
                login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_REGISTRO_EVENTO_XLSX)
                .body(wb::write);

        } catch (EmptyResultDataAccessException exceptionEmply) {
            ResponseMensagem mensagemVazioExc = new ResponseMensagem();
            mensagemVazioExc.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemVazioExc.setMensagem(exceptionEmply.getMessage());
            LOGGER.error(exceptionEmply);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemVazioExc.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException exAcesso) {
            ResponseMensagem retornoSqlExcep = new ResponseMensagem();
            retornoSqlExcep.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlExcep.setMensagem(exAcesso.getMessage());
            LOGGER.error(exAcesso);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlExcep.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de registro
     * de eventos exportar arquivo Excel
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterRegistroEventoCsv")
    @Operation(summary = "Obtem visão de evento aberto relacionada por canal"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<InputStreamResource> obterRegistroEventoCsv(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim,
        @RequestParam(value = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(value = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "codigoTipoEvento", required = false) BigDecimal codigoTipoEvento,
        @RequestParam(value = "login", required = true) String login) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            Workbook wb = centralEventosService.obterRegistroEventoExcel(
                listaCodigoProduto, listaCodigoCanal, statusEvento, dataInicioDate, dataFimDate,
                codigoTipoEvento,
                login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_REGISTRO_EVENTO_CSV)
                .body(new InputStreamResource(Utils.csvConverter(wb)));

        } catch (EmptyResultDataAccessException exceptionRegistroCsv) {
            ResponseMensagem mensagemEmptyRegistroCsv = new ResponseMensagem();
            mensagemEmptyRegistroCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyRegistroCsv.setMensagem(exceptionRegistroCsv.getMessage());
            LOGGER.error(exceptionRegistroCsv);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyRegistroCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eRegistroCsv) {
            ResponseMensagem retornoSqlRegistroCsv = new ResponseMensagem();
            retornoSqlRegistroCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlRegistroCsv.setMensagem(eRegistroCsv.getMessage());
            LOGGER.error(eRegistroCsv);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlRegistroCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de registro
     * de eventos exportar arquivo Excel
     *
     * @param dataInicio String
     * @param dataFim    String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterRegistroEventoPDF")
    @Operation(summary = "Obtem visão de evento aberto relacionada por canal"
        + " em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<InputStreamResource> obterRegistroEventoPDF(
        @RequestParam(value = "dataIncio", required = true) String dataInicio,
        @RequestParam(value = "dataFim", required = true) String dataFim,
        @RequestParam(value = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(value = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "codigoTipoEvento", required = false) BigDecimal codigoTipoEvento,
        @RequestParam(value = "login", required = true) String login) {

        try {
            centralEventosService.validarParametrosVisaoEventoAberto(dataInicio, dataFim);
            Date dataInicioDate = Utils.strDateFmtBrasilToJavaDate(dataInicio);
            Date dataFimDate = Utils.strDateFmtBrasilToJavaDate(dataFim);

            ByteArrayInputStream docRegistroPdf = centralEventosService.obterRegistroEventoPDF(
                listaCodigoProduto, listaCodigoCanal, statusEvento, dataInicioDate, dataFimDate,
                codigoTipoEvento,
                login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_REGISTRO_EVENTO_PDF)
                .body(new InputStreamResource(docRegistroPdf));

        } catch (EmptyResultDataAccessException exceptionRegistroPdf) {
            ResponseMensagem mensagemEmptyRegistroPdf = new ResponseMensagem();
            mensagemEmptyRegistroPdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyRegistroPdf.setMensagem(exceptionRegistroPdf.getMessage());
            LOGGER.error(exceptionRegistroPdf);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyRegistroPdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eRegistroPdf) {
            ResponseMensagem retornoSqlRegistroPdf = new ResponseMensagem();
            retornoSqlRegistroPdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlRegistroPdf.setMensagem(eRegistroPdf.getMessage());
            LOGGER.error(eRegistroPdf);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlRegistroPdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoProdutoCanalDetalhePDF")
    @Operation(summary = "Obtem visão de evento por produto em detalhe em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<InputStreamResource> obterVisaoEventoProdutoCanalDetalhePDF(
        @Parameter(description = "Periodo de tempo determinado para visão evento produto detalhe, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(value = "peridoVisaoEvento",
                required = true) Integer periodoVisaoEvento,
        @RequestParam(value = "codigoProduto", required = false) List<BigDecimal> codigoProduto,
        @RequestParam(value = "codigoCanal", required = false) List<BigDecimal> codigoCanal,
        @RequestParam(value = "login", required = true) String login) {
        Integer periodo = 0;
        try {

            if (periodoVisaoEvento == Constantes.INT_1) {
                periodo = Constantes.INT_1;
            } else if (periodoVisaoEvento == Constantes.INT_2) {
                periodo = Constantes.INT_7;
            } else {
                periodo = Constantes.INT_30;
            }

            ByteArrayInputStream docVisaoEventoPdf = centralEventosService.obterVisaoEventoProdutoCanalDetalhePDF(
                periodo, codigoProduto, codigoCanal, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_REGISTRO_EVENTO_PDF)
                .body(new InputStreamResource(docVisaoEventoPdf));

        } catch (EmptyResultDataAccessException exceptionVisaoEventoPdf) {
            ResponseMensagem mensagemEmptyVisaoEventoPdf = new ResponseMensagem();
            mensagemEmptyVisaoEventoPdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyVisaoEventoPdf.setMensagem(exceptionVisaoEventoPdf.getMessage());
            LOGGER.error(exceptionVisaoEventoPdf);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyVisaoEventoPdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eVisaoEventoPdf) {
            ResponseMensagem retornoSqlVisaoEventoPdf = new ResponseMensagem();
            retornoSqlVisaoEventoPdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlVisaoEventoPdf.setMensagem(eVisaoEventoPdf.getMessage());
            LOGGER.error(eVisaoEventoPdf);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlVisaoEventoPdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoCanal        BigDecimal
     * @param login              String
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoProdutoCanalDetalheExcelCsv")
    @Operation(summary = "Obtem visão de evento por produto em detalhe em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<StreamingResponseBody> obterVisaoEventoProdutoCanalDetalheExcelCsv(
        @Parameter(description = "Periodo de tempo determinado para visão evento produto detalhe, "
            + "1 = Ultimas 24 horas, 2 = Ultima Semana, 3 = Ultimo mês") @RequestParam(value = "peridoVisaoEvento",
                required = true) Integer periodoVisaoEvento,
        @Parameter(description = "Tipo de arquivo Excel ou CSV"
            + "1 = Excel ou 2 = CSV") @RequestParam(value = "tipoArquivo", required = true) Integer tipoArquivo,
        @RequestParam(value = "codigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(value = "codigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(value = "login", required = true) String login) {
        Integer periodo = 0;
        try {

            if (periodoVisaoEvento == Constantes.INT_1) {
                periodo = Constantes.INT_1;
            } else if (periodoVisaoEvento == Constantes.INT_2) {
                periodo = Constantes.INT_7;
            } else {
                periodo = Constantes.INT_30;
            }

            Workbook wbVisaoEventoExcelCsv = centralEventosService.obterVisaoEventoProdutoCanalDetalheExcelCsv(periodo,
                listaCodigoProduto,
                listaCodigoCanal, login);
            if (tipoArquivo == 1) {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_REGISTRO_EVENTO_XLSX)
                    .body(wbVisaoEventoExcelCsv::write);
            } else {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_REGISTRO_EVENTO_CSV)
                    .body(wbVisaoEventoExcelCsv::write);
            }

        } catch (EmptyResultDataAccessException exceptionVisaoEventoExcelCsv) {
            ResponseMensagem mensagemEmptyVisaoEventoExcelCsv = new ResponseMensagem();
            mensagemEmptyVisaoEventoExcelCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyVisaoEventoExcelCsv.setMensagem(exceptionVisaoEventoExcelCsv.getMessage());
            LOGGER.error(exceptionVisaoEventoExcelCsv);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyVisaoEventoExcelCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eVisaoEventoExcelCsv) {
            ResponseMensagem retornoSqlVisaoEventoExcelCsv = new ResponseMensagem();
            retornoSqlVisaoEventoExcelCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlVisaoEventoExcelCsv.setMensagem(eVisaoEventoExcelCsv.getMessage());
            LOGGER.error(eVisaoEventoExcelCsv);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlVisaoEventoExcelCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoDetalhadoPDF")
    @Operation(summary = "Obtem visão de evento detalhe em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<InputStreamResource> obterVisaoEventoDetalhePDF(
        @RequestParam(value = "codigoErro", required = false) Integer codigoErro,
        @RequestParam(value = "codigoEmpresa", required = false) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto", required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal", required = true) BigDecimal codigoCanal,
        @RequestParam("dataProcessamento") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date dataProcessamento,
        @RequestParam(value = "periodoTempo", required = true) Integer periodoTempo,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "login", required = true) String login) {

        try {

            ByteArrayInputStream docVisaoEventoDetalhePdf = centralEventosService.obterVisaoEventoDetalhadoPDF(
                codigoErro, codigoEmpresa, codigoProduto, codigoCanal, dataProcessamento,
                periodoTempo, statusEvento, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                    INLINE_FILENAME_REGISTRO_EVENTO_PDF)
                .body(new InputStreamResource(docVisaoEventoDetalhePdf));

        } catch (EmptyResultDataAccessException exceptionVisaoEventoDetalhePdf) {
            ResponseMensagem mensagemEmptyVisaoEventoDetalhePdf = new ResponseMensagem();
            mensagemEmptyVisaoEventoDetalhePdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyVisaoEventoDetalhePdf.setMensagem(exceptionVisaoEventoDetalhePdf.getMessage());
            LOGGER.error(exceptionVisaoEventoDetalhePdf);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyVisaoEventoDetalhePdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eVisaoEventoDetalhePdf) {
            ResponseMensagem retornoSqlVisaoEventoDetalhePdf = new ResponseMensagem();
            retornoSqlVisaoEventoDetalhePdf.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlVisaoEventoDetalhePdf.setMensagem(eVisaoEventoDetalhePdf.getMessage());
            LOGGER.error(eVisaoEventoDetalhePdf);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlVisaoEventoDetalhePdf.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

    /**
     * Obtem informações de visao de evento aberto por canal para painel de central
     * de eventos
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @param codigoProduto      BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterVisaoEventoDetalhadoExcelCsv")
    @Operation(summary = "Obtem visão de evento detalhe em central de eventos do painel OV. ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<StreamingResponseBody> obterVisaoEventoDetalheExcelCsv(
        @RequestParam(value = "tipoArquivo", required = true) Integer tipoArquivo,
        @RequestParam(value = "codigoErro", required = false) Integer codigoErro,
        @RequestParam(value = "codigoEmpresa", required = false) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto", required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal", required = true) BigDecimal codigoCanal,
        @RequestParam("dataProcessamento") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date dataProcessamento,
        @RequestParam(value = "periodoTempo", required = true) Integer periodoTempo,
        @RequestParam(value = "statusEvento", required = false) Integer statusEvento,
        @RequestParam(value = "login", required = true) String login) {

        try {
            Workbook wbVisaoEventoDetalheExcelCsv = centralEventosService.obterVisaoEventoDetalhadoExcelCsv(
                codigoErro, codigoEmpresa, codigoProduto, codigoCanal, dataProcessamento,
                periodoTempo, statusEvento, login);
            if (tipoArquivo == 1) {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_REGISTRO_EVENTO_XLSX)
                    .body(wbVisaoEventoDetalheExcelCsv::write);
            } else {
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_REGISTRO_EVENTO_CSV)
                    .body(wbVisaoEventoDetalheExcelCsv::write);
            }

        } catch (EmptyResultDataAccessException exceptionVisaoEventoDetalheExcelCsv) {
            ResponseMensagem mensagemEmptyVisaoEventoDetalheExcelCsv = new ResponseMensagem();
            mensagemEmptyVisaoEventoDetalheExcelCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_3);
            mensagemEmptyVisaoEventoDetalheExcelCsv.setMensagem(exceptionVisaoEventoDetalheExcelCsv.getMessage());
            LOGGER.error(exceptionVisaoEventoDetalheExcelCsv);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmptyVisaoEventoDetalheExcelCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_3);

        } catch (AcessoADadosException eVisaoEventoDetalheExcelCsv) {
            ResponseMensagem retornoSqlVisaoEventoDetalheExcelCsv = new ResponseMensagem();
            retornoSqlVisaoEventoDetalheExcelCsv.setCodigoRetorno(Constantes.CODIGO_RETORNO_2);
            retornoSqlVisaoEventoDetalheExcelCsv.setMensagem(eVisaoEventoDetalheExcelCsv.getMessage());
            LOGGER.error(eVisaoEventoDetalheExcelCsv);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                retornoSqlVisaoEventoDetalheExcelCsv.getMensagem() + ";" + Constantes.CODIGO_RETORNO_2);

        }
    }

}
