package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CentralEventosDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.GraficoDetalheEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaDetalheEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaRegistroEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaVisaoEventoCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaVisaoEventoProdutoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.RelacionadosDetalheEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoEventoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoGeralCanalRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.VisaoGeralProdutoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelacaoCanalProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelacaoProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.SituacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * CentralEventosDaoImpl Classe implementador acesso a base de dados.
 *
 * @author Wipro
 */
@Repository
public class CentralEventosDaoImpl implements CentralEventosDao {

    private static final String CODIGO_PRODUTO = "codigoProduto";

    private static final String CODIGO_EMPRESA = "codigoEmpresa";

    private static final String CODIGO_CANAL = "codigoCanal";

    private static final String CODIGO_ERRO = "codigoErro";

    private static final String SOMA_TRANSACAO = "SOMA_TRANSACAO";

    private static final String SOMA_EVENTO_MODERADO = "SOMA_EVENTO_MODERADO";

    private static final String SOMA_EVENTO_GRAVE = "SOMA_EVENTO_GRAVE";

    private static final String AMERICA_SAO_PAULO = "America/Sao_Paulo";

    private static final String RESULTADO_VAZIO = "Resultado vazio";

    private static final String AND_EVENTO_CCANAL_DGTAL_PNEL = " AND EVENTO.CCANAL_DGTAL_PNEL = :codigoCanal ";

    private static final String AND_EVENTO_CERRO_CNXAO_PNEL_RECORRENCIA_EVENTO_CERRO_CNXAO_PNEL = "AND "
        + "EVENTO.CERRO_CNXAO_PNEL = RECORRENCIA_EVENTO.CERRO_CNXAO_PNEL (+) ";

    private static final String AND_EVENTO_DVERIF_APLIC_RECORRENCIA_EVENTO_DVERIF_APLIC = "AND EVENTO.DVERIF_APLIC"
        + " = RECORRENCIA_EVENTO.DVERIF_APLIC (+) ";

    private static final String AND_EVENTO_CCANAL_DGTAL_PNEL_RECORRENCIA_EVENTO_CCANAL_DGTAL_PNEL = "AND EVENTO.CCANAL"
        + "_DGTAL_PNEL = RECORRENCIA_EVENTO.CCANAL_DGTAL_PNEL (+) ";

    private static final String AND_EVENTO_CPRODT_PNEL_RECORRENCIA_EVENTO_CPRODT_PNEL = "AND EVENTO.CPRODT_PNEL"
        + " = RECORRENCIA_EVENTO.CPRODT_PNEL (+) ";

    private static final String AND_EVENTO_CEMPR_PNEL_RECORRENCIA_EVENTO_CEMPR_PNEL = "AND EVENTO.CEMPR_PNEL ="
        + " RECORRENCIA_EVENTO.CEMPR_PNEL (+) ";

    private static final String AND_EVENTO_CTPO_EVNTO_PNEL_TIPO_EVENTO_CTPO_EVNTO_PNEL = "AND EVENTO.CTPO_EVNTO_PNEL ="
        + " TIPO_EVENTO.CTPO_EVNTO_PNEL ";

    private static final String AND_PRODUTO_CPRODT_PNEL_EVENTO_CPRODT_PNEL = "AND PRODUTO.CPRODT_PNEL "
        + "= EVENTO.CPRODT_PNEL ";

    private static final String AND_DPROCS_APLIC_SYSDATE_AND_DPROCS_APLIC_SYSDATE = " AND DPROCS_APLIC  "
        + ">= SYSDATE-1/24  AND DPROCS_APLIC <= SYSDATE ";

    private static final String RCRRC_EVNTO_RECORRENCIA_EVENTO = "RCRRC_EVNTO RECORRENCIA_EVENTO ";

    private static final String TPO_EVNTO_PNEL_TIPO_EVENTO = "TPO_EVNTO_PNEL TIPO_EVENTO, ";

    private static final String PRODT_PNEL_PRODUTO = "PRODT_PNEL PRODUTO, ";

    private static final String CANAL_DGTAL_PNEL_CANAL = "CANAL_DGTAL_PNEL CANAL, ";

    private static final String PNEL_MNTTO_CNXAO_EVENTO = "PNEL_MNTTO_CNXAO EVENTO, ";

    private static final Logger LOGGER = LogManager.getLogger(CentralEventosDaoImpl.class);

    private static final String SELECT_SUM_QEVNTO_GRAVE_CNXAO_QEVNTO_GRAVE_DISPN_QEVNTO_GRAVE = Constantes.SELECT
        + "SUM(QEVNTO_GRAVE_CNXAO + QEVNTO_GRAVE_DISPN + QEVNTO_GRAVE_FUNCL ) "
        + "AS SOMA_EVENTO_GRAVE, ";

    private static final String AND_DVERIF_APLIC_SYSTIMESTAMP_PERIODO_AND_DVERIF_APLIC_SYSTIMESTAMP = " AND"
        + " DVERIF_APLIC  >= SYSTIMESTAMP - :periodo AND DVERIF_APLIC <= SYSTIMESTAMP ";

    private static final String SUM_QEVNTO_NORML_FUNCL_AS_SOMA_EVENTO_FUNC_SUM_QEVNTO = " SUM(QEVNTO_NORML_FUNCL )"
        + " AS SOMA_EVENTO_FUNC, "
        + "SUM(QEVNTO_NORML_CNXAO) AS SOMA_EVENTO_VOLUMETRIA, ";

    private static final String SUM_QTRANS_EXECT_INSUC_AS_SOMA_TRANSACAO_SUM_QEVNTO_NORML = " SUM(QTRANS_EXECT_INSUC ) "
        + " AS SOMA_TRANSACAO,"
        + " SUM(QEVNTO_NORML_DISPN) AS SOMA_EVENTO_DISP, ";

    private static final String SUM_QEVNTO_MRADO_CNXAO_QEVNTO_MRADO_DISPN_QEVNTO_MRADO_FUNCL_AS_SOMA_EVENTO = "SUM"
        + "(QEVNTO_MRADO_CNXAO + QEVNTO_MRADO_DISPN + QEVNTO_MRADO_FUNCL ) "
        + "AS SOMA_EVENTO_MODERADO, ";

    private static final String FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_CANAL_DGTAL_PNEL_CANAL = Constantes.FROM
        + " OVSM.PNEL_MNTTO_CNXAO EVENTO, "
        + "OVSM.CANAL_DGTAL_PNEL CANAL ";

    private static final String FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_PRODT_PNEL_PRODUTO = Constantes.FROM
        + " OVSM.PNEL_MNTTO_CNXAO EVENTO, "
        + "OVSM.PRODT_PNEL PRODUTO ";

    private static final String WHERE_EVENTO_CPRODT_PNEL_PRODUTO_CPRODT_PNEL = " WHERE EVENTO.CPRODT_PNEL"
        + " = PRODUTO.CPRODT_PNEL ";

    private static final String WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL = " WHERE"
        + " EVENTO.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL ";

    private static final String SELECT_VISAO_EVENTO = " SELECT SUM(QEVNTO_NORML_DISPN ) AS QNT_EVENTO_DISPN,"
        + "SUM(QEVNTO_NORML_FUNCL ) AS QNT_EVENTO_FUNCL, SUM(QEVNTO_NORML_CNXAO ) AS QNT_EVENTO_VOLUM, "
        + " SUM(QEVNTO_NORML_DISPN + QEVNTO_NORML_FUNCL + QEVNTO_NORML_CNXAO) AS QNT_TOTAL,"
        + " SUM(QTRANS_EXECT_INSUC) AS TRANSACAO, "
        + " SUM(QTRANS_EXECT_INSUC + QTRANS_EXECT_SCESS) AS TRANSACAO_TOTAL " + Constantes.FROM
        + Constantes.OWNER_TABELA
        + "PNEL_MNTTO_CNXAO " + " WHERE CERRO_CNXAO_PNEL <> 97 "
        + "AND CERRO_CNXAO_PNEL <> 200 AND DPROCS_APLIC >= :dataInicio AND DPROCS_APLIC <= :dataFim ";

    private static final String SELECT_VISAO_EVENTO_PRODUTO = Constantes.SELECT
        + "SUM(EVENTO.QEVNTO_NORML_DISPN + EVENTO.QEVNTO_NORML_FUNCL + EVENTO.QEVNTO_NORML_CNXAO) AS QNT_TOTAL, "
        + " EVENTO.CPRODT_PNEL, PRODUTO.IPRODT  " + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_PRODT_PNEL_PRODUTO
        + WHERE_EVENTO_CPRODT_PNEL_PRODUTO_CPRODT_PNEL
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 97 "
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 200 "
        + "AND EVENTO.DPROCS_APLIC >= :dataInicio AND EVENTO.DPROCS_APLIC <= :dataFim "
        + " GROUP BY EVENTO.CPRODT_PNEL, PRODUTO.IPRODT ";

    private static final String SELECT_VISAO_EVENTO_CANAL = Constantes.SELECT
        + " SUM(EVENTO.QEVNTO_NORML_DISPN + EVENTO.QEVNTO_NORML_FUNCL + EVENTO.QEVNTO_NORML_CNXAO) AS QNT_TOTAL, "
        + " EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL  "
        + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_CANAL_DGTAL_PNEL_CANAL
        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 97 "
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 200 "
        + "AND EVENTO.DPROCS_APLIC >= :dataInicio AND EVENTO.DPROCS_APLIC <= :dataFim "
        + " GROUP BY EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL ";

    private static final String SELECT_REGISTRO_EVENTO = " SELECT MAX(EVENTO.DPROCS_APLIC) AS DATA_DPROCS_APLIC, "
        + "EVENTO.CERRO_CNXAO_PNEL, "
        + " TIPO_EVENTO.ITPO_EVNTO_PNEL,  EVENTO.OSIT_ABERT_EVNTO, "
        + "PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, "
        + "EVENTO.QTRANS_EXECT_INSUC, RECORRENCIA_EVENTO.QSEGDA_EVNTO, "
        + "RECORRENCIA_EVENTO.QRCRRC_ERRO_EVNTO, EVENTO.DINIC_ERRO_FUNCL, EVENTO.DINIC_ERRO_VOLUM, "
        + "EVENTO.DINIC_ERRO_DISPN, SUM(EVENTO.QEVNTO_NORML_FUNCL) AS QEVNTO_NORML_FUNCL, "
        + "SUM(EVENTO.QEVNTO_NORML_DISPN) AS QEVNTO_NORML_DISPN, "
        + "SUM(EVENTO.QEVNTO_NORML_CNXAO) AS QEVNTO_NORML_CNXAO,  MAX(EVENTO.CSIT_VOLUM) AS CSIT_VOLUM, "
        + "MAX(EVENTO.CSIT_DISPN) AS CSIT_DISPN,  "
        + "MAX(EVENTO.CSIT_FUNCL) AS CSIT_FUNCL, "
        + "EVENTO.CEMPR_PNEL, EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, MIN(EVENTO.DPROCS_APLIC) AS DPROCS_APLIC, "
        + "SUM((SELECT COUNT(*) FROM OVSM.PNEL_MSGEM_EVNTO MSG "
        + "WHERE MSG.CEMPR_PNEL = EVENTO.CEMPR_PNEL AND MSG.CPRODT_PNEL = EVENTO.CPRODT_PNEL "
        + "AND MSG.CCANAL_DGTAL_PNEL= EVENTO.CCANAL_DGTAL_PNEL "
        + "AND MSG.DPROCS_APLIC = EVENTO.DPROCS_APLIC AND EVENTO.CERRO_CNXAO_PNEL = CERRO_CNXAO_PNEL)) AS MSGS, "
        + "SUBSTR(EVENTO.IETAPA_PRODT_CANAL,INSTR(EVENTO.IETAPA_PRODT_CANAL,'/',-1)+1) AS ETAPA, "
        + "SUM(EVENTO.QEVNTO_PER_APURC) AS QTD_30_DIAS, EVENTO.EURL_CANAL_DGTAL AS URL, EVENTO.IAPI_ORIGE AS API, "
        + "EVENTO.IPLATF_CNXAO AS MAINFRAME, EVENTO.CSERVC_TRANS_PNEL AS WEB_SERVICE "

        + Constantes.FROM + Constantes.OWNER_TABELA + CentralEventosDaoImpl.PNEL_MNTTO_CNXAO_EVENTO +
        Constantes.OWNER_TABELA
        + CANAL_DGTAL_PNEL_CANAL + Constantes.OWNER_TABELA + PRODT_PNEL_PRODUTO + Constantes.OWNER_TABELA
        + TPO_EVNTO_PNEL_TIPO_EVENTO + Constantes.OWNER_TABELA + RCRRC_EVNTO_RECORRENCIA_EVENTO

        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL
        + AND_PRODUTO_CPRODT_PNEL_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CTPO_EVNTO_PNEL_TIPO_EVENTO_CTPO_EVNTO_PNEL
        + AND_EVENTO_CEMPR_PNEL_RECORRENCIA_EVENTO_CEMPR_PNEL
        + AND_EVENTO_CPRODT_PNEL_RECORRENCIA_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CCANAL_DGTAL_PNEL_RECORRENCIA_EVENTO_CCANAL_DGTAL_PNEL
        + AND_EVENTO_DVERIF_APLIC_RECORRENCIA_EVENTO_DVERIF_APLIC
        + AND_EVENTO_CERRO_CNXAO_PNEL_RECORRENCIA_EVENTO_CERRO_CNXAO_PNEL
        + " AND TO_CHAR(EVENTO.DPROCS_APLIC ,'yyyy-mm-dd') >= TO_CHAR(:dataInicio ,'yyyy-mm-dd') "
        + " AND TO_CHAR(EVENTO.DPROCS_APLIC ,'yyyy-mm-dd') <= TO_CHAR(:dataFim ,'yyyy-mm-dd') ";

    private static final String SELECT_SIT_EVENTO = "SELECT CSIT_EVNTO_PNEL, ISIT_EVNTO_PNEL FROM "
        + Constantes.OWNER_TABELA + "SIT_EVNTO_PNEL ";

    public static final String AND_EVENTO_CPRODT_PNEL_CODIGO_PRODUTO = " AND EVENTO.CPRODT_PNEL = :codigoProduto ";
    private static final String SELECT_VISAO_EVENTO_GERAL_PRODUTO_DETALHAR = "  "
        + "SELECT SUM(QEVNTO_GRAVE_CNXAO + QEVNTO_GRAVE_DISPN + QEVNTO_GRAVE_FUNCL ) AS SOMA_EVENTO_GRAVE, "
        + SUM_QEVNTO_MRADO_CNXAO_QEVNTO_MRADO_DISPN_QEVNTO_MRADO_FUNCL_AS_SOMA_EVENTO
        + SUM_QTRANS_EXECT_INSUC_AS_SOMA_TRANSACAO_SUM_QEVNTO_NORML
        + SUM_QEVNTO_NORML_FUNCL_AS_SOMA_EVENTO_FUNC_SUM_QEVNTO + " EVENTO.CPRODT_PNEL, PRODUTO.IPRODT "
        + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_PRODT_PNEL_PRODUTO + WHERE_EVENTO_CPRODT_PNEL_PRODUTO_CPRODT_PNEL
        + AND_EVENTO_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_DVERIF_APLIC_SYSTIMESTAMP_PERIODO_AND_DVERIF_APLIC_SYSTIMESTAMP;

    private static final String SELECT_VISAO_EVENTO_GERAL_RELACIONADO_PRODUTO_DETALHAR = " "
        + SELECT_SUM_QEVNTO_GRAVE_CNXAO_QEVNTO_GRAVE_DISPN_QEVNTO_GRAVE
        + SUM_QEVNTO_MRADO_CNXAO_QEVNTO_MRADO_DISPN_QEVNTO_MRADO_FUNCL_AS_SOMA_EVENTO
        + " SUM(QTRANS_EXECT_INSUC ) AS SOMA_TRANSACAO, EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL "

        + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_CANAL_DGTAL_PNEL_CANAL

        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL + AND_EVENTO_CPRODT_PNEL_CODIGO_PRODUTO
        + AND_DVERIF_APLIC_SYSTIMESTAMP_PERIODO_AND_DVERIF_APLIC_SYSTIMESTAMP;

    private static final String SELECT_VISAO_EVENTO_GERAL_CANAL_DETALHAR = ""
        + SELECT_SUM_QEVNTO_GRAVE_CNXAO_QEVNTO_GRAVE_DISPN_QEVNTO_GRAVE
        + SUM_QEVNTO_MRADO_CNXAO_QEVNTO_MRADO_DISPN_QEVNTO_MRADO_FUNCL_AS_SOMA_EVENTO
        + SUM_QTRANS_EXECT_INSUC_AS_SOMA_TRANSACAO_SUM_QEVNTO_NORML
        + SUM_QEVNTO_NORML_FUNCL_AS_SOMA_EVENTO_FUNC_SUM_QEVNTO
        + " EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL "
        + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_CANAL_DGTAL_PNEL_CANAL
        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL + AND_EVENTO_CCANAL_DGTAL_PNEL
        + AND_DVERIF_APLIC_SYSTIMESTAMP_PERIODO_AND_DVERIF_APLIC_SYSTIMESTAMP;

    private static final String SELECT_VISAO_EVENTO_GERAL_RELACIONADO_CANAL_DETALHAR = ""
        + SELECT_SUM_QEVNTO_GRAVE_CNXAO_QEVNTO_GRAVE_DISPN_QEVNTO_GRAVE
        + SUM_QEVNTO_MRADO_CNXAO_QEVNTO_MRADO_DISPN_QEVNTO_MRADO_FUNCL_AS_SOMA_EVENTO
        + SUM_QTRANS_EXECT_INSUC_AS_SOMA_TRANSACAO_SUM_QEVNTO_NORML
        + SUM_QEVNTO_NORML_FUNCL_AS_SOMA_EVENTO_FUNC_SUM_QEVNTO + " EVENTO.CPRODT_PNEL, PRODUTO.IPRODT "
        + FROM_OVSM_PNEL_MNTTO_CNXAO_EVENTO_OVSM_PRODT_PNEL_PRODUTO + WHERE_EVENTO_CPRODT_PNEL_PRODUTO_CPRODT_PNEL
        + AND_EVENTO_CCANAL_DGTAL_PNEL
        + AND_DVERIF_APLIC_SYSTIMESTAMP_PERIODO_AND_DVERIF_APLIC_SYSTIMESTAMP;

    private static final String SELECT_STATUS_EVENTO_SINAL = Constantes.SELECT
        + "EVENTO.CSIT_DISPN,EVENTO.CSIT_FUNCL,EVENTO.CSIT_VOLUM, PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL "
        + "FROM OVSM.PNEL_MNTTO_CNXAO EVENTO, "
        + "OVSM.PRODT_PNEL PRODUTO, OVSM.CANAL_DGTAL_PNEL CANAL WHERE EVENTO.CPRODT_PNEL = PRODUTO.CPRODT_PNEL  "
        + "AND EVENTO.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL "
        + "AND EVENTO.CPRODT_PNEL = :codigoProduto  "
        + "AND EVENTO.CCANAL_DGTAL_PNEL = :codigoCanal ";

    private static final String SELECT_STATUS_DETALHE_EVENTO = " SELECT"
        + " SUM(QEVNTO_GRAVE_CNXAO + QEVNTO_GRAVE_DISPN + QEVNTO_GRAVE_FUNCL ) AS SOMA_EVENTO_GRAVE, "
        + " SUM(QEVNTO_MRADO_CNXAO + QEVNTO_MRADO_DISPN + QEVNTO_MRADO_FUNCL ) AS SOMA_EVENTO_MODERADO, "
        + " SUM(QTRANS_EXECT_INSUC )  AS SOMA_TRANSACAO, SUM(QEVNTO_NORML_DISPN) AS SOMA_EVENTO_DISP, "
        + " SUM(QEVNTO_NORML_FUNCL ) AS SOMA_EVENTO_FUNC, SUM(QEVNTO_NORML_CNXAO) AS SOMA_EVENTO_VOLUMETRIA, "
        + " PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL "
        + " FROM  OVSM.PNEL_MNTTO_CNXAO EVENTO, OVSM.PRODT_PNEL PRODUTO , OVSM.CANAL_DGTAL_PNEL CANAL "
        + " WHERE EVENTO.CPRODT_PNEL = PRODUTO.CPRODT_PNEL "
        + " AND EVENTO.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL "
        + " AND EVENTO.CPRODT_PNEL = :codigoProduto AND EVENTO.CCANAL_DGTAL_PNEL = :codigoCanal  ";

    private static final String SELECT_REGISTRO_EVENTO_DETALHE = " SELECT EVENTO.CERRO_CNXAO_PNEL, "
        + " TIPO_EVENTO.ITPO_EVNTO_PNEL,  EVENTO.OSIT_ABERT_EVNTO, "
        + "PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, "
        + "EVENTO.QTRANS_EXECT_INSUC, RECORRENCIA_EVENTO.QSEGDA_EVNTO, "
        + "RECORRENCIA_EVENTO.QRCRRC_ERRO_EVNTO, EVENTO.DINIC_ERRO_FUNCL, EVENTO.DINIC_ERRO_VOLUM, "
        + "EVENTO.DINIC_ERRO_DISPN, SUM(EVENTO.QEVNTO_NORML_FUNCL) AS QEVNTO_NORML_FUNCL, "
        + "SUM(EVENTO.QEVNTO_NORML_DISPN) AS QEVNTO_NORML_DISPN, "
        + "SUM(EVENTO.QEVNTO_NORML_CNXAO) AS QEVNTO_NORML_CNXAO, MAX(EVENTO.CSIT_VOLUM) AS CSIT_VOLUM,  "
        + "MAX(EVENTO.CSIT_DISPN) AS CSIT_DISPN, MAX(EVENTO.CSIT_FUNCL) AS CSIT_FUNCL, "
        + "EVENTO.CEMPR_PNEL, EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, MIN(EVENTO.DPROCS_APLIC) AS DPROCS_APLIC, "
        + "SUM((SELECT COUNT(*) FROM OVSM.PNEL_MSGEM_EVNTO MSG "
        + "WHERE MSG.CEMPR_PNEL = EVENTO.CEMPR_PNEL AND MSG.CPRODT_PNEL = EVENTO.CPRODT_PNEL "
        + "AND MSG.CCANAL_DGTAL_PNEL= EVENTO.CCANAL_DGTAL_PNEL "
        + "AND MSG.DPROCS_APLIC = EVENTO.DPROCS_APLIC AND EVENTO.CERRO_CNXAO_PNEL = CERRO_CNXAO_PNEL )) AS MSGS, "
        + "SUBSTR(EVENTO.IETAPA_PRODT_CANAL,INSTR(EVENTO.IETAPA_PRODT_CANAL,'/',-1)+1) AS ETAPA, "
        + "SUM(EVENTO.QEVNTO_PER_APURC) AS QTD_30_DIAS, EVENTO.EURL_CANAL_DGTAL AS URL, EVENTO.IAPI_ORIGE AS API, "
        + "EVENTO.IPLATF_CNXAO AS MAINFRAME, EVENTO.CSERVC_TRANS_PNEL AS WEB_SERVICE "

        + Constantes.FROM + Constantes.OWNER_TABELA + PNEL_MNTTO_CNXAO_EVENTO + Constantes.OWNER_TABELA
        + CANAL_DGTAL_PNEL_CANAL + Constantes.OWNER_TABELA + PRODT_PNEL_PRODUTO + Constantes.OWNER_TABELA
        + TPO_EVNTO_PNEL_TIPO_EVENTO + Constantes.OWNER_TABELA + RCRRC_EVNTO_RECORRENCIA_EVENTO

        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL
        + AND_PRODUTO_CPRODT_PNEL_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CTPO_EVNTO_PNEL_TIPO_EVENTO_CTPO_EVNTO_PNEL
        + AND_EVENTO_CEMPR_PNEL_RECORRENCIA_EVENTO_CEMPR_PNEL
        + AND_EVENTO_CPRODT_PNEL_RECORRENCIA_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CCANAL_DGTAL_PNEL_RECORRENCIA_EVENTO_CCANAL_DGTAL_PNEL
        + AND_EVENTO_DVERIF_APLIC_RECORRENCIA_EVENTO_DVERIF_APLIC
        + AND_EVENTO_CERRO_CNXAO_PNEL_RECORRENCIA_EVENTO_CERRO_CNXAO_PNEL
        + "AND EVENTO.OSIT_ABERT_EVNTO = :statusEvento "
        + "AND EVENTO.CPRODT_PNEL = :codigoProduto AND EVENTO.CCANAL_DGTAL_PNEL = :codigoCanal  "
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 97 AND EVENTO.CERRO_CNXAO_PNEL <> 200 ";

    private static final String COUNT_REGISTRO_EVENTO_DETALHE = " SELECT COUNT(*) "
        + Constantes.FROM + Constantes.OWNER_TABELA + PNEL_MNTTO_CNXAO_EVENTO + Constantes.OWNER_TABELA
        + CANAL_DGTAL_PNEL_CANAL + Constantes.OWNER_TABELA + PRODT_PNEL_PRODUTO + Constantes.OWNER_TABELA
        + CentralEventosDaoImpl.TPO_EVNTO_PNEL_TIPO_EVENTO + Constantes.OWNER_TABELA
        + RCRRC_EVNTO_RECORRENCIA_EVENTO

        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL
        + CentralEventosDaoImpl.AND_PRODUTO_CPRODT_PNEL_EVENTO_CPRODT_PNEL
        + CentralEventosDaoImpl.AND_EVENTO_CTPO_EVNTO_PNEL_TIPO_EVENTO_CTPO_EVNTO_PNEL
        + CentralEventosDaoImpl.AND_EVENTO_CEMPR_PNEL_RECORRENCIA_EVENTO_CEMPR_PNEL
        + CentralEventosDaoImpl.AND_EVENTO_CPRODT_PNEL_RECORRENCIA_EVENTO_CPRODT_PNEL
        + CentralEventosDaoImpl.AND_EVENTO_CCANAL_DGTAL_PNEL_RECORRENCIA_EVENTO_CCANAL_DGTAL_PNEL
        + CentralEventosDaoImpl.AND_EVENTO_DVERIF_APLIC_RECORRENCIA_EVENTO_DVERIF_APLIC
        + CentralEventosDaoImpl.AND_EVENTO_CERRO_CNXAO_PNEL_RECORRENCIA_EVENTO_CERRO_CNXAO_PNEL
        + "AND EVENTO.OSIT_ABERT_EVNTO = :statusEvento "
        + "AND EVENTO.CPRODT_PNEL = :codigoProduto AND EVENTO.CCANAL_DGTAL_PNEL = :codigoCanal  "
        + "AND EVENTO.CERRO_CNXAO_PNEL <> 97 AND EVENTO.CERRO_CNXAO_PNEL <> 200 ";

    private static final String SELECT_GRAFICO_DETALHE_EVENTO = Constantes.SELECT
        + " TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd HH24:MI')  AS HORA_OCORRENCIA, "
        + " SUM(QTRANS_EXECT_SCESS + QTRANS_EXECT_INSUC) AS SOMA_VOLUMETRIA_ATUAL, "
        + " SUM (QTRANS_EXECT_SCESS) AS SOMA_SEM_EVENTO, "
        + " SUM(QTRANS_EXECT_INSUC) AS SOMA_COM_EVENTO, "
        + " SUM(QTRANS_EXECT_INSUC +  QTRANS_EXECT_INSUC ) AS MEDIA_HISTORICA, "
        + " CEMPR_PNEL, CPRODT_PNEL, CCANAL_DGTAL_PNEL "
        + " FROM OVSM.PNEL_MNTRD_HORA "
        + " WHERE DPROCS_APLIC >= :dataInicio  AND  DPROCS_APLIC <=:dataFinal "
        + " AND CEMPR_PNEL = :codigoEmpresa  AND CPRODT_PNEL = :codigoProduto   AND CCANAL_DGTAL_PNEL = :codigoCanal "
        + " GROUP BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd HH24:MI'), CEMPR_PNEL, CPRODT_PNEL, CCANAL_DGTAL_PNEL "
        + " ORDER BY TO_CHAR(DPROCS_APLIC,'yyyy-mm-dd HH24:MI') ";

    private static final String SELECT_REGISTRO_EVENTO_DETALHE_RELACIONADOS = " SELECT EVENTO.CERRO_CNXAO_PNEL"
        + " AS CODIGO, "
        + "PRODUTO.IPRODT AS PRODUTO, CANAL.ICANAL_DGTAL_PNEL AS CANAL, TIPO_EVENTO.ITPO_EVNTO_PNEL AS TIPO, "
        + "SUM(RECORRENCIA_EVENTO.QSEGDA_EVNTO) AS DURACAO, COUNT(*) AS QTD "
        + Constantes.FROM + Constantes.OWNER_TABELA + PNEL_MNTTO_CNXAO_EVENTO + Constantes.OWNER_TABELA
        + CANAL_DGTAL_PNEL_CANAL + Constantes.OWNER_TABELA + PRODT_PNEL_PRODUTO + Constantes.OWNER_TABELA
        + TPO_EVNTO_PNEL_TIPO_EVENTO + Constantes.OWNER_TABELA + RCRRC_EVNTO_RECORRENCIA_EVENTO

        + WHERE_EVENTO_CCANAL_DGTAL_PNEL_CANAL_CCANAL_DGTAL_PNEL
        + AND_PRODUTO_CPRODT_PNEL_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CTPO_EVNTO_PNEL_TIPO_EVENTO_CTPO_EVNTO_PNEL
        + AND_EVENTO_CEMPR_PNEL_RECORRENCIA_EVENTO_CEMPR_PNEL
        + AND_EVENTO_CPRODT_PNEL_RECORRENCIA_EVENTO_CPRODT_PNEL
        + AND_EVENTO_CCANAL_DGTAL_PNEL_RECORRENCIA_EVENTO_CCANAL_DGTAL_PNEL
        + AND_EVENTO_DVERIF_APLIC_RECORRENCIA_EVENTO_DVERIF_APLIC
        + AND_EVENTO_CERRO_CNXAO_PNEL_RECORRENCIA_EVENTO_CERRO_CNXAO_PNEL
        + "AND EVENTO.CERRO_CNXAO_PNEL = :codigoErro "
        + "AND DPROCS_APLIC BETWEEN trunc(sysdate, 'YEAR') AND add_months(trunc(sysdate, 'YEAR'), 12)-1/24/60/60 "
        + "GROUP BY PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.CERRO_CNXAO_PNEL "
        + "ORDER BY PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.CERRO_CNXAO_PNEL ";

    private static final String SELECT_TOTAL_EVENTO_DETALHE_RELACIONADOS = "SELECT COUNT(*) AS TOTAL "
        + Constantes.FROM + Constantes.OWNER_TABELA + "PNEL_MNTTO_CNXAO EVENTO "
        + "WHERE EVENTO.CERRO_CNXAO_PNEL = :codigoErro AND "
        + "EVENTO.DPROCS_APLIC BETWEEN trunc(sysdate, 'YEAR') AND add_months(trunc(sysdate, 'YEAR'), 12)-1/24/60/60 "
        + "GROUP BY EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL , EVENTO.CTPO_EVNTO_PNEL, EVENTO.CERRO_CNXAO_PNEL ";

    private static final String SELECT_DETALHE_EVENTO_RELACIONADOS = "SELECT * FROM ("
        + " SELECT ROWNUM RNUM, CODIGO, PRODUTO, CANAL, TIPO, DURACAO, QTD FROM( "
        + SELECT_REGISTRO_EVENTO_DETALHE_RELACIONADOS
        + ")) WHERE RNUM > :linha FETCH FIRST :limite ROWS ONLY";
    public static final String AND_DPROCS_APLIC_SYSDATE_1_24_AND_DPROCS_APLIC_SYSDATE = " AND DPROCS_APLIC  "
        + ">= SYSDATE-1/24 AND DPROCS_APLIC <= SYSDATE ";
    public static final int PERIODO_TEMPO_99 = 99;

    private static final String SELECT_VISAO_EVENTO_PRODUTO_CANAL_DETALHAR = Constantes.SELECT
        + "SUM(QEVNTO_GRAVE_CNXAO + QEVNTO_GRAVE_DISPN + QEVNTO_GRAVE_FUNCL ) AS SOMA_EVENTO_GRAVE, "
        + "SUM(QEVNTO_MRADO_CNXAO + QEVNTO_MRADO_DISPN + QEVNTO_MRADO_FUNCL ) AS SOMA_EVENTO_MODERADO, "
        + "SUM(QTRANS_EXECT_INSUC )  AS SOMA_TRANSACAO, SUM(QEVNTO_NORML_DISPN) AS SOMA_EVENTO_DISP, "
        + "SUM(QEVNTO_NORML_FUNCL ) AS SOMA_EVENTO_FUNC, SUM(QEVNTO_NORML_CNXAO) AS SOMA_EVENTO_VOLUMETRIA, "
        + "PRODUTO.IPRODT AS PRODUTO, CANAL.ICANAL_DGTAL_PNEL AS CANAL, "
        + "(SELECT SUM(E1.QEVNTO_GRAVE_CNXAO + E1.QEVNTO_GRAVE_DISPN + E1.QEVNTO_GRAVE_FUNCL + "
        + "E1.QEVNTO_MRADO_CNXAO + E1.QEVNTO_MRADO_DISPN + E1.QEVNTO_MRADO_FUNCL ) "
        + "FROM OVSM.PNEL_MNTTO_CNXAO E1 WHERE E1.CPRODT_PNEL = EVENTO.CPRODT_PNEL AND "
        + "E1.CCANAL_DGTAL_PNEL = EVENTO.CCANAL_DGTAL_PNEL AND DVERIF_APLIC  >= SYSTIMESTAMP - :periodo "
        + "AND DVERIF_APLIC <= SYSTIMESTAMP AND E1.OSIT_ABERT_EVNTO = 1 AND E1.CERRO_CNXAO_PNEL <> 97 "
        + "AND E1.CERRO_CNXAO_PNEL <> 200 ) AS ABERTOS, "
        + "(SELECT SUM(E1.QEVNTO_GRAVE_CNXAO + E1.QEVNTO_GRAVE_DISPN + E1.QEVNTO_GRAVE_FUNCL +"
        + " E1.QEVNTO_MRADO_CNXAO + E1.QEVNTO_MRADO_DISPN + E1.QEVNTO_MRADO_FUNCL ) "
        + "FROM OVSM.PNEL_MNTTO_CNXAO E1 WHERE E1.CPRODT_PNEL = EVENTO.CPRODT_PNEL AND"
        + " E1.CCANAL_DGTAL_PNEL = EVENTO.CCANAL_DGTAL_PNEL AND DVERIF_APLIC  >= SYSTIMESTAMP - :periodo "
        + "AND DVERIF_APLIC <= SYSTIMESTAMP AND E1.OSIT_ABERT_EVNTO = 2 AND "
        + "E1.CERRO_CNXAO_PNEL <> 97 AND E1.CERRO_CNXAO_PNEL <> 200 ) AS FECHADOS "
        + "FROM  OVSM.PNEL_MNTTO_CNXAO EVENTO, OVSM.PRODT_PNEL PRODUTO, OVSM.CANAL_DGTAL_PNEL CANAL "
        + "WHERE EVENTO.CPRODT_PNEL = PRODUTO.CPRODT_PNEL "
        + "AND EVENTO.CCANAL_DGTAL_PNEL = CANAL.CCANAL_DGTAL_PNEL AND EVENTO.CERRO_CNXAO_PNEL <> 97 AND EVENTO"
        + ".CERRO_CNXAO_PNEL <> 200 "
        + "AND DVERIF_APLIC  >= SYSTIMESTAMP - :periodo AND DVERIF_APLIC <= SYSTIMESTAMP  ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public CentralEventosDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public VisaoEvento obterVisaoEventoAberto(Date dataInicio, Date dataFim) {

        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, dataInicio);
            params.addValue(Constantes.DATA_FIM, dataFim);

            VisaoEvento visaoEvento = jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO, params,
                new VisaoEventoRowMapper());

            if (visaoEvento == null) {
                throw new EmptyResultDataAccessException("Resultado vazio.", 1);
            }

            return visaoEvento;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public VisaoEvento obterPorcentagemVisaoEventoAbertoAnterior(Date dataInicio, Date dataFim) {

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, Utils.converterDataLocaldateAnterior(dataInicio));
            params.addValue(Constantes.DATA_FIM, Utils.converterDataLocaldateAnterior(dataFim));

            VisaoEvento visaoEvento = jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO, params,
                new VisaoEventoRowMapper());

            if (visaoEvento == null) {
                throw new EmptyResultDataAccessException("Resultado vazio.", 1);
            }

            VisaoEvento visaoEventoAnterior = obterPorcentagemVisaoEventoAbertoAnterior(dataInicio, dataFim);

            if (visaoEventoAnterior != null) {
                visaoEvento.setPorcentagemEventosFuncionalidade(visaoEvento.getPorcentagemEventosFuncionalidade()
                    - visaoEventoAnterior.getPorcentagemEventosFuncionalidade());

                visaoEvento.setPorcentagemEventosDisponibilidade(visaoEvento.getPorcentagemEventosDisponibilidade()
                    - visaoEventoAnterior.getPorcentagemEventosDisponibilidade());

                visaoEvento.setPorcentagemEventosVolumetria(visaoEvento.getPorcentagemEventosVolumetria()
                    - visaoEventoAnterior.getPorcentagemEventosVolumetria());

                visaoEvento.setPorcentagemTransacaoImpactada(visaoEvento.getPorcentagemTransacaoImpactada()
                    - visaoEventoAnterior.getPorcentagemTransacaoImpactada());
            }

            return visaoEvento;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoEventoProduto> obterVisaoEventoProduto(Date dataInicio, Date dataFim) {
        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, dataInicio);
            params.addValue(Constantes.DATA_FIM, dataFim);

            List<VisaoEventoProduto> listaVisaoEventoProduto = jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO_PRODUTO,
                params, new ListaVisaoEventoProdutoRowMapper());

            if (listaVisaoEventoProduto.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado sem dado.", 1);
            }

            List<VisaoEventoProduto> listaVisaoEventoProdutoAnterior = obterVisaoEventoProdutoAnterior(dataInicio,
                dataFim);

            avaliarListaVisaoEventoProduto(listaVisaoEventoProduto, listaVisaoEventoProdutoAnterior);

            return listaVisaoEventoProduto;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * Avaliar lista visao evento
     *
     * @param listaVisaoEventoProduto         List<VisaoEventoProduto>
     * @param listaVisaoEventoProdutoAnterior List<VisaoEventoProduto>
     */
    private static void avaliarListaVisaoEventoProduto(List<VisaoEventoProduto> listaVisaoEventoProduto,
        List<VisaoEventoProduto> listaVisaoEventoProdutoAnterior) {
        for (int i = 0; i < listaVisaoEventoProduto.size(); i++) {
            for (int j = 0; j < listaVisaoEventoProdutoAnterior.size(); j++) {

                if (listaVisaoEventoProduto.get(i).getCodigoProduto()
                    .equals(listaVisaoEventoProdutoAnterior.get(j).getCodigoProduto())) {

                    listaVisaoEventoProduto.get(i)
                        .setPorcentagemOcorrencia(listaVisaoEventoProduto.get(i).getPorcentagemOcorrencia()
                            - listaVisaoEventoProdutoAnterior.get(j).getPorcentagemOcorrencia());
                }
            }
        }
    }

    /**
     * Obter visão evento produto anterior.
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoProduto>
     */
    private List<VisaoEventoProduto> obterVisaoEventoProdutoAnterior(Date dataInicio, Date dataFim) {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, Utils.converterDataLocaldateAnterior(dataInicio));
            params.addValue(Constantes.DATA_FIM, Utils.converterDataLocaldateAnterior(dataFim));

            return jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO_PRODUTO, params,
                new ListaVisaoEventoProdutoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoEventoCanal> obterVisaoEventoCanal(Date dataInicio, Date dataFim) {
        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, dataInicio);
            params.addValue(Constantes.DATA_FIM, dataFim);

            List<VisaoEventoCanal> listaVisaoEventoCanal = jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO_CANAL,
                params, new ListaVisaoEventoCanalRowMapper());

            if (listaVisaoEventoCanal.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado sem dado.", 1);
            }

            List<VisaoEventoCanal> listaVisaoEventoCanalAnterior = obterVisaoEventoCanalAnterior(dataInicio, dataFim);

            avaliarListaVisaoEventoCanal(listaVisaoEventoCanal, listaVisaoEventoCanalAnterior);

            return listaVisaoEventoCanal;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    public void avaliarListaVisaoEventoCanal(List<VisaoEventoCanal> listaVisaoEventoCanal,
        List<VisaoEventoCanal> listaVisaoEventoCanalAnterior) {
        for (int i = 0; i < listaVisaoEventoCanal.size(); i++) {
            for (int j = 0; j < listaVisaoEventoCanalAnterior.size(); j++) {

                if (listaVisaoEventoCanal.get(i).getCodigoCanal()
                    .equals(listaVisaoEventoCanalAnterior.get(j).getCodigoCanal())) {

                    listaVisaoEventoCanal.get(i)
                        .setPorcentagemOcorrencia(listaVisaoEventoCanal.get(i).getPorcentagemOcorrencia()
                            - listaVisaoEventoCanalAnterior.get(j).getPorcentagemOcorrencia());
                }
            }
        }
    }

    /**
     * Obter visao evento por canal anterior
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoCanal>
     */
    private List<VisaoEventoCanal> obterVisaoEventoCanalAnterior(Date dataInicio, Date dataFim) {
        try {

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, Utils.converterDataLocaldateAnterior(dataInicio));
            params.addValue(Constantes.DATA_FIM, Utils.converterDataLocaldateAnterior(dataFim));

            return jdbcTemplate.queryForObject(SELECT_VISAO_EVENTO_CANAL,
                params, new ListaVisaoEventoCanalRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new ArrayList<>();
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<RegistroEvento> obterRegistroEvento(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, Integer statusEvento, Date dataInicio, Date dataFim,
        BigDecimal codigoTipoEvento) {

        try {

            StringBuilder sql = new StringBuilder(SELECT_REGISTRO_EVENTO);
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(Constantes.DATA_INICIO, dataInicio);
            params.addValue(Constantes.DATA_FIM, dataFim);

            montarParametrosRegistroEvento(listaCodigoProduto, listaCodigoCanal, statusEvento, codigoTipoEvento, sql,
                params);
            List<RegistroEvento> registroEvento = jdbcTemplate.queryForObject(sql.toString(), params,
                new ListaRegistroEventoRowMapper());
            List<SituacaoEvento> situacaoEvento = obterListaSituacaoEvento();

            avaliarListaRegistroEventoSituacaoEvento(registroEvento, situacaoEvento);

            return registroEvento;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * Lista registro evento
     *
     * @param registroEvento List<RegistroEvento>
     * @param situacaoEvento List<SituacaoEvento>
     */
    private static void avaliarListaRegistroEventoSituacaoEvento(List<RegistroEvento> registroEvento,
        List<SituacaoEvento> situacaoEvento) {
        for (int i = 0; i < registroEvento.size(); i++) {
            for (int j = 0; j < situacaoEvento.size(); j++) {

                if (registroEvento.get(i).getCodigoGravidade() != null
                    && registroEvento.get(i).getCodigoGravidade().equals(situacaoEvento.get(j).getCodigo())) {
                    registroEvento.get(i).setDescricaoGravidade(situacaoEvento.get(j).getDescricao());
                }
            }
        }
    }

    /**
     * Monta parametro registro evento para query parametrizada.
     *
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @param statusEvento       Integer
     * @param codigoTipoEvento   BigDecimal
     * @param sql                StringBuilder
     * @param params             MapSqlParameterSource
     */
    private static void montarParametrosRegistroEvento(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        Integer statusEvento, BigDecimal codigoTipoEvento, StringBuilder sql, MapSqlParameterSource params) {
        StringBuilder valor = new StringBuilder();

        if (listaCodigoProduto != null && !listaCodigoProduto.isEmpty()) {
            sql.append(" AND EVENTO.CPRODT_PNEL IN ( ");
            valor.setLength(0);
            valor.append(listaCodigoProduto.get(0) + "");

            for (int i = 1; i < listaCodigoProduto.size(); i++) {
                valor.append(", " + listaCodigoProduto.get(i));
            }
            sql.append(valor.toString() + " ) ");
        }

        if (listaCodigoCanal != null && !listaCodigoCanal.isEmpty()) {
            sql.append(" AND EVENTO.CCANAL_DGTAL_PNEL IN ( ");
            valor.setLength(0);
            valor.append(listaCodigoCanal.get(0) + "");

            for (int i = 1; i < listaCodigoCanal.size(); i++) {
                valor.append(", " + listaCodigoCanal.get(i));
            }
            sql.append(valor.toString() + " ) ");
        }

        if (statusEvento != null && statusEvento > 0) {
            sql.append(" AND EVENTO.OSIT_ABERT_EVNTO = :statusEvento ");
            params.addValue("statusEvento", statusEvento);
        }

        if (codigoTipoEvento != null) {
            sql.append(" AND EVENTO.CTPO_EVNTO_PNEL = :codigoTipoEvento ");
            params.addValue("codigoTipoEvento", codigoTipoEvento);
        }

        sql.append(" AND EVENTO.CERRO_CNXAO_PNEL <> 97 AND EVENTO.CERRO_CNXAO_PNEL <> 200 ");

        String groupBy = "GROUP BY  EVENTO.CERRO_CNXAO_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.OSIT_ABERT_EVNTO, "
            + "PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL,"
            + "TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.QTRANS_EXECT_INSUC, RECORRENCIA_EVENTO.QSEGDA_EVNTO, "
            + " RECORRENCIA_EVENTO.QRCRRC_ERRO_EVNTO, EVENTO.DINIC_ERRO_VOLUM, "
            + "EVENTO.DINIC_ERRO_DISPN, EVENTO.CEMPR_PNEL, EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, "
            + "SUBSTR(EVENTO.IETAPA_PRODT_CANAL,INSTR(EVENTO.IETAPA_PRODT_CANAL,'/',-1)+1), "
            + "EVENTO.EURL_CANAL_DGTAL, EVENTO.IAPI_ORIGE, EVENTO.IPLATF_CNXAO, "
            + "EVENTO.CSERVC_TRANS_PNEL, EVENTO.DINIC_ERRO_FUNCL ";

        sql.append(groupBy);
        sql.append(" ORDER BY DATA_DPROCS_APLIC DESC ");

    }

    /**
     * Obter situação de eventos
     *
     * @return List<SituacaoEvento>
     */
    public List<SituacaoEvento> obterListaSituacaoEvento() {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_SIT_EVENTO, new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<SituacaoEvento> listaEvento = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                SituacaoEvento evento = new SituacaoEvento();
                evento.setCodigo((BigDecimal) mapa.get("CSIT_EVNTO_PNEL"));
                evento.setDescricao((String) mapa.get("ISIT_EVNTO_PNEL"));

                listaEvento.add(evento);
            }

            return listaEvento;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public VisaoGeralProduto obterVisaoEventoProdutoDetalhe(Integer periodoVisaoEvento, BigDecimal codigoProduto) {
        try {

            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO_GERAL_PRODUTO_DETALHAR);
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_PRODUTO, codigoProduto);

            if (periodoVisaoEvento == Constantes.INT_1) {
                params.addValue(Constantes.PERIODO, Constantes.INT_1);
            } else if (periodoVisaoEvento == Constantes.INT_2) {
                params.addValue(Constantes.PERIODO, Constantes.INT_7);
            } else {
                params.addValue(Constantes.PERIODO, Constantes.INT_30);
            }

            StringBuilder sqlGroup = new StringBuilder(" GROUP BY EVENTO.CPRODT_PNEL, PRODUTO.IPRODT ");
            VisaoGeralProduto visaoGeralProduto = jdbcTemplate.queryForObject(sql.toString() + sqlGroup.toString(),
                params, new VisaoGeralProdutoRowMapper());
            visaoGeralProduto
                .setListaRelacaoCanalProduto(obterVisaoGeralRelacaoCanalProduto(periodoVisaoEvento, codigoProduto));

            return visaoGeralProduto;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * Obter visaoEvento para relacao de canal produto na visao geral
     *
     * @param periodoVisaoEvento BigDecimal
     * @param codigoProduto      BigDecimal
     * @return List<RelacaoCanalProduto>
     */
    private List<RelacaoCanalProduto> obterVisaoGeralRelacaoCanalProduto(Integer periodoVisaoEvento,
        BigDecimal codigoProduto) {
        try {

            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO_GERAL_RELACIONADO_PRODUTO_DETALHAR);

            StringBuilder sqlGroup = new StringBuilder(
                " GROUP BY EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL ");

            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_PRODUTO, codigoProduto);

            receberParametrosEventoProdutoCanal(params, periodoVisaoEvento);

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql.toString()
                + sqlGroup.toString(), params);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado não encontrado", 1);
            }

            List<RelacaoCanalProduto> listaRelacaoCanalProduto = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                RelacaoCanalProduto relacao = new RelacaoCanalProduto();
                relacao.setCodigoCanal((BigDecimal) mapa.get("CCANAL_DGTAL_PNEL"));
                relacao.setDescricaoCanal((String) mapa.get("ICANAL_DGTAL_PNEL"));
                BigDecimal bd = (BigDecimal) mapa.get(SOMA_EVENTO_GRAVE);
                relacao.setEventoGrave(bd.intValue());
                bd = (BigDecimal) mapa.get(SOMA_EVENTO_MODERADO);
                relacao.setEventoModerado(bd.intValue());
                bd = (BigDecimal) mapa.get(SOMA_TRANSACAO);
                relacao.setTransacaoImpactada(bd.intValue());

                listaRelacaoCanalProduto.add(relacao);
            }

            return listaRelacaoCanalProduto;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public VisaoGeralCanal obterVisaoEventoCanalDetalhe(Integer periodoVisaoEvento, BigDecimal codigoCanal) {
        try {
            StringBuilder sqlGroup = new StringBuilder(" GROUP BY EVENTO.CCANAL_DGTAL_PNEL, CANAL.ICANAL_DGTAL_PNEL ");
            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO_GERAL_CANAL_DETALHAR);
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_CANAL, codigoCanal);

            receberParametrosEventoProdutoCanal(params, periodoVisaoEvento);

            VisaoGeralCanal visaoGeralCanal = jdbcTemplate.queryForObject(sql.toString()
                + sqlGroup.toString(), params,
                new VisaoGeralCanalRowMapper());
            visaoGeralCanal
                .setListaRelacaoProdutoCanal(obterVisaoGeralRelacaoProdutoCanal(periodoVisaoEvento, codigoCanal));

            return visaoGeralCanal;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    private List<RelacaoProdutoCanal> obterVisaoGeralRelacaoProdutoCanal(Integer periodoVisaoEvento,
        BigDecimal codigoCanal) {

        try {

            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO_GERAL_RELACIONADO_CANAL_DETALHAR);
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_CANAL, codigoCanal);

            receberParametrosEventoProdutoCanal(params, periodoVisaoEvento);

            StringBuilder sqlGroup = new StringBuilder(
                " GROUP BY EVENTO.CCANAL_DGTAL_PNEL, EVENTO.CPRODT_PNEL, PRODUTO.IPRODT ");

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql.toString()
                + sqlGroup.toString(), params);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<RelacaoProdutoCanal> listaRelacaoProdutoCanal = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                RelacaoProdutoCanal relacao = new RelacaoProdutoCanal();
                relacao.setCodigoProduto((BigDecimal) mapa.get("CPRODT_PNEL"));
                relacao.setDescricaoProduto((String) mapa.get("IPRODT"));

                BigDecimal valor = (BigDecimal) mapa.get(CentralEventosDaoImpl.SOMA_EVENTO_GRAVE);
                relacao.setEventoGrave(valor.intValue());

                valor = (BigDecimal) mapa.get(CentralEventosDaoImpl.SOMA_EVENTO_MODERADO);
                relacao.setEventoModerado(valor.intValue());

                valor = (BigDecimal) mapa.get(CentralEventosDaoImpl.SOMA_TRANSACAO);
                relacao.setTransacaoImpactada(valor.intValue());

                listaRelacaoProdutoCanal.add(relacao);
            }

            return listaRelacaoProdutoCanal;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoDetalhadaProdutoCanal> obterListaEventoProdutoCanalDetalhe(Integer periodoVisaoEvento,
        BigDecimal codigoProduto, BigDecimal codigoCanal) {
        try {
            StringBuilder sql = new StringBuilder(SELECT_VISAO_EVENTO_PRODUTO_CANAL_DETALHAR);
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue("periodo", periodoVisaoEvento);
            if (codigoProduto != null) {
                sql.append(AND_EVENTO_CPRODT_PNEL_CODIGO_PRODUTO);
                params.addValue(CODIGO_PRODUTO, codigoProduto);
            } else {
                sql.append(AND_EVENTO_CCANAL_DGTAL_PNEL);
                params.addValue(CODIGO_CANAL, codigoCanal);
            }

            sql.append(
                " GROUP BY EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL ");
            sql.append(" ORDER BY PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL ");

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql.toString(), params);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<VisaoDetalhadaProdutoCanal> listaProdutoCanal = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                BigDecimal a = (BigDecimal) mapa.get("ABERTOS");
                BigDecimal f = (BigDecimal) mapa.get("FECHADOS");
                BigDecimal t = null;
                if (a != null) {
                    a.add(f);
                } else {
                    t = f;
                }
                VisaoDetalhadaProdutoCanal relacao = new VisaoDetalhadaProdutoCanal();
                relacao.setProduto((String) mapa.get("PRODUTO"));
                relacao.setCanal((String) mapa.get("CANAL"));
                relacao.setEventoGrave((BigDecimal) mapa.get(SOMA_EVENTO_GRAVE));
                relacao.setEventoModerado((BigDecimal) mapa.get(SOMA_EVENTO_MODERADO));
                relacao.setNumeroImpacto((BigDecimal) mapa.get(SOMA_TRANSACAO));
                relacao.setEventoDisponibilidade((BigDecimal) mapa.get("SOMA_EVENTO_DISP"));
                relacao.setEventoFuncional((BigDecimal) mapa.get("SOMA_EVENTO_FUNC"));
                relacao.setEventoVolumetria((BigDecimal) mapa.get("SOMA_EVENTO_VOLUMETRIA"));
                relacao.setEventoAberto(a);
                relacao.setEventoFechado(f);
                relacao.setTotal(t);
                relacao.setPeriodo((periodoVisaoEvento + " dia(s)").toString());
                listaProdutoCanal.add(relacao);
            }

            return listaProdutoCanal;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<StatusDetalheEvento> obterStatusDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal, Date dataProcessamento,
        Integer periodoTempo, Integer statusEvento) {

        try {
            StringBuilder sqlStatus = new StringBuilder(SELECT_STATUS_EVENTO_SINAL);
            StringBuilder sqlDetalhe = new StringBuilder(SELECT_STATUS_DETALHE_EVENTO);
            StringBuilder sqlEventoCount = new StringBuilder(COUNT_REGISTRO_EVENTO_DETALHE);
            StringBuilder sqlEventoList = new StringBuilder(SELECT_REGISTRO_EVENTO_DETALHE);

            MapSqlParameterSource paramsStatus = new MapSqlParameterSource();
            paramsStatus.addValue(CODIGO_PRODUTO, codigoProduto);
            paramsStatus.addValue(CODIGO_CANAL, codigoCanal);

            if (codigoErro != null) {
                sqlStatus.append("AND EVENTO.DPROCS_APLIC = :dataProc "
                    + "AND EVENTO.CERRO_CNXAO_PNEL = :codigoErro ");
                paramsStatus.addValue(CODIGO_ERRO, codigoErro);
                paramsStatus.addValue("dataProc", dataProcessamento);
            }

            sqlStatus.append("ORDER BY EVENTO.OSIT_ABERT_EVNTO ASC, EVENTO.DPROCS_APLIC DESC,  PRODUTO.IPRODT ASC, "
                + "CANAL.ICANAL_DGTAL_PNEL ASC OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY");

            List<Map<String, Object>> listaStatus = jdbcTemplate.queryForList(sqlStatus.toString(), paramsStatus);

            MapSqlParameterSource paramsQtd = new MapSqlParameterSource();
            MapSqlParameterSource paramsEvento = new MapSqlParameterSource();

            paramsQtd.addValue(CODIGO_PRODUTO, codigoProduto);
            paramsQtd.addValue(CODIGO_CANAL, codigoCanal);
            paramsQtd.addValue("periodoTempo", periodoTempo);

            if (periodoTempo == PERIODO_TEMPO_99) {
                sqlDetalhe.append(AND_DPROCS_APLIC_SYSDATE_AND_DPROCS_APLIC_SYSDATE);
            } else {
                sqlDetalhe.append(
                    " AND DVERIF_APLIC  >= SYSTIMESTAMP - :periodoTempo  AND DVERIF_APLIC <= SYSTIMESTAMP ");
            }

            sqlDetalhe.append(" GROUP BY EVENTO.CPRODT_PNEL, PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL ");
            List<Map<String, Object>> listaQtd = jdbcTemplate.queryForList(sqlDetalhe.toString(), paramsQtd);

            List<StatusDetalheEvento> listastatusEventoDetalhe = new ArrayList<>();
            StatusDetalheEvento statusEventoDetalhe = new StatusDetalheEvento();

            if (listaStatus.size() == 1) {
                statusEventoDetalhe.setDisponibilidade((BigDecimal) listaStatus.get(0).get("CSIT_DISPN"));
                statusEventoDetalhe.setFuncionalidade((BigDecimal) listaStatus.get(0).get("CSIT_FUNCL"));
                statusEventoDetalhe.setVolumetria((BigDecimal) listaStatus.get(0).get("CSIT_VOLUM"));
                statusEventoDetalhe.setNomeProduto((String) listaStatus.get(0).get("IPRODT"));
                statusEventoDetalhe.setNomeCanal((String) listaStatus.get(0).get("ICANAL_DGTAL_PNEL"));
            }

            if (listaQtd.size() == 1) {
                statusEventoDetalhe
                    .setSomaEventoGrave((BigDecimal) listaQtd.get(0).get(CentralEventosDaoImpl.SOMA_EVENTO_GRAVE));
                statusEventoDetalhe.setSomaEventoModerado(
                    (BigDecimal) listaQtd.get(0).get(CentralEventosDaoImpl.SOMA_EVENTO_MODERADO));
                statusEventoDetalhe
                    .setSomaTransacao((BigDecimal) listaQtd.get(0).get(CentralEventosDaoImpl.SOMA_TRANSACAO));
                statusEventoDetalhe.setSomaEventoDisponibilidade((BigDecimal) listaQtd.get(0).get("SOMA_EVENTO_DISP"));
                statusEventoDetalhe.setSomaEventoFuncionalidade((BigDecimal) listaQtd.get(0).get("SOMA_EVENTO_FUNC"));
                statusEventoDetalhe.setSomaEventoVolumetria((BigDecimal) listaQtd.get(0).get("SOMA_EVENTO_VOLUMETRIA"));
            }

            paramsEvento.addValue(CODIGO_PRODUTO, codigoProduto);
            paramsEvento.addValue(CODIGO_CANAL, codigoCanal);
            paramsEvento.addValue("statusEvento", statusEvento);
            paramsEvento.addValue("periodoTempo", periodoTempo);

            if (periodoTempo == PERIODO_TEMPO_99) {
                sqlEventoCount.append(AND_DPROCS_APLIC_SYSDATE_AND_DPROCS_APLIC_SYSDATE);
                sqlEventoList.append(AND_DPROCS_APLIC_SYSDATE_AND_DPROCS_APLIC_SYSDATE);
            } else {
                sqlEventoCount.append(
                    " AND EVENTO.DVERIF_APLIC  >= SYSTIMESTAMP - "
                        + ":periodoTempo  AND EVENTO.DVERIF_APLIC <= SYSTIMESTAMP ");
                sqlEventoList.append(
                    " AND EVENTO.DVERIF_APLIC  >= SYSTIMESTAMP - "
                        + ":periodoTempo  AND EVENTO.DVERIF_APLIC <= SYSTIMESTAMP ");
            }

            String groupBy = "GROUP BY  EVENTO.CERRO_CNXAO_PNEL, TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.OSIT_ABERT_EVNTO, "
                + "PRODUTO.IPRODT, CANAL.ICANAL_DGTAL_PNEL,"
                + "TIPO_EVENTO.ITPO_EVNTO_PNEL, EVENTO.QTRANS_EXECT_INSUC, RECORRENCIA_EVENTO.QSEGDA_EVNTO, "
                + " RECORRENCIA_EVENTO.QRCRRC_ERRO_EVNTO, EVENTO.DINIC_ERRO_VOLUM, "
                + "EVENTO.DINIC_ERRO_DISPN, EVENTO.CEMPR_PNEL, EVENTO.CPRODT_PNEL, EVENTO.CCANAL_DGTAL_PNEL, "
                + "SUBSTR(EVENTO.IETAPA_PRODT_CANAL,INSTR(EVENTO.IETAPA_PRODT_CANAL,'/',-1)+1), "
                + "EVENTO.EURL_CANAL_DGTAL, EVENTO.IAPI_ORIGE, EVENTO.IPLATF_CNXAO, "
                + "EVENTO.CSERVC_TRANS_PNEL, EVENTO.DINIC_ERRO_FUNCL ";

            sqlEventoList.append(groupBy);

            sqlEventoList.append(" ORDER BY DPROCS_APLIC DESC, PRODUTO.IPRODT ASC, CANAL.ICANAL_DGTAL_PNEL ASC ");

            int rowCount = jdbcTemplate.queryForObject(sqlEventoCount.toString(), paramsEvento, Integer.class);
            if (rowCount > 0) {
                List<RegistroEvento> listEventos = jdbcTemplate.queryForObject(sqlEventoList.toString(),
                    paramsEvento,
                    new ListaDetalheEventoRowMapper());

                if (!listEventos.isEmpty()) {
                    statusEventoDetalhe.setListaEvento(listEventos);
                }
            } else {
                statusEventoDetalhe.setListaEvento(new ArrayList<>());
            }

            listastatusEventoDetalhe.add(statusEventoDetalhe);

            return listastatusEventoDetalhe;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<GraficoDetalheEvento> obterGraficoDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal, Date dataProcessamento) {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();

            params.addValue(CODIGO_EMPRESA, codigoEmpresa);
            params.addValue(CODIGO_PRODUTO, codigoProduto);
            params.addValue(CODIGO_CANAL, codigoCanal);
            params.addValue("dataInicio",
                dataProcessamento.toInstant().atZone(ZoneId.of(AMERICA_SAO_PAULO)).toLocalDateTime()
                    .minusHours(Constantes.INT_4));
            params.addValue("dataFinal",
                dataProcessamento.toInstant().atZone(ZoneId.of(AMERICA_SAO_PAULO)).toLocalDateTime()
                    .plusHours(Constantes.INT_4));

            return jdbcTemplate.queryForObject(SELECT_GRAFICO_DETALHE_EVENTO, params,
                new GraficoDetalheEventoRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }

    }

    /**
     * {@inheritDoc}
     */
    public List<RelaciondosDetalheEvento> obterDetalheEventoRelacionados(Integer codigoErro, Integer limite,
        Integer linha) {

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_ERRO, codigoErro);
            params.addValue("limite", limite);
            params.addValue("linha", linha);

            return jdbcTemplate.queryForObject(SELECT_DETALHE_EVENTO_RELACIONADOS, params,
                new RelacionadosDetalheEventoRowMapper());

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public Integer obterTotalEventoRelacionados(Integer codigoErro) {

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(CODIGO_ERRO, codigoErro);

            List<Map<String, Object>> totalLista = jdbcTemplate.queryForList(SELECT_TOTAL_EVENTO_DETALHE_RELACIONADOS,
                params);
            return totalLista.size();

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoDetalhadaProdutoCanal> obterListaEventoDetalhado(Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento) {
        try {

            return new ArrayList<>();

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    private static void receberParametrosEventoProdutoCanal(MapSqlParameterSource params, Integer periodoVisaoEvento) {
        if (periodoVisaoEvento == Constantes.INT_1) {
            params.addValue(Constantes.PERIODO, Constantes.INT_1);
        } else if (periodoVisaoEvento == Constantes.INT_2) {
            params.addValue(Constantes.PERIODO, Constantes.INT_7);
        } else {
            params.addValue(Constantes.PERIODO, Constantes.INT_30);
        }
    }
}
