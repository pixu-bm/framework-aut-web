package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiAutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

@Component
public class ConsultaApiAuto {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiAuto.class);

    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    private static final int MAXIMO_CARACTERS = INT_100;
    private static final String PRODUTO = "AUTO";
    public static final int INTERVALO_DEFAULT = 16;
    public static final int INTERVALO_AUTO = 15;

    @Autowired
    private ConsultaApiAutoDao consultaApiAutoDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "SHOPPING SEGUROS"};

    private boolean status;

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;

    private String bolPropostaAuto = "/V2/PAOL-Wsat/services/BolPropostaAuto";
    private String bolCalculoAuto = "/V2/PAOL-Wsat/services/BolCalculoAuto";
    private String disqueSegurosWebService = "/V2/WSBL-IdentificadorCorretor/service/DisqueSegurosWebService";
    private String shoppingSegurosWebService = "/V2/CCRR-ServicosSinergia/service/shoppingSegurosWebService";
    private String consultaComprovanteWebService = "/V2/SHSG-Servicos/service/ConsultaComprovanteWebService";
    private String finalizacaoCompraWebService = "/V2/SHSG-Servicos/service/FinalizacaoCompraWebService";

    private String[] metodosApi = {bolPropostaAuto, bolCalculoAuto, disqueSegurosWebService, shoppingSegurosWebService,
        consultaComprovanteWebService, finalizacaoCompraWebService};

    public ConsultaApiAuto(
        ConsultaApiAutoDao consultaApiAutoDao) {
        this.consultaApiAutoDao = consultaApiAutoDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerAuto = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerAuto);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualAuto = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterAuto = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualAuto.format(formatterAuto);
            LocalDateTime dataHoraAtualAuto = LocalDateTime.parse(agoraFormatado, formatterAuto);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiAutoDao.obterultimoregistroinseridoAuto();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterAuto);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualAuto, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + bolPropostaAuto);
                HttpURLConnection connectionAuto = (HttpURLConnection) url.openConnection();
                connectionAuto.setRequestMethod("POST");
                connectionAuto.setRequestProperty("Content-Type", "application/json");
                connectionAuto.setDoOutput(true);
                connectionAuto.setInstanceFollowRedirects(false);
                connectionAuto.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{}";

                try (OutputStream os = connectionAuto.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaAutoTemp = new LinkedList<>();

                validarConexaoAutoTemp(dataHoraAtualAuto, connectionAuto, canal,
                    enderecoApi + bolPropostaAuto,
                    listaAutoTemp, enderecoApi + bolPropostaAuto);

                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanalAuto = (HttpURLConnection) urlapi.openConnection();
                    connectionCanalAuto.setRequestMethod("POST");
                    connectionCanalAuto.setRequestProperty("Content-Type", "application/json");
                    connectionCanalAuto.setDoOutput(true);
                    connectionCanalAuto.setInstanceFollowRedirects(false);
                    connectionCanalAuto.addRequestProperty("Authorization", authorization);

                    try (OutputStream os = connectionCanalAuto.getOutputStream()) {
                        byte[] inputCanal = jsonRequest.getBytes(StandardCharsets.UTF_8);
                        os.write(inputCanal, 0, inputCanal.length);
                    }

                    validarConexaoAutoTempApi(dataHoraAtualAuto, connectionCanalAuto,
                        canal, null, listaAutoTemp);

                }

                if (minutos >= INTERVALO_AUTO) {

                    consultaApiAutoDao.inserirConsultaApiAuto(listaAutoTemp);

                    consultaApiAutoDao.validarDuplicadosAuto(listaAutoTemp);

                    consultaApiAutoDao.liberarProcessamentoAuto(listaAutoTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoAutoTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaAutoTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            // Consulta Realizada com erro
            status = true;

            listaAutoTemp
                .addLast(obterAutoNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {
            // Consulta Realizada com sucesso
            status = false;

            listaAutoTemp.addLast(obterAutoOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    private void validarConexaoAutoTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaViagemTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            status = true;

            listaViagemTemp.addLast(obterAutoNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            status = false;

            listaViagemTemp.addLast(obterAutoOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public TabelaTemp obterAutoNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        status = true;
        TabelaTemp autoTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        autoTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        autoTemp.setCindRegProcs("J");
        // Codigo de retorno
        autoTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        autoTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        autoTemp.setRenderUrlOrign(enderecoApi);
        autoTemp.setRservcOrign(null);
        autoTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            autoTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            autoTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            autoTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            autoTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            autoTemp.setIapiOrign(enderecoApi);
            autoTemp.setIetapaOfert(enderecoApi);
        }

        autoTemp.setIcanalOrign(canal);
        autoTemp.setIemprOrign("BARE");
        autoTemp.setIprodtOrign(PRODUTO);
        autoTemp.setIsprodOrign(null);

        autoTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        autoTemp.setIsitEvnto("NOK");
        autoTemp.setDinicErro(dataHoraAtual);
        autoTemp.setDfimErro(null);
        autoTemp.setDinclReg(dataHoraAtual);
        autoTemp.setDaltReg(null);

        return autoTemp;
    }

    public TabelaTemp obterAutoOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp autoTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        autoTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        autoTempOk.setCindRegProcs("J");
        // Codigo de retorno
        autoTempOk.setCerroOrign("200");
        autoTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        autoTempOk.setRenderUrlOrign(enderecoApi);
        autoTempOk.setRservcOrign(null);
        autoTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            autoTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            autoTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            autoTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            autoTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            autoTempOk.setIapiOrign(enderecoApi);
            autoTempOk.setIetapaOfert(enderecoApi);
        }

        autoTempOk.setIcanalOrign(canal);
        autoTempOk.setIemprOrign("BARE");
        autoTempOk.setIprodtOrign(PRODUTO);
        autoTempOk.setIsprodOrign(null);

        autoTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        autoTempOk.setIsitEvnto("OK");
        autoTempOk.setDinicErro(dataHoraAtual);
        autoTempOk.setDfimErro(null);
        autoTempOk.setDinclReg(dataHoraAtual);
        autoTempOk.setDaltReg(null);

        return autoTempOk;
    }

    // Metodo responsavel por buscar o tempo parametrizado em milisegundos 900000
    public int buscaTempoParametrizado() {

        // Necessario implementar consulta na tabela de config de tempos para buscar os parametros
        // status = true erro identificado
        if (status) {
            return TEMPO_PARAMETRIZADO_SUCESSO;
        }

        return TEMPO_PARAMETRIZADO_ERRO;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
