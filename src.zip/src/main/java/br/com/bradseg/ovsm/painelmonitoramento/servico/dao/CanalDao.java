package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;

import java.util.List;

/**
 * Interface canal dao
 * 
 * @author Wipro
 */
public interface CanalDao {

    /**
     * Listar canal
     * 
     * @return
     */
    List<Canal> listarCanal();
}
