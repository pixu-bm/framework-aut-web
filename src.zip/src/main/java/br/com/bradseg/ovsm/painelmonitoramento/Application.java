package br.com.bradseg.ovsm.painelmonitoramento;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Paineis OV Serviços API", version = "1.0",
    description = "API de suporte, serviços e consulta" +
        " para paineis de monitoramento OV Bradesco Seguros"))
public class Application {

    private static final Log LOGGER = LogFactory.getLog(Application.class);

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        LOGGER.debug("Iniciando a aplicacao ...");
        SpringApplication.run(Application.class);
    }

    @PostConstruct
    public void init() {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }

}
