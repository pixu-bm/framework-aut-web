package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Wipro
 */
public class VolumetriaTempoRealTransacaoEventoRowMapper
    implements RowMapper<List<VolumetriaTempoRealTransacaoEvento>> {

    public List<VolumetriaTempoRealTransacaoEvento> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<VolumetriaTempoRealTransacaoEvento> listaVolumetriaTempoRealTransacaoEvento = new ArrayList<>();
        do {
            VolumetriaTempoRealTransacaoEvento volumetriaTempoReal = new VolumetriaTempoRealTransacaoEvento();
            volumetriaTempoReal.setCodigoCanal(new BigDecimal(rowNum));
            volumetriaTempoReal.setCodigoCanal(rs.getBigDecimal("CCANAL_DGTAL_PNEL"));
            volumetriaTempoReal.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
            volumetriaTempoReal.setVolumeTransacao(rs.getBigDecimal("VOLUME_TRANSACAO"));
            volumetriaTempoReal.setVolumeImpactado(rs.getBigDecimal("VOLUME_IMPACTADO"));
            volumetriaTempoReal.setQuantidadeEventoDisponibilidade(rs.getBigDecimal("EVNTO_NORML_DISPN"));
            volumetriaTempoReal.setQuantidadeEventoFuncionalidade(rs.getBigDecimal("EVNTO_NORML_FUNC"));
            volumetriaTempoReal.setQuantidadeEventoTransacao(rs.getBigDecimal("EVNTO_NORML_CNXAO"));
            volumetriaTempoReal.setSomaEventoGrave(rs.getBigDecimal("SOMA_EVENTO_GRAVE"));
            volumetriaTempoReal.setSomaTotalEvento(rs.getBigDecimal("SOMA_TOTAL_EVENTO"));
            volumetriaTempoReal.setSomaDuracaoEvento(rs.getBigDecimal("SOMA_DURACAO_EVENTO"));

            listaVolumetriaTempoRealTransacaoEvento.add(volumetriaTempoReal);
        } while (rs.next());

        return listaVolumetriaTempoRealTransacaoEvento;
    }

}
