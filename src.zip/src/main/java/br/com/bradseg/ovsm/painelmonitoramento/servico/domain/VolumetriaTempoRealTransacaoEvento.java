package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Volumetria em tempo real eventos e transações para construção de grid
 * informativa a consulta paineis OV
 * 
 * @author Wipro
 */
public class VolumetriaTempoRealTransacaoEvento {

    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private BigDecimal volumeTransacao;
    private BigDecimal volumeImpactado;
    private BigDecimal quantidadeEventoDisponibilidade;
    private BigDecimal quantidadeEventoFuncionalidade;
    private BigDecimal quantidadeEventoTransacao;
    private BigDecimal somaEventoGrave;
    private BigDecimal somaTotalEvento;
    private BigDecimal somaDuracaoEvento;

    public VolumetriaTempoRealTransacaoEvento() {
        super();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public BigDecimal getVolumeTransacao() {
        return volumeTransacao;
    }

    public void setVolumeTransacao(BigDecimal volumeTransacao) {
        this.volumeTransacao = volumeTransacao;
    }

    public BigDecimal getVolumeImpactado() {
        return volumeImpactado;
    }

    public void setVolumeImpactado(BigDecimal volumeImpactado) {
        this.volumeImpactado = volumeImpactado;
    }

    public BigDecimal getQuantidadeEventoDisponibilidade() {
        return quantidadeEventoDisponibilidade;
    }

    public void setQuantidadeEventoDisponibilidade(BigDecimal quantidadeEventoDisponibilidade) {
        this.quantidadeEventoDisponibilidade = quantidadeEventoDisponibilidade;
    }

    public BigDecimal getQuantidadeEventoFuncionalidade() {
        return quantidadeEventoFuncionalidade;
    }

    public void setQuantidadeEventoFuncionalidade(BigDecimal quantidadeEventoFuncionalidade) {
        this.quantidadeEventoFuncionalidade = quantidadeEventoFuncionalidade;
    }

    public BigDecimal getQuantidadeEventoTransacao() {
        return quantidadeEventoTransacao;
    }

    public void setQuantidadeEventoTransacao(BigDecimal quantidadeEventoTransacao) {
        this.quantidadeEventoTransacao = quantidadeEventoTransacao;
    }

    public BigDecimal getSomaEventoGrave() {
        return somaEventoGrave;
    }

    public void setSomaEventoGrave(BigDecimal somaEventoGrave) {
        this.somaEventoGrave = somaEventoGrave;
    }

    public BigDecimal getSomaTotalEvento() {
        return somaTotalEvento;
    }

    public void setSomaTotalEvento(BigDecimal somaTotalEvento) {
        this.somaTotalEvento = somaTotalEvento;
    }

    public BigDecimal getSomaDuracaoEvento() {
        return somaDuracaoEvento;
    }

    public void setSomaDuracaoEvento(BigDecimal somaDuracaoEvento) {
        this.somaDuracaoEvento = somaDuracaoEvento;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

}
