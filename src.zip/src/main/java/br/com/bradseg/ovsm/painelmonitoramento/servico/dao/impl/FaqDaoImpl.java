package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.FaqDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Repository
public class FaqDaoImpl implements FaqDao {

    private static final Logger LOGGER = LogManager.getLogger(FaqDaoImpl.class);

    private static final String RESULTADO_VAZIO = "Resultado não pode ser vazio";

    private static final String AINIC_PUBL = "AINIC_PUBL";

    private static final String PERGUNTA = "pergunta";

    private static final String COD_SEQ = "codSeq";

    private static final String SELECT = "SELECT "
        + "    T.CFAQ, "
        + "    T.AINIC_PUBL, "
        + "    T.NPRIOR_VSLAO, "
        + "    T.RPGNTA, "
        + "    T.RRESPT, "
        + "    T.DINCL_REG, "
        + "    T.RENDER_IMAGE "
        + " FROM "
        + "    OVSM.FAQ_PNEL T "
        + " WHERE T.AFIM_PUBL IS NULL";

    private static final String AND_PERGUNTA = " AND LOWER(T.RPGNTA) LIKE :pergunta ";

    private static final String ORDER_BY = " ORDER BY T.NPRIOR_VSLAO DESC ";

    private static final String EDITAR = "INSERT INTO "
        + " OVSM.FAQ_PNEL T (T.CFAQ, "
        + " T.AINIC_PUBL, "
        + " T.RPGNTA, "
        + " T.RRESPT, "
        + " T.NPRIOR_VSLAO, "
        + " T.NUSUAR, "
        + " T.DINCL_REG, "
        + " T.RENDER_IMAGE) "
        + " VALUES "
        + " (:codSeq, "
        + " SYSTIMESTAMP, "
        + " :pergunta, "
        + " :resposta, "
        + " :prioridade, "
        + " (SELECT u.NUSUAR FROM USUAR u WHERE u.CUSUAR = :login), "
        + " SYSDATE, "
        + " :imagem)";

    private static final String SALVAR = "INSERT INTO "
        + " OVSM.FAQ_PNEL T (T.CFAQ, "
        + " T.AINIC_PUBL, "
        + " T.RPGNTA, "
        + " T.RRESPT, "
        + " T.NPRIOR_VSLAO, "
        + " T.NUSUAR, "
        + " T.DINCL_REG, "
        + " T.RENDER_IMAGE) "
        + " VALUES "
        + " ((SELECT fp.CFAQ FROM FAQ_PNEL fp  ORDER BY fp.CFAQ DESC OFFSET 0 ROWS FETCH FIRST 1 ROWS ONLY) + 1, "
        + " SYSTIMESTAMP, "
        + " :pergunta, "
        + " :resposta, "
        + " :prioridade, "
        + " (SELECT u.NUSUAR FROM USUAR u WHERE u.CUSUAR = :login), "
        + " SYSDATE, "
        + " :imagem)";

    private static final String EXCLUIR = " UPDATE OVSM.FAQ_PNEL T "
        + " SET T.AFIM_PUBL = SYSTIMESTAMP "
        + " WHERE T.CFAQ = :codSeq"
        + " AND T.AINIC_PUBL = :codData";

    private static final String PRE_EDIT = "SELECT "
        + " fp.CFAQ, fp.AINIC_PUBL "
        + " FROM FAQ_PNEL fp "
        + " WHERE fp.CFAQ = :codSeq "
        + " ORDER BY fp.AINIC_PUBL DESC "
        + " OFFSET 0 ROWS FETCH FIRST 1 ROWS ONLY";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public FaqDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Faq> listarPerguntasFaq() {

        try {
            StringBuilder sql = new StringBuilder(SELECT);
            sql.append(ORDER_BY);
            List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql.toString(), new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<Faq> listaFaqCarregar = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Faq faqCarregar = new Faq();
                faqCarregar.setCod((BigDecimal) mapa.get("CFAQ"));
                faqCarregar.setData(((Timestamp) mapa.get(AINIC_PUBL)).toString());
                faqCarregar.setPrioridade((BigDecimal) mapa.get("NPRIOR_VSLAO"));
                faqCarregar.setPergunta((String) mapa.get("RPGNTA"));
                faqCarregar.setResposta((String) mapa.get("RRESPT"));
                faqCarregar.setDataCriacao((Date) mapa.get("DINCL_REG"));
                faqCarregar.setImagem((String) mapa.get("RENDER_IMAGE"));

                listaFaqCarregar.add(faqCarregar);
            }

            return listaFaqCarregar;

        } catch (EmptyResultDataAccessException eCarregar) {
            LOGGER.error(eCarregar);
            throw new AcessoADadosException(eCarregar.getMessage());
        } catch (AcessoADadosException eCarregar) {
            LOGGER.error(eCarregar);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    @Override
    public List<Faq> pesquisar(String pergunta) {
        try {
            StringBuilder sql = new StringBuilder(SELECT);
            sql.append(AND_PERGUNTA);
            sql.append(ORDER_BY);

            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue(PERGUNTA, "%" + pergunta.toLowerCase() + "%");

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(sql.toString(), param);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<Faq> listaFaq = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Faq faq = new Faq();
                faq.setCod((BigDecimal) mapa.get("CFAQ"));
                faq.setData(((Timestamp) mapa.get(AINIC_PUBL)).toString());
                faq.setPrioridade((BigDecimal) mapa.get("NPRIOR_VSLAO"));
                faq.setPergunta((String) mapa.get("RPGNTA"));
                faq.setResposta((String) mapa.get("RRESPT"));
                faq.setDataCriacao((Date) mapa.get("DINCL_REG"));
                faq.setImagem((String) mapa.get("RENDER_IMAGE"));

                listaFaq.add(faq);
            }

            return listaFaq;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void editar(BigDecimal codSeq, String pergunta, String resposta, Float prioridade, String imagem,
        String login) {
        try {

            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue(COD_SEQ, codSeq);

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(PRE_EDIT, param);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(RESULTADO_VAZIO, 1);
            }

            List<Faq> listaFaq = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Faq faq = new Faq();
                faq.setCod((BigDecimal) mapa.get("CFAQ"));
                faq.setData(((Timestamp) mapa.get(AINIC_PUBL)).toString());
                listaFaq.add(faq);
            }

            excluir(listaFaq.get(0).getCod(), listaFaq.get(0).getData());

            param = new MapSqlParameterSource();
            param.addValue(COD_SEQ, codSeq.intValue());
            param.addValue(PERGUNTA, pergunta);
            param.addValue("resposta", resposta);
            param.addValue("prioridade", prioridade);
            param.addValue("login", login);
            param.addValue("imagem", imagem);

            jdbcTemplate.update(EDITAR, param);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void salvar(String pergunta, String resposta, Float prioridade, String imagem, String login) {
        try {

            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue(PERGUNTA, pergunta);
            param.addValue("resposta", resposta);
            param.addValue("prioridade", prioridade);
            param.addValue("login", login);
            param.addValue("imagem", imagem);

            jdbcTemplate.update(SALVAR, param);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void excluir(BigDecimal codSeq, String codData) {
        try {
            Timestamp ts = Timestamp.valueOf(codData);
            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue(COD_SEQ, codSeq);
            param.addValue("codData", ts);

            jdbcTemplate.update(EXCLUIR, param);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
