package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Classe responsável por informaçoes dos comentários
 *
 * @author Wipro
 *
 */

public class ComentarioRequest {

    private BigDecimal codigoEmpresa;
    private BigDecimal codigoProduto;
    private BigDecimal codigoCanal;
    private Date dataInclusao;
    private Date dataProcs;
    private BigDecimal codigoErroConexaoPainel;
    private String comentario;
    private String login;

    public ComentarioRequest() {
        super();
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public Date getDataProcs() {
        if (dataProcs != null) {
            return (Date) dataProcs.clone();
        }
        return null;
    }

    public void setDataProcs(Date dataProcs) {
        this.dataProcs = (Date) dataProcs.clone();
    }

    public Date getDataInclusao() {
        if (dataInclusao != null) {
            return (Date) dataInclusao.clone();
        }
        return null;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = (Date) dataInclusao.clone();
    }

    public BigDecimal getCodigoErroConexaoPainel() {
        return codigoErroConexaoPainel;
    }

    public void setCodigoErroConexaoPainel(BigDecimal codigoErroConexaoPainel) {
        this.codigoErroConexaoPainel = codigoErroConexaoPainel;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

}
