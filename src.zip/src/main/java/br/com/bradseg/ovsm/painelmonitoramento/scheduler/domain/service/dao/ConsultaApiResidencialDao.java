package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

public interface ConsultaApiResidencialDao {

    String obterultimoregistroinserido();

    void liberarProcessamentoResidencial(Collection<?> listaResidencialTemp);

    void validarDuplicadosResidencial(Collection<?> listaResidencialTemp);

    void inserirConsultaApiResidencial(List<TabelaTemp> listaResidencialTemp) throws SQLException;
}
