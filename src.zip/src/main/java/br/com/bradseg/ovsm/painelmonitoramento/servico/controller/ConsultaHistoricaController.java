package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConsultaHistoricaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/service/consultaHistorica")
public class ConsultaHistoricaController {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaHistoricaController.class);

    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final String INLINE_FILENAME_CONSULTA_HISTORICA_XLSX = "inline;filename=\"consultaHistorica.xlsx\"";
    public static final String INLINE_FILENAME_CONSULTA_HISTORICA_PDF = "inline;filename=\"consultaHistorica.pdf\"";
    public static final String INLINE_FILENAME_CONSULTA_HISTORICA_CSV = "inline;filename=\"consultaHistorica.csv\"";
    private static final String MSG_NENHUM_DADO_ENCONTRADO = "Nenhum dado encontrado";
    

    @Autowired
    private ConsultaHistoricaService consultaHistoricaService;

    public ConsultaHistoricaController() {
        super();
    }

    @GetMapping("/consultaHistoricoExcel")
    @Operation(summary = "Obtem Excel consulta historico.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno"),
        @ApiResponse(responseCode = "404", description = "Nenhum registro encontrado")})
    public ResponseEntity<StreamingResponseBody> obterExcelConsultaHistorica(
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "listaTipoEvento", required = false) List<BigDecimal> listaTipoEvento,
        @RequestParam(name = "freqMin", required = false) String freqMin,
        @RequestParam(name = "freqMax", required = false) String freqMax,
        @RequestParam(name = "duracaoMin", required = false) String duracaoMin,
        @RequestParam(name = "duracaoMax", required = false) String duracaoMax,
        @RequestParam(name = "transacaoMin", required = false) String transacaoMin,
        @RequestParam(name = "transacaoMax", required = false) String transacaoMax,
        @RequestParam(name = "nomeServico", required = false) String nomeServico,
        @RequestParam(name = "dataInicio", required = false) String dataInicio,
        @RequestParam(name = "dataFim", required = false) String dataFim,
        @RequestParam(name = "login", required = false) String login) {

        try {
            Workbook wb = consultaHistoricaService
                .exportarExcel(listaCodigoProduto, listaCodigoCanal, listaTipoEvento,
                    freqMin, freqMax, duracaoMin, duracaoMax,
                    transacaoMin, transacaoMax, nomeServico,
                    dataInicio,
                    dataFim, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_CONSULTA_HISTORICA_XLSX)
                .body(wb::write);

        } catch (SQLException eConsulta) {
            ResponseMensagem msgConsulta = new ResponseMensagem();
            msgConsulta.setCodigoRetorno(CODIGO_RETORNO_2);
            msgConsulta.setMensagem(eConsulta.getMessage());
            LOGGER.error(eConsulta);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                msgConsulta.getMensagem() + ";" + CODIGO_RETORNO_2, eConsulta);

        } catch (IllegalArgumentException eConsulta) {
            ResponseMensagem msgIllegalArgumentExceptionConsulta = new ResponseMensagem();
            msgIllegalArgumentExceptionConsulta.setCodigoRetorno(CODIGO_RETORNO_1);
            msgIllegalArgumentExceptionConsulta.setMensagem(eConsulta.getMessage());
            LOGGER.error(eConsulta);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                msgIllegalArgumentExceptionConsulta.getMensagem() + ";" + CODIGO_RETORNO_1, eConsulta);

        } catch (EmptyResultDataAccessException eConsulta) {
            ResponseMensagem msgEmptyResultDataAccessExceptionConsulta = new ResponseMensagem();
            msgEmptyResultDataAccessExceptionConsulta.setCodigoRetorno(CODIGO_RETORNO_1);
            msgEmptyResultDataAccessExceptionConsulta.setMensagem(eConsulta.getMessage());
            LOGGER.error(eConsulta);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, MSG_NENHUM_DADO_ENCONTRADO);
        }
    }
    
    @GetMapping("/consultaHistoricoExcelPdf")
    @Operation(summary = "Obtem PDF Consulta historico.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno"),
        @ApiResponse(responseCode = "404", description = "Nenhum registro encontrado")})
    public ResponseEntity<InputStreamResource> obterPdfConsultaHistorica(
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @Parameter(description = "Tipo evento recebe um lista que aceita os seguintes valores, "
            + "1 = Funcionalidade, 2 = volumetria e 3 = Disponibilidade")
        @RequestParam(name = "listaTipoEvento", required = false) List<BigDecimal> listaTipoEvento,
        @RequestParam(name = "freqMin", required = false) String freqMin,
        @RequestParam(name = "freqMax", required = false) String freqMax,
        @RequestParam(name = "duracaoMin", required = false) String duracaoMin,
        @RequestParam(name = "duracaoMax", required = false) String duracaoMax,
        @RequestParam(name = "transacaoMin", required = false) String transacaoMin,
        @RequestParam(name = "transacaoMax", required = false) String transacaoMax,
        @RequestParam(name = "nomeServico", required = false) String nomeServico,
        @RequestParam(name = "dataInicio", required = false) String dataInicio,
        @RequestParam(name = "dataFim", required = false) String dataFim,
        @RequestParam(name = "login", required = true) String login) {

        try {
            ByteArrayInputStream doc = consultaHistoricaService
                .exportarPdf(listaCodigoProduto, listaCodigoCanal, listaTipoEvento,
                    freqMin, freqMax, duracaoMin, duracaoMax,
                    transacaoMin, transacaoMax, nomeServico,
                    dataInicio,
                    dataFim, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                  INLINE_FILENAME_CONSULTA_HISTORICA_PDF)
                .body(new InputStreamResource(doc));

        } catch (SQLException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagem.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegal = new ResponseMensagem();
            mensagemIllegal.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegal.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegal.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmpty = new ResponseMensagem();
            mensagemEmpty.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemEmpty.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, MSG_NENHUM_DADO_ENCONTRADO);
        }
    }

    @GetMapping("/consultaHistoricoCsv")
    @Operation(summary = "Obtem Csv consulta historico.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno"),
        @ApiResponse(responseCode = "404", description = "Nenhum registro encontrado")})
    public ResponseEntity<StreamingResponseBody> obterCsvConsultaHistorica(
        @RequestParam(name = "listaCodigoProduto", required = false) List<BigDecimal> listaCodigoProduto,
        @RequestParam(name = "listaCodigoCanal", required = false) List<BigDecimal> listaCodigoCanal,
        @RequestParam(name = "listaTipoEvento", required = false) List<BigDecimal> listaTipoEvento,
        @RequestParam(name = "freqMin", required = false) String freqMin,
        @RequestParam(name = "freqMax", required = false) String freqMax,
        @RequestParam(name = "duracaoMin", required = false) String duracaoMin,
        @RequestParam(name = "duracaoMax", required = false) String duracaoMax,
        @RequestParam(name = "transacaoMin", required = false) String transacaoMin,
        @RequestParam(name = "transacaoMax", required = false) String transacaoMax,
        @RequestParam(name = "nomeServico", required = false) String nomeServico,
        @RequestParam(name = "dataInicio", required = false) String dataInicio,
        @RequestParam(name = "dataFim", required = false) String dataFim,
        @RequestParam(name = "login", required = false) String login) {

        try {
            Workbook wb = consultaHistoricaService
                .exportarExcel(listaCodigoProduto, listaCodigoCanal, listaTipoEvento,
                    freqMin, freqMax, duracaoMin, duracaoMax,
                    transacaoMin, transacaoMax, nomeServico,
                    dataInicio,
                    dataFim, login);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, INLINE_FILENAME_CONSULTA_HISTORICA_CSV)
                .body(wb::write);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQL = new ResponseMensagem();
            mensagemSQL.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQL.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQL.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgument = new ResponseMensagem();
            mensagemIllegalArgument.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgument.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgument.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemIllegalArgument = new ResponseMensagem();
            mensagemIllegalArgument.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgument.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, MSG_NENHUM_DADO_ENCONTRADO);
        }
    }
}
