package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * Status Detalhe Evento
 * 
 * @author Wipro
 */
public class StatusDetalheEvento {
    private BigDecimal disponibilidade;
    private BigDecimal funcionalidade;
    private BigDecimal volumetria;
    private BigDecimal somaEventoGrave;
    private BigDecimal somaEventoModerado;
    private BigDecimal somaTransacao;
    private BigDecimal somaEventoDisponibilidade;
    private BigDecimal somaEventoFuncionalidade;
    private BigDecimal somaEventoVolumetria;
    private String nomeProduto;
    private String nomeCanal;
    private List<RegistroEvento> listaEvento;

    public StatusDetalheEvento() {
        super();
    }

    public List<RegistroEvento> getListaEvento() {
        return Collections.unmodifiableList(listaEvento);
    }

    public void setListaEvento(List<RegistroEvento> listaEvento) {
        this.listaEvento = Collections.unmodifiableList(listaEvento);
    }

    public BigDecimal getSomaEventoFuncionalidade() {
        return somaEventoFuncionalidade;
    }

    public void setSomaEventoFuncionalidade(BigDecimal somaEventoFuncionalidade) {
        this.somaEventoFuncionalidade = somaEventoFuncionalidade;
    }

    public BigDecimal getSomaTransacao() {
        return somaTransacao;
    }

    public void setSomaTransacao(BigDecimal somaTransacao) {
        this.somaTransacao = somaTransacao;
    }

    public String getNomeCanal() {
        return nomeCanal;
    }

    public void setNomeCanal(String nomeCanal) {
        this.nomeCanal = nomeCanal;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public BigDecimal getSomaEventoVolumetria() {
        return somaEventoVolumetria;
    }

    public void setSomaEventoVolumetria(BigDecimal somaEventoVolumetria) {
        this.somaEventoVolumetria = somaEventoVolumetria;
    }

    public BigDecimal getSomaEventoDisponibilidade() {
        return somaEventoDisponibilidade;
    }

    public void setSomaEventoDisponibilidade(BigDecimal somaEventoDisponibilidade) {
        this.somaEventoDisponibilidade = somaEventoDisponibilidade;
    }

    public BigDecimal getSomaEventoModerado() {
        return somaEventoModerado;
    }

    public void setSomaEventoModerado(BigDecimal somaEventoModerado) {
        this.somaEventoModerado = somaEventoModerado;
    }

    public BigDecimal getSomaEventoGrave() {
        return somaEventoGrave;
    }

    public void setSomaEventoGrave(BigDecimal somaEventoGrave) {
        this.somaEventoGrave = somaEventoGrave;
    }

    public BigDecimal getVolumetria() {
        return volumetria;
    }

    public void setVolumetria(BigDecimal volumetria) {
        this.volumetria = volumetria;
    }

    public BigDecimal getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(BigDecimal disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public BigDecimal getFuncionalidade() {
        return funcionalidade;
    }

    public void setFuncionalidade(BigDecimal funcionalidade) {
        this.funcionalidade = funcionalidade;
    }
}
