/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Classe responsável por trafegar dados e contruir canal painel monitoramento
 * atual do sistema OV
 * 
 * @author Wipro
 *
 */
public class CanalPainelMonitoramentoAtual {

    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private Date dataInicioRegitro;
    private Date dataAlteracaoRegistro;
    private List<EventoPainelMonitoramentoAtual> listaEvento;

    public CanalPainelMonitoramentoAtual() {
        super();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public Date getDataAlteracaoRegistro() {
        if (dataAlteracaoRegistro != null) {
            return (Date) dataAlteracaoRegistro.clone();
        }
        return null;
    }

    public void setDataAlteracaoRegistro(Date dataAlteracaoRegistro) {
        this.dataAlteracaoRegistro = (Date) dataAlteracaoRegistro.clone();
    }

    public Date getDataInicioRegitro() {
        if (dataInicioRegitro != null) {
            return (Date) dataInicioRegitro.clone();
        }
        return null;
    }

    public void setDataInicioRegitro(Date dataInicioRegitro) {
        this.dataInicioRegitro = (Date) dataInicioRegitro.clone();
    }

    public List<EventoPainelMonitoramentoAtual> getListaEvento() {
        if (listaEvento != null) {
            return new ArrayList<>(listaEvento);
        }
        return Collections.emptyList();
    }

    public void setListaEvento(List<EventoPainelMonitoramentoAtual> listaEvento) {
        this.listaEvento = new ArrayList<>(listaEvento);
    }

}
