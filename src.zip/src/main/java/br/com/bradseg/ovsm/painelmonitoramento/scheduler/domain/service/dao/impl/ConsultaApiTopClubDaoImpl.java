package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiTopClubDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.rowmapper.ConsultaApiCaptalizacaoRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Repository
public class ConsultaApiTopClubDaoImpl implements ConsultaApiTopClubDao {

    private static final Logger LOGGER = LogManager.getLogger(ConsultaApiTopClubDaoImpl.class);
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String ERRO_INTERNO = "Erro interno";

    private static final String VALIDAR_REGISTROS_DUPLICADOS_TOPCLUB = "DELETE FROM " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP A WHERE ROWID > (SELECT MIN(ROWID)FROM DWMF.TEMPR_SAUDE C "
        + "WHERE A.RTRANS_ORIGN = C.RTRANS_ORIGN "
        + "AND A.ICANAL_ORIGN = C.ICANAL_ORIGN "
        + "AND REPLACE(A.IAPI_ORIGN, NULL, '1') = REPLACE(C.IAPI_ORIGN, NULL, '1')"
        + "AND C.CIND_REG_PROCS = 'J')"
        + "AND A.CIND_REG_PROCS = 'J'";

    private static final String INSERIR_CONSULTA_TOPCLUB = "INSERT INTO " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP (CORIGE_DADO, CIND_REG_PROCS, CERRO_ORIGN, "
        + "RMSGEM_ERRO_ORIGN, RENDER_URL_ORIGN, RSERVC_ORIGN, ITRANS_ORIGN, "
        + "RTRANS_ORIGN, IAPI_ORIGN, ICANAL_ORIGN, IEMPR_ORIGN, IPRODT_ORIGN, "
        + "ISPROD_ORIGN, IETAPA_OFERT, IPLATF_ORIGN, ISIT_EVNTO, DINIC_ERRO, "
        + "DFIM_ERRO, DINCL_REG, DALT_REG)"
        + " VALUES(:CORIGE_DADO, :CIND_REG_PROCS, :CERRO_ORIGN, :RMSGEM_ERRO_ORIGN, :RENDER_URL_ORIGN,"
        + " :RSERVC_ORIGN, :ITRANS_ORIGN, :RTRANS_ORIGN, :IAPI_ORIGN, :ICANAL_ORIGN, :IEMPR_ORIGN,"
        + " :IPRODT_ORIGN, :ISPROD_ORIGN, :IETAPA_OFERT, :IPLATF_ORIGN, :ISIT_EVNTO, :DINIC_ERRO,"
        + " :DFIM_ERRO, :DINCL_REG, :DALT_REG)";

    private static final String LIBERAR_PROCESSAMENTO_TOPCLUB = "UPDATE " + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "SET CIND_REG_PROCS='L' "
        + "WHERE CIND_REG_PROCS = 'J' "
        + "AND IPRODT_ORIGN = 'VIDA' ";

    private static final String SELECT_MAX_REGISTRO_TOPCLUB = "SELECT MAX(DINCL_REG) AS DINCL_REG FROM "
        + Constantes.OWNER_TABELA_DWMF
        + "TEMPR_BVP "
        + "WHERE IPRODT_ORIGN = 'VIDA' ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public ConsultaApiTopClubDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public String obterultimoregistroinseridoTopClub() {
        try {
            return jdbcTemplate.queryForObject(SELECT_MAX_REGISTRO_TOPCLUB, new MapSqlParameterSource(),
                new ConsultaApiCaptalizacaoRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return null;
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException("PROBLEMA_DE_ACESSO_AOS_DADOS");
        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void liberarProcessamentoTopClub(Collection<?> listaTopClubTemp) {

        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaTopClubTemp.size());

            jdbcTemplate.batchUpdate(LIBERAR_PROCESSAMENTO_TOPCLUB,
                batchValues.toArray(new Map[listaTopClubTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void validarDuplicadosTopClub(Collection<?> listaTopCLubTemp) {
        try {

            List<Map<String, Object>> batchValues = new ArrayList<>(listaTopCLubTemp.size());

            jdbcTemplate.batchUpdate(VALIDAR_REGISTROS_DUPLICADOS_TOPCLUB,
                batchValues.toArray(new Map[listaTopCLubTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);

        }

    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void inserirConsultaApiTopClub(List<TabelaTemp> listaTopClubTemp) throws SQLException {
        try {
            List<Map<String, Object>> batchValues = new ArrayList<>(listaTopClubTemp.size());

            for (TabelaTemp topClubTemp : listaTopClubTemp) {
                batchValues.add(

                    new MapSqlParameterSource("CORIGE_DADO", topClubTemp.getcorrigeDado())
                        .addValue("CIND_REG_PROCS", topClubTemp.getCindRegProcs())
                        .addValue("CERRO_ORIGN", topClubTemp.getCerroOrign())
                        .addValue("RMSGEM_ERRO_ORIGN", topClubTemp.getRmsgemErroOrign())
                        .addValue("RENDER_URL_ORIGN", topClubTemp.getRenderUrlOrign())
                        .addValue("RSERVC_ORIGN", topClubTemp.getRservcOrign())
                        .addValue("ITRANS_ORIGN", topClubTemp.getItransOrign())
                        .addValue("RTRANS_ORIGN", topClubTemp.getRtransOrign())
                        .addValue("IAPI_ORIGN", topClubTemp.getIapiOrign())
                        .addValue("ICANAL_ORIGN", topClubTemp.getIcanalOrign())
                        .addValue("IEMPR_ORIGN", topClubTemp.getIemprOrign())
                        .addValue("IPRODT_ORIGN", topClubTemp.getIprodtOrign())
                        .addValue("ISPROD_ORIGN", topClubTemp.getIsprodOrign())
                        .addValue("IETAPA_OFERT", topClubTemp.getIetapaOfert())
                        .addValue("IPLATF_ORIGN", topClubTemp.getIplatfOrign())
                        .addValue("ISIT_EVNTO", topClubTemp.getIsitEvnto())
                        .addValue("DINIC_ERRO", topClubTemp.getDinicErro())
                        .addValue("DFIM_ERRO", topClubTemp.getDfimErro())
                        .addValue("DINCL_REG", topClubTemp.getDinclReg())
                        .addValue("DALT_REG", topClubTemp.getDaltReg())
                        .getValues());
            }

            jdbcTemplate.batchUpdate(INSERIR_CONSULTA_TOPCLUB,
                batchValues.toArray(new Map[listaTopClubTemp.size()]));

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(ERRO_INTERNO);
        }

    }

}
