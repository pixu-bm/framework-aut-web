package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

public interface IndicadorNegocioService {

    void validarParametro(Integer periodo);

    void validarParametrosDatas(String dataInicio, String dataFim);

    void validarParametroRanking(Integer codigoPesquisa);

    VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException;

    List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    List<VolumetriaVisaoNegocio> obterVolumetriaVisaoNegocio(Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, Date dataInicio, Date dataFim);

    IndicadoresNegocio obterIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    List<ComboRankingEventos> obterRankingEventos(Integer codigoPesquisa, Date dataInicio,
        Date dataFim);

    NumeroTransacoes obterNumeroTransacao(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    List<EventoPorCanal> obterEventoPorCanal(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    TipoEvento obterTipoEvento(Integer periodo, List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim) throws SQLException;

}
