package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;

/**
 * Service para empresa
 * 
 * @author Wipro
 */
public interface EmpresaService {

    /**
     * Obter EMpresa
     * 
     * @return List<Empresa>
     */
    List<Empresa> obterEmpresas();
}
