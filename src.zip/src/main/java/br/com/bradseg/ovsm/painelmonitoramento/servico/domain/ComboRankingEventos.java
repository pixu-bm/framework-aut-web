package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

public class ComboRankingEventos {
    private String descricaoProduto;
    private String descricaoCanal;
    private BigDecimal duracao;
    private BigDecimal impacto;
    private BigDecimal recorrencia;
    
    public ComboRankingEventos() {
        super();
    }
    
    public String getDescricaoProduto() {
        return descricaoProduto;
    }
    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }
    public String getDescricaoCanal() {
        return descricaoCanal;
    }
    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }
    public BigDecimal getDuracao() {
        return duracao;
    }
    public void setDuracao(BigDecimal duracao) {
        this.duracao = duracao;
    }
    public BigDecimal getImpacto() {
        return impacto;
    }
    public void setImpacto(BigDecimal impacto) {
        this.impacto = impacto;
    }
    public BigDecimal getRecorrencia() {
        return recorrencia;
    }
    public void setRecorrencia(BigDecimal recorrencia) {
        this.recorrencia = recorrencia;
    }  

}
