package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ComboRankingEventos;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.NumeroTransacoes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

public interface IndicadorNegocioDao {

    VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException;

    List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException;

    List<VolumetriaVisaoNegocio> obterVolumetriaVisaoNegocio(Integer periodo,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, Date dataInicio, Date dataFim)
        throws SQLException;

    IndicadoresNegocio obterIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    IndicadoresNegocio obterIndicadoresNegocioComparacao(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    List<ComboRankingEventos> obterRankingEventos(Integer codigoPesquisa, Date dataInicio, Date dataFim)
        throws SQLException;

    NumeroTransacoes obterNumeroTransacao(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    List<EventoPorCanal> obterListaEventoCanal(Integer periodo, List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim) throws SQLException;

    TipoEvento obterTipoEvento(Integer periodo, List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        String dataInicio, String dataFim) throws SQLException;

    List<ComboRankingEventos> relatorioRankingEventos(Integer codigoPesquisa, Date dataInicio, Date dataFim)
        throws SQLException;

    List<IndicadoresNegocio> relatorioIndicadoresNegocio(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim);

    List<IndicadoresNegocio> relatorioIndicadoresNegocioComparacao(
        List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim);

    List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempoRelatorio(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String dataInicio, String dataFim)
        throws SQLException;
}
