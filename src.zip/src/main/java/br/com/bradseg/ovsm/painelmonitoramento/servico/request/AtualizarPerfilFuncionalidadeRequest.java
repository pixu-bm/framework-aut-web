package br.com.bradseg.ovsm.painelmonitoramento.servico.request;

import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;

/**
 * Classe de request de serviço para atualizar perfil funcionalidade 
 * request
 * @author Wipro
 */
public class AtualizarPerfilFuncionalidadeRequest {


    private String login;
    private String perfil;
    private List<Funcionalidade> listaFuncionalidade;

    /**
     * Construtor
     */
    public AtualizarPerfilFuncionalidadeRequest() {
        super();
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public List<Funcionalidade> getListaFuncionalidade() {
        return listaFuncionalidade;
    }

    public void setListaFuncionalidade(List<Funcionalidade> listaFuncionalidade) {
        this.listaFuncionalidade = listaFuncionalidade;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

}
