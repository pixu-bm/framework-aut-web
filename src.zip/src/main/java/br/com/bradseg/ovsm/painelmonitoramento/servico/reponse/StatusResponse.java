package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;

/**
 * Status response.
 * @author Wipro
 */
public class StatusResponse extends ResponseMensagem {

    private List<Status> status;

    public StatusResponse() {
        super();
    }

    public List<Status> getStatus() {
        return Collections.unmodifiableList(status);
    }

    public void setStatus(List<Status> status) {
        this.status = Collections.unmodifiableList(status);
    }

}
