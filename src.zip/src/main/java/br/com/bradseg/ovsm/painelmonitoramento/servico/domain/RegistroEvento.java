package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

public class RegistroEvento extends RegistroEventoSuper{

   
    private String codigoEmpresa;
    private String codigoProduto;
    private String codigoCanal;
    private String dataProcessamento;
    private String msgQtd;
    private String etapaEvento;
    private String qtdEventoUltimo30;
    private String url;
    private String api;
    private String mainframe;
    private String webService;

    public RegistroEvento() {
        super();
    }

    public String getWebService() {
        return webService;
    }

    public void setWebService(String webService) {
        this.webService = webService;
    }

    public String getMainframe() {
        return mainframe;
    }

    public void setMainframe(String mainframe) {
        this.mainframe = mainframe;
    }

    public String getApi() {
        return api;
    }

    public void setApi(String api) {
        this.api = api;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getQtdEventoUltimo30() {
        return qtdEventoUltimo30;
    }

    public void setQtdEventoUltimo30(String qtdEventoUltimo30) {
        this.qtdEventoUltimo30 = qtdEventoUltimo30;
    }

    public String getEtapaEvento() {
        return etapaEvento;
    }

    public void setEtapaEvento(String etapaEvento) {
        this.etapaEvento = etapaEvento;
    }

    public String getMsgQtd() {
        return msgQtd;
    }

    public void setMsgQtd(String msgQtd) {
        this.msgQtd = msgQtd;
    }

    public String getDataProcessamento() {
        return dataProcessamento;
    }

    public void setDataProcessamento(String dataProcessamento) {
        this.dataProcessamento = dataProcessamento;
    }

    public String getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(String codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(String codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }


}
