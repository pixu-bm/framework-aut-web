package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

public class RegistroEventoSuper {
    
    private BigDecimal codigo;
    private String status;
    private String descricaoGravidade;
    private String descricaoProduto;
    private String descricaoCanal;
    private String descricaoTipo;
    private BigDecimal numeroTransacao;
    private String duracao;
    private String dataInicioEvento;
    private Integer recorrencia;
    private BigDecimal codigoGravidade;
    
    public RegistroEventoSuper(){
        super();
    }

    public BigDecimal getCodigo() {
        return codigo;
    }

    public void setCodigo(BigDecimal codigo) {
        this.codigo = codigo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescricaoGravidade() {
        return descricaoGravidade;
    }

    public void setDescricaoGravidade(String descricaoGravidade) {
        this.descricaoGravidade = descricaoGravidade;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public String getDescricaoTipo() {
        return descricaoTipo;
    }

    public void setDescricaoTipo(String descricaoTipo) {
        this.descricaoTipo = descricaoTipo;
    }

    public BigDecimal getNumeroTransacao() {
        return numeroTransacao;
    }

    public void setNumeroTransacao(BigDecimal numeroTransacao) {
        this.numeroTransacao = numeroTransacao;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getDataInicioEvento() {
        return dataInicioEvento;
    }

    public void setDataInicioEvento(String dataInicioEvento) {
        this.dataInicioEvento = dataInicioEvento;
    }

    public Integer getRecorrencia() {
        return recorrencia;
    }

    public void setRecorrencia(Integer recorrencia) {
        this.recorrencia = recorrencia;
    }

    public BigDecimal getCodigoGravidade() {
        return codigoGravidade;
    }

    public void setCodigoGravidade(BigDecimal codigoGravidade) {
        this.codigoGravidade = codigoGravidade;
    }
    
    
}
