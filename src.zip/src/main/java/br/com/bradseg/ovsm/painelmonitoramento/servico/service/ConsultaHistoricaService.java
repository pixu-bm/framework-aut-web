package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;

public interface ConsultaHistoricaService {

    Workbook exportarExcel(List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException;

    ByteArrayInputStream exportarPdf(List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin, String transacaoMax, String nomeServico, String dataInicio, String dataFim)
        throws SQLException;

}
