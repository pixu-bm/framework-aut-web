package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.LoginRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;

import java.sql.SQLException;
import java.util.List;

/**
 * Interface de serviço para obter informações de login
 * @author Wipro
 */
public interface LoginService {

    /**
     * Loga o usuario ao paineis OV.
     * @param usuario Usuario
     * @return 
     * @throws SQLException 
     */
    String logar(Usuario usuario) throws SQLException;

    /**
     * Valida os parametros de usuario.
     * @param usuario Usuario
     */
    void validarLogin(LoginRequest login);

    /**
     * Validar os parametros para solicitação de acesso ao sistema
     * @param solicitarAcesso SolicitacaoAcessoRequest
     */
    void validarSolicitacaoAcesso(SolicitacaoAcessoRequest solicitarAcesso);

    /**
     * Inserir solicitação de acesso para o usuario com cadastros e com pendencia de aprovação do gestor
     * @param usuario Usuario
     * @throws SQLException 
     */
    void inserirUsuarioAprovacao(Usuario usuario) throws SQLException;

    /**
     * Lista empresa usuario response
     * @return List<EmpresaUsuario>
     * @throws SQLException 
     */
    List<EmpresaUsuario> listarEmpresaUsuario() throws SQLException;

    /**
     * Lista todos os departamento associados a uma empresa.
     * @param codigoEmpresa 
     * @return List<DepartamentoUsuario>
     * @throws SQLException
     */
    List<DepartamentoUsuario> listarDepartamentoUsuarioEmpresa(String codigoEmpresa) throws SQLException;

    /**
     * Validar parametro empresa usuario
     * @param codigoEmpresa String
     */
    void validarParametroEmpresaUsuario(String codigoEmpresa);

}
