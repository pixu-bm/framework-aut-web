package br.com.bradseg.ovsm.painelmonitoramento.scheduler.config;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao.ConsultaApiSaudeDao;
import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;

@Component
public class ConsultaApiSaude {

    private static final int INT_100 = 100;

    private static final Log LOGGER = LogFactory.getLog(ConsultaApiSaude.class);

    public static final int TEMPO_PARAMETRIZADO_SUCESSO = 900_000;
    public static final int TEMPO_PARAMETRIZADO_ERRO = 600_000;
    private static final int MAXIMO_CARACTERS = INT_100;
    private static final String V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE = "/V2/EEDI-EmissaoExpressaServicos/service/";
    public static final int INTERVALO_DEFAULT = 16;
    private static final String PRODUTO = "DENTAL";
    public static final int INTERVALO_SAUDE = 15;

    @Autowired
    private ConsultaApiSaudeDao consultaApiSaudeDao;

    private String[] canais = {"INTERNET BANKING", "MOBILE BANKING", "SHOPPING SEGUROS", "NEXT"};

    private boolean status;

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApi}")
    private String enderecoApi;

    private String validaProposta = "/V2/EEDI-EmissaoExpressaServicos/service/PropostaWebService";
    private String cancelarPropostaProtocolo = "/V2/EEDI-EmissaoExpressaServicos/service/PropostaWebService"
        + "/cancelarPropostaPorProtocolo";
    private String cancelarPropostaShoppingSeguros = V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE
        + "PropostaWebService/cancelarPropostaPorProtocolo";
    private String listarPlanosVigentesPorCanalESegmento = V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE
        + "Proposta100PorCentoCorretorWebService/cancelarPropostaPorProtocolo";
    private String finalizarProposta = V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE
        + "Proposta100PorCentoCorretorWebService/finalizarProposta";
    private String listarPlanoVigentePorCanal = V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE
        + "Proposta100PorCentoCorretorWebService/listarPlanosVigentePorCanal";
    private String cancelarPropostasDoSite100CorretorComDataDeValidadeExpirada = 
        V2_EEDI_EMISSAO_EXPRESSA_SERVICOS_SERVICE
        + "Proposta100PorCentoCorretorWebService/cancelarPropostasDoSite100CorretorComDataDeValidadeExpirada";

    private String[] metodosApi = {validaProposta, cancelarPropostaProtocolo, cancelarPropostaShoppingSeguros,
        listarPlanosVigentesPorCanalESegmento, finalizarProposta, listarPlanoVigentePorCanal,
        cancelarPropostasDoSite100CorretorComDataDeValidadeExpirada};

    public ConsultaApiSaude(
        ConsultaApiSaudeDao consultaApiSaudeDao) {
        this.consultaApiSaudeDao = consultaApiSaudeDao;
    }

    public void consultaApi() {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String tokendatapowerSaude = validaTokenDataPower.createJWT(datapowerpwd);

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/V2/Auth",
                tokendatapowerSaude);

            LocalDateTime datahoraregistro;
            String dataultimoregistro;

            LocalDateTime horaAtualSaude = LocalDateTime.now(ZoneId.of("America/Sao_Paulo"));
            DateTimeFormatter formatterSaude = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String agoraFormatado = horaAtualSaude.format(formatterSaude);
            LocalDateTime dataHoraAtualSaude = LocalDateTime.parse(agoraFormatado, formatterSaude);

            // metodo para pegar ultimo registro
            dataultimoregistro = consultaApiSaudeDao.obterultimoregistroinseridoSaude();

            if (dataultimoregistro != null) {
                datahoraregistro = LocalDateTime.parse(dataultimoregistro, formatterSaude);
            } else {
                datahoraregistro = LocalDateTime.now(
                    ZoneId.of("America/Sao_Paulo")).minusMinutes(INTERVALO_DEFAULT);
            }

            long minutos = datahoraregistro.until(dataHoraAtualSaude, ChronoUnit.MINUTES);

            for (String canal : canais) {

                URL url = new URL(enderecoApi + validaProposta);
                HttpURLConnection connectionSaude = (HttpURLConnection) url.openConnection();
                connectionSaude.setRequestMethod("POST");
                connectionSaude.setRequestProperty("Content-Type", "application/json");
                connectionSaude.setDoOutput(true);
                connectionSaude.setInstanceFollowRedirects(false);
                connectionSaude.addRequestProperty("Authorization", authorization);

                String jsonRequest = "{}";


                try (OutputStream os = connectionSaude.getOutputStream()) {
                    byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                LinkedList<TabelaTemp> listaSaudeTemp = new LinkedList<>();

                validarConexaoSaudeTemp(dataHoraAtualSaude, connectionSaude, canal,
                    enderecoApi + validaProposta,
                    listaSaudeTemp, enderecoApi + validaProposta);



                for (String api : metodosApi) {

                    URL urlapi = new URL(enderecoApi + api);
                    HttpURLConnection connectionCanalSaude = (HttpURLConnection) urlapi.openConnection();
                    connectionCanalSaude.setRequestMethod("POST");
                    connectionCanalSaude.setRequestProperty("Content-Type", "application/json");
                    connectionCanalSaude.setDoOutput(true);
                    connectionCanalSaude.setInstanceFollowRedirects(false);
                    connectionCanalSaude.addRequestProperty("Authorization", authorization);



                  try (OutputStream os = connectionCanalSaude.getOutputStream()){
                    byte[] inputCancal = jsonRequest.getBytes(StandardCharsets.UTF_8);
                    os.write(inputCancal, 0, inputCancal.length);
                   }

                    validarConexaoSaudeTempApi(dataHoraAtualSaude, connectionCanalSaude,
                        canal, null, listaSaudeTemp);

                }


                if (minutos >= INTERVALO_SAUDE) {

                    consultaApiSaudeDao.inserirConsultaApiSaude(listaSaudeTemp);

                    consultaApiSaudeDao.validarDuplicadosSaude(listaSaudeTemp);

                    consultaApiSaudeDao.liberarProcessamentoSaude(listaSaudeTemp);
                }
            }

        } catch (SQLException | IOException e) {
            LOGGER.error(Constantes.ERROR, e);
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    protected void validarConexaoSaudeTemp(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String enderecoApi,
        LinkedList<TabelaTemp> listaSaudeTemp, String metodosApi) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            // Consulta Realizada com erro
            status = true;

            listaSaudeTemp
                .addLast(obterSaudeNOk(canal, enderecoApi, metodosApi, dataHoraAtual, connection));

        } else {
            // Consulta Realizada com sucesso
            status = false;

            listaSaudeTemp.addLast(obterSaudeOk(canal, enderecoApi, metodosApi, dataHoraAtual));

        }
    }

    private void validarConexaoSaudeTempApi(LocalDateTime dataHoraAtual,
        HttpURLConnection connection, String canal, String metodosApi,
        LinkedList<TabelaTemp> listaSaudeTemp) throws IOException {

        if (connection.getResponseCode() != Constantes.RESPONSE_CODE_400
            && connection.getResponseCode() != Constantes.RESPONSE_CODE_200) {
            status = true;

            listaSaudeTemp.addLast(obterSaudeNOk(canal, null, metodosApi, dataHoraAtual, connection));

        } else {
            status = false;

            listaSaudeTemp.addLast(obterSaudeOk(canal, null, metodosApi, dataHoraAtual));

        }
    }

    public TabelaTemp obterSaudeNOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual, HttpURLConnection connection) throws IOException {
        // Consulta Realizada com erro
        status = true;
        TabelaTemp saudeTemp = new TabelaTemp();
        // Fluxo para Salvar a API
        saudeTemp.setcorrigeDado(Constantes.CORRIGE_DADO);
        saudeTemp.setCindRegProcs("J");
        // Codigo de retorno
        saudeTemp.setCerroOrign(String.valueOf(connection.getResponseCode()));
        saudeTemp.setRmsgemErroOrign(connection.getResponseMessage());
        // Endereco API consultada
        saudeTemp.setRenderUrlOrign(enderecoApi);
        saudeTemp.setRservcOrign(null);
        saudeTemp.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            saudeTemp.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            saudeTemp.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            saudeTemp.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            saudeTemp.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            saudeTemp.setIapiOrign(enderecoApi);
            saudeTemp.setIetapaOfert(enderecoApi);
        }

        saudeTemp.setIcanalOrign(canal);
        saudeTemp.setIemprOrign("SAUDE");
        saudeTemp.setIprodtOrign(PRODUTO);
        saudeTemp.setIsprodOrign(null);

        saudeTemp.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        saudeTemp.setIsitEvnto("NOK");
        saudeTemp.setDinicErro(dataHoraAtual);
        saudeTemp.setDfimErro(null);
        saudeTemp.setDinclReg(dataHoraAtual);
        saudeTemp.setDaltReg(null);

        return saudeTemp;
    }

    public static TabelaTemp obterSaudeOk(String canal, String enderecoApi, String metodosApi,
        LocalDateTime dataHoraAtual) {
        TabelaTemp saudeTempOk = new TabelaTemp();
        // Fluxo para Salvar a API
        saudeTempOk.setcorrigeDado(Constantes.CORRIGE_DADO);
        saudeTempOk.setCindRegProcs("J");
        // Codigo de retorno
        saudeTempOk.setCerroOrign("200");
        saudeTempOk.setRmsgemErroOrign("OK");
        // Endereco API consultada
        saudeTempOk.setRenderUrlOrign(enderecoApi);
        saudeTempOk.setRservcOrign(null);
        saudeTempOk.setItransOrign("A001");

        if (metodosApi != null &&
            metodosApi.length() > INT_100) {
            saudeTempOk.setRtransOrign(metodosApi.substring(0, MAXIMO_CARACTERS));
        } else {
            saudeTempOk.setRtransOrign(metodosApi);
        }

        if (enderecoApi != null &&
            enderecoApi.length() > INT_100) {
            saudeTempOk.setIapiOrign(enderecoApi.substring(0, MAXIMO_CARACTERS));
            saudeTempOk.setIetapaOfert(enderecoApi.substring(0, MAXIMO_CARACTERS));
        } else {
            saudeTempOk.setIapiOrign(enderecoApi);
            saudeTempOk.setIetapaOfert(enderecoApi);
        }

        saudeTempOk.setIcanalOrign(canal);
        saudeTempOk.setIemprOrign("SAUDE");
        saudeTempOk.setIprodtOrign(PRODUTO);
        saudeTempOk.setIsprodOrign(null);

        saudeTempOk.setIplatfOrign(Constantes.PLATA_FORMA_ORIGN);
        saudeTempOk.setIsitEvnto("OK");
        saudeTempOk.setDinicErro(dataHoraAtual);
        saudeTempOk.setDfimErro(null);
        saudeTempOk.setDinclReg(dataHoraAtual);
        saudeTempOk.setDaltReg(null);

        return saudeTempOk;
    }

    // Metodo responsavel por buscar o tempo parametrizado em milisegundos 900000
    public int buscaTempoParametrizado() {

        // Necessario implementar consulta na tabela de config de tempos para buscar os parametros
        // status = true erro identificado
        if (status) {
            return TEMPO_PARAMETRIZADO_SUCESSO;
        }

        return TEMPO_PARAMETRIZADO_ERRO;
    }

    public void setEnderecoApi(String enderecoApi) {
        this.enderecoApi = enderecoApi;
    }
}
