package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.FaqDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.FaqService;

/**
 * Classe responsável por implementar Canal service
 * @author Wipro
 */
@Service
public class FaqServiceImpl implements FaqService {

    private static final Log LOGGER = LogFactory.getLog(FaqServiceImpl.class);

    private FaqDao faqDao;

    @Autowired
    public FaqServiceImpl(FaqDao faqDao) {
        this.faqDao = faqDao;
    }

    @Override
    public List<Faq> carregar() {
        try {

            return faqDao.listarPerguntasFaq();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public List<Faq> pesquisar(String pergunta) {
        try {

            return faqDao.pesquisar(pergunta);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void editar(BigDecimal cod, String pergunta, String resposta, Float prioridade, String imagem,
        String login) {
        try {

            faqDao.editar(cod, pergunta, resposta, prioridade, imagem, login);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void salvar(String pergunta, String resposta, Float prioridade, String imagem, String login) {
        try {

            faqDao.salvar(pergunta, resposta, prioridade, imagem, login);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    @Override
    public void excluir(BigDecimal codSeq, String codData) {
        try {

            faqDao.excluir(codSeq, codData);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
