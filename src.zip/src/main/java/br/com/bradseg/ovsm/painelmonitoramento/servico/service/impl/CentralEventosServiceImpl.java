package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.itextpdf.text.Document;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CentralEventosDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CentralEventosService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.CentralEventosServiceExport;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Central de evento service implementador
 *
 * @author Wipro
 */
@Service
public class CentralEventosServiceImpl implements CentralEventosService {

    private CentralEventosDao dao;

    private CentralEventosServiceExport export;

    private static final Log LOGGER = LogFactory
      .getLog(CentralEventosServiceImpl.class);
    public static final String ERROR = "Error: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private static final String MSG_NENHUM_EVTO_ENCONTRADO = "Nenhum registro de evento";

    @Autowired
    public CentralEventosServiceImpl(CentralEventosDao dao,
      CentralEventosServiceExport export) {
        this.dao = dao;
        this.export = export;
    }

    /**
     * {@inheritDoc}
     */
    public VisaoEvento obterVisaoEventoAberto(Date dataInicio, Date dataFim) {
        try {
            return dao.obterVisaoEventoAberto(dataInicio, dataFim);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void validarParametrosVisaoEventoAberto(String dataInicio,
      String dataFim) {
        Assert.notNull(dataInicio, "dataInicio não pode ser nulo.");
        Assert.notNull(dataFim, "dataFim não pode ser nulo.");
        Assert.notNull(Utils.strDateFmtBrasilToJavaDate(dataInicio),
          "Formato de dataInicio errado.");
        Assert.notNull(Utils.strDateFmtBrasilToJavaDate(dataFim),
          "Formato de dataInicio errado.");
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoEventoProduto> obterVisaoEventoProduto(Date dataInicio,
      Date dataFim) {
        try {
            List<VisaoEventoProduto> lista = dao
              .obterVisaoEventoProduto(dataInicio, dataFim);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  "Nenhum evento por produto encontrado.", 1);
            }

            return lista;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoEventoCanal> obterVisaoEventoCanal(Date dataInicio,
      Date dataFim) {
        try {
            List<VisaoEventoCanal> lista = dao.obterVisaoEventoCanal(dataInicio,
              dataFim);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  "Nenhum evento por canal encontrado.", 1);
            }

            return lista;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<RegistroEvento> obterRegistroEvento(
      List<BigDecimal> listaCodigoProduto,
      List<BigDecimal> listaCodigoCanal, Integer statusEvento,
      Date dataInicio, Date dataFim,
      BigDecimal codigoTipoEvento) {
        try {
            List<RegistroEvento> lista = dao.obterRegistroEvento(
              listaCodigoProduto, listaCodigoCanal, statusEvento,
              dataInicio, dataFim, codigoTipoEvento);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  MSG_NENHUM_EVTO_ENCONTRADO, 1);
            }

            return lista;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<StatusDetalheEvento> obterStatusDetalheEvento(
      Integer codigoErro,
      BigDecimal codigoEmpresa, BigDecimal codigoProduto,
      BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo,
      Integer statusEvento) {
        try {

            List<StatusDetalheEvento> lista = dao.obterStatusDetalheEvento(
              codigoErro, codigoEmpresa,
              codigoProduto, codigoCanal,
              dataProcessamento, periodoTempo, statusEvento);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  MSG_NENHUM_EVTO_ENCONTRADO, 1);
            }

            return lista;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<GraficoDetalheEvento> obterGraficoDetalheEvento(Integer codigoErro,
      BigDecimal codigoEmpresa, BigDecimal codigoProduto,
      BigDecimal codigoCanal, Date dataProcessamento) {
        try {

            List<GraficoDetalheEvento> gafico = dao.obterGraficoDetalheEvento(codigoErro, codigoEmpresa,
              codigoProduto, codigoCanal,
              dataProcessamento);

            if (gafico.isEmpty()) {
                throw new EmptyResultDataAccessException(MSG_NENHUM_EVTO_ENCONTRADO, 1);
            }

            return gafico;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<RelaciondosDetalheEvento> obterDetalheEventoRelacionados(Integer codigoErro, Integer limite,
      Integer linha) {
        try {

            List<RelaciondosDetalheEvento> lista = dao.obterDetalheEventoRelacionados(codigoErro, limite, linha);

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException(MSG_NENHUM_EVTO_ENCONTRADO, 1);
            }

            return lista;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Integer obterTotalEventoRelacionados(Integer codigoErro) {
        try {

            return dao.obterTotalEventoRelacionados(codigoErro);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public VisaoGeralProduto obterVisaoEventoProdutoDetalhe(Integer periodoVisaoEvento, BigDecimal codigoProduto) {
        try {
            return dao.obterVisaoEventoProdutoDetalhe(periodoVisaoEvento,
              codigoProduto);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public VisaoGeralCanal obterVisaoEventoCanalDetalhe(
      Integer periodoVisaoEvento, BigDecimal codigoCanal) {
        try {
            return dao.obterVisaoEventoCanalDetalhe(periodoVisaoEvento,
              codigoCanal);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoDetalhadaProdutoCanal> obterListaEventoProdutoCanalDetalhe(
      Integer periodoVisaoEvento, BigDecimal codigoProduto, BigDecimal codigoCanal) {
        try {
            return dao.obterListaEventoProdutoCanalDetalhe(periodoVisaoEvento, codigoProduto, codigoCanal);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VisaoDetalhadaProdutoCanal> obterListaEventoDetalhadoPDF(Integer codigoErro, BigDecimal codigoEmpresa,
      BigDecimal codigoProduto,
      BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento) {
        try {
            return dao.obterListaEventoDetalhado(codigoErro, codigoEmpresa, codigoProduto, codigoCanal,
              dataProcessamento, periodoTempo, statusEvento);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(), 1);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Workbook obterRegistroEventoExcel(
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
      Integer statusEvento, Date dataInicio, Date dataFim,
      BigDecimal codigoTipoEvento, String login) {

        try {
            List<RegistroEvento> listaRegistroEvento = obterRegistroEvento(
              listaCodigoProduto, listaCodigoCanal, statusEvento, dataInicio,
              dataFim, codigoTipoEvento);

            return export.obterArquivoRegistroEventoExcel(
              listaRegistroEvento, login, dataInicio, dataFim,
              listaCodigoProduto, listaCodigoCanal);

        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public ByteArrayInputStream obterRegistroEventoPDF(
      List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
      Integer statusEvento, Date dataInicio, Date dataFim,
      BigDecimal codigoTipoEvento, String login) {

        try {
            List<RegistroEvento> listaRegistroEvento = obterRegistroEvento(
              listaCodigoProduto, listaCodigoCanal, statusEvento, dataInicio,
              dataFim, codigoTipoEvento);

            return export.obterArquivoRegistroEventoPDF(
              listaRegistroEvento, login, dataInicio, dataFim,
              listaCodigoProduto, listaCodigoCanal);

        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public ByteArrayInputStream obterVisaoEventoProdutoCanalDetalhePDF(Integer periodoVisaoEvento,
      List<BigDecimal> codigoProduto,
      List<BigDecimal> codigoCanal, String login) {

        try {
            BigDecimal produto = null;
            BigDecimal canal = null;
            if (codigoProduto != null) {
                produto = codigoProduto.get(0);
            }
            if (codigoCanal != null) {
                canal = codigoCanal.get(0);
            }
            List<VisaoDetalhadaProdutoCanal> listaRegistro = obterListaEventoProdutoCanalDetalhe(periodoVisaoEvento,
              produto, canal);

            return export.obterArquivoRegistroProdutoCanalEventoPDF(
              listaRegistro, periodoVisaoEvento, codigoProduto, codigoCanal, login);

        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public ByteArrayInputStream obterVisaoEventoDetalhadoPDF(Integer codigoErro, BigDecimal codigoEmpresa,
      BigDecimal codigoProduto,
      BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento,
      String login) {

        try {
             List<StatusDetalheEvento> listaRegistroEvento = obterStatusDetalheEvento(
             codigoErro, codigoEmpresa, codigoProduto, codigoCanal,
             dataProcessamento, periodoTempo, statusEvento);
             

            return export.obterArquivoRegistroEventoDetalhadoPDF(
              listaRegistroEvento, login, codigoErro, codigoEmpresa, codigoProduto,
              codigoCanal, dataProcessamento, periodoTempo, statusEvento);

        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
