package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Classe row mapper responsável extrair dados da tabela Configuração de
 * intervalo
 * 
 * @author Wipro
 */
public class ListaConfiguracaoIntervaloProcessamentoRowMapper
    implements RowMapper<ConfiguracaoIntervaloProcessamentoResponse> {

    @Override
    public ConfiguracaoIntervaloProcessamentoResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
        ConfiguracaoIntervaloProcessamentoResponse configInterProc = new ConfiguracaoIntervaloProcessamentoResponse();

        configInterProc.setQuantidadeMinutoIntervaloErro(
            rs.getInt("QMNUTO_INTVL_ERRO"));
        configInterProc.setQuantidadeMinutoIntervaloNormal(
            rs.getInt("QMNUTO_INTVL_NORML"));

        return configInterProc;
    }

}
