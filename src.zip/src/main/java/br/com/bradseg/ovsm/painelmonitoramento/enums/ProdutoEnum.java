package br.com.bradseg.ovsm.painelmonitoramento.enums;

public enum ProdutoEnum {

    PREVIDENCIA(1, "PREVIDÊNCIA", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING}),
    VIAGEM(2, "VIAGEM", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING}),
    SAPP(3, "SAPP", new CanalEnum[] {CanalEnum.SHOPPING, CanalEnum.NEXT}),
    VIDA(4, "VIDA", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING, CanalEnum.MOVE}),
    AUTO(5, "AUTO", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.SHOPPING, CanalEnum.MOVE, CanalEnum.MEI, CanalEnum.NET_EMPRESA}),
    RESIDENCIAL(6, "RESIDENCIAL", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.SHOPPING, CanalEnum.NEXT}),
    CAPITALIZACAO(7, "CAPITALIZAÇÃO", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING}),
    DENTAL(8, "DENTAL", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING, CanalEnum.NEXT}),
    SUPERPROTEGIDO(9, "SUPERPROTEGIDO", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING, CanalEnum.NEXT}),
    CARTAO_DEBITO(10, "CARTAO DEBITO", new CanalEnum[] {CanalEnum.INTERNET_BANKING,
        CanalEnum.MOBILE_BANKING, CanalEnum.ATM, CanalEnum.SHOPPING, CanalEnum.NEXT});

    private final Integer valor;
    private final String descricao;
    private final CanalEnum[] enums;

    ProdutoEnum(Integer valor, String descricao, CanalEnum[] enums) {
        this.valor = valor;
        this.descricao = descricao;
        this.enums = enums.clone();
    }

    public Integer getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public CanalEnum[] getEnums() {
        return enums.clone();
    }

}
