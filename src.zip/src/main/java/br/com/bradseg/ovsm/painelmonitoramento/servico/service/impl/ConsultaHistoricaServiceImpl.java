package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConsultaHistoricaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConsultaHistoricaService;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.export.ConsultaHistoricaServiceExport;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

@Service
public class ConsultaHistoricaServiceImpl implements ConsultaHistoricaService {

    private static final Log LOGGER = LogFactory
        .getLog(ConsultaHistoricaServiceImpl.class);
    public static final String ERROR = "Error: ";
    private static final int HORA = 3600;
    private static final int MIN_SEC = 60;
    public static final int INT_4 = 4;
    public static final int INT_1 = 1;
    public static final int INT_2 = 2;
    public static final int INT_3 = 3;
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    public static final String MSG_NENHUM_DADO_ENCONTRADO = "Não foram encontrados dados para a pesquisa";

    private ConsultaHistoricaDao consultaHistoricaDao;

    private ConsultaHistoricaServiceExport export;

    @Autowired
    public ConsultaHistoricaServiceImpl(
        ConsultaHistoricaDao consultaHistoricaDao,
        ConsultaHistoricaServiceExport export) {
        this.consultaHistoricaDao = consultaHistoricaDao;
        this.export = export;
    }

    @Override
    public Workbook exportarExcel(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim, String login) throws SQLException {

        try {
            return export.gerarExcel(obtemDados(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMin, freqMin, duracaoMin, duracaoMax, transacaoMin, transacaoMax, nomeServico,
                dataInicio, dataFim));
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }

    @Override
    public ByteArrayInputStream exportarPdf(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim, String login) throws SQLException {

        try {
            return export.gerarPdf(obtemDados(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMin, freqMin, duracaoMin, duracaoMax, transacaoMin, transacaoMax, nomeServico,
                dataInicio, dataFim), login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }

    private List<ConsultaHistorica> obtemDados(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException {
        Integer freqMinCvt = null;
        Integer freqMaxCvt = null;
        Integer transacaoMinCvt = null;
        Integer transacaoMaxCvt = null;

        try {
            freqMinCvt = Integer.parseInt(freqMin);
        } catch (NumberFormatException e) {
            LOGGER.error(ERROR, e);
            freqMinCvt = null;
        }
        try {
            freqMaxCvt = Integer.parseInt(freqMax);
        } catch (NumberFormatException e) {
            LOGGER.error(ERROR, e);
            freqMaxCvt = null;
        }

        try {
            transacaoMinCvt = Integer.parseInt(transacaoMin);
        } catch (NumberFormatException e) {
            LOGGER.error(ERROR, e);
            transacaoMinCvt = null;
        }

        try {
            transacaoMaxCvt = Integer.parseInt(transacaoMax);
        } catch (NumberFormatException e) {
            LOGGER.error(ERROR, e);
            transacaoMaxCvt = null;
        }
        try {

            List<ConsultaHistorica> lista = consultaHistoricaDao.obterHistorico(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMinCvt, freqMaxCvt, duracaoMin, duracaoMax, transacaoMinCvt, transacaoMaxCvt, nomeServico,
                dataInicio, dataFim);

            for (ConsultaHistorica e : lista) {
                e.setDuracaoDispFmt(Utils.converteHoraMinutoSegundoBig(e.getDuracaoDisp() + ""));
                e.setDuracaoFuncFmt(Utils.converteHoraMinutoSegundoBig(e.getDuracaoFunc() + ""));
                e.setDuracaoVoluFmt(Utils.converteHoraMinutoSegundoBig(e.getDuracaoVolu() + ""));
            }

            return lista;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }
}
