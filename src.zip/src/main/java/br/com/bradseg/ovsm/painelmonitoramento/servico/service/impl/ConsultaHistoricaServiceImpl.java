package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ConsultaHistoricaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConsultaHistorica;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConsultaHistoricaService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.PlanilhaUtils;

@Service
public class ConsultaHistoricaServiceImpl implements ConsultaHistoricaService {

    private static final Log LOGGER = LogFactory
        .getLog(ConsultaHistoricaServiceImpl.class);
    public static final String ERROR = "Error: ";
    private static final int HORA = 3600;
    private static final int MIN_SEC = 60;
    public static final int INT_4 = 4;
    public static final int INT_1 = 1;
    public static final int INT_2 = 2;
    public static final int INT_3 = 3;
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    private static final int INT_0 = 0;
    private static final int MARGIN_RIGHT_30 = 30;
    private static final int MARGIN_TOP_20 = 20;
    private static final int MARGIN_BOTTOM_20 = 20;
    private static final int MARGIN_LEFT_30 = 30;
    private static final int INT_9 = 9;
    private static final String CODIGO_EVENTO = "Código do Evento";
    private static final String GRAVIDADE = "Gravidade";
    private static final String PRODUTO = "Produto";
    private static final String CANAL = "Canal";
    private static final String TIPO_EVENTO = "Tipo do Evento";
    private static final String TRANSACOES_IMPAC = "Transações Impactadas";
    private static final String DURACAO_FUNCL = "Duração Funcionalidade";
    private static final String DURACAO_DISPON = "Duração Disponibilidade";
    private static final String DURACAO_VOLUM = "Duração Volumetria";
    private static final String DATA = "Data";
    private static final String RECORRENCIA = "Recorrencia (30 Dias)";
    private static final String MSG_NENHUM_DADO_ENCONTRADO = "Nenhum dado encontrado";
    private static final int INT_8 = 8;
    private static final int INT_10 = 10;
    private static final int INT_5 = 5;
    private static final int INT_6 = 6;
    private static final int INT_7 = 7;
    private static final int INT_11 = 11;
    private static final float FLOAT_0_3 = 0.3f;

    private ConsultaHistoricaDao consultaHistoricaDao;

    @Autowired
    public ConsultaHistoricaServiceImpl(
        ConsultaHistoricaDao consultaHistoricaDao) {
        this.consultaHistoricaDao = consultaHistoricaDao;
    }

    @Override
    public Workbook exportarExcel(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException {

        try {
            return gerarExcel(obtemDados(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMin, freqMin, duracaoMin, duracaoMax, transacaoMin, transacaoMax, nomeServico,
                dataInicio, dataFim));
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }

    @Override
    public ByteArrayInputStream exportarPdf(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException {

        try {
            return gerarPdf(obtemDados(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMin, freqMin, duracaoMin, duracaoMax, transacaoMin, transacaoMax, nomeServico,
                dataInicio, dataFim));
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }

    private ByteArrayInputStream gerarPdf(List<ConsultaHistorica> obtemDados) {
        Document documento = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            documento.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documento, out);

            documento.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT_9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT_9, BaseColor.BLACK);

            documento = montarListaConsultaHistoricoPDF(documento, obtemDados, font1, font2);
            documento.close();

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    private Document montarListaConsultaHistoricoPDF(Document documento,
        List<ConsultaHistorica> listaConsultaHistorica,
        Font font1, Font font2) {
        try {
            PdfPTable tabBodyConsulta = new PdfPTable(INT_11);
            tabBodyConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);

            Map<Integer, String> cabecalhoConsulta = new HashMap<>();
            cabecalhoConsulta.put(1, CODIGO_EVENTO);
            cabecalhoConsulta.put(INT_2, GRAVIDADE);
            cabecalhoConsulta.put(INT_3, PRODUTO);
            cabecalhoConsulta.put(INT_4, CANAL);
            cabecalhoConsulta.put(INT_5, TIPO_EVENTO);
            cabecalhoConsulta.put(INT_6, TRANSACOES_IMPAC);
            cabecalhoConsulta.put(INT_7, DURACAO_DISPON);
            cabecalhoConsulta.put(INT_8, DURACAO_FUNCL);
            cabecalhoConsulta.put(INT_9, DURACAO_VOLUM);
            cabecalhoConsulta.put(INT_10, DATA);
            cabecalhoConsulta.put(INT_11, RECORRENCIA);
            
            for (Map.Entry<Integer, String> pair : cabecalhoConsulta.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_0_3);
                col.setBorderColor(BaseColor.BLACK);
            }
            
            PdfPTable tabBodyItens = new PdfPTable(INT_11);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);

            if (listaConsultaHistorica != null) {
                for (int i = INT_0; i < listaConsultaHistorica.size(); i++) {
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getCodigoEvento().toString(),
                        tabBodyItens, font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getGravidade(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getProduto(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getCanal(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getTipoEvento(),
                        tabBodyItens, font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getTransacoesImpactadas().toString(),
                        tabBodyItens,
                        font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoDispFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoFuncFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getDuracaoVoluFmt(),
                        tabBodyItens, font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(listaConsultaHistorica.get(i).getData(), tabBodyItens,
                        font1);
                    tabBodyItens = AddLinhaConsultaHistoricaPDF(
                        listaConsultaHistorica.get(i).getRecorrencia().toString(),
                        tabBodyItens,
                        font1);
                }
            }

            documento.add(tabBodyConsulta);

            if (listaConsultaHistorica != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private PdfPTable AddLinhaConsultaHistoricaPDF(String item, PdfPTable tabBodyConsulta, Font font1) {
        PdfPCell colConsulta = new PdfPCell();
        colConsulta.setBackgroundColor(BaseColor.WHITE);
        colConsulta.setHorizontalAlignment(Element.ALIGN_LEFT);
        if (item != null) {
            colConsulta.setPhrase(new Phrase(item, font1));
        } else {
            colConsulta.setPhrase(new Phrase("", font1));
        }
        colConsulta.setBorderWidth(FLOAT_0_3);
        colConsulta.setBorderColor(BaseColor.BLACK);
        tabBodyConsulta.addCell(colConsulta);
        return tabBodyConsulta;
    }

    private Workbook gerarExcel(List<ConsultaHistorica> lista) {
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Historico");
        int countSheet = INT_0;

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT_0;

        String[] valoresCabecalho = {CODIGO_EVENTO, GRAVIDADE, PRODUTO,
            CANAL, TIPO_EVENTO, TRANSACOES_IMPAC, DURACAO_DISPON, DURACAO_FUNCL,
            DURACAO_VOLUM, DATA, RECORRENCIA};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = 0; i < lista.size(); i++) {
            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getCodigoEvento().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getGravidade());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getTipoEvento());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getTransacoesImpactadas().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoDispFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoFuncFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getDuracaoVoluFmt());
            count++;

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getData());

            montarCelula(
                row, count, sheet, style,
                lista.get(i).getRecorrencia().toString());

        }

        return wb;
    }

    private static void montarCelula(Row row, int count,
        Sheet sheet, CellStyle styleInicial, String value) {

        Cell celula = row.createCell(count);
        celula.setCellValue(value);
        celula.setCellStyle(styleInicial);
        int tamanho = celula.getColumnIndex();
        sheet.autoSizeColumn(tamanho);
    }

    private String fomatarDuracao(long duracao) {
        long segundos = duracao;
        long horas = segundos / HORA;
        segundos = segundos % HORA;
        long minutos = segundos / MIN_SEC;
        segundos = segundos % HORA;

        return horas + ":" + minutos + ":" + segundos;
    }

    private List<ConsultaHistorica> obtemDados(List<BigDecimal> listaCodigoProduto,
        List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento, String freqMin, String freqMax, String duracaoMin, String duracaoMax,
        String transacaoMin,
        String transacaoMax, String nomeServico, String dataInicio, String dataFim) throws SQLException {
        Integer freqMinCvt = null;
        Integer freqMaxCvt = null;
        Integer transacaoMinCvt = null;
        Integer transacaoMaxCvt = null;

        try {
            freqMinCvt = Integer.parseInt(freqMin);
        } catch (Exception e) {
            LOGGER.error(ERROR, e);
            freqMinCvt = null;
        }
        try {
            freqMaxCvt = Integer.parseInt(freqMax);
        } catch (Exception e) {
            LOGGER.error(ERROR, e);
            freqMaxCvt = null;
        }

        try {
            transacaoMinCvt = Integer.parseInt(transacaoMin);
        } catch (Exception e) {
            LOGGER.error(ERROR, e);
            transacaoMinCvt = null;
        }

        try {
            transacaoMaxCvt = Integer.parseInt(transacaoMax);
        } catch (Exception e) {
            LOGGER.error(ERROR, e);
            transacaoMaxCvt = null;
        }
        try {

            List<ConsultaHistorica> lista = consultaHistoricaDao.obterHistorico(listaCodigoProduto, listaCodigoCanal,
                listTipoEvento,
                freqMinCvt, freqMaxCvt, duracaoMin, duracaoMax, transacaoMinCvt, transacaoMaxCvt, nomeServico,
                dataInicio, dataFim);

            for (ConsultaHistorica e : lista) {
                e.setDuracaoDispFmt(fomatarDuracao(e.getDuracaoDisp()));
                e.setDuracaoFuncFmt(fomatarDuracao(e.getDuracaoFunc()));
                e.setDuracaoVoluFmt(fomatarDuracao(e.getDuracaoVolu()));
            }

            return lista;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException(MSG_NENHUM_DADO_ENCONTRADO, 0);
        }
    }
}
