package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;

/**
 * Interface responsável por obter a busca a base de dados informações
 * relacionadas ao painel de monitamento
 * 
 * @author Wipro
 */
public interface PainelPrincipalDao {

    /**
     * Obter informações relacionadas ao painel de monitoramento junto a base de
     * dados Paineis OV.
     * 
     * @return PainelMonitoramento
     * @throws SQLException
     */
    PainelMonitoramentoAtual obterPainelMonitoramento() throws SQLException;

    /**
     * Obter visão evento por periodo de datas de visão
     * 
     * @param periodoVisaoEvento Integer
     * @return VisaoEvento
     * @throws SQLException
     */
    VisaoEvento obterVisaoEvento(Integer periodoVisaoEvento) throws SQLException;

    /**
     * Obter volumetria tempo real
     * 
     * @param periodoVisaoEvento              Integer
     * @param produtoPainelMonitoramentoAtual ProdutoPainelMonitoramentoAtual
     * @return VolumetriaTempoReal
     * @throws SQLException
     */
    VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento) throws SQLException;

    /**
     * Obter volumetria tempo real por periodo de faixa de tempo
     * 
     * @param periodoVisaoEvento              Integer
     * @param ProdutoPainelMonitoramentoAtual ProdutoPainelMonitoramentoAtual
     * @return List<VolumetriaTempoReal>
     * @throws SQLException
     */
    List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento) throws SQLException;

    /**
     * Obter volumetria tempo real de transacao e eventos para criação de tabela e
     * grid informativa nos paineis OV
     * 
     * @param periodoVisaoEvento              Integer
     * @param produtoPainelMonitoramentoAtual ProdutoPainelMonitoramentoAtual
     * @return List<VolumetriaTempoRealEvento>
     * @throws SQLException
     */
    List<VolumetriaTempoRealTransacaoEvento> obterVolumetriaTempoRealTransacaoEvento(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento) throws SQLException;

}
