package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;
import java.util.Date;

import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ComentarioRequest;

/**
 * Comentário dominio
 *
 * @author Wipro
 */
public class Comentario {
    private BigDecimal codigoEmpresa;
    private BigDecimal codigoProduto;
    private BigDecimal codigoCanal;
    private Date dataVerificacao;
    private Date dataProcs;
    private BigDecimal codigoErroConexaoPainel;
    private String mensagemComentario;
    private String login;
    private String nomeUsuario;
    private String perfilUsuario;
    private Date dataInclusao;

    public Comentario() {
        super();
    }

    /**
     * Construtor comentarioRequest
     *
     * @param comentarioRequest ComentarioRequest
     */
    public Comentario(ComentarioRequest comentarioRequest) {
        this.codigoEmpresa = comentarioRequest.getCodigoEmpresa();
        this.codigoProduto = comentarioRequest.getCodigoProduto();
        this.codigoCanal = comentarioRequest.getCodigoCanal();
        this.dataProcs = (Date) comentarioRequest.getDataProcs().clone();
        this.codigoErroConexaoPainel = comentarioRequest.getCodigoErroConexaoPainel();
        this.mensagemComentario = comentarioRequest.getComentario();
        this.login = comentarioRequest.getLogin();
        this.dataInclusao = (Date) comentarioRequest.getDataInclusao().clone();
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public Date getDataVerificacao() {
        if (dataVerificacao != null) {
            return (Date) dataVerificacao.clone();
        }
        return null;
    }

    public void setDataVerificacao(Date dataVerificacao) {
        this.dataVerificacao = (Date) dataVerificacao.clone();
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public BigDecimal getCodigoErroConexaoPainel() {
        return codigoErroConexaoPainel;
    }

    public void setCodigoErroConexaoPainel(BigDecimal codigoErroConexaoPainel) {
        this.codigoErroConexaoPainel = codigoErroConexaoPainel;
    }

    public Date getDataProcs() {
        if (dataProcs != null) {
            return (Date) dataProcs.clone();
        }
        return null;
    }

    public void setDataProcs(Date dataProcs) {
        this.dataProcs = (Date) dataProcs.clone();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getComentario() {
        return mensagemComentario;
    }

    public void setComentario(String comentario) {
        this.mensagemComentario = comentario;
    }

    public String getPerfilUsuario() {
        return perfilUsuario;
    }

    public void setPerfilUsuario(String perfilUsuario) {
        this.perfilUsuario = perfilUsuario;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public Date getDataInclusao() {
        if (dataInclusao != null) {
            return (Date) dataInclusao.clone();
        }
        return null;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = (Date) dataInclusao.clone();
    }

}
