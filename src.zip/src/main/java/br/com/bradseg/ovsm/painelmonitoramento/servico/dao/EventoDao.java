package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;

import java.util.List;

/**
 * Interface dao para acesso base TPO_EVENTO_PNEL
 * 
 * @author Wipro
 */
public interface EventoDao {

    /**
     * Listar todos os tipos de evento.
     * 
     * @return Map<BigDecimal, String>
     */
    List<Evento> obterListaEvento();

}
