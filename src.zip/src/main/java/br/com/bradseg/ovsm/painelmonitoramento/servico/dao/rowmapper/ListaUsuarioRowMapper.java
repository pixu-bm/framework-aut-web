package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista de usuario row mappar: realiza o mapeamento para extração de uma lista de
 * usuarios
 *
 * @author Wipro
 */
public class ListaUsuarioRowMapper implements ResultSetExtractor<List<Usuario>> {

    @Override
    public List<Usuario> extractData(ResultSet rs) throws SQLException {
        List<Usuario> listaUsuario = new ArrayList<>();

        while (rs.next()) {
            Usuario usuario = new Usuario();
            usuario.setLogin(rs.getString("CUSUAR"));
            usuario.setNome(rs.getString("IUSUAR"));
            usuario.setNomeEmpresa(rs.getString("IEMPR"));
            usuario.setNomeDepartamento(rs.getString("IDEPTO"));
            usuario.setPerfil(rs.getString("RTPO_PRFIL"));

            String codigoStatus = rs.getString("CSTTUS_CAD");

            if ("AGARD".equals(codigoStatus)) {
                usuario.setStatus("PENDENTE");
            }

            if ("APROV".equals(codigoStatus)) {
                usuario.setStatus("ATIVO");
            }

            if ("CANCEL".equals(codigoStatus)) {
                usuario.setStatus("CANCELADO");
            }

            if ("NEGAD".equals(codigoStatus)) {
                usuario.setStatus("REJEITADO");
            }

            usuario.setDataSolicitacao(rs.getDate("AINCL"));
            usuario.setDataSolicitacaoFmt(Utils.javaDateFormatoBrasil(usuario.getDataSolicitacao()));

            listaUsuario.add(usuario);
        }

        return listaUsuario;
    }

}
