package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Parametro Evento
 * 
 * @author Wipro
 */
public class ParametroEvento extends ParametroEventoSuper {

    private Integer quantidadeTransacaoOnline;
    private Integer quantidadeTransacaoOffline;
    private Integer quantidadeMinimaEventoModerado;
    private Integer quantidadeMaximaEventoModerado;
    private Integer quantidadeMinimaEventoAlto;
    private Integer quantidadeMaximaEventoAlto;
    private Integer quantidadeMinimaEventoVolumeModerado;
    private Integer quantidadeMaximaEventoVolumeModerado;
    private Integer quantidadeMinimaEventoVolumeAlto;
    private Integer quantidadeMaximaEventoVolumeAlto;
    private Integer quantidadeLimiteEventoVolumeBemBaixo;

    public ParametroEvento() {
        super();
    }

    public Integer getQuantidadeTransacaoOnline() {
        return quantidadeTransacaoOnline;
    }

    public void setQuantidadeTransacaoOnline(Integer quantidadeTransacaoOnline) {
        this.quantidadeTransacaoOnline = quantidadeTransacaoOnline;
    }

    public Integer getQuantidadeTransacaoOffline() {
        return quantidadeTransacaoOffline;
    }

    public void setQuantidadeTransacaoOffline(Integer quantidadeTransacaoOffline) {
        this.quantidadeTransacaoOffline = quantidadeTransacaoOffline;
    }

    public Integer getQuantidadeMinimaEventoModerado() {
        return quantidadeMinimaEventoModerado;
    }

    public void setQuantidadeMinimaEventoModerado(Integer quantidadeMinimaEventoModerado) {
        this.quantidadeMinimaEventoModerado = quantidadeMinimaEventoModerado;
    }

    public Integer getQuantidadeMaximaEventoModerado() {
        return quantidadeMaximaEventoModerado;
    }

    public void setQuantidadeMaximaEventoModerado(Integer quantidadeMaximaEventoModerado) {
        this.quantidadeMaximaEventoModerado = quantidadeMaximaEventoModerado;
    }

    public Integer getQuantidadeMinimaEventoAlto() {
        return quantidadeMinimaEventoAlto;
    }

    public void setQuantidadeMinimaEventoAlto(Integer quantidadeMinimaEventoAlto) {
        this.quantidadeMinimaEventoAlto = quantidadeMinimaEventoAlto;
    }

    public Integer getQuantidadeMaximaEventoAlto() {
        return quantidadeMaximaEventoAlto;
    }

    public void setQuantidadeMaximaEventoAlto(Integer quantidadeMaximaEventoAlto) {
        this.quantidadeMaximaEventoAlto = quantidadeMaximaEventoAlto;
    }

    public Integer getQuantidadeMinimaEventoVolumeModerado() {
        return quantidadeMinimaEventoVolumeModerado;
    }

    public void setQuantidadeMinimaEventoVolumeModerado(Integer quantidadeMinimaEventoVolumeModerado) {
        this.quantidadeMinimaEventoVolumeModerado = quantidadeMinimaEventoVolumeModerado;
    }

    public Integer getQuantidadeMaximaEventoVolumeModerado() {
        return quantidadeMaximaEventoVolumeModerado;
    }

    public void setQuantidadeMaximaEventoVolumeModerado(Integer quantidadeMaximaEventoVolumeModerado) {
        this.quantidadeMaximaEventoVolumeModerado = quantidadeMaximaEventoVolumeModerado;
    }

    public Integer getQuantidadeMinimaEventoVolumeAlto() {
        return quantidadeMinimaEventoVolumeAlto;
    }

    public void setQuantidadeMinimaEventoVolumeAlto(Integer quantidadeMinimaEventoVolumeAlto) {
        this.quantidadeMinimaEventoVolumeAlto = quantidadeMinimaEventoVolumeAlto;
    }

    public Integer getQuantidadeMaximaEventoVolumeAlto() {
        return quantidadeMaximaEventoVolumeAlto;
    }

    public void setQuantidadeMaximaEventoVolumeAlto(Integer quantidadeMaximaEventoVolumeAlto) {
        this.quantidadeMaximaEventoVolumeAlto = quantidadeMaximaEventoVolumeAlto;
    }

    public Integer getQuantidadeLimiteEventoVolumeBemBaixo() {
        return quantidadeLimiteEventoVolumeBemBaixo;
    }

    public void setQuantidadeLimiteEventoVolumeBemBaixo(Integer quantidadeLimiteEventoVolumeBemBaixo) {
        this.quantidadeLimiteEventoVolumeBemBaixo = quantidadeLimiteEventoVolumeBemBaixo;
    }

}
