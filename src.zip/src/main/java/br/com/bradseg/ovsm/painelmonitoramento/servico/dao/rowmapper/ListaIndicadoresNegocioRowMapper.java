package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.IndicadoresNegocio;

/**
 * Volumetria tempo real volumetria maxima mapa objetos extração de base de
 * dados.
 * 
 * @author Wipro
 */
public class ListaIndicadoresNegocioRowMapper implements RowMapper<List<IndicadoresNegocio>> {

    private static final Log LOGGER = LogFactory
        .getLog(ListaIndicadoresNegocioRowMapper.class);
    private static final int INT_3600 = 3600;
    private static final int INT_60 = 60;
    private static final int INT_10 = 10;

    @Override
    public List<IndicadoresNegocio> mapRow(ResultSet rs, int rowNum) throws SQLException {

        List<IndicadoresNegocio> listIndicadoresNegocio = new ArrayList<>();

        while (rs.next()) {
            IndicadoresNegocio indicadoresNegocio = new IndicadoresNegocio();
            indicadoresNegocio.setTotalTransacoes(rowNum);
            try {
                if (rs.getString("PRODUTO") != null) {
                    indicadoresNegocio.setProduto(rs.getString("PRODUTO"));
                }
                if (rs.getString("CANAL") != null) {
                    indicadoresNegocio.setCanal(rs.getString("CANAL"));
                }
            } catch (SQLException e) {
                LOGGER.info(e);
                indicadoresNegocio.setProduto("");
                indicadoresNegocio.setCanal("");
            }
            indicadoresNegocio.setTotalTransacoes(rs.getInt("SOMA_TRANSACOES"));
            indicadoresNegocio.setQtdEventos(rs.getInt("SOMA_EVENTOS"));
            indicadoresNegocio.setTempoTotalEventos(formatoHoraMinutoSegundoLista(rs.getLong("SOMA_TEMPO_EVENTOS")));
            indicadoresNegocio.setTransacoesImpactadas(rs.getInt("TRANSACOES_IMPACTADAS"));
            indicadoresNegocio.setFrequenciaEventos(rs.getInt("FREQUENCIA_EVENTOS"));
            indicadoresNegocio.setTempoMedioEventos(formatoHoraMinutoSegundoLista(rs.getLong("MEDIA_TEMPO_EVENTOS")));

            listIndicadoresNegocio.add(indicadoresNegocio);
        }
        return listIndicadoresNegocio;
    }

    private static String formatoHoraMinutoSegundoLista(Long segundosList) {

        Long horasList = (segundosList / INT_3600);

        Long minutosList = ((segundosList - (horasList * INT_60 * INT_60)) / INT_60);

        Long segundosLocalList = segundosList - (horasList * INT_60 * INT_60) - (minutosList * INT_60);

        String strHorasList = "";
        String srtMinutosList = "";
        String srtSegundosList = "";

        if (horasList < INT_10) {
            strHorasList = "0" + horasList;
        } else {
            strHorasList = horasList.toString();
        }

        if (minutosList < INT_10) {
            srtMinutosList = "0" + minutosList;
        } else {
            srtMinutosList = minutosList.toString();
        }

        if (segundosLocalList < INT_10) {
            srtSegundosList = "0" + segundosLocalList;
        } else {
            srtSegundosList = segundosLocalList.toString();
        }

        return strHorasList + ":" + srtMinutosList + ":" + srtSegundosList;
    }
}
