/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.DepartamentoUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ListaDepartamentoUsuarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ListaEmpresaUsuarioResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.PerfilResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.LoginRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.SolicitacaoAcessoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.LoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.sql.SQLException;
import java.util.List;

/**
 * Classe responsável por expor rest e controlar serviços de login
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/login")
public class LoginController {

    private static final Logger LOGGER = LogManager.getLogger(LoginController.class);

    public static final String SUCESSO = "Sucesso";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_3 = 3;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final String ERRO = "erro: ";
    public static final int CODIGO_RETORNO_4 = 4;
    @Autowired
    private LoginService loginService;

    public LoginController() {
        super();
    }

    /**
     * Serviço para logar no paineis de monitoramento OV
     *
     * @param login LoginRequest
     * @return ResponseEntity<ResponseMensagem>
     */
    @PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Serviço para logar no paineis de monitoramento OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "404", description = "Login não encontrado"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> logar(@RequestBody LoginRequest login) {

        try {

            loginService.validarLogin(login);
            Usuario usuario = new Usuario();
            usuario.setLogin(login.getLogin());

            String perfil = loginService.logar(usuario);
            PerfilResponse perfilResponse = new PerfilResponse();
            perfilResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            perfilResponse.setMensagem(SUCESSO);
            perfilResponse.setPerfil(perfil);

            return ResponseEntity.ok(perfilResponse);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumentException = new ResponseMensagem();
            mensagemIllegalArgumentException.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumentException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumentException.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagemEmptyResultDataAccessException = new ResponseMensagem();
            mensagemEmptyResultDataAccessException.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagemEmptyResultDataAccessException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                mensagemEmptyResultDataAccessException.getMensagem() + ";" + CODIGO_RETORNO_3, e);

        } catch (SQLException e) {
            ResponseMensagem mensagemBancodedados = new ResponseMensagem();
            mensagemBancodedados.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemBancodedados.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemBancodedados.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }
    }

    /**
     * Serviço para listar todas as empresas em que usuário pode pertencer.
     *
     * @return ResponseEntity<ResponseMensagem>
     * @throws SQLException
     */
    @GetMapping(value = "/empresaUsuario")
    @Operation(summary = "Serviço para listar todas as empresas em que usuário pode pertencer.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> listarEmpresaUsuario() throws SQLException {
        try {
            List<EmpresaUsuario> listaEmpresaUsuario = loginService.listarEmpresaUsuario();

            ListaEmpresaUsuarioResponse listaEmpresaUsuarioResponse = new ListaEmpresaUsuarioResponse();
            listaEmpresaUsuarioResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            listaEmpresaUsuarioResponse.setMensagem(SUCESSO);

            listaEmpresaUsuarioResponse.setListaEmpresaUsuarioResponse(listaEmpresaUsuario);

            return ResponseEntity.ok(listaEmpresaUsuarioResponse);

        } catch (SQLException e) {
            ResponseMensagem mensagemErroSql = new ResponseMensagem();
            mensagemErroSql.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemErroSql.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroSql.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (ResponseStatusException e) {
            ResponseMensagem mensagemErroPadrao = new ResponseMensagem();
            mensagemErroPadrao.setCodigoRetorno(CODIGO_RETORNO_99);
            mensagemErroPadrao.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroPadrao.getMensagem() + ";" + CODIGO_RETORNO_99, e);
        }
    }

    /**
     * Lista todos os departamentos associados a uma empresa
     *
     * @param codigoEmpresa
     * @return ResponseEntity<ResponseMensagem>
     * @throws SQLException
     */
    @GetMapping("/departamentoUsuarioEmpresa")
    @Operation(summary = "Lista todos os departamentos associados a uma empresa")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> listarDepartamentoUsuarioEmpresa(
        @RequestParam(name = "codigoEmpresa") String codigoEmpresa) throws SQLException {
        try {

            loginService.validarParametroEmpresaUsuario(codigoEmpresa);
            List<DepartamentoUsuario> listaDepartamentoUsuario = loginService
                .listarDepartamentoUsuarioEmpresa(codigoEmpresa);
            ListaDepartamentoUsuarioResponse departamentoUsuarioResponse = new ListaDepartamentoUsuarioResponse();
            departamentoUsuarioResponse.setCodigoRetorno(CODIGO_RETORNO_0);
            departamentoUsuarioResponse.setMensagem(SUCESSO);
            departamentoUsuarioResponse.setListaDepartamentoUsuario(listaDepartamentoUsuario);

            return ResponseEntity.ok(departamentoUsuarioResponse);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegal = new ResponseMensagem();
            mensagemIllegal.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegal.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegal.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (DataIntegrityViolationException e) {

            ResponseMensagem mensagemDataIntegrityViolationException = new ResponseMensagem();
            mensagemDataIntegrityViolationException.setCodigoRetorno(CODIGO_RETORNO_4);
            mensagemDataIntegrityViolationException.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemDataIntegrityViolationException.getMensagem() + ";" + CODIGO_RETORNO_4, e);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQLEx = new ResponseMensagem();
            mensagemSQLEx.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLEx.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLEx.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (ResponseStatusException e) {
            ResponseMensagem mensagemExce = new ResponseMensagem();
            mensagemExce.setCodigoRetorno(CODIGO_RETORNO_99);
            mensagemExce.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemExce.getMensagem() + ";" + CODIGO_RETORNO_99, e);

        }

    }

    /**
     * Serviço para solicitar acesso a um usuário que não existe no portal OV.
     *
     * @param solicitarAcesso SolicitacaoAcessoRequest
     * @return ResponseEntity<ResponseMensagem>
     * @throws SQLException
     */
    @PostMapping(value = "/solicitarAcesso", consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Serviço para solicitar acesso a um usuário que não existe no portal OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> solicitarAcesso(@RequestBody SolicitacaoAcessoRequest solicitarAcesso)
        throws SQLException {
        try {
            loginService.validarSolicitacaoAcesso(solicitarAcesso);
            Usuario usuario = new Usuario(solicitarAcesso);
            loginService.inserirUsuarioAprovacao(usuario);

            ResponseMensagem responseMensagem = new ResponseMensagem();
            responseMensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            responseMensagem.setMensagem(SUCESSO);

            return ResponseEntity.ok(responseMensagem);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegalArgumen = new ResponseMensagem();
            mensagemIllegalArgumen.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegalArgumen.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegalArgumen.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        } catch (DataIntegrityViolationException e) {
            ResponseMensagem mensagemDataIntegrity = new ResponseMensagem();
            mensagemDataIntegrity.setCodigoRetorno(CODIGO_RETORNO_4);
            mensagemDataIntegrity.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemDataIntegrity.getMensagem() + ";" + CODIGO_RETORNO_4, e);

        } catch (SQLException e) {
            ResponseMensagem mensagemSQLExcep = new ResponseMensagem();
            mensagemSQLExcep.setCodigoRetorno(CODIGO_RETORNO_2);
            mensagemSQLExcep.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemSQLExcep.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (ResponseStatusException e) {
            ResponseMensagem mensagemExcepti = new ResponseMensagem();
            mensagemExcepti.setCodigoRetorno(CODIGO_RETORNO_99);
            mensagemExcepti.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemExcepti.getMensagem() + ";" + CODIGO_RETORNO_99, e);
        }

    }

}
