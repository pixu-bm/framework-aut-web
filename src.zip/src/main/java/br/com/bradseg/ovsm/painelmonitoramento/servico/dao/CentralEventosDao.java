package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.GraficoDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RelaciondosDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEventoProduto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralProduto;

/**
 * Central eventos dao interface
 *
 * @author Wipro
 */
public interface CentralEventosDao {

    /**
     * Obter visão evento em aberto.
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return VisaoEvento
     */
    VisaoEvento obterVisaoEventoAberto(Date dataInicio, Date dataFim);

    /**
     * Obter visão evento por produtos
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoProduto>
     */
    List<VisaoEventoProduto> obterVisaoEventoProduto(Date dataInicio, Date dataFim);

    /**
     * Obter visão evento por canal
     *
     * @param dataInicio Date
     * @param dataFim    Date
     * @return List<VisaoEventoCanal>
     */
    List<VisaoEventoCanal> obterVisaoEventoCanal(Date dataInicio, Date dataFim);

    /**
     * Obter lista de registros de evento
     *
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @param statusEvento       Integer
     * @param dataInicio         Date
     * @param dataFim            Date
     * @param codigoTipoEvento   BigDecimal
     * @return List<RegistroEvento>
     */
    List<RegistroEvento> obterRegistroEvento(List<BigDecimal> listaCodigoProduto,
      List<BigDecimal> listaCodigoCanal,
      Integer statusEvento, Date dataInicio,
      Date dataFim,
      BigDecimal codigoTipoEvento);

    /**
     * Obter visao evento dentalhe
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     * @return VisaoGeralProduto
     */
    VisaoGeralProduto obterVisaoEventoProdutoDetalhe(Integer periodoVisaoEvento, BigDecimal codigoProduto);

    /**
     * Obter visao evento dentalhe canal
     *
     * @param periodoVisaoEvento Integer
     * @param codigoCanal        BigDecimal
     * @return VisaoGeralProduto
     */
    VisaoGeralCanal obterVisaoEventoCanalDetalhe(Integer periodoVisaoEvento, BigDecimal codigoCanal);

    /**
     * Obter visao evento dentalhe produto / canal
     *
     * @param periodoVisaoEvento Integer
     * @param codigoProduto      BigDecimal
     *                           <<<<<<< HEAD
     * @param codigoCanal        BigDecimal
     *                           =======
     * @param codigoCanal        BigDecimal
     *                           >>>>>>> bb86f73 (SHOLOVSM00-58:Add correçoes de
     *                           bugs central de evento)
     * @return List<VisaoDetalhadaProdutoCanal>
     */
    List<VisaoDetalhadaProdutoCanal> obterListaEventoProdutoCanalDetalhe(Integer periodoVisaoEvento,
      BigDecimal codigoProduto, BigDecimal codigoCanal);

    /**
     * Obter status detalhe evento
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @param periodoTempo      Integer
     * @param statusEvento      Integer
     * @return List<StatusDetalheEvento>
     */
    List<StatusDetalheEvento> obterStatusDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
      BigDecimal codigoProduto, BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo,
      Integer statusEvento);

    /**
     * Obter grafico detalhe evento
     *
     * @param codigoErro        Integer
     * @param codigoEmpresa     BigDecimal
     * @param codigoProduto     BigDecimal
     * @param codigoCanal       BigDecimal
     * @param dataProcessamento Date
     * @return List<GraficoDetalheEvento>
     */
    List<GraficoDetalheEvento> obterGraficoDetalheEvento(Integer codigoErro, BigDecimal codigoEmpresa,
      BigDecimal codigoProduto, BigDecimal codigoCanal, Date dataProcessamento);

    /**
     * Obter lista detalhe evento relacionados
     *
     * @param codigoErro Integer
     * @param limite     Integer
     * @param linha      Integer
     * @return List<RelaciondosDetalheEvento>
     */
    List<RelaciondosDetalheEvento> obterDetalheEventoRelacionados(Integer codigoErro, Integer limite,
      Integer linha);

    /**
     * Obter total evento relacionados
     *
     * @param codigoErro Integer
     * @return Integer
     */
    Integer obterTotalEventoRelacionados(Integer codigoErro);

}
