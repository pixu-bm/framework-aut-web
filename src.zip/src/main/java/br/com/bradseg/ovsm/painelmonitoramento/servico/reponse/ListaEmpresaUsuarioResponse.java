package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Lista de empresas de usuário response
 * @author Wipro
 *
 */
public class ListaEmpresaUsuarioResponse extends ResponseMensagem {

    private List<EmpresaUsuario> listaEmpresasUsuarioResponse;

    public ListaEmpresaUsuarioResponse() {
        super();
    }

    public List<EmpresaUsuario> getListaEmpresaUsuarioResponse() {
        return  Collections.unmodifiableList(listaEmpresasUsuarioResponse);
    }

    public void setListaEmpresaUsuarioResponse(List<EmpresaUsuario> listaEmpresaUsuarioResponse) {
        this.listaEmpresasUsuarioResponse = 
            Collections.unmodifiableList(listaEmpresaUsuarioResponse);
    }

}
