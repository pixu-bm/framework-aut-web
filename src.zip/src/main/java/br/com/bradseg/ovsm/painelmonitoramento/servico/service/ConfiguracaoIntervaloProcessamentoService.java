package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;

import java.math.BigDecimal;
import java.sql.SQLException;

/**
 * Interface para serviços de configuração de intervalo de processamento de
 * monitoramento de serviços do painel OV
 * 
 * @author Wipro
 */
public interface ConfiguracaoIntervaloProcessamentoService {

    /**
     * Listar todos os dados e parametros de configuração de intervalo de
     * processamento.
     * 
     * @return ConfiguracaoIntervaloProcessamentoResponse
     * @throws SQLException
     */
    ConfiguracaoIntervaloProcessamentoResponse obterConfiguracaoIntervaloProcessamento(BigDecimal codigoEmpresa,
        BigDecimal codigoProduto, BigDecimal codigoCanal) throws SQLException;

    /**
     * Validar parametro de configuração de intervalo de processamento
     * 
     * @param configuracaoIntervaloProcessamentoRequest ConfiguracaoIntervaloProcessamentoRequest
     */
    void validarParametroConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest);

    /**
     * 
     * @param configuracaoIntervaloProcessamento ConfiguracaoIntervaloProcessamento
     * @throws SQLException
     */
    void inserirConfiguracaoIntervaloProcessamento(
        ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento) throws SQLException;

    /**
     * Obter parametro Evento
     * 
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal   BigDecimal
     * @return ParametroEvento
     * @throws SQLException
     */
    ParametroEvento obterParametroEvento(BigDecimal codigoEmpresa, BigDecimal codigoProduto,
        BigDecimal codigoCanal) throws SQLException;

    /**
     * Atualizar parametro evento
     * 
     * @param parametroEvento ParametroEventoRequest 
     */
    void atualizarParametroEvento(ParametroEventoRequest parametroEvento) throws SQLException;

    /**
     * Valida se parametro evento está de acordo 
     * para inserir dados
     * 
     * @param parametroEvento ParametroEventoRequest
     */
    void validarParametroEvento(ParametroEventoRequest parametroEvento);
}
