package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils;

/**
 * Classe responsável por implementar constantes da aplicação
 *
 * @author Wipro
 */
public final class Constantes {

    public static final String OWNER_TABELA = "OVSM.";

    public static final String OWNER_TABELA_DWMF = "DWMF.";

    public static final String ERROR = "Error: ";

    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    public static final String CONSULTA_SEM_RESULTADO = "Consulta sem resultado";

    public static final String FROM = " FROM ";

    public static final int INT_30 = 30;

    public static final int INT_7 = 7;

    public static final int INT_2 = 2;

    public static final int INT_1 = 1;

    public static final String SELECT = " SELECT ";
    
    public static final String JOIN = " JOIN ";

    public static final int INT_0 = 0;

    public static final int INT_4 = 4;

    public static final int INT_5 = 5;

    public static final int INT_3 = 3;

    public static final String PERIODO = "periodo";

    public static final String DATA_FIM = "dataFim";

    public static final String DATA_INICIO = "dataInicio";

    public static final String ERRO_DE_VIOLACAO_DE_INTEGRIDADE = "Erro de violação de integridade.";

    public static final String RESULTADO_NAO_ENCONTRADO = "Resultado não encontrado.";

    public static final String RESULTADO_VAZIO = "Resultado não pode ser vazio.";
    
    public static final int RESPONSE_CODE_400 = 400;
    
    public static final int RESPONSE_CODE_200 = 200;
    
    public static final String PLATA_FORMA_ORIGN = "API";
    
    public static final int CORRIGE_DADO = 850;
    
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_3 = 3;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";

    private Constantes() {
        super();
    }

}
