package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.CanalService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Classe responsável por implementar Canal service
 * @author Wipro
 */
@Service
public class CanalServiceImpl implements CanalService {

    private static final Log LOGGER = LogFactory.getLog(CanalServiceImpl.class);

    private CanalDao canalDao;

    @Autowired
    public CanalServiceImpl(CanalDao canalDao) {
        this.canalDao = canalDao;
    }

    /**
    * {@inheritDoc}
    */
    public List<Canal> obterCanais() {
        try {
            return canalDao.listarCanal();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
