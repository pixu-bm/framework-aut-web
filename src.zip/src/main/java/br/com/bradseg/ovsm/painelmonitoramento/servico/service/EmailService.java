package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

public interface EmailService {
    
    
    void enviarEmail(String destinatario, String mensagem, String assunto);

}
