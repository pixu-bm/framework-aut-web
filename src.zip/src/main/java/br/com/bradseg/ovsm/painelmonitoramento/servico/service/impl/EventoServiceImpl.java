package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EventoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EventoService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Configuração de intervalo processamento service.
 * 
 * @author Wipro
 */
@Service
public class EventoServiceImpl implements EventoService {

    private static final Log LOGGER = LogFactory
        .getLog(EventoServiceImpl.class);
    public static final String ERROR = "Error: ";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private EventoDao eventoDao;

    @Autowired
    public EventoServiceImpl(EventoDao eventoDao) {
        this.eventoDao = eventoDao;
    }

    /**
     * {@inheritDoc}
     */
    public List<Evento> obterListaEvento() {
        try {
            return eventoDao.obterListaEvento();
        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(),
                e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
