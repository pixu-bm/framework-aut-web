package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EmpresaCombo;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmpresaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Classe rest
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/empresa")
public class EmpresaController {

    private static final Logger LOGGER = LogManager.getLogger(EmpresaController.class);

    public static final int CODIGO_RETORNO_99 = 99;
    public static final int CODIGO_RETORNO_1 = 1;
    public static final int CODIGO_RETORNO_0 = 0;
    public static final String SUCESSO = "Sucesso";
    public static final String ERRO = "erro: ";

    @Autowired
    public EmpresaService empresaService;

    public EmpresaController() {
        super();
    }

    @GetMapping("/")
    @Operation(summary = "Obtem todos as empresas para pesquisa criação de "
        + "combo box nos paineis OV.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = SUCESSO),
        @ApiResponse(responseCode = "400", description = "Requisição com erro"),
        @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterEmpresa() {

        try {
            List<Empresa> empresas = empresaService.obterEmpresas();
            EmpresaCombo empresaCombo = new EmpresaCombo();
            empresaCombo.setCodigoRetorno(CODIGO_RETORNO_0);
            empresaCombo.setMensagem(SUCESSO);
            empresaCombo.setEmpresaCombos(empresas);

            return ResponseEntity.ok(empresaCombo);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagemIllegal = new ResponseMensagem();
            mensagemIllegal.setCodigoRetorno(CODIGO_RETORNO_1);
            mensagemIllegal.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegal.getMensagem() + ";" + CODIGO_RETORNO_1, e);

        }

    }
}
