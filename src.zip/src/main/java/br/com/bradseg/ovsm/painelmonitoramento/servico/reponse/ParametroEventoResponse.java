package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ParametroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

/**
 * Parametro evento response
 * 
 * @author Wipro
 */
public class ParametroEventoResponse extends ResponseMensagem {

    private ParametroEvento parametroEvento;

    public ParametroEventoResponse() {
        super();
    }

    public ParametroEvento getParametroEvento() {
        return parametroEvento;
    }

    public void setParametroEvento(ParametroEvento parametroEvento) {
        this.parametroEvento = parametroEvento;
    }
}
