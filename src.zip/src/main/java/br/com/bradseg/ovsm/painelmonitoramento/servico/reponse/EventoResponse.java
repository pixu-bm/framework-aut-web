package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Evento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Evento response.
 * 
 * @author Wipro
 */
public class EventoResponse extends ResponseMensagem {

    private List<Evento> listaEvento;

    public EventoResponse() {
        super();
    }

    public List<Evento> getListaEvento() {
        return Collections.unmodifiableList(listaEvento);
    }

    public void setListaEvento(List<Evento> listaEvento) {
        this.listaEvento = Collections.unmodifiableList(listaEvento);
    }

}
