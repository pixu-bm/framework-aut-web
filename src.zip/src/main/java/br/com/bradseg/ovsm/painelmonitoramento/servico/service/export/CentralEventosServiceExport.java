package br.com.bradseg.ovsm.painelmonitoramento.servico.service.export;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.LoginDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.RegistroEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoDetalhadaProdutoCanal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.utils.PlanilhaUtils;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Classe central de eventos service para exportação de arquivos.
 *
 * @author Wipro
 */
@Service
public class CentralEventosServiceExport {

    public static final int MARGIN_LEFT_30 = 30;
    public static final int INT_9 = 9;
    private static final int INT_6 = 6;
    private static final int INT_5 = 5;
    public static final int INT_4 = 4;
    public static final int INT_3 = 3;
    public static final int INT_2 = 2;
    public static final int INT_1 = 1;
    public static final int INT_0 = 0;
    private static final float FLOAT_0_3 = 0.3F;
    private static final int INT_7 = 7;
    private static final int INT_8 = 8;
    private static final int INT_10 = 10;
    private static final int INT_11 = 11;
    private static final int INT_13 = 13;
    private static final int INT_99 = 99;
    private static final int INT_100 = 100;
    public static final int MARGIN_RIGHT_30 = 30;
    public static final int MARGIN_TOP_20 = 20;
    public static final int MARGIN_BOTTOM_20 = 20;
    public static final int INT_70 = 70;
    private static final String PRODUTO = "Produto";
    private static final String CANAL = "Canal";
    private static final String GRAVIDADE = "Gravidade";
    private static final String DURACAO = "Duração";
    private static final String TIPO = "Tipo";
    private static final String TRANSACAO = "Transação";
    private static final String DATA_INICIO_EVENTO = "Data inicio evento";
    private static final String RECORRENCIA = "Recorrencia";
    private static final String FILTROS_APLICADOS = "Filtros aplicados";
    private static final String PERIODO = "Periodo";

    private LoginDao loginDao;

    private ProdutoDao produtoDao;

    private CanalDao canalDao;

    private static final Log LOGGER = LogFactory
        .getLog(CentralEventosServiceExport.class);

    @Autowired
    public CentralEventosServiceExport(LoginDao loginDao, ProdutoDao produtoDao, CanalDao canalDao) {
        this.loginDao = loginDao;
        this.produtoDao = produtoDao;
        this.canalDao = canalDao;
    }

    /**
     * Obter arquivo registro evento
     *
     * @param listaRegistroEvento List<RegistroEvento>
     * @return Workbook
     */
    public Workbook obterArquivoRegistroEventoExcel(
        List<RegistroEvento> listaRegistroEvento, String login,
        Date dataInicio, Date dataFim,
        List<BigDecimal> listaProduto, List<BigDecimal> listaCanal) {

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Eventos");
        int countSheet = INT_0;

        Row row = sheet.createRow(countSheet);

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Object[] objectArray = {login, dataInicio, dataFim, listaProduto,
            listaCanal};

        montarCabecalhoRegistroEventoExcel(wb, sheet, countSheet, row,
            objectArray);

        countSheet = INT_9;
        row = sheet.createRow(countSheet);
        int count = INT_0;

        String[] valoresCabecalho = {GRAVIDADE, PRODUTO,
            CANAL, TIPO, TRANSACAO, DATA_INICIO_EVENTO, RECORRENCIA,
            DURACAO};

        for (int i = INT_0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDescricaoGravidade());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDescricaoProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDescricaoCanal());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDescricaoTipo());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getNumeroTransacao().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDataInicioEvento());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getRecorrencia().toString());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistroEvento.get(i).getDuracao());

        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    /**
     * Obter arquivo registro evento
     *
     * @param listaRegistroEvento List<RegistroEvento>
     * @param login               String
     * @param dataInicio          Date
     * @param dataFim             Date
     * @param listaProduto        List<BigDecimal>
     * @param listaCanal          List<BigDecimal>
     * @return Workbook
     */
    public ByteArrayInputStream obterArquivoRegistroEventoPDF(
        List<RegistroEvento> listaRegistroEvento, String login,
        Date dataInicio, Date dataFim,
        List<BigDecimal> listaProduto, List<BigDecimal> listaCanal) {
        Document documento = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        Integer graves = INT_0;
        Integer moderado = INT_0;

        if (listaRegistroEvento != null) {
            for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
                if ("EVENTO GRAVE".equalsIgnoreCase(listaRegistroEvento.get(i).getDescricaoGravidade())) {
                    graves++;
                } else {
                    moderado++;
                }
            }
        }
        
        try {
            
            documento.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documento, out);

            documento.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT_9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT_9, BaseColor.BLACK);

            String dataInicioStr = Utils.javaDateFormatoBrasil(dataInicio);
            String dataFimStr = Utils.javaDateFormatoBrasil(dataFim);

            Object[] objectArray = {login, dataInicioStr, dataFimStr, listaProduto, listaCanal, graves, moderado};
            documento = montarCabecalhoRegistroEventoPDF(documento, objectArray, font1, font2);

            documento = montarListaRegistroEventoPDF(documento, listaRegistroEvento, font1, font2);
            documento.close();

        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }

        try {

            return new ByteArrayInputStream(out.toByteArray());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Obter arquivo registro evento
     *
     * @param listaRegistroEvento List<RegistroEvento>
     * @param login               String
     * @param dataInicio          Date
     * @param dataFim             Date
     * @param codigoProduto       List<BigDecimal>
     * @param codigoCanal         List<BigDecimal>
     * @return Workbook
     */
    public ByteArrayInputStream obterArquivoRegistroProdutoCanalEventoPDF(
        List<VisaoDetalhadaProdutoCanal> listaRegistro, Integer periodoVisaoEvento, List<BigDecimal> codigoProduto,
        List<BigDecimal> codigoCanal, String login) {
        Document documento = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String dataInicio;
        String dataFim = Utils.javaDateFormatoBrasil(Date.from(Instant.now()));
        try {

            Integer graves = INT_0;
            Integer moderados = INT_0;

            if (listaRegistro != null) {
                for (int i = INT_0; i < listaRegistro.size(); i++) {
                    graves += listaRegistro.get(i).getEventoGrave().intValue();
                    moderados += listaRegistro.get(i).getEventoModerado().intValue();
                }
            }

            documento.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documento, out);

            documento.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT_9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT_9, BaseColor.BLACK);

            dataInicio = Utils.javaDateFormatoBrasil(DateUtils.addDays(Date.from(Instant.now()), -periodoVisaoEvento));

            Object[] objectArray = {login, dataInicio, dataFim, codigoProduto, codigoCanal, graves,
                moderados};

            documento = montarCabecalhoRegistroEventoPDF(documento, objectArray, font1, font2);

            documento = montarListaRegistroProdutoCanalPDF(documento, listaRegistro, font1, font2);

            documento.close();

        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        try {

            return new ByteArrayInputStream(out.toByteArray());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Obter arquivo registro evento
     *
     * @param listaRegistroEvento List<RegistroEvento>
     * @param login               String
     * @param codigoErro          Integer
     * @param codigoEmpresa       BigDecimal
     * @param codigoProduto       BigDecimal
     * @param codigoCanal         BigDecimal
     * @param dataProcessamento   Date
     * @param periodoTempo        Integer
     * @param statusEvento        Integer
     * @return Workbook
     */
    public ByteArrayInputStream obterArquivoRegistroEventoDetalhadoPDF(
        List<StatusDetalheEvento> listaRegistro, String login, Integer codigoErro, BigDecimal codigoEmpresa,
        BigDecimal codigoProduto,
        BigDecimal codigoCanal, Date dataProcessamento, Integer periodoTempo, Integer statusEvento) {

        Document documento = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String dataInicio;
        String dataFim = Utils.javaDateFormatoBrasil(Date.from(Instant.now()));

        try {

            documento.setMargins(MARGIN_LEFT_30, MARGIN_RIGHT_30, MARGIN_TOP_20, MARGIN_BOTTOM_20);
            PdfWriter.getInstance(documento, out);

            documento.open();
            Font font1 = FontFactory.getFont(FontFactory.COURIER, INT_9, BaseColor.BLACK);
            Font font2 = FontFactory.getFont(FontFactory.COURIER_BOLD, INT_9, BaseColor.BLACK);

            if (periodoTempo == INT_99) {
                periodoTempo = 0;
            }

            dataInicio = Utils.javaDateFormatoBrasil(DateUtils.addDays(Date.from(Instant.now()), -periodoTempo));

            List<BigDecimal> produto = new ArrayList<>();
            produto.add(codigoProduto);
            List<BigDecimal> canal = new ArrayList<>();
            canal.add(codigoCanal);

            Integer graves = INT_0;
            Integer moderados = INT_0;

            if (listaRegistro != null) {
                graves = listaRegistro.get(0).getSomaEventoGrave().intValue();
                moderados = listaRegistro.get(0).getSomaEventoModerado().intValue();
                Object[] objectArray = {login, dataInicio, dataFim, produto, canal, graves,
                    moderados};

                documento = montarCabecalhoRegistroEventoPDF(documento, objectArray, font1, font2);

                documento = montarListaRegistroDetalhadoPDF(documento, listaRegistro.get(0).getListaEvento(), font1,
                    font2);
            } else {
                Object[] objectArray = {login, dataInicio, dataFim, produto, canal, graves,
                    moderados};

                documento = montarCabecalhoRegistroEventoPDF(documento, objectArray, font1, font2);

                documento = montarListaRegistroDetalhadoPDF(documento, null, font1,
                    font2);
            }

            documento.close();

        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }

        try {

            return new ByteArrayInputStream(out.toByteArray());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    private Document montarCabecalhoRegistroEventoPDF(Document documento, Object[] objectArray, Font font1,
        Font font2) {

        Usuario usuario = new Usuario();
        String login = (String) objectArray[INT_0];
        Integer graves = (Integer) objectArray[INT_5];
        Integer moderados = (Integer) objectArray[INT_6];
        Integer total = graves + moderados;

        usuario.setLogin(login.toUpperCase());

        try {
            usuario = loginDao.obterInformacaoUsuario(usuario);

            PdfPTable tabCab = new PdfPTable(INT_4);
            tabCab.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabCab.setWidthPercentage(INT_70);
            Map<Integer, String> linhaVazio = new HashMap<>();

            Map<Integer, String> linha1 = new HashMap<>();
            linha1.put(INT_1, "Usuário");
            linha1.put(INT_2, usuario.getNome());
            linha1.put(INT_3, "Versão de Central");
            linha1.put(INT_4, "1.0");
            tabCab = addCabecalhoRegistroEventoPDF(linha1, tabCab, font1, font2, INT_1, INT_0);

            Map<Integer, String> linha6 = new HashMap<>();
            linha6.put(INT_1, "Data e hora Exp");
            linha6.put(INT_2, toDate());
            linha6.put(INT_3, "");
            linha6.put(INT_4, "");
            tabCab = addCabecalhoRegistroEventoPDF(linha6, tabCab, font1, font2, INT_1, INT_0);

            // Add linha vazia
            tabCab = addCabecalhoRegistroEventoPDF(linhaVazio, tabCab, font1, font2, INT_3, INT_0);

            Map<Integer, String> linha2 = new HashMap<>();
            linha2.put(INT_1, FILTROS_APLICADOS);
            linha2.put(INT_2, "");
            tabCab = addCabecalhoRegistroEventoPDF(linha2, tabCab, font1, font2, INT_2, INT_0);

            Map<Integer, String> linha3 = new HashMap<>();
            linha3.put(INT_1, CANAL);
            if (objectArray[INT_4] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_4];
                String canais = obterTextoCanal(lista);
                linha3.put(INT_2, canais);
            } else {
                String valueEmpty = " ";
                linha3.put(INT_2, valueEmpty);
            }
            tabCab = addCabecalhoRegistroEventoPDF(linha3, tabCab, font1, font2, INT_2, INT_0);

            Map<Integer, String> linha4 = new HashMap<>();
            linha4.put(INT_1, PRODUTO);
            if (objectArray[INT_3] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_3];
                String produtos = obterTextoProdutos(lista);
                linha4.put(INT_2, produtos);
            } else {
                String valueEmpty = " ";
                linha4.put(INT_2, valueEmpty);
            }
            tabCab = addCabecalhoRegistroEventoPDF(linha4, tabCab, font1, font2, INT_2, INT_0);

            Map<Integer, String> linha5 = new HashMap<>();
            linha5.put(INT_1, PERIODO);
            linha5.put(INT_2, "de " + objectArray[INT_1] + " até " + objectArray[INT_2]);

            tabCab = addCabecalhoRegistroEventoPDF(linha5, tabCab, font1, font2, INT_2, INT_0);

            // Add linha vazia
            tabCab = addCabecalhoRegistroEventoPDF(linhaVazio, tabCab, font1, font2, INT_3, INT_0);

            Map<Integer, String> linha7 = new HashMap<>();
            linha7.put(INT_1, "Resumos");
            linha7.put(INT_2, "");
            tabCab = addCabecalhoRegistroEventoPDF(linha7, tabCab, font1, font2, INT_2, INT_0);

            Map<Integer, String> linha8 = new HashMap<>();
            linha8.put(INT_1, "Qtd de Eventos");
            linha8.put(INT_2, total.toString());
            linha8.put(INT_3, null);
            linha8.put(INT_4, null);
            tabCab = addCabecalhoRegistroEventoPDF(linha8, tabCab, font1, font2, INT_1, INT_0);

            Map<Integer, String> linha9 = new HashMap<>();
            linha9.put(INT_1, "Eventos Graves");
            linha9.put(INT_2, graves.toString());
            linha9.put(INT_3, null);
            linha9.put(INT_4, null);
            tabCab = addCabecalhoRegistroEventoPDF(linha9, tabCab, font1, font2, INT_1, INT_0);

            Map<Integer, String> linha10 = new HashMap<>();
            linha10.put(INT_1, "Eventos Moderados");
            linha10.put(INT_2, moderados.toString());
            linha10.put(INT_3, null);
            linha10.put(INT_4, null);
            tabCab = addCabecalhoRegistroEventoPDF(linha10, tabCab, font1, font2, INT_1, INT_0);

            tabCab.setSpacingAfter(INT_10);

            documento.add(tabCab);

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static Document montarListaRegistroEventoPDF(Document documento,
        List<RegistroEvento> listaRegistroEvento,
        Font font1, Font font2) {
        try {
            PdfPTable tabBodyLista = new PdfPTable(INT_8);
            tabBodyLista.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyLista.setWidthPercentage(INT_100);
            tabBodyLista.setSpacingBefore(INT_10);

            Map<Integer, String> cabecalho = new HashMap<>();
            cabecalho.put(INT_1, GRAVIDADE);
            cabecalho.put(INT_2, PRODUTO);
            cabecalho.put(INT_3, CANAL);
            cabecalho.put(INT_4, TIPO);
            cabecalho.put(INT_5, TRANSACAO);
            cabecalho.put(INT_6, DATA_INICIO_EVENTO);
            cabecalho.put(INT_7, RECORRENCIA);
            cabecalho.put(INT_8, DURACAO);

            for (Map.Entry<Integer, String> pair : cabecalho.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_0_3);
                col.setBorderColor(BaseColor.BLACK);
            }

            PdfPTable tabBodyItensLista = new PdfPTable(INT_8);
            tabBodyItensLista.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyItensLista.setWidthPercentage(INT_100);

            if (listaRegistroEvento != null) {
                for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoGravidade(),
                        tabBodyItensLista, font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoProduto(),
                        tabBodyItensLista,
                        font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoCanal(),
                        tabBodyItensLista,
                        font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoTipo(),
                        tabBodyItensLista,
                        font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(
                        listaRegistroEvento.get(i).getNumeroTransacao().toString(),
                        tabBodyItensLista, font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDataInicioEvento(),
                        tabBodyItensLista,
                        font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getQtdEventoUltimo30(),
                        tabBodyItensLista, font1);
                    tabBodyItensLista = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDuracao(),
                        tabBodyItensLista,
                        font1);
                }
            }

            documento.add(tabBodyLista);
            if (listaRegistroEvento != null) {
                documento.add(tabBodyItensLista);
            }

        } catch (AcessoADadosException ex) {
            LOGGER.error(Constantes.ERROR, ex);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException ex) {
            LOGGER.error(Constantes.ERROR, ex);
        }
        return documento;
    }

    private static Document montarListaRegistroProdutoCanalPDF(Document documento,
        List<VisaoDetalhadaProdutoCanal> listaRegistroEvento,
        Font font1, Font font2) {
        try {
            PdfPTable tabBody = new PdfPTable(INT_11);
            tabBody.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBody.setWidthPercentage(INT_100);
            tabBody.setSpacingBefore(INT_10);

            Map<Integer, String> cabecalho = new HashMap<>();
            cabecalho.put(INT_1, PRODUTO);
            cabecalho.put(INT_2, CANAL);
            cabecalho.put(INT_3, "Qtd eventos abertos");
            cabecalho.put(INT_4, "Qtd eventos fechados");
            cabecalho.put(INT_5, "Qtd eventos graves");
            cabecalho.put(INT_6, "Qtd eventos moderados");
            cabecalho.put(INT_7, "Qtd eventos disponibilidade");
            cabecalho.put(INT_8, "Qtd eventos funcional");
            cabecalho.put(INT_9, "Qtd eventos volumetria");
            cabecalho.put(INT_10, "Totalizado de eventos");
            cabecalho.put(INT_11, "Período");

            PdfPTable tabBodyItensListaRegistro = new PdfPTable(INT_11);
            tabBodyItensListaRegistro.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyItensListaRegistro.setWidthPercentage(INT_100);

            for (Map.Entry<Integer, String> pairListaRegistro : cabecalho.entrySet()) {
                PdfPCell colListaRegistro = new PdfPCell();
                colListaRegistro.setBackgroundColor(BaseColor.LIGHT_GRAY);
                colListaRegistro.setHorizontalAlignment(Element.ALIGN_CENTER);
                colListaRegistro.setPhrase(new Phrase(pairListaRegistro.getValue(), font2));
                colListaRegistro.setBorderWidth(FLOAT_0_3);
                colListaRegistro.setBorderColor(BaseColor.BLACK);
                tabBodyItensListaRegistro.addCell(colListaRegistro);
            }

            if (listaRegistroEvento != null) {
                for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
                    tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getProduto(),
                        tabBodyItensListaRegistro, font1);
                    tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getCanal(),
                        tabBodyItensListaRegistro, font1);

                    auxilioMontarListaRegistroProdutoCanalPDF(listaRegistroEvento.get(i), tabBodyItensListaRegistro, font1);
                    
                    tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                        listaRegistroEvento.get(i).getTotal().toString(),
                        tabBodyItensListaRegistro, font1);
                    tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getPeriodo(),
                        tabBodyItensListaRegistro, font1);

                }
            }

            documento.add(tabBody);
            if (listaRegistroEvento != null) {
                documento.add(tabBodyItensListaRegistro);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static void auxilioMontarListaRegistroProdutoCanalPDF(VisaoDetalhadaProdutoCanal visaoDetalhadaProdutoCanal,
        PdfPTable tabBodyItensListaRegistro, Font font1) {
        

        if (visaoDetalhadaProdutoCanal.getEventoAberto() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoAberto().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }
        
        if (visaoDetalhadaProdutoCanal.getEventoFechado() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoFechado().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }

        if (visaoDetalhadaProdutoCanal.getEventoGrave() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoGrave().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }

        if (visaoDetalhadaProdutoCanal.getEventoModerado() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoModerado().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }

        if (visaoDetalhadaProdutoCanal.getEventoDisponibilidade() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoDisponibilidade().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }

        if (visaoDetalhadaProdutoCanal.getEventoFuncional() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoFuncional().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }

        if (visaoDetalhadaProdutoCanal.getEventoVolumetria() != null) {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF(
                visaoDetalhadaProdutoCanal.getEventoVolumetria().toString(),
                tabBodyItensListaRegistro, font1);
        } else {
            tabBodyItensListaRegistro = addLinhaRegistroEventoPDF("0", tabBodyItensListaRegistro, font1);
        }        
    }

    private static Document montarListaRegistroDetalhadoPDF(Document documento,
        List<RegistroEvento> listaRegistroEvento,
        Font font1, Font font2) {
        try {
            PdfPTable tabBody = new PdfPTable(INT_9);
            tabBody.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBody.setWidthPercentage(INT_100);
            tabBody.setSpacingBefore(INT_10);

            Map<Integer, String> cabecalho = new HashMap<>();
            cabecalho.put(INT_1, PRODUTO);
            cabecalho.put(INT_2, CANAL);
            cabecalho.put(INT_3, TIPO);
            cabecalho.put(INT_4, "Status");
            cabecalho.put(INT_5, "Etapa");
            cabecalho.put(INT_6, "Código");
            cabecalho.put(INT_7, GRAVIDADE);
            cabecalho.put(INT_8, "Data");
            cabecalho.put(INT_9, DURACAO);

            PdfPTable tabBodyItens = new PdfPTable(INT_9);
            tabBodyItens.setHorizontalAlignment(Element.ALIGN_LEFT);
            tabBodyItens.setWidthPercentage(INT_100);

            for (Map.Entry<Integer, String> pair : cabecalho.entrySet()) {
                PdfPCell col = new PdfPCell();
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
                col.setHorizontalAlignment(Element.ALIGN_CENTER);
                col.setPhrase(new Phrase(pair.getValue(), font2));
                col.setBorderWidth(FLOAT_0_3);
                col.setBorderColor(BaseColor.BLACK);
                tabBodyItens.addCell(col);
            }

            if (listaRegistroEvento != null) {
                for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoProduto(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoCanal(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoTipo(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(validaStatus(listaRegistroEvento.get(i).getStatus()),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getEtapaEvento(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getCodigo().toString(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDescricaoGravidade(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDataInicioEvento(),
                        tabBodyItens, font1);
                    tabBodyItens = addLinhaRegistroEventoPDF(listaRegistroEvento.get(i).getDuracao(),
                        tabBodyItens, font1);
                }
            }

            documento.add(tabBody);
            if (listaRegistroEvento != null) {
                documento.add(tabBodyItens);
            }

        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        } catch (DocumentException e) {
            LOGGER.error(Constantes.ERROR, e);
        }
        return documento;
    }

    private static PdfPTable addCabecalhoRegistroEventoPDF(Map<Integer, String> linha, PdfPTable tabCab, Font font1,
        Font font2, Integer tipo, Integer borda) {

        if (tipo == INT_1) {
            for (Map.Entry<Integer, String> pair : linha.entrySet()) {
                PdfPCell col = new PdfPCell();
                auxilioCabecalhoRegistroEventoPDFTipo1(col, pair, font1, font2, borda);
                tabCab.addCell(col);
            }
        } else if (tipo == INT_2) {
            for (Map.Entry<Integer, String> pair : linha.entrySet()) {
                PdfPCell col = new PdfPCell();
                auxilioCabecalhoRegistroEventoPDFTipo2(col, pair, font1, font2, borda);
                tabCab.addCell(col);
            }
        } else {
            PdfPCell col = new PdfPCell();
            col.setBackgroundColor(BaseColor.WHITE);
            col.setPhrase(new Phrase(" ", font1));
            col.setBorderWidth(borda);
            col.setBorderColor(BaseColor.LIGHT_GRAY);
            col.setColspan(INT_4);
        }
        return tabCab;
    }
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoRegistroEventoPDFTipo1(PdfPCell col, Entry<Integer, String> pair, Font font1,
        Font font2, Integer borda) {
        
        
        if (pair.getKey() % INT_2 == INT_0) {
            if (pair.getValue() != null && !"".equalsIgnoreCase(pair.getValue())) {
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                col.setBackgroundColor(BaseColor.WHITE);
            }
            col.setHorizontalAlignment(Element.ALIGN_LEFT);
            col.setPhrase(new Phrase(pair.getValue(), font1));
            col.setBorderWidth(borda);
            col.setBorderColor(BaseColor.LIGHT_GRAY);
        } else {
            col.setBackgroundColor(BaseColor.WHITE);
            if (pair.getKey() == INT_3) {
                col.setHorizontalAlignment(Element.ALIGN_RIGHT);
            } else {
                col.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            col.setPhrase(new Phrase(pair.getValue(), font2));
            col.setBorderWidth(borda);
            col.setBorderColor(BaseColor.LIGHT_GRAY);
        }
    }
    
    /**
     * Metodo criado para passar quantidade de IF's no sonar
     *
     * @author Mateus Pondiolli - Wipro
     */
    private static void auxilioCabecalhoRegistroEventoPDFTipo2(PdfPCell col, Entry<Integer, String> pair, Font font1,
        Font font2, Integer borda) {

        if (pair.getKey() == INT_2) {
            if (!"".equalsIgnoreCase(pair.getValue())) {
                col.setBackgroundColor(BaseColor.LIGHT_GRAY);
            } else {
                col.setBackgroundColor(BaseColor.WHITE);
            }
            col.setHorizontalAlignment(Element.ALIGN_LEFT);
            col.setPhrase(new Phrase(pair.getValue(), font1));
            col.setBorderWidth(borda);
            col.setBorderColor(BaseColor.LIGHT_GRAY);
            col.setColspan(INT_3);
        } else {
            col.setBackgroundColor(BaseColor.WHITE);
            col.setHorizontalAlignment(Element.ALIGN_LEFT);
            col.setPhrase(new Phrase(pair.getValue(), font2));
            col.setBorderWidth(borda);
            col.setBorderColor(BaseColor.LIGHT_GRAY);
        }
    }

    private static PdfPTable addLinhaRegistroEventoPDF(String item, PdfPTable tabBody, Font font1) {
        PdfPCell col = new PdfPCell();
        col.setBackgroundColor(BaseColor.WHITE);
        col.setHorizontalAlignment(Element.ALIGN_LEFT);
        if (item != null) {
            col.setPhrase(new Phrase(item, font1));
        } else {
            col.setPhrase(new Phrase("", font1));
        }
        col.setBorderWidth(FLOAT_0_3);
        col.setBorderColor(BaseColor.BLACK);
        tabBody.addCell(col);
        return tabBody;
    }

    private String obterTextoProdutos(List<BigDecimal> listaProduto) {
        StringBuilder texto = new StringBuilder("");
        List<Produto> produtosBase = produtoDao.listarProduto();

        for (int i = INT_0; i < listaProduto.size(); i++) {
            for (int j = INT_0; j < produtosBase.size(); j++) {
                if (listaProduto.get(i)
                    .equals(produtosBase.get(j).getCodigo())) {
                    texto.append(produtosBase.get(j).getDescricao())
                        .append(";");

                }
            }
        }

        return texto.toString();
    }

    private String obterTextoCanal(List<BigDecimal> listaCanal) {
        StringBuilder texto = new StringBuilder("");
        List<Canal> canalBase = canalDao.listarCanal();

        for (int i = INT_0; i < listaCanal.size(); i++) {
            for (int j = INT_0; j < canalBase.size(); j++) {
                if (listaCanal.get(i).equals(canalBase.get(j).getCodigo())) {
                    texto.append(canalBase.get(j).getDescricao()).append(";");
                }
            }
        }

        return texto.toString();
    }

    private static void montarCelula(Row row, int count,
        Sheet sheet, CellStyle styleInicial, String value) {

        Cell celula = row.createCell(count);
        celula.setCellValue(value);
        celula.setCellStyle(styleInicial);
    }

    private void montarCabecalhoRegistroEventoExcel(
        Workbook wb, Sheet sheet, int countSheet, Row row,
        Object[] objectArray) {

        Usuario usuario = new Usuario();
        String login = (String) objectArray[INT_0];
        usuario.setLogin(login.toUpperCase());
        try {
            usuario = loginDao.obterInformacaoUsuario(usuario);
            int count = INT_0;
            CellStyle styleInicial = PlanilhaUtils.createStyleBordaCima(wb);
            CellStyle styleTopoDireitaCinza = PlanilhaUtils
                .createStyleBordaTopoDireitaCinza(wb);
            CellStyle styleEsquerda = PlanilhaUtils
                .createStyleBordaEsquerda(wb);
            CellStyle styleDireita = PlanilhaUtils.createStyleBordaDireita(wb);
            CellStyle styleCinza = PlanilhaUtils.createStyleCinza(wb);
            CellStyle styleBranco = PlanilhaUtils.createStyleBranco(wb);

            montarCelula(row, count, sheet, styleInicial, "Usuario ");
            count++;
            montarCelula(row, count, sheet, styleInicial, usuario.getNome());
            count++;
            count = montarCelulaEmBranco(wb, row, count, sheet, INT_1);
            montarCelula(row, count, sheet, styleInicial, "Versão ");
            count++;
            montarCelula(row, count, sheet, styleTopoDireitaCinza, "1.0 ");

            // Segunda linha
            countSheet++;
            count = INT_0;
            row = sheet.createRow(countSheet);

            count = montarCelulaEmBranco(wb, row, count, sheet, INT_4);
            montarCelula(row, count, sheet, styleDireita, "");
            // pula uma Duas linhas
            countSheet++;
            count = INT_0;
            row = sheet.createRow(countSheet);

            montarCelula(row, count, sheet, styleBranco, FILTROS_APLICADOS);
            count++;
            count = montarCelulaEmBranco(wb, row, count, sheet, INT_3);
            montarCelula(row, count, sheet, styleDireita, "");

            // Terceira linha
            countSheet++;
            row = sheet.createRow(countSheet);
            count = INT_0;

            montarCelula(row, count, sheet, styleEsquerda, CANAL);
            count++;
            if (objectArray[INT_4] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_4];
                String canais = obterTextoCanal(lista);
                montarCelula(
                    row, count, sheet, styleCinza, canais);
                count++;
            } else {
                String valueEmpty = "";
                montarCelula(row, count, sheet, styleCinza, valueEmpty);
                count++;
            }
            count = montarCelulaEmBranco(wb, row, count, sheet, INT_2);

            montarCabecalhoRegistroEventoRestante(countSheet, row, sheet, wb,
                objectArray, count);

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    private void montarCabecalhoRegistroEventoRestante(
        int countSheet, Row row, Sheet sheet, Workbook wb, Object[] objectArray,
        int count) {

        Date dataInicio = (Date) objectArray[INT_1];
        Date dataFim = (Date) objectArray[INT_2];

        CellStyle styleEsquerda = PlanilhaUtils.createStyleBordaEsquerda(wb);
        CellStyle styleDireita = PlanilhaUtils.createStyleBordaDireita(wb);
        CellStyle styleBaixo = PlanilhaUtils.createStyleBordaBaixo(wb);
        CellStyle styleBaixoDireita = PlanilhaUtils
            .createStyleBordaBaixoDireita(wb);
        CellStyle styleCinza = PlanilhaUtils.createStyleCinza(wb);

        montarCelula(row, count, sheet, styleDireita, "");

        // Quarta linha
        countSheet++;
        row = sheet.createRow(countSheet);
        count = INT_0;
        montarCelula(
            row, count, sheet, styleEsquerda, PRODUTO);
        count++;
        if (objectArray[INT_3] != null) {
            List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_3];
            montarCelula(row, count, sheet, styleCinza,
                obterTextoProdutos(lista));
            count++;
        } else {
            String value = "";
            montarCelula(row, count, sheet, styleCinza, value);
            count++;
        }
        count = montarCelulaEmBranco(wb, row, count, sheet, INT_2);
        montarCelula(row, count, sheet, styleDireita, "");

        // Quinta linha
        countSheet++;
        row = sheet.createRow(countSheet);
        count = INT_0;

        montarCelula(row, count, sheet, styleEsquerda, PERIODO);
        count++;
        montarCelula(row, count, sheet, styleCinza,
            "de " + Utils.javaDateFormatoBrasil(dataInicio) + " Até "
                + Utils.javaDateFormatoBrasil(dataFim));
        count++;
        count = montarCelulaEmBranco(wb, row, count, sheet, INT_2);
        montarCelula(row, count, sheet, styleDireita, "");

        // Ultima linha
        countSheet++;
        row = sheet.createRow(countSheet);
        count = INT_0;

        for (int i = INT_0; i < INT_4; i++) {
            montarCelula(row, count, sheet, styleBaixo, "");
            count++;
        }

        montarCelula(row, count, sheet, styleBaixoDireita, "");
    }

    private static Integer montarCelulaEmBranco(Workbook wb, Row row, int count,
        Sheet sheet, int numeroCelula) {
        CellStyle styleBranco = PlanilhaUtils.createStyleBranco(wb);

        for (int i = INT_0; i < numeroCelula; i++) {
            montarCelula(
                row, count, sheet, styleBranco, "");
            count++;
        }

        return count;

    }

    private static String toDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = Date.from(Instant.now());
        return dateFormat.format(date);
    }

    private static String validaStatus(String status) {
        if (Integer.parseInt(status) == INT_2) {
            return "Fechado";
        } else {
            return "Aberto";
        }
    }

    public Workbook obterArquivoRegistroProdutoCanalEventoExcelCsv(List<VisaoDetalhadaProdutoCanal> listaRegistro,
        Integer periodo, List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, String login) {
        String dataInicio;
        String dataFim = Utils.javaDateFormatoBrasil(Date.from(Instant.now()));

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Detalhe Registro");

        Integer graves = INT_0;
        Integer moderados = INT_0;

        if (listaRegistro != null) {
            for (int i = INT_0; i < listaRegistro.size(); i++) {
                graves += listaRegistro.get(i).getEventoGrave().intValue();
                moderados += listaRegistro.get(i).getEventoModerado().intValue();
            }
        }

        dataInicio = Utils.javaDateFormatoBrasil(DateUtils.addDays(Date.from(Instant.now()), -periodo));

        Object[] objectArray = {login, dataInicio, dataFim, listaCodigoProduto, listaCodigoCanal, graves,
            moderados};

        geraCabecalhoExcel(wb, sheet, objectArray);

        int countSheet = INT_13;

        String periodoTempo = "";

        if (periodo == 1) {
            periodoTempo = "Dia";
        } else if (periodo == INT_2) {
            periodoTempo = "Semana";
        } else {
            periodoTempo = "Mês";
        }

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT_0;

        String[] valoresCabecalho = {PRODUTO, CANAL, "Qtd eventos abertos",
            "Qtd eventos fechados", "Qtd eventos graves", "Qtd eventos moderados", "Qtd eventos disponibilidade",
            "Qtd eventos funcional", "Qtd eventos volumetria", "Totalizado de eventos", "Período"};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        for (int i = 0; i < listaRegistro.size(); i++) {
            count = 0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, style,
                listaRegistro.get(i).getProduto());
            count++;

            montarCelula(
                row, count, sheet, style,
                listaRegistro.get(i).getCanal());
            count++;

            count = auxilioObterArquivoRegistroProdutoCanalEventoExcelCsv(
                listaRegistro.get(i), row, count, sheet, style);
            
            montarCelula(
                row, count, sheet, style,
                periodoTempo);
        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    private int auxilioObterArquivoRegistroProdutoCanalEventoExcelCsv(
        VisaoDetalhadaProdutoCanal visaoDetalhadaProdutoCanal, Row row, int count, Sheet sheet, CellStyle style) {
        
        if (visaoDetalhadaProdutoCanal.getEventoAberto() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoAberto().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;
        
        if (visaoDetalhadaProdutoCanal.getEventoFechado() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoFechado().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getEventoGrave() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoGrave().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getEventoModerado() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoModerado().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getEventoDisponibilidade() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoDisponibilidade().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getEventoFuncional() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoFuncional().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getEventoVolumetria() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getEventoVolumetria().toString());
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }
        count++;

        if (visaoDetalhadaProdutoCanal.getTotal() != null) {
            montarCelula(
                row, count, sheet, style,
                visaoDetalhadaProdutoCanal.getTotal().toString());        
        } else {
            montarCelula(
                row, count, sheet, style,
                "0");
        }    
        
        return ++count;
    }

    private void geraCabecalhoExcel(Workbook wb, Sheet sheet, Object[] objectArray) {
        Usuario usuario = new Usuario();
        String login = (String) objectArray[INT_0];
        Integer graves = (Integer) objectArray[INT_5];
        Integer moderados = (Integer) objectArray[INT_6];
        Integer total = graves + moderados;
        usuario.setLogin(login.toUpperCase());

        try {
            usuario = loginDao.obterInformacaoUsuario(usuario);

            CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

            CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

            int countSheet = INT_0;
            Row row = sheet.createRow(countSheet);
            int count = INT_0;

            montarCelula(
                row, count, sheet, styleCabecalho, "Usuário");
            count++;

            montarCelula(
                row, count, sheet, style,
                usuario.getNome());
            count = count + INT_2;

            montarCelula(
                row, count, sheet, styleCabecalho, "Versão de Central");
            count++;

            montarCelula(
                row, count, sheet, style,
                "1.0");

            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, "Data e hora Exp");
            count++;

            montarCelula(
                row, count, sheet, style,
                toDate());

            count = INT_0;
            countSheet = countSheet + INT_2;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, FILTROS_APLICADOS);
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, CANAL);
            count++;

            if (objectArray[INT_4] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_4];
                String canais = obterTextoCanal(lista);
                montarCelula(
                    row, count, sheet, style,
                    canais);
            } else {
                String valueEmpty = " ";
                montarCelula(
                    row, count, sheet, style,
                    valueEmpty);
            }

            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, PRODUTO);
            count++;

            if (objectArray[INT_3] != null) {
                List<BigDecimal> lista = (List<BigDecimal>) objectArray[INT_3];
                String produtos = obterTextoProdutos(lista);
                montarCelula(
                    row, count, sheet, style,
                    produtos);
            } else {
                String valueEmpty = " ";
                montarCelula(
                    row, count, sheet, style,
                    valueEmpty);
            }

            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, PERIODO);
            count++;

            montarCelula(
                row, count, sheet, style,
                "de " + objectArray[INT_1] + " até " + objectArray[INT_2]);

            count = INT_0;
            countSheet = countSheet + INT_2;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, "Resumo");
            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, "Qtd de eventos");
            count++;

            montarCelula(
                row, count, sheet, style,
                total + "");
            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, "Eventos Graves");
            count++;

            montarCelula(
                row, count, sheet, style,
                graves + "");
            count = INT_0;
            countSheet++;
            row = sheet.createRow(countSheet);

            montarCelula(
                row, count, sheet, styleCabecalho, "Eventos Moderados");
            count++;

            montarCelula(
                row, count, sheet, style,
                moderados + "");

        } catch (AcessoADadosException | SQLException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    public Workbook obterArquivoRegistroEventoDetalhadoExcelCsv(List<StatusDetalheEvento> listaRegistroEvento,
        String login, BigDecimal codigoProduto, BigDecimal codigoCanal,
        Integer periodo) {

        String dataInicio;
        String dataFim = Utils.javaDateFormatoBrasil(Date.from(Instant.now()));

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Detalhe Registro");

        Integer graves = INT_0;
        Integer moderados = INT_0;

        if (!listaRegistroEvento.isEmpty()) {
            for (int i = INT_0; i < listaRegistroEvento.size(); i++) {
                graves += listaRegistroEvento.get(i).getSomaEventoGrave().intValue();
                moderados += listaRegistroEvento.get(i).getSomaEventoModerado().intValue();
            }
        }

        if (periodo == INT_99) {
            periodo = 0;
        }

        dataInicio = Utils.javaDateFormatoBrasil(DateUtils.addDays(Date.from(Instant.now()), -periodo));

        List<BigDecimal> listaProduto = new ArrayList<>();
        listaProduto.add(codigoProduto);
        List<BigDecimal> listaCanal = new ArrayList<>();
        listaCanal.add(codigoCanal);

        Object[] objectArray = {login, dataInicio, dataFim, listaProduto, listaCanal, graves,
            moderados};

        geraCabecalhoExcel(wb, sheet, objectArray);

        int countSheet = INT_13;

        CellStyle styleCabecalho = PlanilhaUtils.createStyleCabecalho(wb);

        CellStyle style = PlanilhaUtils.createStyleBordaTotal(wb);

        Row row = sheet.createRow(countSheet);
        int count = INT_0;

        String[] valoresCabecalho = {PRODUTO, CANAL, "Status",
            "Etapa", "Código", GRAVIDADE, "Data", DURACAO};

        for (int i = 0; i < valoresCabecalho.length; i++) {
            montarCelula(
                row, count, sheet, styleCabecalho, valoresCabecalho[i]);
            count++;
        }

        if (!listaRegistroEvento.isEmpty()) {
            for (int i = 0; i < listaRegistroEvento.get(0).getListaEvento().size(); i++) {
                count = 0;
                countSheet++;
                row = sheet.createRow(countSheet);

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDescricaoProduto());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDescricaoCanal());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDescricaoTipo());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    validaStatus(listaRegistroEvento.get(0).getListaEvento().get(i).getStatus()));
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getEtapaEvento());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getCodigo().toString());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDescricaoGravidade());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDataInicioEvento());
                count++;

                montarCelula(
                    row, count, sheet, style,
                    listaRegistroEvento.get(0).getListaEvento().get(i).getDuracao());
            }
        }
        
        for(int i = 0; i< valoresCabecalho.length; i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }
}
