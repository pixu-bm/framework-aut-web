package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.EmpresaDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Empresa;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmpresaService;

/**
 * Classe responsável por implementar Empresa service
 * 
 * @author Wipro
 */
@Service
public class EmpresaServiceImpl implements EmpresaService {

    private static final Log LOGGER = LogFactory
        .getLog(EmpresaServiceImpl.class);

    private EmpresaDao empresaDao;

    @Autowired
    public EmpresaServiceImpl(EmpresaDao empresaDao) {
        this.empresaDao = empresaDao;
    }

    /**
     * {@inheritDoc}
     */
    public List<Empresa> obterEmpresas() {
        try {
            return empresaDao.listarEmpresa();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(
                Constantes.RESULTADO_NAO_ENCONTRADO, e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

}
