package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.GestaoAcessoPerfilDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaFuncionalidadeRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper.ListaUsuarioRowMapper;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Gestao acesso perfil dao Classe implementador.
 *
 * @author Wipro
 */
@Repository
public class GestaoAcessoPerfilDaoImpl implements GestaoAcessoPerfilDao {

    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS_PERFIL = "Erro ao obter lista"
      + " de funcionalidades do perfil!";
    private static final int INT_5 = 5;
    private static final String CANCEL = "CANCEL";
    private static final String NEGAD = "NEGAD";
    public static final String ERROR = "Error: ";
    public static final String ERRO_INTERNO = "Erro interno.";
    public static final String LOGIN = "login";
    public static final String PERFIL = "perfil";
    public static final String STATUS = "status";
    public static final String LOGIN_APROVADOR = "loginAprovador";
    public static final String NUMERO_USUARIO = "numeroUsuario";
    public static final String CODIGO_TIPO_RECUSA = "tipoRecusaAcesso";
    public static final String MOTIVO_RECUSA = "motivoRecusa";
    public static final String ERRO_DE_INTEGRIDADE_DOS_DADOS = "Erro de integridade dos dados.";
    public static final String CODIGO_FUNCIONALIDADE = "codigoFuncionalidade";
    private static final Logger LOGGER = LogManager.getLogger(GestaoAcessoPerfilDaoImpl.class);
    private static final String SELECT_PERFIL_USUARIO = " SELECT CTPO_PRFIL , RTPO_PRFIL FROM "
      + Constantes.OWNER_TABELA + "TPO_PRFIL_USUAR ";
    private static final String SELECT_USUARIO = " SELECT USUARIO.CUSUAR ,USUARIO.IUSUAR , USUARIO.CEMPR ,"
      + " EMPRESA.IEMPR , DEPARTAMENTO.IDEPTO, USUARIO.AINCL, " + " PERFIL.RTPO_PRFIL, USUARIO.CSTTUS_CAD "
      + " FROM " + Constantes.OWNER_TABELA + "USUAR USUARIO JOIN " + Constantes.OWNER_TABELA
      + "EMPR_USUAR EMPRESA " + " ON(USUARIO.CEMPR = EMPRESA.CEMPR) " + "  JOIN " + Constantes.OWNER_TABELA
      + "DEPTO DEPARTAMENTO " + " ON(USUARIO.CDEPTO = DEPARTAMENTO.CDEPTO "
      + " AND USUARIO.CEMPR = DEPARTAMENTO.CEMPR ) " + " LEFT JOIN "
      + Constantes.OWNER_TABELA + "TPO_PRFIL_USUAR PERFIL  "
      + " ON(USUARIO.CTPO_PRFIL = PERFIL.CTPO_PRFIL) "

      + "WHERE 1=1 ";
    private static final String SELECT_NUMERO_USUARIO = " SELECT NUSUAR FROM " + Constantes.OWNER_TABELA
      + "USUAR WHERE CUSUAR = :login ";
    private static final String SELECT_NUMERO_USUARIO_REJEITADO_CANCELADO = " SELECT NUSUAR FROM "
      + Constantes.OWNER_TABELA + "USUAR_CANCD WHERE NUSUAR = :numeroUsuario ";

    private static final String UPDATE_STATUS_PERFIL_USUARIO = " UPDATE " + Constantes.OWNER_TABELA + "USUAR "
      + " SET CTPO_PRFIL = :perfil , CSTTUS_CAD = :status , AULT_ATULZ = SYSDATE " + " WHERE CUSUAR = :login ";

    private static final String INSERT_USUARIO_REJEITADO_CANCELADO = " INSERT INTO " + Constantes.OWNER_TABELA
      + "USUAR_CANCD (NUSUAR, CTPO_RCUSA_ACSSO, RMOTVO_RCUSA, AINCL, AULT_ATULZ) "
      + " VALUES(:numeroUsuario, :tipoRecusaAcesso, :motivoRecusa, SYSDATE, SYSDATE)";

    private static final String UPDATE_USUARIO_REJEITADO_CANCELADO = " UPDATE " + Constantes.OWNER_TABELA
      + "USUAR_CANCD " + " SET CTPO_RCUSA_ACSSO = :tipoRecusaAcesso "
      + " , RMOTVO_RCUSA = :motivoRecusa, AULT_ATULZ = SYSDATE " + " WHERE NUSUAR = :numeroUsuario ";

    private static final String SELECT_FUNCIONALIDADE_PERFIL = " SELECT FUNCIONALIDADE_PERFIL.CFUNCL ,"
      + " FUNCIONALIDADE.RFUNCL " + " FROM " + Constantes.OWNER_TABELA + "FUNCL FUNCIONALIDADE, "
      + Constantes.OWNER_TABELA + "PRFIL_FUNCL FUNCIONALIDADE_PERFIL "
      + " WHERE FUNCIONALIDADE.CFUNCL = FUNCIONALIDADE_PERFIL.CFUNCL "
      + " AND FUNCIONALIDADE_PERFIL.CTPO_PRFIL = :perfil ";
    private static final String SELECT_FUNCIONALIDADE = " SELECT CFUNCL, RFUNCL FROM " + Constantes.OWNER_TABELA
      + "FUNCL ";
    private static final String DELETE_PERFIL_FUNCIONALIDADE = " DELETE  " + Constantes.OWNER_TABELA + "PRFIL_FUNCL "
      + " WHERE CTPO_PRFIL = :perfil ";
    private static final String INSERT_PERFIL_FUNCIONALIDADE = " INSERT INTO " + Constantes.OWNER_TABELA
      + "PRFIL_FUNCL(CTPO_PRFIL,CFUNCL) " + "        VALUES(:perfil, :codigoFuncionalidade) ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public GestaoAcessoPerfilDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public List<PerfilUsuario> listarPerfilUsuario() throws SQLException {
        try {

            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_PERFIL_USUARIO,
              new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Consulta sem resultado", 1);
            }

            List<PerfilUsuario> listaEmpresaUsuario = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);

                PerfilUsuario perfilUsuario = new PerfilUsuario();
                perfilUsuario.setCodigoTipoPerfil((String) mapa.get("CTPO_PRFIL"));
                perfilUsuario.setDescricaoTipoPerfil((String) mapa.get("RTPO_PRFIL"));

                listaEmpresaUsuario.add(perfilUsuario);

            }

            return listaEmpresaUsuario;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public List<Usuario> listarUsuario(Usuario usuario) throws SQLException {
        try {
            StringBuilder sql = new StringBuilder(SELECT_USUARIO);
            MapSqlParameterSource params = new MapSqlParameterSource();
            String compare = CANCEL;

            if (usuario.getCodigoDepartamento() != null) {
                sql.append(" AND USUARIO.CDEPTO = :codigoDepartamento ");
                params.addValue("codigoDepartamento", usuario.getCodigoDepartamento());
            }

            if (usuario.getDataSolicitacao() != null) {
                sql.append(" AND TO_CHAR(USUARIO.AINCL,'yyyy-mm-dd') = TO_CHAR(:dataSolicitacao ,'yyyy-mm-dd') ");
                params.addValue("dataSolicitacao", usuario.getDataSolicitacao());
            }

            if (usuario.getStatus() != null) {

                if(compare.equals(usuario.getStatus())){
                    sql.append(" AND USUARIO.CSTTUS_CAD = :codigoStatus ");
                    params.addValue("codigoStatus", "CANCD");
                } else{
                    sql.append(" AND USUARIO.CSTTUS_CAD = :codigoStatus ");
                    params.addValue("codigoStatus", usuario.getStatus());
                }
            }

            if (usuario.getNome() != null) {
                sql.append(" AND LOWER(USUARIO.IUSUAR)  LIKE LOWER('%" + usuario.getNome() + "%')");
            }

            if (usuario.getMatricula() != null) {
                sql.append(" AND LOWER(USUARIO.CUSUAR)  = LOWER('" + usuario.getMatricula() + "')");
            }

            if (usuario.getCodigoEmpresa() != null) {
                sql.append(" AND EMPRESA.CEMPR = :codigoEmpresa ");
                params.addValue("codigoEmpresa", usuario.getCodigoEmpresa());
            }

            if (usuario.getPerfil() != null) {
                sql.append(" AND  USUARIO.CTPO_PRFIL= :codigoPerfil ");
                params.addValue("codigoPerfil", usuario.getPerfil());
            }

            return jdbcTemplate.query(sql.toString(), params, new ListaUsuarioRowMapper());

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new EmptyResultDataAccessException("Dados não encontrado", 1);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void atualizarStatusPerfilUsuario(Usuario usuario) throws SQLException {

        String compareCancel = CANCEL;

        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(LOGIN, usuario.getLogin());
            params.addValue(PERFIL, usuario.getPerfil());

            if (compareCancel.equals(usuario.getStatus())){
                params.addValue(STATUS, "CANCD");
            }else{
                params.addValue(STATUS, usuario.getStatus().substring(0,INT_5));
            }

            params.addValue(LOGIN_APROVADOR, usuario.getLoginAprovador());

            jdbcTemplate.update(UPDATE_STATUS_PERFIL_USUARIO, params);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    public BigDecimal obterNumeroUsuario(Usuario usuario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(LOGIN, usuario.getLogin());

            return jdbcTemplate.queryForObject(SELECT_NUMERO_USUARIO, params, BigDecimal.class);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new BigDecimal(0);
        }
    }

    public BigDecimal obterNumeroUsuarioCanceladoRejeitado(BigDecimal numeroUsuario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(NUMERO_USUARIO, numeroUsuario);

            return jdbcTemplate.queryForObject(SELECT_NUMERO_USUARIO_REJEITADO_CANCELADO, params, BigDecimal.class);

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            return new BigDecimal(0);
        }
    }

    /**
     * Inserir dado quando usuario é cancelado.
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    public void inserirUsuarioCancelado(Usuario usuario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();

            String compare = CANCEL;
            if (compare.equals(usuario.getStatus())) {
                params.addValue(CODIGO_TIPO_RECUSA, "C");
            }
            compare = NEGAD;
            if (compare.equals(usuario.getStatus())) {
                params.addValue(CODIGO_TIPO_RECUSA, "R");
            }

            params.addValue(NUMERO_USUARIO, usuario.getNumeroInternoUsuario());
            params.addValue(MOTIVO_RECUSA, usuario.getMotivoRecusa());

            jdbcTemplate.update(INSERT_USUARIO_REJEITADO_CANCELADO, params);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS, e);

        }
    }

    /**
     * Atualizar usuario cancelado
     *
     * @param usuario Usuario
     * @throws SQLException
     */
    public void atualizarUsuarioCancelado(Usuario usuario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(NUMERO_USUARIO, usuario.getNumeroInternoUsuario());

            String compare = CANCEL;
            if (compare.equals(usuario.getStatus())) {
                params.addValue(CODIGO_TIPO_RECUSA, "C");
            }
            compare = NEGAD;
            if (compare.equals(usuario.getStatus())) {
                params.addValue(CODIGO_TIPO_RECUSA, "R");
            }

            params.addValue(MOTIVO_RECUSA, usuario.getMotivoRecusa());
            params.addValue(LOGIN_APROVADOR, usuario.getLoginAprovador());

            jdbcTemplate.update(UPDATE_USUARIO_REJEITADO_CANCELADO, params);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS, e);

        }
    }

    /**
     * {@inheritDoc}
     */
    public List<Funcionalidade> obterListaFuncionalidadePerfil(String perfil) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(PERFIL, perfil);

            List<Funcionalidade> listaFuncionalidade = jdbcTemplate.query(SELECT_FUNCIONALIDADE_PERFIL, params,
              new ListaFuncionalidadeRowMapper());

            if (listaFuncionalidade.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  "Nenhuma funcionalidade " + "cadastrada para o perfil desejado", 1);
            }

            return listaFuncionalidade;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS_PERFIL);
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<Funcionalidade> obterListaFuncionalidade() throws SQLException {
        try {
            List<Funcionalidade> listaFuncionalidade = jdbcTemplate.query(SELECT_FUNCIONALIDADE,
              new MapSqlParameterSource(), new ListaFuncionalidadeRowMapper());

            if (listaFuncionalidade.isEmpty()) {
                throw new EmptyResultDataAccessException(
                  "Nenhuma funcionalidade " + "cadastrada para o perfil desejado", 1);
            }

            return listaFuncionalidade;

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void removerPerfilFuncionalidade(Usuario usuario) throws SQLException {
        try {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue(PERFIL, usuario.getPerfil());

            jdbcTemplate.update(DELETE_PERFIL_FUNCIONALIDADE, params);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS, e);

        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public void inserirPerfilFuncionalidade(Usuario usuario) throws SQLException {

        try {

            for (int i = 0; i < usuario.getListaFuncionalidades().size(); i++) {

                MapSqlParameterSource params = new MapSqlParameterSource();
                params.addValue(PERFIL, usuario.getPerfil());
                params.addValue(CODIGO_FUNCIONALIDADE,
                  usuario.getListaFuncionalidades().get(i).getCodigoFuncionalidade());

                jdbcTemplate.update(INSERT_PERFIL_FUNCIONALIDADE, params);

            }

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(e);
            throw new DataIntegrityViolationException(ERRO_DE_INTEGRIDADE_DOS_DADOS, e);

        }
    }

}
