package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.util.ValidaTokenDataPower;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.EmailService;

/**
 * Configuração de intervalo processamento service.
 * 
 * @author Wipro
 */
@Service
public class EmailServiceImpl implements EmailService {

    private static final Log LOGGER = LogFactory.getLog(EmailServiceImpl.class);
    private static final String ENVIAR_EMAIL = "/bsad-bff-envia-email/v1/email";
    private static final int INT_200 = 200;

    @Value("${DATAPOWER_USER}")
    private String datapoweruser;
    @Value("${DATAPOWER_PWD}")
    private String datapowerpwd;

    @Value("${enderecoApiExterno}")
    private String enderecoApi;

    public EmailServiceImpl() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public void enviarEmail(String destinatario, String mensagem, String assunto) {
        try {
            ValidaTokenDataPower validaTokenDataPower = new ValidaTokenDataPower();

            String authorization = validaTokenDataPower.recuperartokendatapower(enderecoApi + "/Auth",
                datapoweruser, datapowerpwd);

            URL url = new URL(enderecoApi + ENVIAR_EMAIL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setInstanceFollowRedirects(false);
            connection.addRequestProperty("Authorization", authorization);

            String jsonRequest = "{ \"from\": \"suportecm@bradescoseguros.com.br\", \n"
                + "  \"to\": \"" + destinatario + "\", \n"
                + "  \"subject\": \"" + assunto + "\", \n"
                + "  \"message\": \"" + mensagem + "\"}";

            try (OutputStream osConect = connection.getOutputStream()) {
                byte[] input = jsonRequest.getBytes(StandardCharsets.UTF_8);
                osConect.write(input, 0, input.length);
            }

            if (connection.getResponseCode() != INT_200) {
                LOGGER.error("Erro ao enviar email: " + connection.getResponseMessage());
            }

        } catch (Exception e) {
            LOGGER.error(e);
        }

    }

}
