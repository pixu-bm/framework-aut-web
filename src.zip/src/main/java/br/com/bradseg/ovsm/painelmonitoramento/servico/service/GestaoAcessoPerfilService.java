package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Status;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Usuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarPerfilFuncionalidadeRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.AtualizarStatusPerfilUsuarioRequest;

import java.sql.SQLException;
import java.util.List;

/**
 * Gestao Acesso perfil service 
 * @author Wipro
 */
public interface GestaoAcessoPerfilService {

    /**
     * Listar todos os perfis de usuários disponível no sistema
     * @return List<PerfilUsuario>
     * @throws SQLException 
     */
    List<PerfilUsuario> listarPerfilUsuario() throws SQLException;

    /**
     * Obter todos os status de usuário disponíveis no sistema 
     * @return
     */
    List<Status> obterStatus();

    /**
     * Listar usuario para central de acesso painel OV.
     * @param centralAcessoRequest CentralAcessoRequest
     * @return List<Usuario>
     * @throws SQLException 
     */
    List<Usuario> listarUsuario(Usuario usuario) throws SQLException;

    /**
     * Atualizar status perfil usuario.
     * @param usuario Usuario
     * @throws SQLException
     */
    void atualizarStatusPerfilUsuario(Usuario usuario) throws SQLException;

    /**
     * Valida os parametros de atualizar perfil usuario
     * @param atualizarStatusPerfilUsuarioRequest AtualizarStatusPerfilUsuarioRequest
     * @throws SQLException 
     */
    void validarParametrosAtualizarStatusPerfilUsuario(
        AtualizarStatusPerfilUsuarioRequest atualizarStatusPerfilUsuarioRequest) throws SQLException;

    /**
     * Obter lista funcionalidade perfil
     * @param perfil String
     * @return List<Funcionalidade>
     * @throws SQLException
     */
    List<Funcionalidade> obterListaFuncionalidadePerfil(String perfil) throws SQLException;

    /**
     * Obter lista funcionalidades de cadastra
     * @return List<Funcionalidade>
     * @throws SQLException
     */
    List<Funcionalidade> obterListaFuncionalidade() throws SQLException;

    /**
     * Validar parametro perfil
     * @param perfil String
     * @throws SQLException
     */
    void validarParametroPerfil(String perfil) throws SQLException;

    /**
     * Validar parametros de atualizar perfil funcionalidade
     * @param atualizarPerfilFuncionalidadeRequest AtualizarPerfilFuncionalidadeRequest
     * @throws SQLException
     */
    void validarParametroAtualizarPerfilFuncionalidade(
        AtualizarPerfilFuncionalidadeRequest atualizarPerfilFuncionalidadeRequest) throws SQLException;

    /**
     * Atualiza o perfil funcionalidade do usuario.
     * @param usuario Usuario
     * @throws SQLException
     */
    void atualizarPerfilFuncionalidade(Usuario usuario) throws SQLException;

}
