package br.com.bradseg.ovsm.painelmonitoramento.enums;

/**
 * Status ENUM para preenchimento de componente de serviço
 * @author Wipro
 */
public enum StatusEnum {

    ATIVO("A", "ATIVO"),
    CANCELADO("C", "CANCELADO"),
    REJEITADO("R", "REJEITADO"),
    PENDENTE("P", "PENDENTE");

    private String valor;
    private String descricao;

    StatusEnum(String valor, String descricao) {
        this.valor = valor;
        this.descricao = descricao;
    }

    public String getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }

}
