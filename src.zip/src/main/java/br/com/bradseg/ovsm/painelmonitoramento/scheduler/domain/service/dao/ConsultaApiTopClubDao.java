package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface ConsultaApiTopClubDao {
    
    String obterultimoregistroinseridoTopClub();
    
    void liberarProcessamentoTopClub(Collection<?> listaTopClubTemp);
    
    void validarDuplicadosTopClub(Collection<?> listaTopClubTemp);
    
    void inserirConsultaApiTopClub(List<TabelaTemp> listaTopClubTemp) throws SQLException;
}
