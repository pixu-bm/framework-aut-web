package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;

/**
 * Visao evento mapa objetos extração de base de dados.
 *
 * @author Wipro
 */
public class VisaoEventoRowMapper implements RowMapper<VisaoEvento> {

    public VisaoEvento mapRow(ResultSet rs, int rowNum) throws SQLException {

        VisaoEvento visaoEvento = new VisaoEvento();
        visaoEvento.setQuantidadeEventosDisponibilidade(rowNum);
        visaoEvento.setQuantidadeEventosDisponibilidade(rs.getInt("QNT_EVENTO_DISPN"));
        visaoEvento.setQuantidadeEventosFuncionalidade(rs.getInt("QNT_EVENTO_FUNCL"));
        visaoEvento.setQuantidadeEventosVolumetria(rs.getInt("QNT_EVENTO_VOLUM"));
        visaoEvento.setQuantidadeTotalEventos(rs.getInt("QNT_TOTAL"));
        visaoEvento.setQuantidadeTransacaoImpactada(rs.getInt("TRANSACAO"));
        visaoEvento.setQuantidadeTotalTransacao(rs.getInt("TRANSACAO_TOTAL"));

        if (visaoEvento.getQuantidadeTotalEventos() != 0) {

            visaoEvento.setPorcentagemEventosDisponibilidade(Utils.calcularPorcentagem(
                visaoEvento.getQuantidadeEventosDisponibilidade(),
                visaoEvento.getQuantidadeTotalEventos()));

            visaoEvento.setPorcentagemEventosFuncionalidade(Utils.calcularPorcentagem(
                visaoEvento.getQuantidadeEventosFuncionalidade(),
                visaoEvento.getQuantidadeTotalEventos()));

            visaoEvento.setPorcentagemEventosVolumetria(Utils.calcularPorcentagem(
                visaoEvento.getQuantidadeEventosVolumetria(),
                visaoEvento.getQuantidadeTotalEventos()));

            if (visaoEvento.getQuantidadeTransacaoImpactada() > 0) {
                visaoEvento.setPorcentagemTransacaoImpactada(Utils.calcularPorcentagem(
                    visaoEvento.getQuantidadeTransacaoImpactada(), visaoEvento.getQuantidadeTotalTransacao()));
            }

        } else {
            visaoEvento.setPorcentagemEventosDisponibilidade(0);

            visaoEvento.setPorcentagemEventosFuncionalidade(0);

            visaoEvento.setPorcentagemEventosVolumetria(0);

            visaoEvento.setPorcentagemTransacaoImpactada(0);
        }

        return visaoEvento;
    }

}
