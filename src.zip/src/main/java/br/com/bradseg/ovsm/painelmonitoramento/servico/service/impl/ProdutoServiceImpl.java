package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import br.com.bradseg.ovsm.painelmonitoramento.enums.ProdutoEnum;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.ProdutoDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ProdutoService;
import br.com.bradseg.ovsm.painelmonitoramento.utils.Utils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Map;

/**
 * Produto service, classe responsável por trazer informações relacionadas a produto.
 * @author Wipro
 */
@Service
public class ProdutoServiceImpl implements ProdutoService {

    private static final Log LOGGER = LogFactory
        .getLog(ProdutoServiceImpl.class);

    private ProdutoDao produtoDao;

    @Autowired
    public ProdutoServiceImpl(ProdutoDao produtoDao) {
        this.produtoDao = produtoDao;
    }

    /**
     * {@inheritDoc}
     */
    public List<Produto> obterProduto() {
        try {
            return produtoDao.listarProduto();

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new EmptyResultDataAccessException(e.getMessage(),
                e.getActualSize());
        } catch (AcessoADadosException e) {
            LOGGER.error(Constantes.ERROR, e);
            throw new AcessoADadosException(
                Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Map<String, String> obterCanaisProduto(String produto) {

        try {

            validarParametroProduto(produto);

            for (int i = 0; i < ProdutoEnum.values().length; i++) {
                if (ProdutoEnum.values()[i].name()
                    .equalsIgnoreCase(produto)) {
                    return Utils.convertEnumArrayToMap(
                        ProdutoEnum.values()[i].getEnums());
                }
            }

            throw new IllegalArgumentException(
                "Nenhum valor correspondente a produto.");

        } catch (IllegalArgumentException e) {
            LOGGER.error(Constantes.ERROR + e);
            throw new IllegalArgumentException(e.getMessage());
        }

    }

    private static void validarParametroProduto(String produto) {
        Assert.notNull(produto, "O produto não pode ser nulo.");
    }

}
