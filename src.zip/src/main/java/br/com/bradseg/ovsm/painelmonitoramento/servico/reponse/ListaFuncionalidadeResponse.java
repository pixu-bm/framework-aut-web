package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Funcionalidade;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Lista de funcionalidade response
 * @author Wipro
 */
public class ListaFuncionalidadeResponse extends ResponseMensagem {

    private List<Funcionalidade> listaFuncionalidade;

    public ListaFuncionalidadeResponse() {
        super();
    }

    public List<Funcionalidade> getListaFuncionalidade() {
        return Collections.unmodifiableList(listaFuncionalidade);
    }

    public void setListaFuncionalidade(List<Funcionalidade> listaFuncionalidade) {
        this.listaFuncionalidade = 
            Collections.unmodifiableList(listaFuncionalidade);
    }

}
