package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

import java.math.BigDecimal;

/**
 * Classe de dominio visao evento canais.
 * 
 * @author Wipro
 */
public class VisaoEventoCanal {

    private Integer quantidadeOcorrencia;
    private BigDecimal codigoCanal;
    private String descricaoCanal;
    private Integer porcentagemOcorrencia;

    public VisaoEventoCanal() {
        super();
    }

    public Integer getQuantidadeOcorrencia() {
        return quantidadeOcorrencia;
    }

    public void setQuantidadeOcorrencia(Integer quantidadeOcorrencia) {
        this.quantidadeOcorrencia = quantidadeOcorrencia;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public Integer getPorcentagemOcorrencia() {
        return porcentagemOcorrencia;
    }

    public void setPorcentagemOcorrencia(Integer porcentagemOcorrencia) {
        this.porcentagemOcorrencia = porcentagemOcorrencia;
    }
}
