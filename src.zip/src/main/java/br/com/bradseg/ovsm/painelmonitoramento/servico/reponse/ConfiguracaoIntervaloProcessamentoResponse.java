package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.math.BigDecimal;

/**
 * Configuração de intervalo parametrização serviço schedule de monitoramento
 * 
 * @author Wipro
 */
public class ConfiguracaoIntervaloProcessamentoResponse extends ResponseMensagem {

    private BigDecimal codigoEmpresa;
    private String descricaoEmpresa;
    private String dataVigenciaFinal;
    private Integer quantidadeMinutoIntervaloNormal;
    private Integer quantidadeMinutoIntervaloErro;
    private BigDecimal codigoProduto;
    private String descricaoProduto;
    private BigDecimal codigoCanal;
    private String descricaoCanal;

    private String dataVigenciaInicio;

    public ConfiguracaoIntervaloProcessamentoResponse() {
        super();
    }

    public void setQuantidadeMinutoIntervaloErro(Integer quantidadeMinutoIntervaloErro) {
        this.quantidadeMinutoIntervaloErro = quantidadeMinutoIntervaloErro;
    }

    public BigDecimal getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(BigDecimal codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getDescricaoEmpresa() {
        return descricaoEmpresa;
    }

    public void setDescricaoEmpresa(String descricaoEmpresa) {
        this.descricaoEmpresa = descricaoEmpresa;
    }

    public String getDataVigenciaFinal() {
        return dataVigenciaFinal;
    }

    public void setDataVigenciaFinal(String dataVigenciaFinal) {
        this.dataVigenciaFinal = dataVigenciaFinal;
    }

    public BigDecimal getCodigoProduto() {
        return codigoProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public Integer getQuantidadeMinutoIntervaloNormal() {
        return quantidadeMinutoIntervaloNormal;
    }

    public String getDataVigenciaInicio() {
        return dataVigenciaInicio;
    }

    public void setDataVigenciaInicio(String dataVigenciaInicio) {
        this.dataVigenciaInicio = dataVigenciaInicio;
    }

    public BigDecimal getCodigoCanal() {
        return codigoCanal;
    }

    public void setCodigoCanal(BigDecimal codigoCanal) {
        this.codigoCanal = codigoCanal;
    }

    public String getDescricaoCanal() {
        return descricaoCanal;
    }

    public Integer getQuantidadeMinutoIntervaloErro() {
        return quantidadeMinutoIntervaloErro;
    }

    public void setDescricaoCanal(String descricaoCanal) {
        this.descricaoCanal = descricaoCanal;
    }

    public void setCodigoProduto(BigDecimal codigoProduto) {
        this.codigoProduto = codigoProduto;

    }

    public void setQuantidadeMinutoIntervaloNormal(Integer quantidadeMinutoIntervaloNormal) {
        this.quantidadeMinutoIntervaloNormal = quantidadeMinutoIntervaloNormal;
    }

}
