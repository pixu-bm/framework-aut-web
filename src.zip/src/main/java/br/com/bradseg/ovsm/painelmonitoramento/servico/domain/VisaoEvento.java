/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.domain;

/**
 * Classe que implementa a visao de evento
 * 
 * @author Wipro
 */
public class VisaoEvento extends ResponseMensagem {

    private Integer quantidadeEventosVolumetria;
    private Integer porcentagemEventosVolumetria;
    private Integer quantidadeEventosDisponibilidade;
    private Integer porcentagemEventosDisponibilidade;
    private Integer quantidadeEventosFuncionalidade;
    private Integer porcentagemEventosFuncionalidade;
    private Integer quantidadeTotalEventos;
    private Integer quantidadeTransacaoImpactada;
    private Integer porcentagemTransacaoImpactada;
    private Integer quantidadeTotalTransacao;

    public VisaoEvento() {
        super();
    }

    public Integer getQuantidadeEventosVolumetria() {
        return quantidadeEventosVolumetria;
    }

    public void setQuantidadeEventosVolumetria(Integer quantidadeEventosVolumetria) {
        this.quantidadeEventosVolumetria = quantidadeEventosVolumetria;
    }

    public Integer getPorcentagemEventosVolumetria() {
        return porcentagemEventosVolumetria;
    }

    public void setPorcentagemEventosVolumetria(Integer porcentagemEventosVolumetria) {
        this.porcentagemEventosVolumetria = porcentagemEventosVolumetria;
    }

    public Integer getQuantidadeEventosDisponibilidade() {
        return quantidadeEventosDisponibilidade;
    }

    public void setQuantidadeEventosDisponibilidade(Integer quantidadeEventosDisponibilidade) {
        this.quantidadeEventosDisponibilidade = quantidadeEventosDisponibilidade;
    }

    public Integer getPorcentagemEventosDisponibilidade() {
        return porcentagemEventosDisponibilidade;
    }

    public void setPorcentagemEventosDisponibilidade(Integer porcentagemEventosDisponibilidade) {
        this.porcentagemEventosDisponibilidade = porcentagemEventosDisponibilidade;
    }

    public Integer getQuantidadeEventosFuncionalidade() {
        return quantidadeEventosFuncionalidade;
    }

    public void setQuantidadeEventosFuncionalidade(Integer quantidadeEventosFuncionalidade) {
        this.quantidadeEventosFuncionalidade = quantidadeEventosFuncionalidade;
    }

    public Integer getPorcentagemEventosFuncionalidade() {
        return porcentagemEventosFuncionalidade;
    }

    public void setPorcentagemEventosFuncionalidade(Integer porcentagemEventosFuncionalidade) {
        this.porcentagemEventosFuncionalidade = porcentagemEventosFuncionalidade;
    }

    public Integer getQuantidadeTotalEventos() {
        return quantidadeTotalEventos;
    }

    public void setQuantidadeTotalEventos(Integer quantidadeTotalEventos) {
        this.quantidadeTotalEventos = quantidadeTotalEventos;
    }

    public Integer getQuantidadeTransacaoImpactada() {
        return quantidadeTransacaoImpactada;
    }

    public void setQuantidadeTransacaoImpactada(Integer quantidadeTransacaoImpactada) {
        this.quantidadeTransacaoImpactada = quantidadeTransacaoImpactada;
    }

    public Integer getPorcentagemTransacaoImpactada() {
        return porcentagemTransacaoImpactada;
    }

    public void setPorcentagemTransacaoImpactada(Integer porcentagemTransacaoImpactada) {
        this.porcentagemTransacaoImpactada = porcentagemTransacaoImpactada;
    }

    public Integer getQuantidadeTotalTransacao() {
        return quantidadeTotalTransacao;
    }

    public void setQuantidadeTotalTransacao(Integer quantidadeTotalTransacao) {
        this.quantidadeTotalTransacao = quantidadeTotalTransacao;
    }

}
