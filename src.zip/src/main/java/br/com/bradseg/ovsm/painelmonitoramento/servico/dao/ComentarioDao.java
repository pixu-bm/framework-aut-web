package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Comentario;

/**
 * Interface para acesso base de dados para tabela de Comentarios
 *
 * @author Wipro
 */

public interface ComentarioDao {

    Boolean obterDadosPainelMonitoramento(Comentario comentario) throws SQLException;

    void inserirComentario(Comentario comentario) throws SQLException;

    void alterarComentario(Comentario comentario) throws SQLException;

    void excluirComentario(Comentario comentario) throws SQLException;

    List<Comentario> obterComentario(String codigoEmpresa, String codigoProduto, String codigoCanal,
      Date dataProcs, String codigoErroConexaoPainel) throws SQLException;

}
