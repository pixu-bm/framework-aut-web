package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.EventoPorCanal;

public class ListaEventoPorCanalRowMapper implements RowMapper<List<EventoPorCanal>> {

    @Override
    public List<EventoPorCanal> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<EventoPorCanal> listaEventoPorCanal = new ArrayList<>();
        do {
            EventoPorCanal eventoPorCanal = new EventoPorCanal();
            Canal canal = new Canal();
            canal.setCodigo(rs.getBigDecimal("CANAL"));
            canal.setDescricao(rs.getString("DESC_CANAL"));
            eventoPorCanal.setCanal(canal);
            eventoPorCanal.setQuantidadeEventoCanal(rs.getInt("SOMAS_EVENTOS"));
            listaEventoPorCanal.add(eventoPorCanal);
        } while (rs.next());

        return listaEventoPorCanal;
    }
}
