package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PerfilUsuario;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Listar perfil usuario response
 * @author Wipro
 *
 */
public class ListaPerfilUsuarioResponse extends ResponseMensagem {

    private List<PerfilUsuario> listaPerfilUsuario;

    public ListaPerfilUsuarioResponse() {
        super();
    }

    public List<PerfilUsuario> getListaPerfilUsuario() {
        return Collections.unmodifiableList(listaPerfilUsuario);
    }

    public void setListaPerfilUsuario(List<PerfilUsuario> listaPerfilUsuario) {
        this.listaPerfilUsuario = 
            Collections.unmodifiableList(listaPerfilUsuario);
    }

}
