package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.TipoEvento;

/**
 * Volumetria tempo real volumetria maxima mapa objetos extração de base de
 * dados.
 * 
 * @author Wipro
 */
public class TipoEventoRowMapper implements RowMapper<TipoEvento> {

    public TipoEvento mapRow(ResultSet rs, int rowNum) throws SQLException {

        TipoEvento tipoEvento 
        = new TipoEvento();
        tipoEvento.setQuantidadeTotalTipoEvento(rowNum);
        tipoEvento.setQuantidadeTotalTipoEvento(rs.getInt("SOMA_TOTAL"));
        tipoEvento.setQuantidadeTotalDisponibilidade(rs.getInt("SOMA_DISPONIBILIDADE"));
        tipoEvento.setQuantidadeTotalFuncionalidade(rs.getInt("SOMA_FUNCIONALIDADE"));
        tipoEvento.setQuantidadeTotalVolumetria(rs.getInt("SOMA_VOLUMETRIA"));

        return tipoEvento;
    }
}
