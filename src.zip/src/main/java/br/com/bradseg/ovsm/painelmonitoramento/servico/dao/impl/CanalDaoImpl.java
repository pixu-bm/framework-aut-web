package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.impl;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.CanalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.utils.Constantes;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Canal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ProdutoDaoImpl Classe implementador acesso a base de dados.
 *
 * @author Wipro
 */
@Repository
public class CanalDaoImpl implements CanalDao {

    private static final Logger LOGGER = LogManager.getLogger(CanalDaoImpl.class);

    private static final String SELECT_CANAL = "SELECT CCANAL_DGTAL_PNEL, ICANAL_DGTAL_PNEL FROM "
        + Constantes.OWNER_TABELA + "CANAL_DGTAL_PNEL CANAL";

    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public CanalDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public List<Canal> listarCanal() {

        try {
            List<Map<String, Object>> lista = jdbcTemplate.queryForList(SELECT_CANAL, new MapSqlParameterSource());

            if (lista.isEmpty()) {
                throw new EmptyResultDataAccessException("Resultado não pode ser vazio", 1);
            }

            List<Canal> listaCanal = new ArrayList<>();

            for (int i = 0; i < lista.size(); i++) {
                Map<String, Object> mapa = lista.get(i);
                Canal canal = new Canal();
                canal.setCodigo((BigDecimal) mapa.get("CCANAL_DGTAL_PNEL"));
                canal.setDescricao((String) mapa.get("ICANAL_DGTAL_PNEL"));

                listaCanal.add(canal);
            }

            return listaCanal;

        } catch (EmptyResultDataAccessException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(e);
            throw new AcessoADadosException(Constantes.PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

}
