package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.StatusDetalheEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

import java.util.Collections;
import java.util.List;

/**
 * Evento response.
 * 
 * @author Wipro
 */
public class StatusDetalheEventoResponse extends ResponseMensagem {

    private List<StatusDetalheEvento> listaStatusDetalheEvento;

    public StatusDetalheEventoResponse() {
        super();
    }

    public List<StatusDetalheEvento> getListaStatusDetalheEvento() {
        return Collections.unmodifiableList(listaStatusDetalheEvento);
    }

    public void setListaStatusDetalheEvento(List<StatusDetalheEvento> listaStatusDetalheEvento) {
        this.listaStatusDetalheEvento = 
            Collections.unmodifiableList(listaStatusDetalheEvento);
    }

}
