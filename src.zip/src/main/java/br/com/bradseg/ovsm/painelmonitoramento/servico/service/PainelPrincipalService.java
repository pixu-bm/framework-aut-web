package br.com.bradseg.ovsm.painelmonitoramento.servico.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;

/**
 * Classe responsável por acessar informações referentes ao painel de
 * monitoramento
 * 
 * @author Wipro
 */
public interface PainelPrincipalService {

    /**
     * Obter todas as informações referente ao painel de monitoramento
     * 
     * @return PainelMonitoramento
     * @throws SQLException
     */
    PainelMonitoramentoAtual obterPainelMonitoramento() throws SQLException;

    /**
     * Obter informações e visão de todos os eventos estatisticamente
     * 
     * @param periodoVisaoEvento Integer
     * @return VisaoEvento
     * @throws SQLException
     */
    VisaoEvento obterVisaoEvento(Integer periodoVisaoEvento) throws SQLException;

    /**
     * Obter volumetria tempo real
     * 
     * @param periodoVisaoEvento              Integer
     * @param produtoPainelMonitoramentoAtual ProdutoPainelMonitoramentoAtual
     * @return VolumetriaTempoReal
     * @throws SQLException
     */
    VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
        throws SQLException;

    /**
     * Obter volumetria tempo real por periodo de faixa de tempo
     * 
     * @param periodoVisaoEvento              Integer
     * @param ProdutoPainelMonitoramentoAtual ProdutoPainelMonitoramentoAtual
     * @return List<VolumetriaTempoReal>
     * @throws SQLException
     */
    List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
        throws SQLException;

    /**
     * Valida os parametros enviados para pesquisa de visão de evento.
     * 
     * @param periodoVisaoEvento Integer
     */
    void validarParametroEvento(Integer periodoVisaoEvento);

    /**
     * Obter volumetria tempo real de transacao e eventos para criação de tabela e
     * grid informativa nos paineis OV
     * 
     * @param periodoVisaoEvento Integer
     * @param listaCodigoProduto List<BigDecimal>
     * @param listaCodigoCanal   List<BigDecimal>
     * @return List<VolumetriaTempoRealEvento>
     * @throws SQLException
     */
    List<VolumetriaTempoRealTransacaoEvento> obterVolumetriaTempoRealTransacaoEvento(Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal, List<BigDecimal> listTipoEvento)
        throws SQLException;
}
