package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import java.math.BigDecimal;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Faq;

public interface FaqDao {

    List<Faq> listarPerguntasFaq();

    List<Faq> pesquisar(String pergunta);

    void editar(BigDecimal cod, String pergunta, String resposta, Float prioridade, String imagem, String login);

    void salvar(String pergunta, String resposta, Float prioridade, String imagem, String login);

    void excluir(BigDecimal codSeq, String codData);

}
