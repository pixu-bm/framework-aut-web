package br.com.bradseg.ovsm.painelmonitoramento.servico.dao.rowmapper;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaVisaoNegocio;

import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Wipro
 */
public class VolumetriaVisaoNegocioRowMapper
    implements RowMapper<List<VolumetriaVisaoNegocio>> {

    public List<VolumetriaVisaoNegocio> mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<VolumetriaVisaoNegocio> listaVolumetriaVisaoNegocio = new ArrayList<>();
        do {
            VolumetriaVisaoNegocio volumetriaVisaoNegocio = new VolumetriaVisaoNegocio();
            volumetriaVisaoNegocio.setCodigoCanal(new BigDecimal(rowNum));
            volumetriaVisaoNegocio.setCodigoCanal(rs.getBigDecimal("CCANAL_DGTAL_PNEL"));
            volumetriaVisaoNegocio.setDescricaoCanal(rs.getString("ICANAL_DGTAL_PNEL"));
            volumetriaVisaoNegocio.setVolumetria(rs.getBigDecimal("VOLUME_TRANSACAO"));
            volumetriaVisaoNegocio.setHistorico(rs.getBigDecimal("HISTORICO"));
            volumetriaVisaoNegocio.setVolumetriaMaxima(rs.getBigDecimal("VOLUMETRIA_MAXIMA"));
            volumetriaVisaoNegocio.setTotalDeEventos(rs.getBigDecimal("SOMA_TOTAL_EVENTO")); 
            volumetriaVisaoNegocio.setEventoDispo(rs.getBigDecimal("EVNTO_NORML_DISPN"));
            volumetriaVisaoNegocio.setEventoFunc(rs.getBigDecimal("EVNTO_NORML_FUNC"));
            volumetriaVisaoNegocio.setEventoVolu(rs.getBigDecimal("EVNTO_NORML_CNXAO"));
            volumetriaVisaoNegocio.setEventosGraves(rs.getBigDecimal("SOMA_EVENTO_GRAVE"));                     

            listaVolumetriaVisaoNegocio.add(volumetriaVisaoNegocio);
        } while (rs.next());

        return listaVolumetriaVisaoNegocio;
    }

}
