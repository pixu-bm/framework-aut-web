package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import java.util.Collections;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;

/**
 * Central Acesso response, classe implementa response dedicado a central de
 * acesso painel OV.
 * 
 * @author Wipro
 */
public class CentralAcessoResponse extends ResponseMensagem {

    private List<CentralAcessoUsuarioResponse> centralAcessoUsuarioResponse;

    public CentralAcessoResponse() {
        super();
    }

    public List<CentralAcessoUsuarioResponse> getCentralAcessoUsuarioResponse() {
        return Collections.unmodifiableList(centralAcessoUsuarioResponse);
    }

    public void setCentralAcessoUsuarioResponse(List<CentralAcessoUsuarioResponse> centralAcessoUsuarioResponse) {
        this.centralAcessoUsuarioResponse = 
            Collections.unmodifiableList(centralAcessoUsuarioResponse);
    }

}
