package br.com.bradseg.ovsm.painelmonitoramento.servico.service.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import br.com.bradseg.ovsm.painelmonitoramento.servico.dao.PainelPrincipalDao;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.PainelMonitoramentoAtual;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoReal;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealTransacaoEvento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VolumetriaTempoRealVolumetriaMaxima;
import br.com.bradseg.ovsm.painelmonitoramento.servico.exception.AcessoADadosException;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.PainelPrincipalService;

/**
 * Camada de serviço para obter informações de painel monitoramento
 * 
 * @author Wipro
 */
@Service
public class PainelPrincipalServiceImpl implements PainelPrincipalService {

    private static final Log LOGGER = LogFactory
        .getLog(PainelPrincipalServiceImpl.class);
    public static final String ERROR = "Error: ";
    public static final int INT = 0;
    public static final int INT1 = 4;
    public static final String PROBLEMA_DE_ACESSO_AOS_DADOS = "Ocorreu um erro inesperado";

    private PainelPrincipalDao painelMonitoramentoDao;

    @Autowired
    public PainelPrincipalServiceImpl(
        PainelPrincipalDao painelMonitoramentoDao) {
        this.painelMonitoramentoDao = painelMonitoramentoDao;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws SQLException
     */
    public PainelMonitoramentoAtual obterPainelMonitoramento()
        throws SQLException {
        try {
            return painelMonitoramentoDao.obterPainelMonitoramento();
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public VisaoEvento obterVisaoEvento(Integer periodoVisaoEvento)
        throws SQLException {
        try {
            validarParametroEvento(periodoVisaoEvento);
            return painelMonitoramentoDao.obterVisaoEvento(periodoVisaoEvento);
        } catch (IllegalArgumentException e) {
            LOGGER.error(ERROR, e);
            throw new IllegalArgumentException(e.getMessage());
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * Valida os parametros enviados para pesquisa de visão de evento.
     * 
     * @param periodoVisaoEvento Integer
     */
    public void validarParametroEvento(Integer periodoVisaoEvento) {
        Assert.notNull(periodoVisaoEvento,
            "Parametro periodoVisaoEvento não deve ser nulo.");
        Assert.isTrue(periodoVisaoEvento > INT,
            "Parametro periodoVisaoEvento não pode ser 0(Zero)");
        Assert.isTrue(periodoVisaoEvento < INT1,
            "Parametro periodoVisaoEvento diferente dos número validos");
    }

    /**
     * {@inheritDoc}
     */
    public VolumetriaTempoRealVolumetriaMaxima obterVolumetriaTempoRealVolumetriaMaxima(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento)
        throws SQLException {
        try {
            return painelMonitoramentoDao
                .obterVolumetriaTempoRealVolumetriaMaxima(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal, listTipoEvento);
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(PROBLEMA_DE_ACESSO_AOS_DADOS);
        }

    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoReal> obterVolumetriaTempoRealFaixaTempo(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento)
        throws SQLException {
        try {
            List<VolumetriaTempoReal> listaVolumetriaTempoReal = painelMonitoramentoDao
                .obterVolumetriaTempoRealFaixaTempo(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal,
                    listTipoEvento);

            if (listaVolumetriaTempoReal.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    "Nenhum dado de volumetria foi encontrado", 1);
            }

            return listaVolumetriaTempoReal;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<VolumetriaTempoRealTransacaoEvento> obterVolumetriaTempoRealTransacaoEvento(
        Integer periodoVisaoEvento,
        List<BigDecimal> listaCodigoProduto, List<BigDecimal> listaCodigoCanal,
        List<BigDecimal> listTipoEvento)
        throws SQLException {
        try {
            List<VolumetriaTempoRealTransacaoEvento> listaVolumetriaTempoRealTransacaoEvento = painelMonitoramentoDao
                .obterVolumetriaTempoRealTransacaoEvento(periodoVisaoEvento,
                    listaCodigoProduto, listaCodigoCanal,
                    listTipoEvento);

            if (listaVolumetriaTempoRealTransacaoEvento.isEmpty()) {
                throw new EmptyResultDataAccessException(
                    "Nenhum dado de volumetria foi encontrado", 1);
            }

            return listaVolumetriaTempoRealTransacaoEvento;
        } catch (AcessoADadosException e) {
            LOGGER.error(ERROR, e);
            throw new AcessoADadosException(e.getMessage());
        }
    }

}
