package br.com.bradseg.ovsm.painelmonitoramento.servico.dao;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.Produto;

import java.util.List;

/**
 * Produto Dao
 * 
 * @author Wipro
 */
public interface ProdutoDao {

    /**
     * Listar produto
     * 
     * @return List<Produto>
     */
    List<Produto> listarProduto();
}
