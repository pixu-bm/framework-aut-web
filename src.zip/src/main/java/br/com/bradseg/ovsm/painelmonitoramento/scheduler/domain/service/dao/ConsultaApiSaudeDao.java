package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

public interface ConsultaApiSaudeDao {
    
    String obterultimoregistroinseridoSaude();
    
    void liberarProcessamentoSaude(Collection<?> listaSaudeTemp);
    
    void validarDuplicadosSaude(Collection<?> listaSaudeTemp);
    
    void inserirConsultaApiSaude(List<TabelaTemp> listaSaudeTemp) throws SQLException;
}
