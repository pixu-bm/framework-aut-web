package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain;

public class TabelaTemp extends TabelaTempSuper {

    private Integer corrigeDado;
    private String cindRegProcs;
    private String cerroOrign;
    private String rmsgemErroOrign;
    private String renderUrlOrign;
    private String rservcOrign;
    private String itransOrign;
    private String rtransOrign;
    private String iapiOrign;
    private String icanalOrign;

    public TabelaTemp() {
        super();
    }

    public Integer getcorrigeDado() {
        return corrigeDado;
    }

    public void setcorrigeDado(Integer corrigeDado) {
        this.corrigeDado = corrigeDado;
    }

    public String getCindRegProcs() {
        return cindRegProcs;
    }

    public void setCindRegProcs(String cindRegProcs) {
        this.cindRegProcs = cindRegProcs;
    }

    public String getCerroOrign() {
        return cerroOrign;
    }

    public void setCerroOrign(String cerroOrign) {
        this.cerroOrign = cerroOrign;
    }

    public String getRmsgemErroOrign() {
        return rmsgemErroOrign;
    }

    public void setRmsgemErroOrign(String rmsgemErroOrign) {
        this.rmsgemErroOrign = rmsgemErroOrign;
    }

    public String getRenderUrlOrign() {
        return renderUrlOrign;
    }

    public void setRenderUrlOrign(String renderUrlOrign) {
        this.renderUrlOrign = renderUrlOrign;
    }

    public String getRservcOrign() {
        return rservcOrign;
    }

    public void setRservcOrign(String rservcOrign) {
        this.rservcOrign = rservcOrign;
    }

    public String getItransOrign() {
        return itransOrign;
    }

    public void setItransOrign(String itransOrign) {
        this.itransOrign = itransOrign;
    }

    public String getRtransOrign() {
        return rtransOrign;
    }

    public void setRtransOrign(String rtransOrign) {
        this.rtransOrign = rtransOrign;
    }

    public String getIapiOrign() {
        return iapiOrign;
    }

    public void setIapiOrign(String iapiOrign) {
        this.iapiOrign = iapiOrign;
    }

    public String getIcanalOrign() {
        return icanalOrign;
    }

    public void setIcanalOrign(String icanalOrign) {
        this.icanalOrign = icanalOrign;
    }
}
