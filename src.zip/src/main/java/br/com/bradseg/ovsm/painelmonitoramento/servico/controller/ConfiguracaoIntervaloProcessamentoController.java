/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package br.com.bradseg.ovsm.painelmonitoramento.servico.controller;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ConfiguracaoIntervaloProcessamento;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ConfiguracaoIntervaloProcessamentoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.reponse.ParametroEventoResponse;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ConfiguracaoIntervaloProcessamentoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.request.ParametroEventoRequest;
import br.com.bradseg.ovsm.painelmonitoramento.servico.service.ConfiguracaoIntervaloProcessamentoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.sql.SQLException;

/**
 * Classe rest
 *
 * @author Wipro
 */
@RestController
@RequestMapping("/service/configuracaoIntervaloProcessamento")
public class ConfiguracaoIntervaloProcessamentoController {

    public static final String ERRO = "erro: ";
    public static final String SUCESSO = "Sucesso.";
    public static final int CODIGO_RETORNO_0 = 0;
    public static final int CODIGO_RETORNO_3 = 3;
    public static final int CODIGO_RETORNO_2 = 2;
    public static final int CODIGO_RETORNO_99 = 99;
    private static final Logger LOGGER = LogManager
        .getLogger(ConfiguracaoIntervaloProcessamentoController.class);
    @Autowired
    private ConfiguracaoIntervaloProcessamentoService configuracaoIntervaloService;

    public ConfiguracaoIntervaloProcessamentoController() {
        super();
    }

    /**
     * Obtem lista com informações de configuração de intervalo de processamento
     * para cada empresa e produto cadastrado no painel OV.
     *
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterConfiguracaoIntervaloProcessamento")
    @Operation(
        summary = "Obtem informações de configuração de intervalo de processamento para cada "
            + "empresa, produto e canal cadastrado no painel OV. ")
    @ApiResponses(
        value = {@ApiResponse(responseCode = "200", description = SUCESSO),
            @ApiResponse(responseCode = "400",
                description = "Requisição com erro"),
            @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterConfiguracaoIntervaloProcessamento(
        @RequestParam(value = "codigoEmpresa",
            required = true) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto",
            required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal",
            required = true) BigDecimal codigoCanal) {
        try {

            ConfiguracaoIntervaloProcessamentoResponse configIntervaloProcessamentoResponse 
            = configuracaoIntervaloService.obterConfiguracaoIntervaloProcessamento
            (codigoEmpresa, codigoProduto, codigoCanal);

            configIntervaloProcessamentoResponse
                .setCodigoRetorno(CODIGO_RETORNO_0);
            configIntervaloProcessamentoResponse.setMensagem(SUCESSO);

            return ResponseEntity.ok(configIntervaloProcessamentoResponse);

        } catch (SQLException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setMensagem(e.getMessage());
            mensagem.setCodigoRetorno(CODIGO_RETORNO_2);
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagem.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        } catch (EmptyResultDataAccessException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagem.getMensagem() + ";" + CODIGO_RETORNO_3,
                e);
        }

    }

    /**
     * Inseri informações e parametros para configuração de intervalo de
     * processamento para que seja consumido pelo processamento e monitoramento de
     * APIs por empresa, canal e produto no monitoramento de paineis OV.
     *
     * @param configuracaoIntervaloProcessamentoRequest ConfiguracaoIntervaloProcessamentoRequest
     * @return ResponseEntity<ResponseMensagem>
     */
    @PostMapping("/inserirConfiguracaoIntervaloProcessamento")
    @Operation(
        summary = "Inseri informações e parametros para configuração de intervalo de processamento para que  "
            + "seja consumido pelo processamento e monitoramento de APIs por empresa,"
            + " canal e produto no monitoramento de paineis OV. ")
    @ApiResponses(
        value = {@ApiResponse(responseCode = "200", description = SUCESSO),
            @ApiResponse(responseCode = "400",
                description = "Requisição com erro"),
            @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> inserirConfiguracaoIntervaloProcessamento(
        @RequestBody ConfiguracaoIntervaloProcessamentoRequest configuracaoIntervaloProcessamentoRequest) {

        try {
            configuracaoIntervaloService
                .validarParametroConfiguracaoIntervaloProcessamento(
                    configuracaoIntervaloProcessamentoRequest);

            ConfiguracaoIntervaloProcessamento configuracaoIntervaloProcessamento 
            = new ConfiguracaoIntervaloProcessamento(
                configuracaoIntervaloProcessamentoRequest);

            configuracaoIntervaloService
                .inserirConfiguracaoIntervaloProcessamento(
                    configuracaoIntervaloProcessamento);

            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);

            return ResponseEntity.ok(mensagem);

        } catch (IllegalArgumentException e) {
            ResponseMensagem mensagem = new ResponseMensagem();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_3);
            mensagem.setMensagem(e.getMessage());
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagem.getMensagem() + ";" + CODIGO_RETORNO_3,
                e);

        } catch (SQLException e) {
            ResponseMensagem mensagemErroSQL = new ResponseMensagem();
            mensagemErroSQL.setMensagem(e.getMessage());
            mensagemErroSQL.setCodigoRetorno(CODIGO_RETORNO_2);
            LOGGER.error(e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroSQL.getMensagem() + ";" + CODIGO_RETORNO_2, e);

        }
    }

    /**
     * Obter parametro evento para parametrização
     *
     * @param codigoEmpresa BigDecimal
     * @param codigoProduto BigDecimal
     * @param codigoCanal   BigDecimal
     * @return ResponseEntity<ResponseMensagem>
     */
    @GetMapping("/obterParametroEvento")
    @Operation(summary = "Obter parametro evento ")
    @ApiResponses(
        value = {@ApiResponse(responseCode = "200", description = SUCESSO),
            @ApiResponse(responseCode = "400",
                description = "Requisição com erro"),
            @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> obterParametroEvento(
        @RequestParam(value = "codigoEmpresa",
            required = true) BigDecimal codigoEmpresa,
        @RequestParam(value = "codigoProduto",
            required = true) BigDecimal codigoProduto,
        @RequestParam(value = "codigoCanal",
            required = true) BigDecimal codigoCanal) {

        try {
            ParametroEventoResponse mensagem = new ParametroEventoResponse();
            mensagem.setCodigoRetorno(CODIGO_RETORNO_0);
            mensagem.setMensagem(SUCESSO);
            mensagem.setParametroEvento(
                configuracaoIntervaloService.obterParametroEvento(codigoEmpresa,
                    codigoProduto, codigoCanal));

            return ResponseEntity.ok(mensagem);

        } catch (EmptyResultDataAccessException except) {
            ResponseMensagem mensagemEmpty = new ResponseMensagem();
            mensagemEmpty.setMensagem(except.getMessage());
            mensagemEmpty.setCodigoRetorno(CODIGO_RETORNO_3);
            LOGGER.error(except);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemEmpty.getMensagem() + ";" + CODIGO_RETORNO_3, except);

        } catch (SQLException except) {
            ResponseMensagem mensagemErroExcept = new ResponseMensagem();
            mensagemErroExcept.setMensagem(except.getMessage());
            mensagemErroExcept.setCodigoRetorno(CODIGO_RETORNO_2);
            LOGGER.error(except);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroExcept.getMensagem() + ";" + CODIGO_RETORNO_2,
                except);

        }
    }

    /**
     * Atualizar parametro evento para parametrização
     *
     * @param parametroEventoRequest ParametroEventoRequest
     * @return ResponseEntity<ResponseMensagem>
     */
    @PostMapping("/atualizarParametroEvento")
    @Operation(
        summary = "Atualiza parametro evento para consumo do data power e schedule API. ")
    @ApiResponses(
        value = {@ApiResponse(responseCode = "200", description = SUCESSO),
            @ApiResponse(responseCode = "400",
                description = "Requisição com erro"),
            @ApiResponse(responseCode = "500", description = "Erro interno")})
    public ResponseEntity<ResponseMensagem> atualizarParametroEvento(
        @RequestBody ParametroEventoRequest parametroEventoRequest) {

        try {

            configuracaoIntervaloService
                .validarParametroEvento(parametroEventoRequest);
            configuracaoIntervaloService
                .atualizarParametroEvento(parametroEventoRequest);
            ResponseMensagem mensag = new ResponseMensagem();
            mensag.setCodigoRetorno(CODIGO_RETORNO_0);
            mensag.setMensagem(SUCESSO);
            return ResponseEntity.ok(mensag);

        } catch (IllegalArgumentException exceptIllegal) {
            ResponseMensagem mensagemIllegal = new ResponseMensagem();
            mensagemIllegal.setMensagem(exceptIllegal.getMessage());
            mensagemIllegal.setCodigoRetorno(CODIGO_RETORNO_3);
            LOGGER.error(exceptIllegal);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                mensagemIllegal.getMensagem() + ";" + CODIGO_RETORNO_3,
                exceptIllegal);

        } catch (DataIntegrityViolationException exceptViolation) {
            ResponseMensagem mensagemErroExViolation = new ResponseMensagem();
            mensagemErroExViolation.setMensagem(exceptViolation.getMessage());
            mensagemErroExViolation.setCodigoRetorno(CODIGO_RETORNO_2);
            LOGGER.error(exceptViolation);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroExViolation.getMensagem() + ";" + CODIGO_RETORNO_2,
                exceptViolation);

        } catch (SQLException exceptSql) {
            ResponseMensagem mensagemErroExSQL = new ResponseMensagem();
            mensagemErroExSQL.setMensagem(exceptSql.getMessage());
            mensagemErroExSQL.setCodigoRetorno(CODIGO_RETORNO_2);
            LOGGER.error(exceptSql);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                mensagemErroExSQL.getMensagem() + ";" + CODIGO_RETORNO_2,
                exceptSql);

        }
    }
}
