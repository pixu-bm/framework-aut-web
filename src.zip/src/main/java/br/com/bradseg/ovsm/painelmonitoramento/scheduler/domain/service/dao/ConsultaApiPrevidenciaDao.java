package br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.service.dao;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import br.com.bradseg.ovsm.painelmonitoramento.scheduler.domain.TabelaTemp;

public interface ConsultaApiPrevidenciaDao {
    
    String obterultimoregistroinserido();
    
    void liberarProcessamentoPrevidencia(Collection<?> listaPrevidenciaTemp);
    
    void validarDuplicadosPrevidencia(Collection<?> listaPrevidenciaTemp);
    
    void inserirConsultaApiPrevidencia(List<TabelaTemp> listaPrevidenciaTemp) throws SQLException;
}
