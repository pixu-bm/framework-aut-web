package br.com.bradseg.ovsm.painelmonitoramento.servico.reponse;

import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.ResponseMensagem;
import br.com.bradseg.ovsm.painelmonitoramento.servico.domain.VisaoGeralCanal;

/**
 * Visao geral canal response
 * 
 * @author Wipro
 */
public class VisaoGeralCanalResponse extends ResponseMensagem {

    private VisaoGeralCanal visaoGeralCanal;

    public VisaoGeralCanalResponse() {
        super();
    }

    public VisaoGeralCanal getVisaoGeralCanal() {
        return visaoGeralCanal;
    }

    public void setVisaoGeralCanal(VisaoGeralCanal visaoGeralCanal) {
        this.visaoGeralCanal = visaoGeralCanal;
    }

}
